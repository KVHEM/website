PROC_TIME = function(on_off,ptm){

  if(on_off == "start"){

    ptm = proc.time()

    return(ptm)

  }

  if(on_off == "stop"){

    ptm = proc.time() - ptm
    elapsed_time = as.double(ptm[3])

    print("ELAPSED TIME")

    elapsed_time = round(elapsed_time,0)

    if(elapsed_time <= 60){

      print(paste(elapsed_time, " s", sep = ""))  
    
    }

    if(elapsed_time > 60 & elapsed_time <= 3600 ){

      min_time = floor(elapsed_time/60)
      sec_time = elapsed_time - min_time*60
      print(paste(min_time, " min, ", sec_time, " s", sep = ""))    
    
    }

    if(elapsed_time > 3600 & elapsed_time <= 86400 ){

      hour_time = floor(elapsed_time/3600)
      min_time = floor((elapsed_time - hour_time*3600)/60)
      sec_time = elapsed_time - hour_time*3600 - min_time*60
      print(paste(hour_time, " h, ", min_time, " min, ", sec_time, " s", sep = ""))    
    
    }

    if(elapsed_time > 86400){

      day_time = floor(elapsed_time/86400)
      hour_time = floor((elapsed_time - day_time*86400)/3600)
      min_time = floor((elapsed_time - day_time*86400 - hour_time*3600)/60)
      sec_time = elapsed_time - day_time*86400 - hour_time*3600 - min_time*60
      print(paste(day_time, " days, ", hour_time, " h, ", min_time, " min, ", sec_time, " s", sep = ""))    
    
    }

  }

}