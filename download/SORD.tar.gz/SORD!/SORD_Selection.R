
# VYBER NEJLEPSIHO JEDINCE - ELITISMUS
# ELITE = function(fit_arr){
# 
#   winner = which.min(fit_arr[,2])
# 
#   winner
# 
# }

MATCH = function(id1, id2, fit1, fit2){

  if(fit1 < fit2){
    win_id = id1
  } else{
    win_id = id2
  }

  return(win_id)

}


# TURNAJOVA SELEKCE (vraci id viteze/vitezu)
TOURNAMENT = function(fit_arr, len_arr, n_winners){

  winners = c()

  for(i in 1:n_winners){
    
    # DVOJITY TURNAJ
    if(DoubleTour){
      #PRVNI SKUPINA UCASTNIKU PRVNIHO KOLA TURNAJE
      group1 = array(c(-1), dim = c(TouSize,2))
      group2 = array(c(-1), dim = c(TouSize,2))

      t_size = 2*TouSize
      
      if(n_winners == 2){

	# VYBER UZLU S NENULOVOU HLOUBKOU
	no0depth_prgs = which(len_arr[, 2] > 1)

	if(length(no0depth_prgs) >= TouSize){

	  group1[,1] = sample(no0depth_prgs,TouSize)
	  group2[,1] = sample(fit_arr[,1][which((fit_arr[,1] %in% group1[,1])==FALSE)], TouSize)

	} else{

	  all_competitors = sample(fit_arr[,1], t_size)
	  #VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, PRVNI SKUPINA
	  group1[,1] = sample(all_competitors,TouSize)
	  #VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, DRUHA SKUPINA = ZBYTEK Z all_competitors
	  group2[,1] = all_competitors[which((all_competitors %in% group1[,1])==FALSE)]

	}

      } else{

	all_competitors = sample(fit_arr[,1], t_size)
	
	#VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, PRVNI SKUPINA
	group1[,1] = sample(all_competitors,TouSize)
	
	#VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, DRUHA SKUPINA = ZBYTEK Z all_competitors
	group2[,1] = all_competitors[which((all_competitors %in% group1[,1])==FALSE)]

      }

      # DOPLNENI FITNESS
      group1[,2] = fit_arr[group1[,1],2]
      group2[,2] = fit_arr[group2[,1],2]

      # RADEK VITEZOU SKUPIN DLE FITNESS     
      winrow1 = which.min(group1[,2])
      winrow2 = which.min(group2[,2])

      # ID VITEZU 
      win1 = group1[winrow1,1]
      win2 = group2[winrow2,1]

      # FITNESS VITEZU 
      win1fit = group1[winrow1,2]
      win2fit = group2[winrow2,2]

      # DELKY VITEZU
      len_prg1 = len_arr[win1,2]
      len_prg2 = len_arr[win2,2]

      # ROZDIL FITNESS PRO KONTROLOVANY TURNAJ
      if(DoubleTControl){

	max_fit_win = max(win1fit,win2fit)

	if(max_fit_win > 0){
	  diff_fit = abs(win1fit - win2fit)/max(win1fit,win2fit) 
	} else {
	  diff_fit = 0
	}

	if(diff_fit > DoubleTCparam){

	  winner = MATCH(win1, win2, win1fit, win2fit)

	} else{

	  winner = MATCH(win1, win2, len_prg1, len_prg2)

	}

      } else{

	winner = MATCH(win1, win2, len_prg1, len_prg2)

	if(len_prg1 == len_prg2){

	  winner = MATCH(win1, win2, win1fit, win2fit)
  
	}

      }

      winners = c(winners,winner)

      fit_arr[winners[length(winners)],2] = NA 

    } else{

      # OBYCEJNY TURNAJ
      group = array(c(-1),dim = c(TouSize,2))

      group[,1] = sample(fit_arr[,1],TouSize)

      for(j in 1:TouSize){

	group[j,2] = fit_arr[group[j,1],2]

      }
  
      winners = c(winners,group[which.min(group[,2]),1]) 

      fit_arr[winners[length(winners)],2] = NA # zamezeni vyberu stejneho jedince pri vyberu rodicu pro krizeni, n_winners=2

    }

  }

  return(winners)

}
