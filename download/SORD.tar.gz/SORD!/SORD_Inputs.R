

INPUTS = function(){

  INPUT_CONTROL = function(data_T, data_V){

    if(ncol(data_T) != ncol(data_V) | ncol(data_T) != length(History)){

      stop("SPATNE NASTAVENI HISTORIE VSTUPU (nebo neodpovida pocet sloupcu v tren. a val. souborech)")

    }

    if(Prediction == 0 && History[length(History)] > 0){

      stop("SPATNE NASTAVENI PREDIKCE A HISTORIE MODELOVANE PROMENNE")

    }

    if(BalanceIsON && SAWisON){

      stop("AKTIVNI BALANCE I SAW")

    }

    if(Elitism == FALSE && SAWisON){

      stop("SAW FUNGUJE JEN PRI ZAPNUTEM ELITISMU")

    }

  }


  HEADER_CHECK = function(fname){

    readed_row = read.table(fname, nrow = 1, header = F)
    n_col = ncol(readed_row)

    vec1row = c()
    for (i in 1:n_col){

      vec1row = c(vec1row, as.vector(readed_row[1,i]))

    }
  
    vec1row[which(vec1row == TRUE)] = "T"
    vec1row[which(vec1row == FALSE)] = "F"



#     hcheck = any(is.character(vec1row))

#     if(hcheck == FALSE){
# 
#       vec1row = NA
#       stop("VSTUPNI DATA MUSI MIT HLAVICKU")
# 
#     }

#     return(list(hcheck = hcheck, names = vec1row))
    return(vec1row)

  }


  INPUT_SETS = function(data,set){

    if(is.character(set) == FALSE){

      data = data[set[1]:set[2],]

    }

    if(any(is.na(data))){

      stop("SPATNA VSTUPNI DATA PRO ZADANY ROZSAH SETU")

    }

    return(data)
 
  }


  MAKE_INPUT = function(input_arr, data, nr_inp_arr, shift_hist){

    #POCET NEZAVISLYCH PROMENNYCH 
    used_col = which(shift_hist > -1)

    first_col = 0
    last_col = 0

    for(i in used_col){

      first_col = last_col + 1
      last_col = first_col + shift_hist[i]

      k = max_shift + 1
      l = nrow(data) - Prediction

      for(j in last_col:first_col){

	input_arr[,j] = data[k:l,i]
	k = k - 1
	l = l - 1

      }

    }

    return(input_arr)

  }


  VARIABLE_DETERMINATION = function(shift_hist, head_names){

    #VEKTOR PORADI POUZIVANYCH PROMENNYCH (SLOUPCU VE VSTUPECH)
    used_col = which(shift_hist > -1)

    var_indx = c()

#     if(head_names[1] == "automaticaly defined"){
# 
#       for(i in used_col){
# 
# 	  char_vec = c("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","z")
# 	  var_indx = c(var_indx, paste(char_vec[i],c(shift_hist[i] : 0),sep=""))
# 
#       }
# 
#       ref_indx = paste("Yref+",Prediction,sep="")
# 
#     } else{

      for(i in used_col){

	  var_indx = c(var_indx, paste(head_names[i],c(shift_hist[i] : 0),sep=""))

      }

      ref_indx = paste(head_names[length(head_names)],"ref+",Prediction,sep="")

#     }  

    if(any(head_names == "y")){

      stop("NAZEV PROMENNE VE VSTUPNICH DATECH NESMI BYT 'y'")

    }

    return(list(var_indx = var_indx, ref_indx = ref_indx))

  }


  SAVE_INPUTS = function(inp, obs, nr_arr, nc_arr1, nc_arr2, fname, used_variables){

    nc_arr = nc_arr1+nc_arr2
    save_arr = array(dim=c(nr_arr,nc_arr)) 
    save_arr[,1:nc_arr1] = inp
    save_arr[,nc_arr] = obs

    write.table(save_arr,paste("Outputs/",fname, sep = ""), row.names = FALSE, col.names = used_variables, sep = "\t")

  }


  BALANCE = function(inp, obs, nr_in, headnam, headarr){

#     if(headnam != "automaticaly defined" && is.character(BalVar)){

      nc = length(BalVar)
      in_arr = array(0, dim = c(nr_in, nc))

      if(BalVar[1] == "Reference"){
	in_arr[,1] = obs
      } else if(BalVar[1] == "Step") {
	in_arr[,1] = c(1:nr_in)
      } else if(any(BalVar[1] == headarr[1:(length(headarr)-1)])){
	pos = which(headarr == BalVar[1])
	in_arr[,1] = inp[,pos]
      } else { 
	stop("Wrong definition of BalVar[1]") 
      }

      if(BalVar[2] == "Reference"){
	in_arr[,2] = obs
      } else if(BalVar[2] == "Step") {
	in_arr[,2] = c(1:nr_in)
      } else if(any(BalVar[2] == headarr[1:(length(headarr)-1)])){
	pos = which(headarr == BalVar[2])
	in_arr[,2] = inp[,pos]
      } else { 
	stop("Wrong definition of BalVar[2]") 
      }

    if(Balance != "Manual"){

      if(Balance == "Proxim"){regime = 1}
      if(Balance == "Surrou"){regime = 2}
      if(Balance == "Remote"){regime = 3}
      if(Balance == "Nonlin"){regime = 4}

      ProxW = rep(0,nr_in)
      SurrW = rep(0,nr_in)
      RemoteW = rep(0,nr_in)
      NonlinW = rep(0,nr_in)

      F90weigts = .Fortran("WEIGHTS", Inputs = as.double(in_arr),  N = as.integer(nr_in), Nc = as.integer(nc),
                         Kp = as.integer(Knear), Ks = as.integer(Knear), Kr = as.integer(Knear), Kn = as.integer(Knear), 
                         ProxW = as.double(ProxW),  SurrW = as.double(SurrW), RemoteW = as.double(RemoteW), 
                         NonlinW = as.double(NonlinW), Regime = as.integer(regime))

      if(Balance == "Proxim"){weights = F90weigts$ProxW}
      if(Balance == "Surrou"){weights = F90weigts$SurrW}
      if(Balance == "Remote"){weights = F90weigts$RemoteW}
      if(Balance == "Nonlin"){weights = F90weigts$NonlinW}

    }

    # RUCNI NASTAVENI VAH
    if(Balance == "Manual"){

      if(file.exists("Inputs/PredefinedWeights") == FALSE) {

	stop("Manual Balance error: File 'Inputs/PredefinedWeights' doesn't exist.")

      }

      weights = vector("numeric", length = nr_in)

      weights = scan("Inputs/PredefinedWeights")

    }
 
    pdf(file=paste("Outputs/Weights-",Balance,".pdf", sep = ""))
    plot(in_arr[,1],in_arr[,2], type = "p", lwd = 1 , cex = (weights^2*2))
    lines(in_arr[,1],in_arr[,2])
    dev.off()
#     stop("ZASTAVENO V Inputs - BALANCE")
    
    return(weights)

  }




  #SOUBORY SE VSTUP. DATY
  source_T = paste("Inputs/",InputFileTrain, sep="")
  source_V = paste("Inputs/",InputFileValid, sep="")  
  
  # URCENI YDA JSOU PRITOMNY HLAVICKY + DEFINOVANI JMEN PROMENNYCH
  header_T = HEADER_CHECK(source_T) 
  header_V = HEADER_CHECK(source_V) 

  if(any(header_T %in% header_V) == FALSE){stop("CHYBI HLAVICKY VSTUPNICH DAT nebo NEJSOU STEJNE V TRENOVACIM SOUBORU A VALIDACNIM SOUBORU")}

  head_names = header_T

#   if(is.na(head_names[1])) { head_names = header_V$names }
#   if(is.na(head_names[1])) { head_names = "automaticaly defined" }
 
  #NACTENI DAT
  data_T = read.table(source_T, header = TRUE) 
  data_V = read.table(source_V, header = TRUE)

#   data_T = read.table(source_T, header = header_T$hcheck) 
#   data_V = read.table(source_V, header = header_V$hcheck)

  #UPRAVA VSTUPNICH DAT NA DEFINOVANE SETY
  data_T = INPUT_SETS(data_T, TrainSet)
  data_V = INPUT_SETS(data_V, ValidSet)

  INPUT_CONTROL(data_T, data_V)

  #POCET RADKU VSTUPNICH DAT 
  nr_data_T = nrow(data_T)
  nr_data_V = nrow(data_V)

  #POCET SLOUPCU VE VSTUPECH (length(History) - 1 vyjadruje soucasnost)
  nc_inp = sum(History) + length(History) - 1

  #POCET SLOUPCU V REFERENCNICH DATECH
  nc_obs = 1

  #POCET RADKU VE VSTUPECH
  shift_hist = History
  shift_hist[length(shift_hist)] = shift_hist[length(shift_hist)] - 1 
  max_shift = max(shift_hist)

  nr_inpT = nr_data_T - max_shift - Prediction
  nr_inpV = nr_data_V - max_shift - Prediction

  #PROMENNE SE VSTUPNIMI (inp) A REFERENCNIMI (obs) DATY PRO TRENOVANI A VALIDACI 
  inpT = array(dim=c(nr_inpT, nc_inp))
  obsT = array(dim=c(nr_inpT, nc_obs))

  inpV = array(dim=c(nr_inpV, nc_inp))
  obsV = array(dim=c(nr_inpV, nc_obs))

  # NAPLNENI DATY - VSTUPNI PROMENNE
  inpT = MAKE_INPUT(inpT, data_T, nr_inpT, shift_hist)
  inpV= MAKE_INPUT(inpV, data_V, nr_inpV, shift_hist)

  # NAPLNENI DATY - REFERENCNI DATA
  first_val = max_shift + Prediction + 1
  obsT[,1] = data_T[first_val:nr_data_T,ncol(data_T)]
  obsV[,1] = data_V[first_val:nr_data_V,ncol(data_V)]

  used_variables = VARIABLE_DETERMINATION(shift_hist, head_names)
  variable_names = used_variables$var_indx
  reference_name = used_variables$ref_indx
  arr_head = c(variable_names, reference_name)
#   print(arr_head)




  #VAZENI DAT - VYTVORENI VEKTORU VAH PRO VAZENE FITNESS (PROCEDURY Balance, SAW, ...)
  Weights = rep(1,nr_inpT)

  if(BalanceIsON){

    if(FitType == "CC0"){stop("Data weighting is not for fitness CC0")}
    if(Knear > (nr_inpT-1)) {stop("Knear wrong value")}
    if(Knear <= 1 & Balance == "Nonlin") {stop("Knear wrong value for Nonlin weights computation")}

    Weights = BALANCE(inpT, obsT, nr_inpT, head_names, arr_head)
    write.table(Weights,"Outputs/Weights", row.names = FALSE, col.names = FALSE)


  }

#   stop("Zastaveno v INPUTS")

  # ULOZENI MATIC VSTUPU  
  SAVE_INPUTS(inpT, obsT, nr_inpT, nc_inp, nc_obs, "InpMatrixTrain", arr_head)
  SAVE_INPUTS(inpV, obsV, nr_inpV, nc_inp, nc_obs, "InpMatrixValid", arr_head)

  list(inpT = inpT, inpV = inpV, obsT = obsT, obsV = obsV, variable_names = variable_names, reference_name = reference_name, 
       nc_inp = nc_inp, nr_inpT = nr_inpT, nr_inpV = nr_inpV, Weights = Weights)

}



NORMALIZE = function(data_list, action){

  if(action == "Norm"){

    norm_facts_inp = vector(length=data_list$nc_inp)
    norm_fact_ref = max(data_list$obsT)

    for(i in 1:data_list$nc_inp){
      norm_facts_inp[i] = max(data_list$inpT[,i])
      data_list$inpT[,i] = data_list$inpT[,i] / norm_facts_inp[i]
      data_list$inpV[,i] = data_list$inpV[,i] / norm_facts_inp[i]
    }

    data_list$obsT = data_list$obsT / norm_fact_ref
    data_list$obsV = data_list$obsV / norm_fact_ref

  }

  if(action == "Renorm"){

    for(i in 1:data_list$nc_inp){
      data_list$inpT[,i] = data_list$inpT[,i] * data_list$norm_facts_inp[i]
      data_list$inpV[,i] = data_list$inpV[,i] * data_list$norm_facts_inp[i]
    }

    data_list$obsT = data_list$obsT * data_list$norm_fact_ref
    data_list$obsV = data_list$obsV * data_list$norm_fact_ref

  }

  return(list(inpT = data_list$inpT, inpV = data_list$inpV, obsT = data_list$obsT, obsV = data_list$obsV, 
              variable_names = data_list$variable_names, reference_name = data_list$reference_name, 
              nc_inp = data_list$nc_inp, nr_inpT = data_list$nr_inpT, nr_inpV = data_list$nr_inpV, 
              Weights = data_list$Weights, norm_facts_inp = norm_facts_inp, norm_fact_ref = norm_fact_ref))

}

