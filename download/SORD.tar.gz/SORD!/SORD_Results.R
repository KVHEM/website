BEST_FITxSIZE = function(fit_vec, size_vec){

  min_fit = min(fit_vec)

  min_fit_id = which(fit_vec == min_fit)

  if(length(min_fit_id) > 1){ # vice programu s min. fitness, lepsi pak urcen na zaklade delky programu

    lengths = size_vec[min_fit_id]

    min_fit_id = min_fit_id[which.min(lengths)]
    
  }
  
  return(list(min_fit = min_fit, min_fit_id = min_fit_id))

}


GEN_RESULTS = function(){

  fit_in_gen = vector("numeric",length = NiPop)
  depths_in_gen = vector("numeric",length = NiPop)
  len_in_gen = vector("numeric",length = NiPop)

  for (i in 1:NiPop){

    flow_prg = paste("prg",i,sep="")
    active_prg = get(flow_prg)

    fit_in_gen[i] = active_prg$fit
    len_in_gen[i] = active_prg$len
    depths_in_gen[i] = NODE_DEPTH(active_prg$arr, active_prg$len)

  }

#   min_fit = min(fit_in_gen)
# 
#   min_fit_id = which(fit_in_gen == min_fit)
# 
#   if(length(min_fit_id) > 1){ # vice programu s min. fitness, lepsi pak urcen na zaklade delky programu
# 
#     lengths = len_in_gen[min_fit_id]
# 
#     min_fit_id = min_fit_id[which.min(lengths)]
#     
#   }

  best_identify = BEST_FITxSIZE(fit_in_gen, len_in_gen)
  min_fit_id = best_identify$min_fit_id
  min_fit = best_identify$min_fit

  best_prg_depth = depths_in_gen[min_fit_id]

  mean_fit = mean(fit_in_gen)
  mean_depth = mean(depths_in_gen) 

  return(list(min_fit = min_fit, mean_fit = mean_fit, mean_depth = mean_depth, best_prg_depth = best_prg_depth, min_fit_id = min_fit_id))

}



RUN_RESULTS = function(run_results){

  actual_generation = GEN_RESULTS()

  min_fit = c(run_results$min_fit, actual_generation$min_fit)

  mean_fit = c(run_results$mean_fit, actual_generation$mean_fit)

  mean_depth = c(run_results$mean_depth, actual_generation$mean_depth)

  best_prg_depth = c(run_results$best_prg_depth, actual_generation$best_prg_depth) 

  i = length(min_fit)

  if(i == 1){
  
    best_prg_run = get(paste("prg",actual_generation$min_fit_id,sep=""))    

  }

  if(i > 1){

    if(min_fit[i] < min(min_fit[1:(i-1)]) | SAWisON){ # funguje i pro pripad ELITE = FALSE

      best_prg_run = get(paste("prg",actual_generation$min_fit_id,sep=""))

    } else{ 

      best_prg_run = run_results$best_prg_run

    }

  }

#   print("best_prg_run$fit")
#   print(best_prg_run$fit)

  return(list(min_fit = min_fit, mean_fit = mean_fit, mean_depth = mean_depth, best_prg_depth = best_prg_depth, best_prg_run = best_prg_run))

}



BEST_PRG = function(best_program){

#   print("best_program$fit")
#   print(best_program$fit)

  best_program = COMP_PRG(best_program, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, 1, fit_all = TRUE, final_comp = TRUE, validation = FALSE)

  print("************************************")

  print("BEST PROGRAM EXPRESSION")
  print(best_program$expr)
  print("FITNESS")
  print(best_program$fit)
  print("ALL FITNESS TRAINING")
  print(best_program$fit_arr)

  print("************************************")
  
  return(best_program)

}

VALIDATE = function(best_prg, action){


  if(SAWisON & action == "Training" | BalanceIsON & action == "Training"){

    val_prg = COMP_PRG(best_prg, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, 1, fit_all = TRUE, final_comp = TRUE, validation = TRUE)

    print("ALL FITNESS TRAINING - NO WEIGHTS")
    print(val_prg$fit_arr)
    print("************************************")
  
  }

  if(action == "Validation"){

    val_prg = COMP_PRG(best_prg, inputs$inpV, inputs$nr_inpV, inputs$nc_inp, inputs$obsV, inputs$variable_names, FitType, 1, fit_all = TRUE, final_comp = TRUE, validation = TRUE)

    print("ALL FITNESS VALIDATION")
    print(val_prg$fit_arr)
    print("************************************")
  
  }

  return(val_prg)

}


LIST2ASCII <- function(x,file=paste(deparse(substitute(x)),sep="")) {

  tmp.wid = getOption("width")  # save current width
  options(width=10000) # increase output width
  sink(file)  # redirect output to file
  print(x) # print the object
  sink()# cancel redirection
  options(width=tmp.wid)# restore linewidth
  return(invisible(NULL))# return (nothing) from function

} 


BEST_OF_THE_BEST = function(fit_runsT, fit_runsV, out_folder, depth_runs){

  best_identify = BEST_FITxSIZE(fit_runsT, depth_runs)
  which_bob = best_identify$min_fit_id
  bob_fitT = best_identify$min_fit

  bob_fitV = fit_runsV[which_bob]

  bob_f_name = paste("Outputs/run_",which_bob, sep="")

  expr = read.table(paste(bob_f_name,"/Expression_",which_bob,sep=""))

  crits = read.table(paste(bob_f_name,"/AllFitness_",which_bob,sep=""))

  if(SAWisON | BalanceIsON){

    crit_no_w = read.table(paste(bob_f_name,"/AllFitNoWeights_",which_bob,sep=""))

  } else{

    crit_no_w = "NA"

  }

  Tvalues = read.table(paste(bob_f_name,"/Training_",which_bob,sep=""),skip = 1)
  colnames(Tvalues) = c("Observed","Computed")

  Vvalues = read.table(paste(bob_f_name,"/Validation_",which_bob,sep=""),skip = 1)
  colnames(Vvalues) = c("Observed","Computed")

  bob_prg = list(Prg.num = which_bob, Expression = expr, Criterions = crits, Criterions_no_weights = crit_no_w, 
                 T_fit_original = bob_fitT, V_fit_original = bob_fitV, Training_values = Tvalues, Validation_values = Vvalues)

  # ULOZENI VYSLEDKU A VLASTNOSTI NEJLEPSIHO PROGRAMU
  to_save = paste(out_folder,"/Best_prg_overall",sep="")

  # PREVOD CRIT0 NA CRIT (NS0 > NS, PI0 > PI, CC0 > CC)

  for(i in 1:length(FitNamVec)){

    if(any(FitNamVec[i] == c("NS0", "PI0"))){

      bob_prg$Criterions[,i] = 1 - bob_prg$Criterions[,i]

      if(SAWisON | BalanceIsON){

	bob_prg$Criterions_no_weights[,i] = 1 - bob_prg$Criterions_no_weights[,i]

      }

    }

  }

  fit_vec_names = FitNamVec
  fit_vec_names[which(fit_vec_names == "NS0"):length(fit_vec_names)] = c("NS","PI")

  colnames(bob_prg$Criterions) = fit_vec_names

  if(SAWisON | BalanceIsON){

    colnames(bob_prg$Criterions_no_weights) = fit_vec_names

  }

  # BEST PROGRAM SUMMARY
  LIST2ASCII(bob_prg, file = to_save)

  # BEST PROGRAM VALUES
  write.table(Vvalues, paste(out_folder,"/Validation_data_bp",sep=""),row.names = FALSE)

  # KOPIROVANI NEJLEPSIHO PROGRAMU
  to_copy = paste("cp -r",bob_f_name, out_folder,sep = " ")
  system(to_copy)

  return(bob_prg)

}


FIND_SIMILAR = function(drive_vecs_arr, out_folder, expr_arr, fitsT, fitsV){

  #VYHODNOCENI POLE S RIDICIMI VEKTORY, HLEDANI PODOBNYCH PROGRAMU
  similarity = array(c(0), dim = c(Runs,2))
  similarity[,1] = c(1:Runs)

  for(i in 1:Runs){

    simil = which(drive_vecs_arr == drive_vecs_arr[i,1])
    similarity[c(i,simil),2] = length(simil)

  }

  sort_similar = similarity[sort.list(similarity[,2], decreasing = TRUE), ]

  to_save = paste(out_folder,"/TableSimilar",sep="")
  write.table(sort_similar, file = to_save, row.names = FALSE, col.names = c("Run", "N similar in runs"), sep="\t")

  if(max(sort_similar[,2]) > 1){

    print("2 or more similar programs in runs")
    most_sim_prg = sort_similar[which(sort_similar[,2] == max(sort_similar[,2])),1]

    msp_arr = array(c(NA),dim = c(length(most_sim_prg),3))

    msp_arr[,1] = expr_arr[most_sim_prg,1]

    msp_arr[,2] = fitsT$fit_val[most_sim_prg]

    msp_arr[,3] = fitsV$fit_val[most_sim_prg]

    to_save = paste(out_folder,"/SimilarPrgs",sep="")
    write.table(msp_arr, file = to_save, row.names = FALSE, 
                col.names = c("Equation", paste("Train. fit (",fitsT$fit_name,")", sep = ""), 
		paste("Valid. fit (",fitsV$fit_name,")", sep = "")), sep="\t")

  }

}

HISTOGRAMS = function(fitsT, fitsV, bp_runs_depth, out_folder){

  PLOT_HIST = function(plot_data, out_folder, out_file, color, main_title){

    to_save = paste(out_folder, out_file,sep="")
    LIST2ASCII(plot_data, file = to_save)
    to_save = paste(out_folder, out_file, ".pdf",sep="")
    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(plot_data,col=color,lwd = 3, main = main_title)
    dev.off()

  }

  if(BalanceIsON | SAWisON){

    titleT = paste("Histogram - weigted ",fitsT$fit_name,", training",sep = "")
    titleV = paste("Histogram - not weighted ",fitsV$fit_name,", validation", sep = "") 

  } else {

    titleT = paste("Histogram of fitness (",fitsT$fit_name,"), training",sep = "")
    titleV = paste("Histogram of fitness (",fitsV$fit_name,"), validation", sep = "")
  
  }

  Fit.train. = as.numeric(fitsT$fit_val)
  Fit.valid. = as.numeric(fitsV$fit_val)
  Depth = as.numeric(bp_runs_depth)

  hist_fit_runs_T = hist(Fit.train., plot = FALSE)
  hist_fit_runs_V = hist(Fit.valid., plot = FALSE)
  hist_bp_depth = hist(Depth, plot = FALSE)

  PLOT_HIST(hist_fit_runs_T, out_folder, "/HistFitT", "orange1", titleT)
  PLOT_HIST(hist_fit_runs_V, out_folder, "/HistFitV", "orange4", titleV)
  PLOT_HIST(hist_bp_depth, out_folder, "/Hist_bp_depth", "green", paste("Histogram of depths, best programs", sep = ""))

}


FIT_NORMALIZER = function(fitness){

  if(FitType == "NS0") {

    fit_val = 1 - fitness
    fit_name = "NS"

  }

#   if(FitType == "CC0") {
# 
#     fit_val = 1 - fitness
#     fit_name = "CC"
# 
#   }

  if(FitType == "PI0") {

    fit_val = 1 - fitness
    fit_name = "PI"

  }

  if(FitType == "MAE" | FitType == "RMSE" | FitType == "MSE"  ){

    fit_val = fitness
    fit_name = FitType

  }

  return(list(fit_val = fit_val, fit_name = fit_name))

}


ENSEMBLES = function(out_T_arr, out_V_arr, out_folder, obs_dataT, obs_dataV, bob_prg){

  ENS_PLOT_ALL = function(out_folder, out_file, main_title, out_arr, obs_data, bob_values, bob_fit, leg){

    to_save = paste(out_folder, out_file, ".pdf", sep="")

    
#     y_min = 0.9*min(min(obs_data),min(bob_values,na.rm = TRUE))
#     y_max = 1.25*max(max(obs_data),max(bob_values,na.rm = TRUE)) 

    ######### NIZE UDELAT JAKO FUNKCI!!!!!!!!!!!!!!!!!!

    y_min = min(min(obs_data,na.rm = TRUE),min(bob_values,na.rm = TRUE)) 
    y_max = max(max(obs_data,na.rm = TRUE),max(bob_values,na.rm = TRUE))
    y_min = y_min - abs(0.1 * y_min) 
    y_max = y_max + abs(0.25 * y_max)

    xaxis = c(1:nrow(out_arr))

    if(any(is.finite(out_arr[,1])==FALSE)){} else{

      pdf(file = to_save)

      par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

      plot(xaxis, out_arr[,1], type = "l", main = main_title, xlab = Xlabel, ylab = Ylabel,  
	  ylim = c(y_min, y_max),  lwd = 3, col = "grey")

      for(run in 1:Runs){

	if(any(is.finite(out_arr[,run])==FALSE)){} else{
	  lines(xaxis, out_arr[,run], lwd = 3, col = "grey")
	}

      }

      points(xaxis, obs_data, lwd = 3, col = "black")
  
      if(any(is.finite(bob_values)==FALSE)){} else{
	lines(xaxis, bob_values , lwd = 3, col = "red")
      }

      normalfit = FIT_NORMALIZER(bob_fit)

      legend(LegPlace, c("ensembles","observed",paste("best ens. (",normalfit$fit_name,leg,"=",round(normalfit$fit_val,3),")",sep="")), 
	      col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

      dev.off()

    }

  }

  
  ENS_PLOT_RANGES = function(out_folder, out_file, main_title, out_arr, obs_data, bob_values, bob_fit, to_plot, leg){

    numplot = length(to_plot)/2

    plot_arr = matrix(c(to_plot), nrow=numplot , ncol=2, byrow = TRUE)

    for(i in 1:numplot){

      to_save = paste(out_folder, out_file, "_in_", plot_arr[i,1], "-", plot_arr[i,2], ".pdf", sep="")

      xaxis = c(plot_arr[i,1]:plot_arr[i,2])
      yaxis = out_arr[xaxis,1]

#       y_min = 0.9*min(min(obs_data[xaxis]),min(bob_values[xaxis],na.rm = TRUE))
#       y_max = 1.25*max(max(obs_data[xaxis]),max(bob_values[xaxis],na.rm = TRUE)) 

      y_min = min(min(obs_data[xaxis],na.rm = TRUE),min(bob_values[xaxis],na.rm = TRUE)) 
      y_max = max(max(obs_data[xaxis],na.rm = TRUE),max(bob_values[xaxis],na.rm = TRUE))
      y_min = y_min - abs(0.1 * y_min) 
      y_max = y_max + abs(0.25 * y_max)

      if(any(is.finite(yaxis)==FALSE)){} else{

	pdf(file = to_save)

	par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

	plot(xaxis, yaxis, type = "l", main = main_title, xlab = Xlabel, ylab = Ylabel,  
	    ylim = c(y_min, y_max),  lwd = 3, col = "grey")



	for(run in 1:Runs){

	  yaxis = out_arr[xaxis,run]

	  if(any(is.finite(yaxis)==FALSE)){} else{
	    lines(xaxis, yaxis, lwd = 3, col = "grey")
	  }

	}

	yaxis = obs_data[xaxis]	

	if(any(is.finite(yaxis)==FALSE)){} else{

	  points(xaxis, yaxis, lwd = 3, col = "black")

	  yaxis = bob_values[xaxis]

	  lines(xaxis, yaxis, lwd = 3, col = "red")

	}

	normalfit = FIT_NORMALIZER(bob_fit)

	legend(LegPlace, c("ensembles","observed",paste("best ens. (",normalfit$fit_name,leg,"=",round(normalfit$fit_val,3),")",sep="")), 
		col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

	dev.off()

      }     
 
    }

  }

  if(BalanceIsON | SAWisON){

    legendAddT = "w"
    legendAddV = "not_w"  

  } else {

    legendAddT = ""
    legendAddV = ""   
  
  }

    
  if(is.character(ToPrintT)){

    ENS_PLOT_ALL(out_folder, "/Ensembles_T", "Training Ensembles", out_T_arr, obs_dataT, bob_prg$Training_values[,2], bob_prg$T_fit_original, legendAddT)
#     stop("ZASTAVENO V ENSEMBLES")

  } else{

    ENS_PLOT_RANGES(out_folder, "/Ensembles_T", "Training Ensembles" , out_T_arr, obs_dataT, bob_prg$Training_values[,2], bob_prg$T_fit_original, ToPrintT, legendAddT)
  
  }


  if(is.character(ToPrintV)){

    ENS_PLOT_ALL(out_folder, "/Ensembles_V", "Validation Ensembles" , out_V_arr, obs_dataV, bob_prg$Validation_values[,2], bob_prg$V_fit_original, legendAddV)

  } else{

    ENS_PLOT_RANGES(out_folder, "/Ensembles_V", "Validation Ensembles" , out_V_arr, obs_dataV, bob_prg$Validation_values[,2], bob_prg$V_fit_original, ToPrintV, legendAddV)
  
  }

}



ALL_RUNS_RESULT = function(obs_dataT, obs_dataV, actual_folder){

  # URCENI SLOUPCE FITNESS
  fit_col = which(FitNamVec == FitType)

  # PRIPRAVA VEKTORU PRO HLOUBKY A FITNESS
  fit_runsT = c()
  fit_runsV = c()
  bp_runs_depth = c() # bp - Best Program

  # POLE PRO RADY VYSLEDKU PRO ENSEMBLY
  out_T_arr = array(c(NA), dim = c(length(obs_dataT),Runs))
  out_V_arr = array(c(NA), dim = c(length(obs_dataV),Runs))

  # POLE PRO RIDICI VEKTORY PRO JEJICH POROVNANI
  drive_vecs_arr = array(c(""), dim = c(Runs,1))

  # POLE PRO VZORCE
  expr_arr = array(c(""), dim = c(Runs,1))

  # NACITANI DAT Z JEDNOTLIVYCH RUNU
  for(run in 1:Runs){

    source_folder = paste("Outputs/run_", run, sep="")
    
    to_read = paste(source_folder,"/AllFitness_", run,sep="")
    fitnesses = read.table(to_read)

    fit_runsT = c(fit_runsT, fitnesses[1,fit_col])
    fit_runsV = c(fit_runsV, fitnesses[2,fit_col])

    to_read = paste(source_folder,"/BestPrgDepth_", run,sep="")
    depths_in_gen = read.table(to_read, skip = 1)
   
    if(Elitism){

      bp_runs_depth = c(bp_runs_depth,depths_in_gen[nrow(depths_in_gen),2])

    } else{

      to_read = paste(source_folder,"/MinFit_", run, sep="")
      fits_in_gen = read.table(to_read, skip = 1)

      best_identify = BEST_FITxSIZE(fits_in_gen[,2], depths_in_gen[,2])
      min_fit_id = best_identify$min_fit_id
      min_fit = best_identify$min_fit

      bp_runs_depth = c(bp_runs_depth,depths_in_gen[min_fit_id,2])

    }

    to_read = paste(source_folder,"/DriveVector_", run, sep="")
    dv = as.character(as.vector(read.table(to_read)))
    drive_vecs_arr[run,1] = dv

    to_read = paste(source_folder,"/Expression_", run, sep="")
    expr = read.table(to_read)
    expr_arr[run,1] = as.character(expr[1,1])

    to_read_T = paste(source_folder,"/Training_", run, sep="") 
    out_T= read.table(to_read_T, skip = 1)

    to_read_V = paste(source_folder,"/Validation_", run, sep="")  
    out_V= read.table(to_read_V, skip = 1)

    out_T_arr[,run] = out_T[,2]
    out_V_arr[,run] = out_V[,2]

  }

  out_folder = paste("All_runs_summary/", actual_folder, sep="")

  # FITNESS TRENOVANI
  to_save = paste(out_folder,"/Fit_in_runsT",sep="")
  write.table(fit_runsT, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # FITNESS VALIDACE
  to_save = paste(out_folder,"/Fit_in_runsV",sep="")
  write.table(fit_runsV, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # HLOUBKY
  to_save = paste(out_folder,"/Bp_depth_in_runs",sep="")
  write.table(bp_runs_depth, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # BEST OF THE BEST PROGRAM
  bob_prg = BEST_OF_THE_BEST(fit_runsT, fit_runsV, out_folder, bp_runs_depth)

  # DALSI VYSLEDKY JEN PRO VICE RUNU NEZ 1
  if(Runs > 1){

    fits_normal_T = FIT_NORMALIZER(fit_runsT)
    fits_normal_V = FIT_NORMALIZER(fit_runsV)

    #PODOBNE PROGRAMY
    FIND_SIMILAR(drive_vecs_arr, out_folder, expr_arr, fits_normal_T, fits_normal_V)

    # HISTOGRAMY
    HISTOGRAMS(fits_normal_T, fits_normal_V, bp_runs_depth, out_folder)

    # ENSEMBLY
    ENSEMBLES(out_T_arr, out_V_arr, out_folder, obs_dataT, obs_dataV, bob_prg)


  }

  #ULOZENI NASTAVENI
  to_copy = paste("cp -r Outputs/SORD_Settings_copy.R", paste(out_folder,"/Used_Settings.R",sep = ""),sep = " ")
  system(to_copy)
  system("rm -rf Outputs/SORD_Settings_copy.R")


}



