#  Copyright 2011 Vojtěch Havlíček
# 
#  This file is part of SORD!.
#  SORD! is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#  SORD! is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
#  along with SORD!. If not, see <http://www.gnu.org/licenses/>.

# This is mains settings of SORD! program
# Start program with ./START command in terminal and in folder SORD!

## NAME OF TRAINING AND VALIDATION INPUT FILES (the last column of inp. file have to be the modelled variable)
InputFileTrain = "???"
InputFileValid = "???"

## TRAINING AND VALIDATION SETS FROM INPUT FILES [ "all" | c(from, to) ] (from IS START OF THE SET, to IS END, NO. OF ROW)
TrainSet = "all"
ValidSet = "all"

## PREDICTION STEP
Prediction = 0

## History of input variables [c(x1, x2, ..., xn, y)] (xn = -1 means unused variables, y = 0 means no available history of modelled variable)
History = c(0,0)


## Weighting technique ["Proxim", "Surrou", "Remote", "Nonlin", "Manual", FALSE] (Knear = parameter k for k-nearest neigh. method; BalVar - variables for balancing ["Reference" - modelled vaariable; "Step" - by step in record or "nameH", where H is history of variable named "name"])
Balance = FALSE
Knear = 2
BalVar = c("Step","Reference")

## SAW - Stepwise adaptative weighting ["Classic", "Precision", FALSE]
SAW = FALSE
SAWtime = 10


## NO. OF INDIVIDUALS
NiPop = 100

## NO. OF GENERATIONS
Ngen = 10

##  NO. OF INDEPENDENT PROGRAM RUNS
Runs = 2


## FITNESS METRIC ("MAE", "MSE", "RMSE", "NS0", "PI0") 
FitType = "MSE"


## MAX. TREE DEPTH - INITIAL GENERATION (ROOT = 0)
MaxDepthIni = 3

## MAX. TREE DEPTH
MaxDepthRun = 7

## DYNAMIC MAXIMUM TREE DEPTH (VERY HEAVY) [TRUE | FALSE]
DMTD = FALSE
QualityRatio = 5


## ELITISM [TRUE | FALSE]
Elitism = TRUE

## TOURNAMENT SIZE
TouSize = 4

## DOUBLE TOURNAMENT [TRUE | FALSE]
DoubleTour = FALSE

## CONTROLLED DOUBLE TOURNAMENT [TRUE | FALSE] (DoubleTCparam - ratio of difference in performance)
DoubleTControl = FALSE
DoubleTCparam = 0.5

## NO NEGATIVE NUMBERS IN RESULT [TRUE | FALSE] (ChngNegative - replacement of negatives [0 | "min"])
NoNegative = FALSE
ChngNegative = "min"


##### PRIMITIVES #####
##FUNCTIONS
# [ "+", "-", "*", "Pdiv", "Psqrt", "aq", "Plog", "Pexp", "PPow", "Plog10", "sigmoid",
# "sin","cos" ,"tan", "tanh", "max", "min", "hstep", "sign", sawt
# "SMA", "RES", "DLY", CSUM, "less", "greater" ]

Functions = list(typ = c(), prob = c(), arity = c())
Functions$typ = c("+", "-", "*", "Pdiv", "Psqrt", "Plog", "Pexp", "sin", "tan")

Functions$prob = c(0)

## TERMINALS
Terminals = list(typ = c(), prob = c(), range = c())
Terminals$typ = c("Constant","Variable")
Terminals$prob = c(0.5,0.5)
Terminals$range = c(-10,10)
RoundConst = 0 # [NA | integer]

## PROBABILITY OF GENETIC OPERATORS (Pr - replication, Pc - crossover, Pm - mutation (tree, constant, separation))
Pr = 0.05
Pc = 0.7
Pm_tree = 0.5
Pm_konst = 0.3
Pm_sep = 0.5

MutKonstSd = 1 # ST. DEV. FOR CONSTANT MUTATION

OffspringSelect = "better" # SELECTION OF CROSSOVER OFFSPRING ["better" | "random"]

## PLOT OPTIONS [ "screen" | "file" | "both" ]
PrintOutput = "file"

## RANGE OF PLOT  [ "all" | c(from, to) ]  (T - training, V - validation, relative to input sets)
ToPrintT = "all"
ToPrintV = "all"

## LABELS OF AXIS
Xlabel = "Time [day]"
Ylabel = "Q [mm/day]"

## CLEAN THE PREVIOUS RESULTS [TRUE | FALSE]
Clean = FALSE


## STOPING CRITERION (PERFORMANCE) 
StopCrit = 0.0001

############################################################################################
source("SORD_Main.R")
############################################################################################

rm(list=ls())
