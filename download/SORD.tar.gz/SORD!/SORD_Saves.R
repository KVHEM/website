
SAVE_VALUES = function(run_results, best_prg, val_prg, obs_dataT, obs_dataV, run, bp_no_w){

    SAVER = function(fold_name, file1, run, dim1, dim2, col1, col2, col_nam1, col_nam2){

      to_save = paste(fold_name,file1, run, sep="")
      data_to_write = array(c(-1),dim=c(dim1, dim2))
      data_to_write[,1] = col1
      data_to_write[,2] = col2 

      write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c(col_nam1, col_nam2), sep="\t")

    }

    # UMISTENI VYSLEDKU
    fold_name = paste("Outputs/run_", run, sep="")

    len_fd = length(run_results$min_fit)

    col1 = c(0:(len_fd-1))

    # HODNOTY PRUBEHU MIN. FITNESS
    SAVER(fold_name, "/MinFit_", run, len_fd, 2, col1, round(run_results$min_fit,6), "Generation", paste("Min.fit.(",FitType,")",sep=""))

    # HODNOTY PRUBEHU MEAN FITNESS
    SAVER(fold_name, "/MeanFit_", run, len_fd, 2, col1, round(run_results$mean_fit,6), "Generation", paste("Mean.fit.(",FitType,")",sep=""))

    # HODNOTY PRUBEHU HLOUBEK STROMU U NEJLEPSIHO PROGRAMU
    SAVER(fold_name, "/BestPrgDepth_", run, len_fd, 2, col1, run_results$best_prg_depth, "Generation", "BestPrgDepth")

    # HODNOTY PRUBEHU HLOUBEK STROMU
    SAVER(fold_name, "/MeanDepth_", run, len_fd, 2, col1, run_results$mean_depth, "Generation", "MeanDepth")

    # HODNOTY DAT TRENOVANI
    SAVER(fold_name, "/Training_", run, length(obs_dataT), 2, obs_dataT, round(best_prg$comp_val,6), "Observed", "Computed")

    # HODNOTY DAT VALIDACE
    SAVER(fold_name, "/Validation_", run, length(obs_dataV), 2, obs_dataV, round(val_prg$comp_val,6), "Observed", "Computed")

    # VYSLEDNA ROVNICE
    to_save = paste(fold_name,"/Expression_", run, sep="")
    data_to_write = best_prg$expr
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = FALSE)

    # DRIVE VECTOR
    to_save = paste(fold_name,"/DriveVector_", run, sep="")
    data_to_write = best_prg$drive_vec
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = FALSE)

    # HODNOTY KRITERII
    to_save = paste(fold_name,"/AllFitness_", run, sep="")
    data_to_write = array(c(-1),dim=c(2,ncol(best_prg$fit_arr)))
    data_to_write[1,] = as.numeric(best_prg$fit_arr[2,])
    data_to_write[2,] = as.numeric(val_prg$fit_arr[2,])
    write.table(data_to_write, file = to_save, row.names = c("Training","Validation"), col.names = FitNamVec, sep="\t")

    if(SAWisON | BalanceIsON){

      to_save = paste(fold_name,"/AllFitNoWeights_", run, sep="")
      data_to_write = array(c(-1),dim=c(2,ncol(bp_no_w$fit_arr)))
      data_to_write[1,] = as.numeric(bp_no_w$fit_arr[2,])
      data_to_write[2,] = as.numeric(val_prg$fit_arr[2,])
      write.table(data_to_write, file = to_save, row.names = c("Training","Validation"), col.names = FitNamVec, sep="\t")

    }

}

