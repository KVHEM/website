PLOT_RUN = function(x_axis, all_min_fit, all_best_prg_depth, regime){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  if(regime == "fits"){
    plot(x_axis, all_min_fit,  type = "s", col = "green", main = "Min. Fitness", 
	 xlab = "Generation", ylab = FitType, lwd = 3)
  }

  if(regime == "depths"){
    plot(x_axis, all_best_prg_depth, type = "s", col = "blue", main = "Best prog. depth", 
	xlab = "Generation", ylab = "Best prog. depth", lwd = 3)
  }

}


PLOT_DATA = function(fitness, x_data, obs_data, comp_data, min_value, max_value, title){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  main_text = paste(title,"\n", FitType, " = ",round(fitness,3),sep = "" )

  plot(x_data, obs_data, type = "p", main = main_text, xlab = Xlabel, ylab = Ylabel,  
       ylim = c(min_value, max_value),  lwd = 3)
  lines(x_data, comp_data, type = "l", col = "red", lwd = 3)
  legend(LegPlace, c("observed","computed"), col=c("black","red"), pch = c(1,-1), lty = c(-1,1), lwd=c(3,3), cex = 1.0)

}


INPUTS_TO_PLOT = function(range, observed, computed){

  x_data = c(range[1]:range[2])
  y_data = observed[range[1]:range[2]]
  comp_data = computed[range[1]:range[2]]

  return(list(x_data = x_data, y_data = y_data, comp_data = comp_data))

}


DATA2PLOT = function(obs_data, program, ranges){

#   y_min = 0.9*min(min(obs_data,program$comp_val,na.rm = TRUE),0)
#   y_max = 1.25*max(max(obs_data,program$comp_val,na.rm = TRUE),0)

  y_min = min(obs_data,program$comp_val,na.rm = TRUE)
  y_max = max(obs_data,program$comp_val,na.rm = TRUE)
  y_min = y_min - abs(0.1 * y_min) 
  y_max = y_max + abs(0.25 * y_max)

  # ROZSAH OS TRENOVANI
  if(is.character(ranges)){

    x_data = c(1:length(obs_data))
    y_data = obs_data
    comp_data = program$comp_val

  } else{

    to_plot = INPUTS_TO_PLOT(ranges[1:2], obs_data, program$comp_val)
    x_data = to_plot$x_data
    y_data = to_plot$y_data
    comp_data = to_plot$comp_data

  }

  return(list(x_data = x_data, y_data = y_data, comp_data = comp_data, y_min = y_min, y_max = y_max))

}



PLOT_GRAPHS = function(run_results, best_prg, val_prg, obs_dataT, obs_dataV, run){

  # OSA X PRO PRUBEH MIN. FIT A PRO MEAN DEPTH
  x_axis = c(0:(length(run_results$min_fit)-1))

  # ROZSAH OS TRENOVANI
  data_plot_T =  DATA2PLOT(obs_dataT, best_prg, ToPrintT)

  T_x_data = data_plot_T$x_data
  T_obs = data_plot_T$y_data
  T_comp = data_plot_T$comp_data
  T_min = data_plot_T$y_min
  T_max = data_plot_T$y_max

  # ROZSAH OS VALIDACE
  data_plot_V =  DATA2PLOT(obs_dataV, val_prg, ToPrintV)

  V_x_data = data_plot_V$x_data
  V_obs = data_plot_V$y_data
  V_comp = data_plot_V$comp_data
  V_min = data_plot_V$y_min
  V_max = data_plot_V$y_max

  if(BalanceIsON | SAWisON){

    titleT = "Training, weighted"
    titleV = "Validation, not weighted"    

  } else {

    titleT = "Training"
    titleV = "Validation"  
  
  }

  if(PrintOutput == "both" | PrintOutput == "screen"){

    # PRIPRAVENI OBLASTI PRO PLOT
    par(mfrow = c(2,2), cex.main = 1.5, cex.axis= 1.5, cex.lab = 1.5)

    # PLOT PRUBEHU VYPOCTU
    PLOT_RUN(x_axis, run_results$min_fit, run_results$best_prg_depth, "fits")
    PLOT_RUN(x_axis, run_results$min_fit, run_results$best_prg_depth, "depths")

    # PLOT DAT TRENOVANI
    PLOT_DATA(best_prg$fit, T_x_data, T_obs, T_comp, T_min, T_max, titleT)

    # PLOT DAT VALIDACE
    if(any(is.finite(V_comp)==FALSE)){} else{
      PLOT_DATA(val_prg$fit, V_x_data, V_obs, V_comp, V_min, V_max, titleV)
    }

  }

  if(PrintOutput == "both" | PrintOutput == "file"){

    # UMISTENI VYSLEDKU
    fold_name = paste("Outputs/run_", run, sep="")

    # PLOT PRUBEHU MIN. FITNESS
    to_save = paste(fold_name,"/MinFit_", run, ".pdf",sep="")
    # postscript(file=paste(name1,"_x_",name2,".ps",sep=""))
    pdf(file=to_save)
    PLOT_RUN(x_axis, run_results$min_fit, run_results$best_prg_depth, "fits")
    dev.off()

    # PLOT PRUBEHU HLOUBEK STROMU NEJLEPSIHO PROGRAMU
    to_save = paste(fold_name,"/BestPrgDepth_", run, ".pdf",sep="")
    pdf(file=to_save)
    PLOT_RUN(x_axis, run_results$min_fit, run_results$best_prg_depth, "depths")
    dev.off()

    # PLOT DAT

    if(is.character(ToPrintT)){

      # PLOT DAT TRENOVANI
      to_save = paste(fold_name,"/Training_", run, ".pdf",sep="")

      pdf(file=to_save)
      PLOT_DATA(best_prg$fit, T_x_data, T_obs, T_comp, T_min, T_max, titleT)
      dev.off()
      
    } else{

      num_plot_T = length(ToPrintT)/2

      to_plot_arr_T = matrix(c(ToPrintT), nrow=num_plot_T , ncol=2, byrow = TRUE)

      for(i in 1:num_plot_T){

	data_plot_T =  DATA2PLOT(obs_dataT, best_prg, to_plot_arr_T[i,1:2])

	T_x_data = data_plot_T$x_data
	T_obs = data_plot_T$y_data
	T_comp = data_plot_T$comp_data

	# PLOT DAT TRENOVANI
	to_save = paste(fold_name,"/Training_", run,"_data_",to_plot_arr_T[i,1],"-",to_plot_arr_T[i,2],".pdf",sep="")

	pdf(file=to_save)
	PLOT_DATA(best_prg$fit, T_x_data, T_obs, T_comp, T_min, T_max, titleT)
	dev.off()

      }

    }


    if(is.character(ToPrintV)){
      
      # PLOT DAT VALIDACE
      to_save = paste(fold_name,"/Validation_", run, ".pdf",sep="")

      if(any(is.finite(V_comp)==FALSE)){} else{
	pdf(file=to_save)
	PLOT_DATA(val_prg$fit, V_x_data, V_obs, V_comp, V_min, V_max, titleV)
	dev.off()
      }

    } else{

      num_plot_V = length(ToPrintV)/2

      to_plot_arr_V = matrix(c(ToPrintV), nrow=num_plot_V , ncol=2, byrow = TRUE)

      for(i in 1:num_plot_V){

	data_plot_V =  DATA2PLOT(obs_dataV, val_prg, to_plot_arr_V[i,1:2])

	V_x_data = data_plot_V$x_data
	V_obs = data_plot_V$y_data
	V_comp = data_plot_V$comp_data

	# PLOT DAT VALIDACE
	to_save = paste(fold_name,"/Validation_", run,"_data_",to_plot_arr_V[i,1],"-",to_plot_arr_V[i,2],".pdf",sep="")

	if(any(is.finite(V_comp)==FALSE)){} else{
	  pdf(file=to_save)
	  PLOT_DATA(val_prg$fit, V_x_data, V_obs, V_comp, V_min, V_max, titleV)
	  dev.off()
	}

      }

    }
  
  }

}
