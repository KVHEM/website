# URCENI HLOUBKY UZLU PRO MUTACE AJ.
NODE_DEPTH = function(prg_arr, node){

  mn_lvl = 0

  if(node > 1){

    max_n_lvl = max(as.numeric(prg_arr[1,2:ncol(prg_arr)]), na.rm = TRUE)

    mn_lvl = mn_lvl + 1

    for(i in 1:node){

      if(i > max_n_lvl){
	
	last_max = max(as.numeric(prg_arr[1:(i-1),2:ncol(prg_arr)]), na.rm=TRUE)
	
	if(max_n_lvl != last_max){

	  mn_lvl = mn_lvl + 1
	  max_n_lvl = last_max

	}

      }

    }

  }

  return(mn_lvl)

}


CHNG_COORD = function(chng_arr, arr_drive_vec, last_val, fromrow, torow){

  k = 1

  for (i in fromrow:torow){
    
    if(any(arr_drive_vec[i] == Functions$typ, na.rm = TRUE)){
 
      for(j in 2:ncol(chng_arr)){

	if(is.na(chng_arr[i,j]) == FALSE){

	  chng_arr[i,j] = last_val + k
	  k = k + 1

	}

      }

    }

  }

  return(chng_arr)

}


CHNG_PRG = function(program, new_arr, new_dvec, new_len){

  program$arr = new_arr
  program$drive_vec = new_dvec
  program$len = new_len
  program$fit = NA
  program$expr = NA 
  program$comp_val = NA 

  return(program)

}


TERM2TERM = function(program, mt_prg, mut_node){

  program$arr[mut_node,] = mt_prg$arr[1,]
  program$drive_vec[mut_node] = mt_prg$drive_vec[1]
  program$fit = NA
  program$expr = NA 
  program$comp_val = NA 

  return(program)

}


TERM2FCN = function(program, mt_prg, mut_node){

  nc_prg = ncol(program$arr)

  # URCENI UZLU K VYMAZANI NA ZAKLADE UKAZATELU VYMAZAVANEHO UZLU
  out_row = c()
  for(i in 2:nc_prg){

    if(is.na(program$arr[mut_node,i]) == FALSE){

      out_row = c(out_row,as.numeric(program$arr[mut_node,i]))

    }

  }

  # MAZANI UZLU NA ZAKLDE UKAZATELU VYSSICH NAHRAZOVANYCH UZLU
  while(is.null(out_row) == FALSE){

    out = out_row
    out_row = c()

    for(i in out){
	
      if(any(program$drive_vec[i] == Functions$typ, na.rm = TRUE)){

	for(j in 2:nc_prg){

	  if(is.na(program$arr[i,j]) == FALSE){

	    out_row = c(out_row,as.numeric(program$arr[i,j]))

	  }

	}

      }

      program$drive_vec[i] = NA
      program$arr[i,1:nc_prg] = rep(NA,nc_prg)

    }

  }

  program$drive_vec[mut_node] = mt_prg$drive_vec[1]
  program$arr[mut_node,] = mt_prg$arr[1,]
  
  # UPRAVA UKAZATELU mozna udelat az po scuknuti celeho programu???
  if(any(program$drive_vec[mut_node:program$len] %in% Functions$typ, na.rm = TRUE) == TRUE){

    coord = which(program$drive_vec[mut_node:program$len] %in% Functions$typ) + mut_node - 1

    for (i in coord){

      k = 1
      last_max = max(as.numeric(program$arr[1:(i-1),2:nc_prg]),na.rm = TRUE)

      for(j in 2:nc_prg){

	if(is.na(program$arr[i,j]) == FALSE){

	  program$arr[i,j] = last_max + k
	  k = k + 1

	}

      }

    }

  }

  # ZMENA ATRIBUTU JEDINCE
  new_len = program$len - length(which(is.na(program$drive_vec)))
  new_arr = array(c(NA), dim = c(new_len,nc_prg))
  new_dvec = rep(NA,new_len)

  j = 1
  for (i in 1:program$len){

    if(is.na(program$drive_vec[i]) == FALSE){

      new_arr[j,] = program$arr[i,]
      new_dvec[j] = program$drive_vec[i]
      j = j + 1

    }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)

  return(program)

}


FCN2TERM = function(program, mt_prg, mut_node){

  nc_prg = ncol(program$arr)

  # DELKA NOVEHO JEDINCE
  new_len = program$len + mt_prg$len - 1

  # POLE A RIDICI VEKTOR NOVEHO JEDINCE
  new_arr = array(c(NA),dim = c(new_len, nc_prg))
  new_dvec = rep(NA,new_len)

  # DOPLNOVANI NOVEHO POLE A RIDICIHO VEKTORU
  new_arr[1:program$len,] = program$arr
  new_dvec[1:program$len] = program$drive_vec

  # POMOCNY MUT. STROM
  mt_prg_help = mt_prg

  # 1. ZMENA UKAZATELU V MUTACNIM STROMU
  last_max = max(as.numeric(new_arr[1:(mut_node-1),2:nc_prg]),na.rm = TRUE)
  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, last_max, 1, mt_prg$len)

  # DOPLNENI UZLU MUTACE KORENEM MUT.STROMU
  new_arr[mut_node,] = mt_prg$arr[1,]
  new_dvec[mut_node] = mt_prg$drive_vec[1]

  # POSLEDNI HODNOTA UKAZATELE
  last_max = max(as.numeric(new_arr[1:mut_node,2:nc_prg]),na.rm = TRUE)

  # ZMENA UKAZATELU V DUSLEDKU VLOZENI NOVE FCE
  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, (mut_node+1), new_len)

  flow_len = program$len

  for(i in 1:mt_prg$len){

    j = 2
#     while(j <= nc_prg && mt_prg_help$arr[i,j] > -1){
    while(j <= nc_prg && is.na(mt_prg_help$arr[i,j]) == FALSE){

      act_pos = as.numeric(mt_prg$arr[i,j])
      act_pos_help = as.numeric(mt_prg_help$arr[i,j])

      if(is.na(new_dvec[act_pos])){

	new_arr[act_pos,] = mt_prg$arr[act_pos_help,]
	new_dvec[act_pos] = mt_prg$drive_vec[act_pos_help]

	if(any(mt_prg$drive_vec[act_pos_help:mt_prg$len] %in% Functions$typ, na.rm = TRUE) == TRUE){

	  last_max = max(as.numeric(new_arr[1:(act_pos-1),2:nc_prg]),na.rm = TRUE)
	  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, act_pos, new_len)
	  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, last_max, act_pos_help, mt_prg$len)

	}

      } else{
	
	new_arr[(act_pos+1):(flow_len+1),] = new_arr[act_pos:flow_len,]
	new_dvec[(act_pos+1):(flow_len+1)] = new_dvec[act_pos:flow_len]

	new_arr[act_pos,] = mt_prg$arr[act_pos_help,]
	new_dvec[act_pos] = mt_prg$drive_vec[act_pos_help]   

	if(any(mt_prg$drive_vec[act_pos_help:mt_prg$len] %in% Functions$typ, na.rm = TRUE) == TRUE){

	  last_max = max(as.numeric(new_arr[1:(act_pos-1),2:nc_prg]), na.rm = TRUE)
	  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, act_pos, new_len)
	  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, last_max, act_pos_help, mt_prg$len)

	}

	flow_len = flow_len + 1 # jenom zde, pri tomto postupu mezery v programu nejsou, takze neni nutne aby toto bylo v predchozim if

      }

      j = j + 1

    }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)

  return(program)
}


TREE_VARIATION = function(program_1, program_2, mut_node){
  # program_1 JE PUVODNI STROM, program_2 JE VKLADANY STROM

  if(mut_node == 1){ # DALE POUZITE FUNKCE NEJSOU NA MOZNOST mut_node == 1 PRIPRAVENE.

    program_1 = program_2
    
  } else{

    node1 = program_1$drive_vec[mut_node]
    node2 = program_2$drive_vec[1]

    # PRIPAD 1: KOREN PROGRAMU 2 JE TERMINAL A NAHRAZUJE V PROGRAMU 1 TERMINAL 
    if(any(node1 == Functions$typ) == FALSE && any(node2 == Functions$typ) == FALSE){

      program_1 = TERM2TERM(program_1, program_2, mut_node)

    }

    # PRIPAD 2: KOREN PROGRAMU 2 JE TERMINAL A NAHRAZUJE V PROGRAMU 1  FUNKCI
    if(any(node1 == Functions$typ) && any(node2 == Functions$typ) == FALSE){

      program_1 = TERM2FCN(program_1, program_2, mut_node)

    }

    # PRIPAD 3: KOREN PROGRAMU 2 JE FUNKCE A NAHRAZUJE V PROGRAMU 1  TERMINAL
    if(any(node1 == Functions$typ) == FALSE && any(node2 == Functions$typ)){

      program_1 = FCN2TERM(program_1, program_2, mut_node)

    }

    # PRIPAD 4: KOREN PROGRAMU 2 JE FUNKCE A NAHRAZUJE V PROGRAMU 1  FUNKCI
    if(any(node1 == Functions$typ) && any(node2 == Functions$typ)){

      term2subst = CREATE_INDIVIDUAL(0, method = "grow")

      program_1 = TERM2FCN(program_1, term2subst, mut_node)

      program_1 = FCN2TERM(program_1, program_2, mut_node)

    }
  
  }

  return(program_1)

}


SEPARATE_PRG = function(program, mut_node){

  help_prg = program

  nc_prg = ncol(program$arr)

  new_separe = c()

  if(any(program$drive_vec[mut_node] == Functions$typ)) {

    for(i in 2:nc_prg){

      if(is.na(help_prg$arr[mut_node,i]) == FALSE){

	new_separe  = c(new_separe, as.numeric(help_prg$arr[mut_node,i]))

      }

    }

  } else{

    new_len = 1

    new_dvec = c(NA)
    new_arr = array(c(NA), dim = c(new_len, nc_prg))
    new_dvec = program$drive_vec[mut_node]
    new_arr[1,] = program$arr[mut_node,]

    program = CHNG_PRG(program, new_arr, new_dvec, new_len)

    program$change = 1

    return(program)
    
  }

  # SEPARACE UZLU NA ZAKLDE UKAZATELU VYSSICH NAHRAZOVANYCH UZLU
  separed_rows = c() 
  while(is.null(new_separe) == FALSE){

    separed_rows = c(separed_rows, new_separe)
    old_separe = new_separe
    new_separe = c()

    for(i in old_separe){
	
      if(any(help_prg$drive_vec[i] == Functions$typ)){

	for(j in 2:nc_prg){

	  if(is.na(help_prg$arr[i,j]) == FALSE){

	    new_separe = c(new_separe,as.numeric(help_prg$arr[i,j]))

	  }

	}

      }

      help_prg$drive_vec[i] = NA
      help_prg$arr[i,1:nc_prg] = rep(NA,nc_prg)

    }

  }

  separed_rows = c(mut_node, separed_rows)

  # POLE A RIDICI VEKTOR NOVEHO JEDINCE
  new_len = length(separed_rows)
  new_dvec = rep(NA,new_len)
  new_arr = array(c(NA),dim = c(new_len, nc_prg))

  k = 2
  for(i in 1:new_len){

    new_dvec[i] = program$drive_vec[separed_rows[i]]
    new_arr[i,] = program$arr[separed_rows[i],]

      for(j in 2:nc_prg){

	if(is.na(new_arr[i,j]) == FALSE){

	  new_arr[i,j] = k
	  k = k + 1

	}

      }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)
  
  return(program)

}


COMP_CROSSBREDS = function(cross_prg1, cross_prg2){

  if(cross_prg1$change == 1){

    c1 = COMP_PRG(cross_prg1, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, 1)

  } else {

    c1 = cross_prg1

  }

  if(cross_prg2$change == 1){

    c2 = COMP_PRG(cross_prg2, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, 1) 

  } else {

    c2 = cross_prg2

  }

  return(list(c1 = c1, c2 = c2))

}


PARENTS_BETTER = function(parent_1, parent_2, winners){

  if(parent_1$fit < parent_2$fit){

    winner = winners[1]

    name_old = paste("prg_old_save",winner,sep="")
    name_new = paste("prg",winner,sep="")

    out = parent_1

  } else{

    winner = winners[2]

    name_old = paste("prg_old_save",winner,sep="")
    name_new = paste("prg",winner,sep="")

    out = parent_2

  } 

  return(list(name_old = name_old, name_new = name_new, out = out, win = winner))

}


OFFSPRING_BETTER = function(parent_1, parent_2, off1, off2, winners, dyn_depth_lim){

  DMTD_off = function(better_off, parent_1, parent_2, dyn_depth_lim){

    tree_depth = NODE_DEPTH(better_off$arr, better_off$len)

    if(tree_depth >= dyn_depth_lim[2]){
#     if(tree_depth > dyn_depth_lim[2]){

      if((better_off$fit * QualityRatio) < dyn_depth_lim[1]){

	outoff = better_off

	newlim = c(better_off$fit, tree_depth, better_off$len)

	variate = FALSE

      } else {

	better_par = PARENTS_BETTER(parent_1, parent_2, winners)

# 	outoff = better_par$out

	if(better_par$out$len > 1){

	  outoff = MUT_SEPAR(better_par$out)

	}else{

	  outoff = better_par$out

	}

	newlim = dyn_depth_lim

	variate = TRUE

      }

    } else {

      outoff = better_off

      newlim = dyn_depth_lim

      variate = TRUE

    }

  return(list(newlim = newlim, outoff = outoff, variate = variate))

  }

  variate = TRUE

  if(off1$fit < off2$fit){

    if(DMTD){

      DMTD_res = DMTD_off(off1, parent_1, parent_2, dyn_depth_lim)
      dyn_depth_lim = DMTD_res$newlim
      off1 = DMTD_res$outoff
      variate = DMTD_res$variate

    }

    winner = winners[1]

    name_old = paste("prg_old_save",winner,sep="")
    name_new = paste("prg",winner,sep="")

    out = off1
    out_par = parent_1

  } else{

    if(DMTD){

      DMTD_res = DMTD_off(off2, parent_1, parent_2, dyn_depth_lim)
      dyn_depth_lim = DMTD_res$newlim
      off2 = DMTD_res$outoff
      variate = DMTD_res$variate

    }

    winner = winners[2]

    name_old = paste("prg_old_save",winner,sep="")
    name_new = paste("prg",winner,sep="")

    out = off2
    out_par = parent_2

  } 

  out$change = 1
# 
#   print(out)

#   stop("ZDE")

  return(list(name_old = name_old, name_new = name_new, out = out, out_par = out_par, win = winner, variate = variate))
 
}

