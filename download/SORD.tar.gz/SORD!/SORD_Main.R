#  Copyright 2011 Vojtěch Havlíček
# 
#  This file is part of SORD!.
#  SORD! is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#  SORD! is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License
#  along with SORD!. If not, see <http://www.gnu.org/licenses/>.


# PATH (provazano se souborem START)
path = scan('/tmp/path_to_Rscript', what = 'character')
setwd(path)

source("SORD_Time.R")
start_time = PROC_TIME("start",NA)

# PRIPRAVA SLOZEK PRO VYSLEDKY
# if(PrintOutput == "both" | PrintOutput == "file"){

  #ADRESAR VYSTUPU
system("rm -rf Outputs")
system("mkdir Outputs")
system("cp -r SORD_Settings.R Outputs/SORD_Settings_copy.R")

for(run in 1:Runs){

  fold_create = paste("mkdir Outputs/run_", run, sep="")
  system(fold_create)

}

# stop("ZDE")

# }

# VEKTOR VSECH FITNESS
FitNamVec = c("MAE", "MSE", "RMSE", "NS0", "PI0")

# VEKTORY FUNKCI DLE ARIT
fce_arity1 = c("Psqrt", "Plog", "Pexp", "Plog10", "sigmoid",
	       "sin", "cos", "tan", "tanh", "hstep", "sign")
fce_arity2 = c("+", "-", "*", "Pdiv", "PPow", "max", "min", "SMA", "RES", "DLY", "aq", "CSUM", "sawt", 
               "less", "greater")
fce_arity3 = c()

# VEKTOR VSECH FUNKCI (Representation 186radek to vyuziva)
cha_vec = c(fce_arity1,fce_arity2,fce_arity3)

# SPECIALNI FUNKCE (vyclenene pro stavbu vyrazu)
spec_fce = c("SMA", "RES", "DLY", "CSUM")

# VEKTOR PREFIX FUNKCI S ARITOU 2
fce_ar2_prefix = c("Pdiv", "PPow", "max", "min", "SMA", "RES", "DLY", "aq", "CSUM", "sawt", "less", "greater")

# VEKTOR PRAVDEPODOBNOSTI PRO VYBER UZLU VARIACE (P(funkce), P(terminal))
NodeSelect = c(0.1,0.9)

# UMISTENI LEGENDY V GRAFECH
LegPlace = "topleft"

# NACTENI SOUBORU S FUNKCEMI
source("SORD_Inputs.R")
source("SORD_Representation.R")
source("SORD_Functions.R")
source("SORD_Compute.R")
source("SORD_Selection.R")
source("SORD_TreeVariate.R")
source("SORD_Mutation.R")
source("SORD_Crossover.R")
source("SORD_Results.R")
source("SORD_Plots.R")
source("SORD_Saves.R")

# if( file.exists("SORD_ADF.R") ){
#   source("SORD_ADF.R")
# }

SAWisON = SAW != FALSE
BalanceIsON = Balance != FALSE

# NACTENI FORTRAN FUNKCI
if(any(Functions$typ == "SMA") | any(Functions$typ == "RES") | any(Functions$typ == "DLY") | any(Functions$typ == "CSUM") ){ #JINAK !!!!!!!

  if(file.exists("F90scripts/Spec_fcs.so") == FALSE){

    system("cd F90scripts; R CMD SHLIB Spec_fcs.f90")

  }

  dyn.load("F90scripts/Spec_fcs.so")

}

if(BalanceIsON){

  if(file.exists("F90scripts/Weights.so") == FALSE){

    system("cd F90scripts; R CMD SHLIB Weights.f90")

  }

  dyn.load("F90scripts/Weights.so")

}


# VSTUPY
inputs = INPUTS()

# inputs = NORMALIZE(inputs, "Norm")

# print(inputs$Weights)
# stop("ZASTAVENO V MAIN")

# VYPOCET NS PRO MODELOVANI CHYB (Bilan)
# 1 - COMP_FIT(inputs$inpT, inputs$obsT, length(inputs$inpT), "NS0", FALSE)
# stop('ZASTAVENO V MAIN')

for(run in 1:Runs){

  print("*****************")
  print(paste(run,". PROGRAM RUN",sep=""))
  print("*****************")

  Training = TRUE
  
  source("SORD_Run.R")

  best_prg = BEST_PRG(run_results$best_prg_run)

#   stop("ZASTAVENO V MAIN")

  if(SAWisON | BalanceIsON){

    best_prg_no_weights = VALIDATE(best_prg, "Training")

  }

  Training = FALSE

  validated_prg = VALIDATE(best_prg, "Validation")

  SAVE_VALUES(run_results, best_prg, validated_prg, inputs$obsT, inputs$obsV, run, best_prg_no_weights)

  PLOT_GRAPHS(run_results, best_prg, validated_prg, inputs$obsT, inputs$obsV, run)

  if(SAWisON){

    inputs$Weights[] = 1

  }

  #VYMAZE PDF S PLOTY, KDYZ JE SPUSTENO POMOCI START A PLOT DO OBRAZOVKY JE POVOLEN
  if( file.exists("Rplots.pdf") ){
    system("rm -rf Rplots.pdf")
  }
  
}

ActualFolder = paste(Sys.Date(),format(Sys.time(), "%X"),sep="_")
ActualFolder = gsub("[[:blank:]]+", "", ActualFolder)

if(Clean){
  system("rm -rf All_runs_summary")
}

if( file.exists("All_runs_summary") ==  FALSE ){
  system("mkdir All_runs_summary")
}

system(paste("mkdir All_runs_summary/", ActualFolder, sep = ""))

ALL_RUNS_RESULT(inputs$obsT, inputs$obsV, ActualFolder)

stop_time = PROC_TIME("stop",start_time)
