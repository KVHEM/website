
# MUTACE PODSTROMU
MUT_TREE = function(mut_prg, max_depth, var_names){

  # URCENI UZLU MUTACE 
  mut_node = sample(c(1:mut_prg$len),1)
  
  # URCENI HLOUBKY UZLU MUTACE
  mn_depth = NODE_DEPTH(mut_prg$arr, mut_node)
 
  # MAX. HLOUBKA NOVEHO MUTACNIHO STROMU
  mt_depth = max((max_depth - mn_depth), 0)

  #TVORBA NOVEHO STROMU MUTACNIHO
  mt_prg = CREATE_INDIVIDUAL(mt_depth, method = "grow")
  mt_prg = INSERT_TERMINALS(mt_prg, var_names)

  # VLOZENI NOVEHO STROMU DO PUVODNIHO PROGRAMU
  mut_prg = TREE_VARIATION(mut_prg, mt_prg, mut_node)

  mut_prg$change = 1

  return(mut_prg)

}


# MUTACE KONSTANT
MUT_CONST = function(mut_prg, rand_sd){

  # VYBER UZLU K MUTACI
  mut_node = which(mut_prg$drive_vec == "Constant")
	
  if(length(mut_node) > 1){

    n_mut = sample(c(1:length(mut_node)),1)
    mutate_vec = sample(mut_node,n_mut)

  } else{

    mutate_vec = mut_node

  }

  for(i in mutate_vec){

    mut_prg$arr[i,1] = as.numeric(mut_prg$arr[i,1]) + rnorm(1,0,rand_sd)

  }
      
  mut_prg$change = 1

  return(mut_prg)

}


# MUTACE SEPARACI
MUT_SEPAR = function(mut_prg){

  # URCENI UZLU MUTACE (rozsah od 2 vice, mutace na rootu by byla replikaci)
  mut_node = sample(c(2:mut_prg$len),1)
  
  # SEPAROVANY PROGRAM
  mut_prg = SEPARATE_PRG(mut_prg, mut_node)

  mut_prg$change = 1

  return(mut_prg)

}

