CROSS_NODE = function(dvec){

  func_presence = dvec %in% Functions$typ

  if(any(func_presence)) {

    cn_prob = runif(1,0,1)

    if(cn_prob > NodeSelect[1]){  
      
      cn = sample(which(func_presence),1)

    } else{

      cn = sample(which((func_presence) == FALSE),1)

    }

  } else{ # JINAK SE JEDNA O JEDINCE SLOZENEHO JEN Z TERMINALU

    cn = 1

  }

}


CROSSOVER = function(parent_1, parent_2){ 

  # URCENI UZLU KRIZENI
  cross_node_1 = CROSS_NODE(parent_1$drive_vec)
  cross_node_2 = CROSS_NODE(parent_2$drive_vec)

  # V PRIPADE VOLBY KORENE JAKO UZLU KRIZENI U OBOU RODICU SE JEDNA JEN O JEICH PROHOZENI
  if(cross_node_1 == 1 && cross_node_2 == 1){

    return(list(offspring_1 = parent_2, offspring_2 = parent_1))

  }

  # SEPARACE STROMU KE KRIZENI
  separed_1 = SEPARATE_PRG(parent_1, cross_node_1)
  separed_2 = SEPARATE_PRG(parent_2, cross_node_2)

  # ZACLENENI DO PUVODNIHO STROMU OPACNEHO RODICE
  offspring_1 = TREE_VARIATION(parent_1, separed_2, cross_node_1)
  offspring_2 = TREE_VARIATION(parent_2, separed_1, cross_node_2)

  offspring_1$change = 1
  offspring_2$change = 1

  # KONTROLA MAX. HLOUBKY
  act_depth_1 = NODE_DEPTH(offspring_1$arr, offspring_1$len)
  act_depth_2 = NODE_DEPTH(offspring_2$arr, offspring_2$len)

  if(act_depth_1 > MaxDepthRun){

    offspring_1 = parent_1
    offspring_1$change = 0

  }

  if(act_depth_2 > MaxDepthRun){

    offspring_2 = parent_2
    offspring_2$change = 0

  }

  return(list(offspring_1 = offspring_1, offspring_2 = offspring_2))

}
