
# FUNKCE NAHODNEHO GENEROVANI CISEL Z LISTU TERMINALU|FUNKCI S NASTAVENYMI PRAVDEPODOBNOSTMI
PROB_RAND = function(inp_list){ # inp_list - terminaly nebo funkce

  cum_prob = cumsum(inp_list$prob)
  rand_val = runif(1,0,1)
  position = min(which(cum_prob >= rand_val))
  outval = inp_list$typ[position]
  return(outval)

}


# NAHODNA VOLBA FUNKCE
RAND_F = function(){

  if(sum(Functions$prob) == 0){

    F = sample(Functions$typ,1)

  } else{

    F = PROB_RAND(Functions)

  }

  return(F)

}


# NAHODNA VOLBA TERMINALU
RAND_T = function(){

  if(sum(Terminals$prob) == 0){

    T = sample(Terminals$typ,1)

  } else{

    T = PROB_RAND(Terminals)

  }

  return(T)

}


# NAHODNA VOLBA HODNOTY UZLU
RAND_FT = function(){

  x = rnorm(1,0,1)

  if(x > 0) {

    FT = RAND_F()

  }

  if(x <= 0) {

    FT = RAND_T()

  } 

  return(FT)

}


# HODNOTA UZLU
NODE = function(method, terminal = FALSE){

  if(terminal == FALSE){

    #NAHODNY VYBER FUNKCE NEBO TERMINALU PRI RUSTOVE METODE
    if(method == "grow"){

      attributes = RAND_FT()
      node_type = attributes
	  
    }

    #NAHODNY VYBER FUNKCE NEBO TERMINALU PRI UPLNE METODE
    if(method == "full"){

      attributes = RAND_F()
      node_type = attributes

    }

  } else{

    attributes = RAND_T()
    node_type = attributes

  }

  return(node_type)

}


# DOPLNENI SOURADNIC UKAZATELU UZLU
NODE_IDENTIFY = function(new_row, node_type){

  numcol = max(Functions$arity)+1

  tuple = rep(NA,numcol)
  tuple[1] = node_type

  if(any(Functions$typ == node_type)) {

    n_arit = Functions$arity[which(Functions$typ == tuple[1])]

    for (i in 1:n_arit){

	new_row = new_row + 1
	tuple[i+1] = new_row

    }

  }

  return(list(tuple = tuple, new_row = new_row))

}


# VYTVORENI JEDINCE
CREATE_INDIVIDUAL = function(max_depth, method) {

  # MAX. ARITA FUNKCÍ
  max_ar = max(Functions$arity)

  #POCET SLOUPCU POLE PROGRAMU
  numcol = max_ar+1

  # MAX POCET RADKU POLE PROGRAMU udelat mozna jinak - dynamicka zmena a doplnovani radku do pole, aby nebyla potreba definovat velke pole
  numrow = 1
  if(max_depth > 0){

    for(i in 1:max_depth){

      numrow = numrow + max_ar^i

    }

  }

  # PRIPRAVA POLE PROGRAMU
  PRG = array(c(NA), dim=c(numrow, numcol))

  # PRVNI RADEK PROGRAMU
  if(max_depth == 0){

    new_node = NODE(method, terminal = TRUE)
    node_full = NODE_IDENTIFY(1,new_node)
    PRG[1,1:numcol] = node_full$tuple
    vec_node_types = PRG[,1]
    return(list(fit = NA, drive_vec = vec_node_types, arr = PRG, len = 1, change = 0, comp_val = NA))

  } else{

    new_node = NODE(method)
    node_full = NODE_IDENTIFY(1,new_node)
    PRG[1,1:numcol] = node_full$tuple

  }

  # POCATECNI NASTAVENI AKTUALNI HLOUBKY A RADKU, MAXIMALNIHO RADKU V HLOUBCE, PROMENNE NOVEHO RADKU(souvisi s ukazateli uzlu)
  act_depth = 1
  act_row = 1
  max_row_level = 1
  new_row = node_full$new_row

  # KONSTRUKCE POLE PROGRAMU
  while(act_depth <= max_depth){
 
    act_col = 2

    # KONSTRUKCE CILOVYCH UZLU PRO UKAZATELE UZLU AKTUALNIHO
    while(act_col <= numcol && is.na(PRG[act_row,act_col])==FALSE){

      if(act_depth < max_depth){

	new_node = NODE(method) 

      }

      if(act_depth == max_depth){

	new_node = NODE(method, terminal = TRUE) 

      }

      node_full = NODE_IDENTIFY(new_row, new_node)

      target_row = as.numeric(PRG[act_row,act_col])

      PRG[target_row,1:numcol] = node_full$tuple

      new_row = node_full$new_row

      act_col = act_col + 1

    }

    # ZMENA AKTUALNI HLOUBKY STROMU
    if(act_row == max_row_level){

      if(any(is.na(as.numeric(PRG[1:act_row,2:numcol]))==FALSE)){
	max_row_level = max(as.numeric(PRG[1:act_row,2:numcol]),na.rm = TRUE)
      }

      act_depth = act_depth + 1
    
    }

    act_row = act_row + 1

    # UKONCENI HLAVNIHO CYKLU
    if(is.na(PRG[act_row,1])) {

      act_depth = max_depth + 1

    }

  }


  # ZKRACENI POLE PROGRAMU
  prg_numrow = max(which(is.na(PRG[,1])==FALSE))
  PROGRAM = array(PRG[1:prg_numrow,], dim = c(prg_numrow, numcol))

  # RIDICI VEKTOR HODNOT V UZLECH (terminal/fce)
  vec_node_types = PROGRAM[,1]

  return(list(arr = PROGRAM, drive_vec = vec_node_types, len = prg_numrow, change = 0, comp_val = NA, expr = NA, fit = NA, fit_arr = NA))

}
