
# DOPLNENI TERMINALU, U PEVNYCH ROVNOU HODNOTY, U TERMINALU PROMENNYCH IDENTIFIKACE SLOUPCE VKLADANEHO VSTUPU ZE VSTUPNIHO SOUBORU
INSERT_TERMINALS = function(program, var_names){

  for (i in 1:program$len){

    # DOPLNENI PEVNYCH NAHODNYCH KONSTANT (NEMENI SE S POSTUPEM VE VSTUPNICH DATECH) (pozice 100)
    if(program$arr[i,1] == "Constant"){

#       program$arr[i,1] = round(runif(1,(Terminals$range[1]-correction),(Terminals$range[2]+correction)),Terminals$range[3])
      program$arr[i,1] = runif(1,Terminals$range[1],Terminals$range[2])

    }
    
    # ZMENA TERMINALU S PROMENNYMI PRI VICE NEZ 1 NEZAVISLE VSTUPNI PROMENNE
    if(program$arr[i,1] == "Variable"){

      program$arr[i,1] = sample(var_names,1)

    }

  }

  return(program)

}


DO_SAW = function(comp_data, ref_data){

  wdiff = abs(comp_data - ref_data)
#   plot(wdiff)

  if(SAW == "Classic"){

    test_val = abs(min(ref_data)/max(ref_data))/10
#     which_add = which(wdiff > 0.1) # Classic SAW zde ma podminku nenulovosti
    which_add = which(wdiff > test_val) # Classic SAW zde ma podminku nenulovosti
    new_weights = inputs$Weights  
    new_weights[which_add] = new_weights[which_add] + 1    

  }

  if(SAW == "Precision"){

    new_weights = inputs$Weights + wdiff

  }

  return(new_weights) 

}


EXPRESSION = function(program){

  exp_arr = array(c(""), dim = c(program$len,1))

  exp_arr[,1] = program$arr[,1]

  # PREVOD PROGRAMU DO SYMBOLICKE FORMY
  for (i in program$len:1){

    if(any(Functions$typ == program$drive_vec[i])){

      for(j in 2:ncol(program$arr)){

	if(is.na(program$arr[i,j]) == FALSE){

	  arg_row = as.numeric(program$arr[i,j])

	  if(j == 2 && is.na(program$arr[i,(j+1)])){

	    if(any(program$drive_vec[i] == spec_fce) == FALSE){

	      exp_arr[i,1] = paste(exp_arr[i,1],"(",exp_arr[arg_row,1],sep="")

	    } else{

	      exp_arr[i,1] = paste(exp_arr[i,1],exp_arr[arg_row,1],sep="")

	    }

	  }

	  if(j == 2 && is.na(program$arr[i,(j+1)]) == FALSE){
	    
	    if(any(fce_ar2_prefix == program$drive_vec[i])){ # arita 2

	      first = paste(exp_arr[i,1],"(",exp_arr[arg_row,1],",",sep="")

	    } else{

	      first = paste("(",exp_arr[arg_row,1],sep="")

	    }

	  }

	  if(j > 2){

	    if(any(fce_ar2_prefix == program$drive_vec[i])){

	      exp_arr[i,1] = paste(first,exp_arr[arg_row,1],sep="")

	    } else{

	      exp_arr[i,1] = paste(first,exp_arr[i,1],exp_arr[arg_row,1],sep="")

	    }

	  }

	}

      } 

      exp_arr[i,1] = paste(exp_arr[i,1],")",sep="")

    }

  }

  final_expr = paste("y = ", exp_arr[1,1], sep = "")

  return(final_expr)

}



# VYPOCET JEDINCE (PRVKY program SOUVISI S NAVRATEM FCE CREATE_INDIVIDUAL)
COMP_PRG = function(program, data_in, nr_in, nc_inp, data_ref, var_names, fit_type, gen, fit_all = FALSE, final_comp = FALSE, validation = FALSE){

  # DOPLNENI TERMINALU, U KONSTANT ROVNOU HODNOTY, U PROMENNYCH VOLBA SLOUPCE VKLADANEHO VSTUPU ZE VSTUPNIHO SOUBORU
  if(gen == 0){

    program = INSERT_TERMINALS(program, var_names)

  }

  #ZAOKROUHLENI 
  if(is.na(RoundConst) == FALSE){

#     print(program$arr)

    const_pos = which(program$drive_vec == "Constant")

    program$arr[const_pos] = round(as.numeric(program$arr[const_pos]),RoundConst)

#     print(program$arr)

#     stop("ZASTAVENO V COMPUTE")

  }

  # PREVOD DO VYRAZU
  program$express = EXPRESSION(program)

  # PRIPRAVA PROMENNYCH
  for(i in 1:nc_inp){

    assign(var_names[i], data_in[,i])

  }

  # VYPOCET
  parsed_exp = parse(text = program$express)

  exp_check = try(eval(parsed_exp), silent = TRUE) # vraci vypoctene hodnoty v promenne y 

  if(class(exp_check) == "try-error"){ # ZMENA CHYBOVE HLASKY TRY

#     warning("Vyskyt NA vysledku vypoctu")

    y = NA
#     print(parsed_exp)
#     print(exp_check)
#     stop("ZASTAVENO V Compute")

  }


  if(is.na(y[1]) == FALSE){
    # ROZSIRENI PROGRAMU BEZ VSTUPNICH PROMENNYCH (konstanty a skalar musi byt preveden na vektor)
    if(length(y) == 1){

      y = rep(y,nr_in)
    
    }
    
    # ZMENA ZAPORNYCH HODNOT
    if(NoNegative){

      if(ChngNegative == 0){
	y[which(y < 0)] = 0
      }

      if(ChngNegative == "min"){
	y[which(y < 0)] = min(data_in)
      }

    }

  }

  # VYHODNOCENI
  fitness = COMP_FIT(y, data_ref, nr_in, fit_type, validation) 

  # OHLIDANI CHYBOVYCH JEDINCU 
  if(is.finite(fitness) == FALSE){

    fitness = 1e100
#     warning("NA/NaN fitness produced, fitness of individual changed to 1e100")

  }

  # VYHODNOCENI VSECH KRITERII
  if(fit_all == TRUE){

    program$fit_arr = array(c(-1), dim = c(2, length(FitNamVec)))
    
    program$fit_arr[1,] = FitNamVec
    for(i in 1:length(FitNamVec)){
    
      program$fit_arr[2,i] = COMP_FIT(y, data_ref, nr_in, FitNamVec[i], validation) 
      program$fit_arr[2,i] = round(as.numeric(program$fit_arr[2,i]),6)

    }

  }

  if(final_comp){

    return(list(arr = program$arr, drive_vec = program$drive_vec, len = program$len, change = 0, comp_val = y, expr = program$express, fit = fitness, fit_arr = program$fit_arr))

  } else{

    return(list(arr = program$arr, drive_vec = program$drive_vec, len = program$len, change = 0, comp_val = NA, expr = program$express, fit = fitness, fit_arr = program$fit_arr))

  }

}
