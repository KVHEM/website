
# POCATECNI POPULACE
# dale jsou jedinci k dispozici jako prg1, prg2,..., prgN

# ARITY FUNKCI
Functions$arity = GET_ARITY(Functions$typ)

# RAMPED_HALF_AND_HALF
if(MaxDepthIni > 1){
  n_groups = MaxDepthIni - 1
}
if(MaxDepthIni <= 1){
  n_groups = 1
}

np_in_grps = floor(NiPop / n_groups)

np_vec = rep(np_in_grps,n_groups)

np_vec[length(np_vec)] = np_vec[length(np_vec)] + (NiPop - sum(np_vec))

np_vec = cumsum(np_vec)

# PRIPRAVA POLE PRO FITNES A ID_PROGRAMU
Fit_arr = array(c(0),dim = c(NiPop,2))

# PRIPRAVA POLE PRO DELKU A ID_PROGRAMU
Len_arr = array(c(0),dim = c(NiPop,2))

# VYTVORENI POCATECNI POPULACE PROGRAMU METODOU RAMPED HALF AND HALF
max_depth_ramped = 2
j = 1
method = "grow"

for (i in 1:NiPop){

  if(i > np_vec[j]){
    
    max_depth_ramped = max_depth_ramped + 1
    j = j + 1

  }
  
  if(method == "grow"){ # stridani metod full a grow

    method = "full"

  } else{

    method = "grow"
  
  }

  # VYTVORENI JEDINCE, PROMENNA indX (od INDividual, program az po vypocteni)
  flow_ind = paste("ind",i,sep="")

  assign(flow_ind,CREATE_INDIVIDUAL(max_depth_ramped, method))

#   a = get(flow_ind)
#   print(a$arr)

  # VYPOCET JEDINCE, PROMENNA prgX
  flow_prg = paste("prg",i,sep="")

  assign(flow_prg,COMP_PRG(get(flow_ind), inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType,0))

  # DOPLNENI POLE FITNESS
  active_prg = get(flow_prg)
  
  Fit_arr[i,] = c(i,active_prg$fit)
  Len_arr[i,] = c(i,active_prg$len)

}

# PRIPRAVENI LISTU PRO VYSLEDKY
run_results = list(min_fit = c(), mean_fit = c(), mean_depth =  c(), best_prg_depth = c(), best_prg_run = c())

# VYSLEDKY Z POCATECNI GENERACE
run_results = RUN_RESULTS(run_results)

print("Initial generation")

print(min(run_results$min_fit))

# TVORBA NOVE (DALSI) GENERACE
act_gen = 1
while(act_gen <= Ngen){

#   if(act_gen> 0.5*Ngen){ DoubleTour = TRUE }

  # ZAPLNOVANI NOVE GENERACE
  n_ind_in_pop = 1
  while(n_ind_in_pop <= NiPop){ # while, kvuli ruznym variacnim operatorum

    # ELITISMUS
    if(Elitism && n_ind_in_pop == 1){

      flow_new_prg = paste("new_prg",n_ind_in_pop,sep="")

      winner = which.min(Fit_arr[,2])

      offspring = get(paste("prg",winner,sep=""))

      offspring$change = 0

      if(SAWisON && any(seq(SAWtime,(Ngen-1),SAWtime) == act_gen)){

	elite_individual = COMP_PRG(offspring, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, act_gen, final_comp = TRUE)

	new_weights = DO_SAW(elite_individual$comp_val,inputs$obsT)

	offspring$change = 1

      }
  
      if(SAWisON){ offspring$change = 1 }

      if(DMTD){

	dyn_depth_lim = c(offspring$fit, NODE_DEPTH(offspring$arr, offspring$len), offspring$len)

      } 

      assign(flow_new_prg, offspring)

      n_ind_in_pop = n_ind_in_pop + 1

    }


    # REPRODUKCE
    var_test = runif(1,0,1)
    if(var_test <= Pr){

      flow_new_prg = paste("new_prg",n_ind_in_pop,sep="")  
    
      winner = TOURNAMENT(Fit_arr, Len_arr, 1)

      offspring = get(paste("prg", winner,sep=""))

      offspring$change = 0

      if(SAWisON){offspring$change = 1}

      assign(flow_new_prg,offspring)
    
      n_ind_in_pop = n_ind_in_pop + 1

    }

    # PROVEDENI MUTACI PODSTROMU KONSTANT A SEPARACI (kvuli DMTD)
    next_variation = TRUE

    # KRIZENI
    var_test = runif(1,0,1)
    if(var_test <= Pc){

      winners = TOURNAMENT(Fit_arr, Len_arr, 2) 

      parent_1 = get(paste("prg",winners[1],sep=""))
      parent_2 = get(paste("prg",winners[2],sep=""))

      off_programs = CROSSOVER( parent_1, parent_2 )

      crossbred_1 = off_programs$offspring_1
      crossbred_2 = off_programs$offspring_2

      if(OffspringSelect == "better"){ # urceni uspesnejsiho krizence pro dalsi prubeh variaci

	crossbreds = COMP_CROSSBREDS(crossbred_1, crossbred_2)

	c1comp = crossbreds$c1
	c2comp = crossbreds$c2

	if(SAWisON){
	  
	  parent_1$change = 1
	  parent_2$change = 1
	  crossbred_1$change = 1 # asi jen pro random selection
	  crossbred_2$change = 1 # asi jen pro random selection
	  c1comp$change = 1
	  c2comp$change = 1

	}

	if(any(c(c1comp$fit,c2comp$fit) < min(parent_1$fit,parent_2$fit))){ # JE NEJAKY POTOMEK LEPSI NEZ NEJLEPSI RODIC?

	  better_prg = OFFSPRING_BETTER(parent_1, parent_2, c1comp, c2comp, winners, dyn_depth_lim)

	  assign(better_prg$name_old, better_prg$out_par)
	  assign(better_prg$name_new, better_prg$out)

	  winner = better_prg$win

	  next_variation = better_prg$variate

	} else { #rodice lepsi nez potomci

	  better_prg = PARENTS_BETTER(parent_1, parent_2, winners)

	  assign(better_prg$name_old, better_prg$out)
	  assign(better_prg$name_new, better_prg$out)

	  winner = better_prg$win

	}

# 	print(get(better_prg$name_new))

      }

      if(OffspringSelect == "random"){ # urceni nahodneho krizence pro dalsi prubeh variaci

	chosen = round(runif(1,0,1),0)

	if(chosen == 0){

	  winner = winners[1]

	  assign(paste("prg_old_save",winner,sep=""), parent_1)
	  assign(paste("prg",winner,sep=""),crossbred_1)

	} else {	

	  winner = winners[2]

	  assign(paste("prg_old_save",winner,sep=""), parent_2)
	  assign(paste("prg",winner,sep=""),crossbred_2)

	}

      }

    }


    # URCENI JEDINCE PRO MUTACE - jen kdyz nedojde ke krizeni. V pripade krizeni pouzit potomek z krizeni
    if(var_test > Pc){

      winner = TOURNAMENT(Fit_arr, Len_arr, 1)  

      mut_prg = get(paste("prg",winner,sep=""))

      assign(paste("prg_old_save",winner,sep=""), mut_prg)

    } else{

      mut_prg = get(paste("prg",winner,sep=""))

    }


    # MUTACE PODSTROMU
    var_test = runif(1,0,1)
    if(var_test <= Pm_tree){

      offspring = MUT_TREE(mut_prg, MaxDepthRun, inputs$variable_names)

      if(DMTD){

	tree_depth = NODE_DEPTH(offspring$arr, offspring$len)
  
	if(tree_depth > dyn_depth_lim[2]){

	  offspring = COMP_PRG(offspring, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, act_gen)
  
	  if(offspring$fit < dyn_depth_lim[1]){

	    dyn_depth_lim = c(offspring$fit, tree_depth, offspring$len)

	    mut_prg = offspring

	    next_variation = FALSE

# 	    stop("ZASTAVENO V RUN 1")

	  }

	} else{

	  mut_prg = offspring

	}

      } else{

	mut_prg = offspring

      }

    }


    # MUTACE SEPARACI
    var_test = runif(1,0,1)
    if(next_variation & var_test <= Pm_sep){

      if(mut_prg$len > 1){ # nema cenu separovat jeden uzel z jednouzloveho jedince

	offspring = MUT_SEPAR(mut_prg)

	mut_prg = offspring

      }

    }


    # MUTACE KONSTANT
    var_test = runif(1,0,1)
    if(next_variation & var_test <= Pm_konst){
      
      if(any(mut_prg$drive_vec == "Constant")){

	offspring = MUT_CONST(mut_prg, MutKonstSd)

	mut_prg = offspring

      }

    }


    flow_new_prg = paste("new_prg",n_ind_in_pop,sep="")

    assign(flow_new_prg, mut_prg)

    assign(paste("prg",winner,sep=""), get(paste("prg_old_save",winner,sep="")))

    n_ind_in_pop = n_ind_in_pop + 1

  }


  # NOVY VYPOCET PROGRAMU
  for (n_ind_in_pop in 1:NiPop){ 

    flow_prg = paste("prg",n_ind_in_pop,sep="")

    # ZMENA Z new_prgX NA prgX
    active_prg = get(paste("new_prg",n_ind_in_pop,sep=""))
    assign(flow_prg, active_prg)

    if(active_prg$change == 1){

      assign(flow_prg,COMP_PRG(active_prg, inputs$inpT, inputs$nr_inpT, inputs$nc_inp, inputs$obsT, inputs$variable_names, FitType, act_gen))
      new_comp_prg = get(flow_prg)

      # NOVE HODNOTY POLE FITNESS
      Fit_arr[n_ind_in_pop,2] = new_comp_prg$fit
      Len_arr[n_ind_in_pop,2] = new_comp_prg$len

    } else{

      Fit_arr[n_ind_in_pop,2] = active_prg$fit
      Len_arr[n_ind_in_pop,2] = active_prg$len

    }
  
  }

# if(SAWisON && any(seq(SAWtime,Ngen,SAWtime) == act_gen)){
# 
#       a = get("new_prg1")
#       print("a$expr")
#       print(a$expr)
# }
# 
# if(SAWisON && any(seq(SAWtime,Ngen,SAWtime) == act_gen)){
#       print("Fit_arr[1,2]")
#       print(Fit_arr[1,2])
# 
# #       stop("V RUN")
# }

  # ZAPIS VYSLEDKU
  run_results = RUN_RESULTS(run_results)

  if(Elitism | SAWisON){
    actual_min_fit = run_results$min_fit[length(run_results$min_fit)]
  } else {
    actual_min_fit = min(run_results$min_fit)
  }

  # PRUBEH VYPOCTU NA OBRAZOVCE
  if(any(seq(5,Ngen,5) == act_gen)){

    print(paste(round(act_gen/Ngen*100,0),"% done",sep = ""))
    print(actual_min_fit)
  
  }

  # ZASTAVENI
  if(actual_min_fit < StopCrit){

    print("*********************************")
    print(paste("STOPING CRITERION REACHED (gen ",act_gen,")",sep=""))
    print("*********************************")

    act_gen = Ngen + 1  

  }

  if(SAWisON && any(seq(SAWtime,(Ngen-1),SAWtime) == act_gen)){

    inputs$Weights = new_weights

  }

  act_gen = act_gen + 1

#   if(act_gen==Ngen){ DoubleTour = FALSE }

}
