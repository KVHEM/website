COMP_FIT = function(data_comp, data_ref, nr_data, fit_type, validation){

  if(any(is.finite(data_comp) == FALSE)) {

    return(NA)

  }

  W = inputs$Weights

  if(validation){

    W = rep(1,nr_data)

  }

  if(fit_type == "MAE"){

    fitness = sum(W * abs(data_ref-data_comp)) / nr_data

  }

  if(fit_type == "MSE"){

    fitness = sum( W * (data_ref-data_comp)^2 ) / nr_data

  }

  if(fit_type == "MSELS"){

    b = sum((data_ref-mean(data_ref)) * (data_comp-mean(data_comp))) / sum((data_comp-mean(data_comp))^2)
    a = mean(data_ref) - b*mean(data_comp)

# print(sum((data_ref-mean(data_ref)) * (data_comp-mean(data_comp))))
# print(sum((data_comp-mean(data_comp))^2))
# print(b)
# print(a)
# stop("ZDE")

    fitness = sum( W * ((a+b*data_comp)-data_ref)^2 ) / nr_data

  }

  if(fit_type == "RMSE"){

    fitness = sqrt(sum( W * (data_ref-data_comp)^2 ) / nr_data)

  }

    #NASH SUTCLIFFE UPRAVENY
    if(fit_type == "NS0"){ 
      
      fitness = sum( W * (data_comp-data_ref)^2 ) / sum( (data_ref-mean(data_ref))^2 )

    }

    #PERSISTENCY INDEX UPRAVENY
    if(fit_type == "PI0"){ 
      
      dat_len = length(data_ref)
      fitness = sum( W[2:dat_len] * (data_comp[2:dat_len]-data_ref[2:dat_len])^2)/sum( (data_ref[2:dat_len]-data_ref[1:(dat_len-1)])^2)

    }

  return(fitness)

}


GET_ARITY = function(ftype_vec){

  arity_vec = c()

  for(i in 1:length(ftype_vec)){

    if(any(fce_arity1 == ftype_vec[i])){
      
      arity_vec = c(arity_vec,1)

    }

    if(any(fce_arity2 == ftype_vec[i])){
      
      arity_vec = c(arity_vec,2)

    }

  }

  return(arity_vec)

}


Pdiv = function(x1, x2){

  if(any(x2 == 0)){

    x2[which(x2 == 0)] = 1
  
  } 

  output = x1 / x2 

#   output = suppressWarnings(x1/x2)
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }

  return(output)

}

# Analytic Quotient, Ni 2012
aq = function(x1, x2){

  output = x1 / sqrt(1 + x2^2) 

  return(output)

}


PPow = function(x1, x2){

  if(any(x2 > 20)){ # lze jit az do exp(709)

    x2[which(x2 > 20)] = 20

  }

  output = (x1^x2)

#   output = suppressWarnings(x1^x2)
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }

  return(output)

}


Psqrt = function(x){

  output = sqrt(abs(x))

  return(output)

}


Plog = function(x){

  if(any(x == 0)){

    x[which(x == 0)] = 1e-9 # lze jit az do 10e-324

  }

  x = abs(x)

#   output = suppressWarnings(log(x))
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }

  output = log(x)

  return(output)

}


Plog10 = function(x){

  if(any(x == 0)){

    x[which(x == 0)] = 1e-9 # lze jit az do 10e-324

  }

  x = abs(x)

#   output = suppressWarnings(log10(x))
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }

  output = log10(x)

  return(output)

}


Pexp = function(x){

  if(any(x > 20)){ # lze jit az do exp(709)

    x[which(x > 20)] = 20

  }

  output = exp(x)

#   output = suppressWarnings(exp(x))
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }
# 
  return(output)

}


sigmoid = function(x){

  if(any(x < -20)){ # lze jit az do exp(709)

    x[which(x < -20)] = -20

  }

  output = 1/(1+exp(-x))

#   output = suppressWarnings(1/(1+exp(-x)))
# 
#   if(any(is.finite(output) == FALSE)){
# 
#     return(NA)
#   
#   }

  return(output)

}


hstep = function(x){

  x[which(x >= 0)] = 1
  x[which(x < 0)] = 0

  output = x

  return(output)

}

sawt = function(amp, T){

  if(any(T == 0)){

    T[which(T == 0)] = 1
  
  } 

  if(Training){

    x = c(1:inputs$nr_inpT)
 
  } else{

    x = c(1:inputs$nr_inpV)

  }

  a = x/T
  
  output = amp*(a - floor(a - 0.5))

# print(x[1:100])
# print(output[1:100])
# stop("here")

  return(output)

}


less = function(x1, x2){

  output = x1
  output[which(x1<x2)] = 1
  output[which(x1>=x2)] = 0
#   stop('less pouzito')
  return(output)

}


greater = function(x1, x2){

  output = x1
  output[which(x1>x2)] = 1
  output[which(x1<=x2)] = 0

  return(output)

}

# x1 = c(1:5)
# x2 = c(5:1)
# 
# greater(x1,x2)


SMA = function(variable, shift){

  if(any(is.finite(variable) == FALSE) | any(is.finite(shift) == FALSE)) {

    return(NA)

  }

  shift = abs(round(shift,0))
  lenvar = length(variable)
  shift[which(shift > lenvar)] = lenvar

  if(lenvar <= 1 | (length(shift) == 1 && shift == 0)){

    return(variable)

  } else{

    if(length(shift) == 1){

      output = rep(0,lenvar)
      out_f90 = .Fortran("SMA", n=as.integer(lenvar), variable=as.double(variable), shift = as.integer(shift), output = as.double(output))
      out_vec = out_f90$output 

# ptm = proc.time()
# 
# variable = c(1:5000000)
# shift = 5
# output = rep(0, length(variable))
# 
# y = filter(variable, rep(1,shift)/shift, sides = 1)
# # y[1:10]
# 
# # a = .Fortran("SMA", n=as.integer(length(variable)), variable=as.double(variable), shift = as.integer(shift), output = as.double(output))
# #  a$output[1:10]
# 
# ptm = proc.time() - ptm
# elapsed_time = as.double(ptm[3])
# print("TIME SPENT [s]")
# print(elapsed_time)

    } else{

      output = rep(0,lenvar)
      out_f90 = .Fortran("SMA_VAR", n=as.integer(lenvar), variable=as.double(variable), shift = as.integer(shift), output = as.double(output))
      out_vec = out_f90$output 

    }   

  }

  return(out_vec)

}


CSUM = function(variable, shift){

  if(any(is.finite(variable) == FALSE) | any(is.finite(shift) == FALSE)) {

    return(NA)

  }

  shift = abs(round(shift,0))
  lenvar = length(variable)
  shift[which(shift > lenvar)] = lenvar

  if(lenvar <= 1 | (length(shift) == 1 && shift == 0)){

    return(variable)

  } else{

    if(length(shift) == 1){

      output = rep(0,lenvar)
      out_f90 = .Fortran("CUMSUM", n=as.integer(lenvar), variable=as.double(variable), shift = as.integer(shift), output = as.double(output))
      out_vec = out_f90$output 

    } else{

      output = rep(0,lenvar)
      out_f90 = .Fortran("CUMSUM_VAR", n=as.integer(lenvar), variable=as.double(variable), shift = as.integer(shift), output = as.double(output))
      out_vec = out_f90$output 

    }   

  }

  return(out_vec)

}


DLY = function(variable, shift){

  if(is.vector(variable) == FALSE | length(variable) <= 1){

    return(variable)

  } else {

    shift = abs(round(shift,0))
    lenvar = length(variable)
    shift[which(shift > lenvar)] = lenvar

    output = rep(0,lenvar)
    out_f90 = .Fortran("DLY", variable=as.double(variable), n=as.integer(lenvar),  
                       shift = as.integer(shift), n_sh=as.integer(length(shift)), output = as.double(output))
    out_vec = out_f90$output 

    return(out_vec)

  }

}





RES = function(variable, lin_par){

  if(any(is.finite(variable) == FALSE) | any(is.finite(lin_par) == FALSE)) {

    return(NA)

  }

  lenvar = length(variable)

  if(is.vector(variable) == FALSE  | lenvar <= 1){

    return(variable)

  } else {

    lin_par = abs(lin_par)

    output = rep(0,lenvar)
    out_f90 = .Fortran("RES", variable = as.double(variable), n = as.integer(lenvar), lin_par = as.double(lin_par),
                       n_lp = as.integer(length(lin_par)), output = as.double(output))
    out_vec = out_f90$output 

    return(out_vec)

  }

}
# 
# 
# 
#   if(weigted_fit == FALSE && BalanceIsON ){
# 
#     if(fit_type == "MAE"){
# 
#       fitness = sum(inputs$Weights * abs(data_ref-data_comp))/sum(inputs$Weights)
# 
#     }
# 
#     if(fit_type == "MSE"){
# 
#       fitness = sum( inputs$Weights * (data_ref-data_comp)^2 )/ sum(inputs$Weights)
# 
#     }
# 
#     if(fit_type == "RMSE"){
# 
#       fitness = sqrt(sum( inputs$Weights * (data_ref-data_comp)^2 )/ sum(inputs$Weights))
# 
#     }
# 
#     if(fit_type == "CC0"){fitness = NA}
# 
#     #NASH SUTCLIFFE UPRAVENY
#     if(fit_type == "NS0"){ 
#       
#       fitness = sum( inputs$Weights * (data_comp-data_ref)^2 ) / sum( inputs$Weights * (data_ref-mean(data_ref))^2 )
# 
#     }
# 
#     #PERSISTENCY INDEX UPRAVENY
#     if(fit_type == "PI0"){ 
#       
#       dat_len = length(data_ref)
#       fitness = sum( inputs$Weights[2:dat_len] * (data_comp[2:dat_len]-data_ref[2:dat_len])^2)/sum( inputs$Weights[2:dat_len] * (data_ref[2:dat_len]-data_ref[1:(dat_len-1)])^2)
# 
#     }




