// JavaScript Document
// Project: RadFlow
// autohor: Jiri Holub
// Description: Stehfest algorithm

  function stehfest(){
    N = 10;
    Vi = new Array (0.08333333333333333,-32.08333333333334,1279.0,-15623.66666666667,84244.1666666666,-236957.5,375911.66666666667,-340071.6666666667,164062.5,-32812.5);
    time = new Array (100,200,500,1000,2000,5000,10000,20000,50000,100000,200000,500000,1000000,2000000,5000000,10000000,20000000,50000000,100000000);
    Ares = new Array();
    data = [[]];
        
      for(a = 0; a < time.length; a++){
        t = time[a];
        sum = 0;
        i = 1; 
          while(i <= N){
            k = (i + i)/2;
            sum = sum + Vi[i-1] *fce(i * (Math.log(2)/t),t);
            i++;
          }
          
        Ares[a] = "<br>"+"td: "+time[a].toExponential()+" --------svd: "+(Math.log(2) / t * sum).toFixed(5);
        res = Math.log(2) / t * sum;
        data[0].push([time[a], res]); 
      } 
    document.getElementById('result').innerHTML = Ares;
    document.getElementById('chart').innerHTML = "";
    ploting(data); 
  }
  
  function fce(par){
  
    C = document.getElementById('storage').value;        // storage
    S = document.getElementById('skin').value;        // skin effect
    
    div = par*(Math.sqrt(par)*BesselK1(Math.sqrt(par)) + C * par * (BesselK0(Math.sqrt(par)) + S * Math.sqrt(par) * BesselK1(Math.sqrt(par))));
    hd = (BesselK0(Math.sqrt(par)) + (S * Math.sqrt(par) * BesselK1(Math.sqrt(par))))/div;       
    return hd;
  }
  
  function ploting(data){
    var plot1 = $.jqplot('chart',data,{
        title: 'Swd',
        grid: {
          drawGridLines: true,    
          borderWidth: 2.0,      
          shadow: false
        },  
        seriesDefaults:{
          markerOptions: {
            size: 7,
            shadow: false
          },
          shadow: false
        },       
        axes: { 
            xaxis: {                
                tickOptions: {
                  formatString: '%.1e'                           //http://perldoc.perl.org/functions/sprintf.html                      
                },
                renderer: $.jqplot.LogAxisRenderer
            },
            yaxis:{
              min:0, 
              max:160,
              tickOptions: {
                formatString: '%.1f'                           //http://perldoc.perl.org/functions/sprintf.html                      
              }
            } 
        }
    });
  }