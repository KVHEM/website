#include <iostream>

#include "asvh.h"

using namespace std;

int main()
{
    cout << "The Recesions Analyses" << endl;
    cout << "\n\n The settings file sghows the following content\n***************************\n\n";
    
    asvh recesions("./settings/settings_file");
    recesions.get_recessions_data();
    recesions.initialize_all_POpulation();
    recesions.run_ensemble();
    return 0;
}
