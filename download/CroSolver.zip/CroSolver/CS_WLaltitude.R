# Computation of water level (WL) altitudes and slope of WL

CompAltSlope = function(CS, AD, minAD){
  # CS - Cross section coordinates
  # AD - Axis Distance of CS [m]
  # minAD - minimal allowed AD [m]
  # RETURNS - list of altitudes and slopes

  KnownPointsComp = function(alts, dists){
  
    # Position of points of negative slope (negative=downstream) - known points
    p = which(!is.na(alts))
    l = length(p)
    # Altitudes on known points
    a = alts[p]
    # Distances of known points from begining
    d = dists[p]
    # Difference of altitudes
    ad = a[1:(l-1)]-a[2:l]
    # Distances among known points
    dd = abs(d[1:(l-1)]-d[2:l])
    
    return(list(points = p, altitudes = a, altdiff = ad, distdiff = dd))
    
  }

  nrb = nrow(CS)
  
  # Cumulative sum of distances
  cdist = cumsum(AD)
  
  # Equalisation of right-left altitudes, minimal altitude for CS is used
  altitudes = rep(NA, nrb)
  
  for(i in 1:nrb){
  
    altitudes[i] = min(CS$Zr[i], CS$Zl[i])
    
  }
    
  # Altitudes adjusting preparation - the higher altitudes than previous altitude are replaced by NA
  last_ok = altitudes[1]
  
  for(i in 2:length(altitudes)){ 
  
    if(altitudes[i]>=last_ok){
    
      altitudes[i] = NA
      
    } else{
    
      last_ok = altitudes[i]
      
    }   
    
  }
  
  # Known points correction. Deleting the first point (higher, because lower is taken as right) of points whose distance is < minAD
  if(is.null(minAD)==FALSE){
  
    knownp = KnownPointsComp(altitudes, cdist)
    pos2del = c()
    
    for(i in 2:length(knownp$distdiff)){
    
      if(knownp$distdiff[i] < minAD){  
      
        pos2del = c(pos2del,i)   
        
      } 
      
    }
    
    altitudes[knownp$points[pos2del]] = NA
    
  }
  
  # Control of the data
  if(all(is.na(altitudes[2:length(altitudes)]))){stop('WRONG DATA OR WRONG SORTING OF DATA OR TOO HIGH MINIMAL DISTANCE')}
    
  # Recomputation of known points
  knownp = KnownPointsComp(altitudes, cdist)
  kp = knownp$points

  # Slopes among the profiles
  slopes = -1 * abs(knownp$altdiff / knownp$distdiff)
  
  # number of new sections with constant slope
  nsl = length(slopes)

  altint = altitudes
  allslopes = rep(NA, length(altitudes))
  
  for(i in 1:nsl){
      
    vec1 = altitudes[kp[i]:kp[i+1]]

    for(j in kp[i]:kp[i+1]){
          
      L = cdist[j] - cdist[kp[i]]
      
      k = j-kp[i]+1
      
      if(is.na(vec1[k])){
      
        vec1[k] = vec1[1] + slopes[i] * L
        
      }
      
    }

    if(any(diff(vec1)>0)){
      stop('vec1: problem')
    }
    
    altint[kp[i]:kp[i+1]] = vec1
    allslopes[kp[i]:kp[i+1]] = slopes[i]
    
  }
  
  altitudes = altint  
  
  # Extrapolation of unknown tail values of altitudes 
  if(is.na(tail(altitudes,1))){
    lop = tail(kp,1) # last known position
    len_alt = length(altitudes)
    # Linear model for unknown tail altitude values
    model1 = lm(altitudes[1:lop]~cdist[1:lop])
    slope = model1$coeff[2]
    # Difference between last known altitude and lr line - needed for move of new points
    diffofLM = ((model1$coeff[1]+cdist[lop]*slope)-altitudes[lop]) 
    # Computation of new last altitudes
    for(i in c((lop+1):len_alt)){
      altitudes[i] = (model1$coeff[1] + cdist[i]*slope) - diffofLM
    }
    # Add new last slopes
    allslopes[(lop+1):len_alt] = slope
  }
  
  return(data.frame(altitudes = altitudes, slopes = allslopes))
  
}