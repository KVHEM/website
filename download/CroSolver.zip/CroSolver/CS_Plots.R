

PlotBanks = function(banks, distR, distL, avgdist, newbank = NA){

  # X,Y limits
  yrang = c(min(banks$Zr,banks$Zl),max(banks$Zr,banks$Zl))
  xrang = c(min(distR,distL,avgdist),max(distR,distL,avgdist))
  
  if(any(is.na(newbank)==FALSE)){
  
    yrang = c(min(newbank,yrang),max(newbank,yrang)) 
    
  }

  dev.new(width=14, height=6)
  par(mfrow = c(2,2))
  plot(distR,banks$Zr,type='l',ylim=yrang,xlim=xrang, xlab = 'Profile reference [m]', ylab = 'RIGHT measured Z [m asl]')
  
  if(any(is.na(newbank)==FALSE)){
  
    lines(avgdist,newbank,type='l',col='red')   
    
  }
  
  grid(NA, NULL) 
  plot(distL,banks$Zl,type='l',ylim=yrang,xlim=xrang, xlab = 'Profile reference [m]', ylab = 'LEFT measured Z [m asl]')
  
  if(any(is.na(newbank)==FALSE)){   
  
    lines(avgdist,newbank,type='l',col='red')
    
  }  
  
  grid(NA, NULL)
  
}


PlotEdgesAndBed = function(CS, rb, AD, toPrint){

  fr = 1
  to = nrow(CS)
  if(toPrint == 'horizontal'){
  
    plot(c(CS$Xr[fr:to], CS$Xl[fr:to]),c(CS$Yr[fr:to], CS$Yl[fr:to]), asp = 1, col = 'red', lwd = 1.5, xlab = 'X', ylab = 'Y', main = 'Bank and heel points')
    
    for(i in fr:to){
       
      lines(c(CS$Xr[i], rb$Xr[i], CS$Xl[i], rb$Xl[i]),c(CS$Yr[i], rb$Yr[i], CS$Yl[i], rb$Yl[i]), col = 'grey')
      
    }
    
    points(c(rb$Xr[fr:to], rb$Xl[fr:to]),c(rb$Yr[fr:to], rb$Yl[fr:to]), col = 'blue', lwd = 1, pch = 3)
    
    legend('bottomright', lty = c(-1,-1,1), pch = c(1,3,-1), col = c('red', 'blue', 'grey'), c('bank pts', 'slope heel pts', 'cross sec.'), lwd = c(1.5,1,1))
    
  } else if(toPrint == 'vertical') {
  
    plot(cumsum(AD), rb$Zr, type = 'l', ylim = c(min(rb$Zr,CS$Zr), max(rb$Zr,CS$Zr)), xlab = 'cross sec. distance [m]', ylab = 'altitude [m asl]', main = 'Water level and riverbed')
    lines(cumsum(AD),CS$Zr, col = 'blue')
    
    legend('bottomleft', lty = c(1, 1), col = c('blue', 'black'), c('water level', 'riverbed'))
  
  }

}