CroSolver = function(data, Q, n, mindist = NULL, CStype = 'trapezoid', sideslope = 1/3, sorting = FALSE, ordering = FALSE, cross_sec = TRUE, plotResults = FALSE){
  # data - XYZ of right and lef bank (6 columns, no header, . separator) 
  # Q - design discharge [m^3/s]
  # n - Mannings roughness coeficient
  # CStype - cross section type 
  # mindist - minimal allowed mean distance between two measured CScomplete12 [m]
  # sideslope - slope of channel sides
  # sorting - find the nearest pairs of right and left points of river banks
  # ordering - ordering of crossections
  # cross_sec - create new cross sections (CS) - perpendicular to river axis
  # plotResults - plot the results
  
  source('CS_SortCoor.R')  
  source('CS_CrossSections.R')
  source('CS_Distances.R')
  source('CS_WLaltitude.R')
  source('CS_Channel.R')  
  source('CS_Plots.R')

  # Identification of header and decimal separator
  iden = read.table(data, nrow = 1)
  h = is.numeric(iden[1,1])
  iden = read.table(data, header = h)
  decs = ifelse(is.numeric(iden[1,1]), '.', ',')

  # Load measured Input Coordinates of points
  InC = read.table(data, header = h, dec = decs)
  
  # Column names - 1:3 Right bank, 4:6 Left bank (r - right, l - left bank)
  colnames(InC) = c('Xr','Yr','Zr','Xl','Yl','Zl')

  # Sorting of original data - find shortest cross section between right and left river banks
  if(sorting){
  
    InC = SortCoor(InC)
    
  }
  
  # ordering of bad sorted cross sections
  if(ordering){
  
    InC = TryToSort(InC)
    
  }
 
  # Change of CS order - first row - highest CS in the mean of river 
  ZMainModel = lm(InC$Zr ~ c(1:length(InC$Zr)))
  ZMainSlope = coef(ZMainModel)[2]
  if(ZMainSlope > 0) {
  
    InC = InC[nrow(InC):1,]
    
  }
  
  # New coordinates of cross sections - perpendicular to middle line of river (middle line is computed as the middle of joint line of measured points)
  if(cross_sec){
  
    CS = CompCrossSections(InC, plotNewCS = FALSE)
    
  } else{
  
    CS = InC
    
  }
 
  # Cross Section dimensions - dist between bank points, axis points and width of CS
  CSdim = GetDistances(CS) # list with CSdim and coordintates of average points 
  
  # New altitude of CS banks (only one vector, after adjustment: Zr == Zl )
  newroute = CompAltSlope(CS, CSdim$axisDist, mindist)
  newCS = CS
  newCS$Zr = newCS$Zl = newroute$altitudes
 
  # Compute the channel
  channel = CompChannel(newCS, abs(newroute$slopes), CSdim$CSwidth, Q, n, CStype, sideslope, CSdim$axisDist)
  
  if(plotResults){
  
    # Right and left Z + new Z
    PlotBanks(CS, cumsum(CSdim$Rdist), cumsum(CSdim$Ldist), cumsum(CSdim$axisDist), newroute$altitudes)  
    
    # Plot of CS banks and heels
    PlotEdgesAndBed(newCS, channel, CSdim$axisDist, 'horizontal')
    PlotEdgesAndBed(newCS, channel, CSdim$axisDist, 'vertical')
  
  }
  
  CScomplete12 = cbind(newCS,channel)
  names(CScomplete12) = c('X_R_Hi','Y_R_Hi','Z_R_Hi','X_L_Hi','Y_L_Hi','Z_L_Hi','X_R_Lo','Y_R_Lo','Z_R_Lo','X_L_Lo','Y_L_Lo','Z_L_Lo')
  CScomplete3 = CScomplete12
  names(CScomplete3) = rep(c('X','Y','Z'), 4)
  CScomplete3 = rbind(CScomplete3[,1:3], CScomplete3[,4:6], CScomplete3[,7:9], CScomplete3[,10:12])
  
  if(file.exists("Outputs") == FALSE){
  
     dir.create("Outputs")
     
  }
  
  write.table(round(CScomplete12, 4), file = 'Outputs/NewXYZ_12_col.txt', row.names = F, quote = F)
  write.table(round(CScomplete3, 4), file = 'Outputs/NewXYZ_3_col.txt', row.names = F, quote = F)
  return('Done!') 

}

