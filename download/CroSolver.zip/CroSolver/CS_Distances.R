
DistComp = function(x1,y1,x2,y2){
  # Computation of distances
  # x, y CSdinates
  dist = sqrt((x1 - x2)^2 + (y1 - y2)^2)
  return(dist)
  
}


GetDistances = function(CS){
  
  nr = nrow(CS)
  
  # Distance of CS left and right point MOZNA ZRUSIT ???
  Rdist = c(0, DistComp(CS$Xr[1:(nr-1)],CS$Yr[1:(nr-1)],CS$Xr[2:nr],CS$Yr[2:nr])) # first distance 0 - useless
  Ldist = c(0, DistComp(CS$Xl[1:(nr-1)],CS$Yl[1:(nr-1)],CS$Xl[2:nr],CS$Yl[2:nr])) # first distance 0 - useless
  
  # Coordinates of average profile
  CSaxis = data.frame(X = (CS$Xr+CS$Xl)/2, Y = (CS$Yr+CS$Yl)/2)

  axisDist = c(0, DistComp(CSaxis$X[1:(nr-1)],CSaxis$Y[1:(nr-1)],CSaxis$X[2:nr],CSaxis$Y[2:nr]))
  
  # Width of the profiles
  CSwidth = DistComp(CS$Xr,CS$Yr,CS$Xl,CS$Yl)

  # Returns right and left bank xy point distances, average distance among profiles, xy CSdinates of avg profiles and width of the profiles
  return(data.frame(Rdist = Rdist, Ldist = Ldist, axisDist = axisDist, CSwidth = CSwidth))

}