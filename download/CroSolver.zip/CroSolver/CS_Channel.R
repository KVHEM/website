
CompQ = function(B, i, h, ss, n){
  # B - width in water level
  # h - estimated depth
  # ss - side slope
  # n - Mannings roughness coefficient
  a = h/ss
  b = B - 2*a
  O = b + 2*sqrt(a^2+h^2)
  S = b*h + a*h
  R = S/O
  C = R^(1/6)/n 
  Q = S*C*sqrt(R*i)
  if(is.nan(Q)) browser()
  return(Q)
}

CompRiverBed = function(banks, depths, pt, ss = NULL, avgdists){
  
  if(pt == 'trapezoid'){
  
    riverbed = banks
    
    # altitude of slope heel 
    riverbed$Zr = riverbed$Zl = riverbed$Zr - depths
    
    # Horizontal length between edge and heel of slope
    hl = depths/ss
    
    # edge length
    el = DistComp(riverbed$Xr, riverbed$Yr, riverbed$Xl, riverbed$Yl)
    
    # ratio of horizontal length and edge length
    ratio_hlel = hl/el
    
    # New coordinates by triangle similarity
    riverbed$Xr = riverbed$Xr - ratio_hlel * (riverbed$Xr - riverbed$Xl)
    riverbed$Xl = riverbed$Xl + ratio_hlel * (riverbed$Xr - riverbed$Xl)
    riverbed$Yr = riverbed$Yr - ratio_hlel * (riverbed$Yr - riverbed$Yl)
    riverbed$Yl = riverbed$Yl + ratio_hlel * (riverbed$Yr - riverbed$Yl)
  
  }
  
  return(riverbed)
  
}


CompChannel = function(banks, slopes, pw, Q, n, pt, ss, avgdists){ # avgdists pro ucely plotu ve fci CompRiverBed
  # banks - adjusted banks
  # slopes - slopes among the profiles
  # pw - profiles width
  # Q - measured discharge
  # n - Mannings roughness coefficient
  # pt - profile type
  # ss - channel side slope
  
  nr = nrow(banks)
  dh = 0.01
  depths = rep(NA,nr)
  
  for(i in 1:nr){
  
    Qest = 0
    h = 0
    
    while(Qest<Q){
    
      h = h+dh
      Qest = CompQ(pw[i], slopes[i], h, ss, n)   
      
    }
    
    depths[i] = h
    
  }
  
  riverbed = CompRiverBed(banks, depths, pt, ss, avgdists)
    
  return(riverbed)

}