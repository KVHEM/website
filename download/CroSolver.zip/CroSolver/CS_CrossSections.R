LinesCF = function(x, y){ 
  # Returns a and b coeficients of lin. eq in form y = A*x+B
  n = length(x)
  if(!0 %in% (x[2:n] - x[1:(n-1)])){
  
    A = (y[2:n] - y[1:(n-1)]) / (x[2:n] - x[1:(n-1)])
    B = -A * x[2:n] + y[2:n]
    
  } else {
    
    stop('JMENOVATEL == 0, fce: LinesCF')
    
  } 
  
  return(data.frame(A, B) ) 
  
}

PerpLineCF = function(x, y, slope, first = FALSE){ 
  # returns eq. of perpendicular line

  A = -1 / slope
  if(first){
    A = c(A[1], A) # prvni bod je dublovan - neni znama rovnice primky k nemu jdouci
  }
  B = -A * x + y

  return(data.frame(A, B)) 
  
}

CompCrossSections = function(OC, plotNewCS = FALSE){
  # OC are Original Coordinates
  
  Intersections = function(Ints, PE, BE, BP){
    # Ints - Data frame of intersections & co.
    # PE - Perpendicular lines Equation
    # BE - Bank Equation coefficients
    # BP - Bank points X, Y and Z
  
    names(BP) = c('X', 'Y', 'Z')
    nBP = nrow(BP)
    t=0
    for(i in 1:nBP){  
    
      isP = data.frame(X = NA, Y = NA, Z = NA) # intersection point
      
      j = i
      found = FALSE
      while(found == FALSE){
      
        #Matice pro vypocet pruseciku
        AR = matrix( c(PE$A[i], BE$A[j], -1,-1), nrow=2, ncol=2 )
        BR = as.matrix( c(PE$B[i], BE$B[j]) )  # a column matrix   
        
        isP[,1:2] = -solve(AR) %*% BR
        
        # Vypocet prvniho pruseciku
        if(i == 1){
        
          isP$Z = BP$Z[1] + (BP$Z[1] - BP$Z[2]) * (DistComp(isP$X[1], isP$Y[1], BP$X[2], BP$Y[2]) / DistComp(BP$X[1], BP$Y[1], BP$X[2], BP$Y[2]))
          Ints[1,] = c(BP$X[1], BP$Y[1], BP$X[2], BP$Y[2], BE$A[1], BE$B[1], isP)
          break
          
        }
        
        # Vypocet vzdalenosti pruseciku od krajnich bodu segmentu
        distBP = DistComp(BP$X[j-1], BP$Y[j-1], BP$X[j], BP$Y[j])
        dist1 = DistComp(isP$X[1], isP$Y[1], BP$X[j-1], BP$Y[j-1])
        dist2 = DistComp(isP$X[1], isP$Y[1], BP$X[j], BP$Y[j])
        
        # Identifikace prislusnosti pruseciku do segmentu
        p1check = dist1 <= distBP 
        p2check = dist2 <= distBP
        
        if(p1check & p2check | i == nBP){
        
          isP$Z = BP$Z[j] + (BP$Z[j-1] - BP$Z[j]) * (dist2 / distBP)
          Ints[i, ] = c(BP$X[j-1], BP$Y[j-1], BP$X[j], BP$Y[j], BE$A[j], BE$B[j], isP)
          found = TRUE

        } else if(dist1 > dist2) {
      
          j = j + 1

        } else if(dist2 > dist1) { 
 
          j = j - 1  
        
          if(j <= 2){
          
            isP$Z = BP$Z[j] + (BP$Z[j-1] - BP$Z[j]) * (dist2 / distBP)
            Ints[i, ] = c(BP$X[j-1], BP$Y[j-1], BP$X[j], BP$Y[j], BE$A[j], BE$B[j], isP)
            found = TRUE

          }
        
        }
      
      }
    
    }
    return(Ints)
  }
   
  # X, Y, Z coordinates of River Axis (on water level). Z coor. will be computed as average between original cross section points
  Axis = data.frame(X = (OC$Xr+OC$Xl)/2, Y = (OC$Yr+OC$Yl)/2, Z = (OC$Zr+OC$Zl)/2 )
  
  nOC = nrow(OC)
  RBlmCf = LBlmCf = data.frame(A = rep(NA,nOC), B = rep(NA,nOC))

  RBlmCf[2:nOC,] = LinesCF(OC$Xr, OC$Yr)
  LBlmCf[2:nOC,] = LinesCF(OC$Xl, OC$Yl) 
  RBlmCf[1,] = RBlmCf[2,]
  LBlmCf[1,] = LBlmCf[2,]
  
  AxisLinesCF = LinesCF(Axis$X, Axis$Y) 
 
  PlCf = PerpLineCF(Axis$X, Axis$Y, AxisLinesCF$A, TRUE)

  # Identification of intersection of segment and CS line
  InsRight = InsLeft = as.data.frame(array(NA, dim = c(nOC, 9)))  # segment for intersection
  colnames(InsRight) = colnames(InsLeft) = c('P1X', 'P1Y', 'P2X', 'P2Y', 'segEQ_A', 'segEQ_B', 'InsX', 'InsY', 'InsZ')

  InsRight = Intersections(InsRight, PlCf, RBlmCf, OC[,1:3])
  InsLeft = Intersections(InsLeft, PlCf, LBlmCf, OC[,4:6])

  if(plotNewCS){
    fr = 1
    to = nrow(Axis)
    plot(Axis$X[fr:to], Axis$Y[fr:to], type = 'l', asp = 1, xlab = 'X', ylab = 'Y', main = 'New cross sections')
    lines(OC$Xr[fr:to], OC$Yr[fr:to])
    lines(OC$Xl[fr:to], OC$Yl[fr:to])

    for(i in fr:to){
      segments(InsRight$InsX[i],InsRight$InsY[i],InsLeft$InsX[i],InsLeft$InsY[i])
    }
    points(InsRight$InsX,InsRight$InsY, col = 'red')
    points(InsLeft$InsX,InsLeft$InsY, col = 'blue')
    
    segments(InsRight$InsX[1],InsRight$InsY[1],InsLeft$InsX[1],InsLeft$InsY[1], col = 'green', lwd = 3)
    
    legend('bottomright', lty = c(1,-1,-1,1), pch = c(-1,1,1,-1), col = c('black', 'red', 'blue', 'green'), 
           c('axis, banks, cross sec.', 'right bank', 'leftbank', 'highest cross s.'), lwd = c(1,1,1,3))
  }
  
  CScoordinates = data.frame(cbind(InsRight[,7:9], InsLeft[,7:9]))
  colnames(CScoordinates) = c('Xr','Yr','Zr','Xl','Yl','Zl')
  return(CScoordinates)  

}
