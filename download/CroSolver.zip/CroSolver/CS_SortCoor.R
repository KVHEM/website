TryToSort = function(OldCoor){
  
  C2S = data.frame(X = OldCoor$Xr, Y = OldCoor$Yr, no = c(1:nrow(OldCoor))) 
  i = 1
  j = 0
  endConst = nrow(C2S)^2 

  while (i <= (nrow(C2S)-2)){

    LCFS = LinesCF(C2S$X[i:(i+1)], C2S$Y[i:(i+1)])
    KolmCF = PerpLineCF(C2S$X[(i+1)], C2S$Y[(i+1)], LCFS$A[1])
    nKolm = nrow(KolmCF)
    A = KolmCF$A[nKolm]
    B = KolmCF$B[nKolm]
    
    polr = ((A * C2S$X[i] - C2S$Y[i] + B) * (A * C2S$X[i+2] - C2S$Y[i+2] + B))
    if(is.finite(polr) & polr > 0 ){
    
      C2Schng = C2S[i+1,]
      C2S[i+1,] = C2S[i+2,]
      C2S[i+2,] = C2Schng 
      i = max(1, i-2)
      
    } else {
    
      i = i + 1
      
    }

    j = j + 1
    if(j >= endConst) {stop('SPATNY PRUBEH PUVODNICH DAT')}

  }
  
  OldCoor[1:nrow(OldCoor),] = OldCoor[C2S$no,]

}

SortCoor = function(OldCoor){

  # Distances betwenn first right bank (RB) point and left bank (LB) points and vice versa
  RxL_first = DistComp(OldCoor$Xr[1], OldCoor$Yr[1], OldCoor$Xl, OldCoor$Yl)
  LxR_first = DistComp(OldCoor$Xl[1], OldCoor$Yl[1], OldCoor$Xr, OldCoor$Yr)
  
  # Distances betwenn last right bank (RB) point and left bank (LB) points and vice versa
  lp = nrow(OldCoor)
  RxL_last = DistComp(OldCoor$Xr[lp], OldCoor$Yr[lp], OldCoor$Xl, OldCoor$Yl)
  LxR_last = DistComp(OldCoor$Xl[lp], OldCoor$Yl[lp], OldCoor$Xr, OldCoor$Yr)
  
  
  # Identification of column with minimal value (Positon of Minimal - colMin)
  arrFirst = cbind(RxL_first, LxR_first)
  firstPos = which(arrFirst == min(arrFirst), arr.ind = TRUE)   

  # Position of minimal value. If minimum is in RxL then POSITION must be identified from RxL vector of lengths and vice versa  
  arrLast = cbind(RxL_last, LxR_last)
  lastPos = which(arrLast == min(arrLast), arr.ind = TRUE)  

  colMinFirst = firstPos[1,2]
  rowMinLast = lastPos[1,1]
  
  # Main and minor bank columns. If minimum is in RxL then main coordinats are from Right bank and vice versa
  if(colMinFirst == 1){
  
    mainRange = 1:3
    minorRange = 4:6
    mb = 'right'
    
  } else if(colMinFirst == 2){
  
    mainRange = 4:6
    minorRange = 1:3
    mb = 'left' 
    
  }
  
  # Main and minor bank coordinates
  mainBank = OldCoor[1:rowMinLast,mainRange]
  minorBank = OldCoor[1:rowMinLast,minorRange] 

  # Deleting duplicate points
  dplp = duplicated(mainBank)
  if(sum(dplp)>0){
    mainBank = mainBank[-which(dplp),]
  }
  
  # Sorted Bank Coordinates
  nr = nrow(mainBank)
  sbc = as.data.frame(array(NA,dim = c(nr,6)))
  colnames(sbc) = colnames(OldCoor)
  sbc[,mainRange] = mainBank
  
  # Searching for oposite points of profile - by using minimal distance
  colnames(mainBank) = colnames(minorBank) = c('X','Y','Z')
  
  for(i in 1:nr){
    sbc[i,minorRange] = minorBank[which.min(DistComp(mainBank$X[i], mainBank$Y[i], minorBank$X, minorBank$Y)),]
  }
 
  return(sbc)

}