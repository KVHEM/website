

INPUTS = function(name){
  
  path = paste("Inputs/", name, sep="")

  data1 = read.table(path) 

  nr_data = nrow(data1)
  nc_data = ncol(data1)

  if(is.numeric(data1[1,1]) == FALSE) {

    data1 = data1[2:nr_data,]
    nr_data = nr_data-1

  }

  if(is.character(TrainSet) & is.character(ValidSet) == FALSE){
    stop("both TrainSet & ValidSet must be a vector or character")
  }

  if(is.character(TrainSet) == FALSE & is.character(ValidSet)){
    stop("both TrainSet & ValidSet must be a vector or character")
  }

  data2 = array(c(0),dim = c(nr_data,nc_data))
    
  for(j in 1:nc_data){

    data2[1:nr_data,j] = data1[1:nr_data,j]

  }


  if(is.character(TrainSet) & is.character(ValidSet)){

    nrt = round(nr_data * (1-ValRatio) ,0)

    inpT = data2[1:nrt,1:(nc_data-1)]

    obsT = data2[1:nrt,nc_data]

    inpV = data2[(nrt+1):nr_data,1:(nc_data-1)]

    obsV = data2[(nrt+1):nr_data,nc_data]

  } else{

    num_dat_T = length(TrainSet)/2

    range_arr_T = matrix(c(TrainSet), nrow=num_dat_T , ncol=2, byrow = TRUE)

    new_lengths = (range_arr_T[,2] - range_arr_T[,1]) + 1

    cnl = cumsum(new_lengths)

    inpT = array(c(-1), dim = c(sum(new_lengths), (nc_data-1)))
    obsT = array(c(-1), dim = c(sum(new_lengths), 1))

    new_row = 1
    for(i in 1:num_dat_T){

	    inpT[new_row:cnl[i],] =  data2[range_arr_T[i,1]:range_arr_T[i,2],1:(nc_data-1)]
	    obsT[new_row:cnl[i],] =  data2[range_arr_T[i,1]:range_arr_T[i,2],nc_data]
	    new_row = cnl[i]+1

    }


    num_dat_V = length(ValidSet)/2

    range_arr_V = matrix(c(ValidSet), nrow=num_dat_V , ncol=2, byrow = TRUE)

    new_lengths = (range_arr_V[,2] - range_arr_V[,1]) + 1

    cnl = cumsum(new_lengths)

    inpV = array(c(-1), dim = c(sum(new_lengths), (nc_data-1)))
    obsV = array(c(-1), dim = c(sum(new_lengths), 1))

    new_row = 1
    for(i in 1:num_dat_V){

	    inpV[new_row:cnl[i],] =  data2[range_arr_V[i,1]:range_arr_V[i,2],1:(nc_data-1)]
	    obsV[new_row:cnl[i],] =  data2[range_arr_V[i,1]:range_arr_V[i,2],nc_data]
	    new_row = cnl[i]+1

    }
      
  }

  list(inpT = inpT, obsT = obsT, inpV = inpV, obsV = obsV, n_col = nc_data, n_row = nr_data)

}



PRINT_INPUTS = function(inputs){

  print("VSTUPY TRENOVANI")
  print(inputs$inpT)
  print("REFERENCE TRENOVANI")
  print(inputs$obsT)
  print("VSTUPY VALIDACE")
  print(inputs$inpV)
  print("REFERENCE  VALIDACE")
  print(inputs$obsV)

  print("************************")

}



inputs = INPUTS(InputFile)
