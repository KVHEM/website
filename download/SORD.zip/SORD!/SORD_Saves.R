
SAVE_VALUES = function(fd_list, ngen, best_prg, val_prg, obs_dataT, obs_dataV, run){

    # UMISTENI VYSLEDKU
    fold_name = paste("Outputs/run_", run, sep="")

    # HODNOTY PRUBEHU MIN. FITNESS
    to_save = paste(fold_name,"/MinFit_", run, ".txt",sep="")
    len_fd = length(fd_list$fit_min)
    data_to_write = array(c(-1),dim=c(len_fd,2))
    data_to_write[,1] = c(0:(len_fd-1))
    data_to_write[,2] = round(fd_list$fit_min,6)
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Generation", paste("Min.fit.(",FitType,")",sep="")),sep="\t")

    # HODNOTY PRUBEHU MEAN FITNESS
    to_save = paste(fold_name,"/MeanFit_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(len_fd,2))
    data_to_write[,1] = c(0:(len_fd-1))
    data_to_write[,2] = round(fd_list$fit_mean,6)
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Generation", paste("Mean.fit.(",FitType,")",sep="")),sep="\t")

    # HODNOTY PRUBEHU HLOUBEK STROMU U NEJLEPSIHO PROGRAMU
    to_save = paste(fold_name,"/BestPrgDepth_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(len_fd,2))
    data_to_write[,1] = c(0:(len_fd-1))
    data_to_write[,2] = fd_list$depth_best_prg
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Generation", "BestPrgDepth"),sep="\t")

    # HODNOTY PRUBEHU HLOUBEK STROMU
    to_save = paste(fold_name,"/MeanDepth_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(len_fd,2))
    data_to_write[,1] = c(0:(len_fd-1))
    data_to_write[,2] = fd_list$depth_mean
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Generation", "MeanDepth"),sep="\t")

    # HODNOTY DAT TRENOVANI
    to_save = paste(fold_name,"/Training_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(length(obs_dataT),2))
    data_to_write[,1] = obs_dataT
    data_to_write[,2] = round(best_prg$comp_val,6)
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Observed", "Computed"),sep="\t")

    # HODNOTY DAT VALIDACE
    to_save = paste(fold_name,"/Validation_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(length(obs_dataV),2))
    data_to_write[,1] = obs_dataV
    data_to_write[,2] = round(val_prg$comp_val,6)
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = c("Observed", "Computed"),sep="\t")

    # VYSLEDNA ROVNICE
    to_save = paste(fold_name,"/Expression_", run, ".txt",sep="")
    data_to_write = best_prg$expr
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = FALSE)

    # DRIVE VECTOR
    to_save = paste(fold_name,"/DriveVector_", run, ".txt",sep="")
    data_to_write = best_prg$drive_vec
    write.table(data_to_write, file = to_save, row.names = FALSE, col.names = FALSE)

    # HODNOTY UKAZATELU
    to_save = paste(fold_name,"/AllFitness_", run, ".txt",sep="")
    data_to_write = array(c(-1),dim=c(2,ncol(best_prg$fit_arr)))
    data_to_write[1,] = as.numeric(best_prg$fit_arr[2,])
    data_to_write[2,] = as.numeric(val_prg$fit_arr[2,])
    write.table(data_to_write, file = to_save, row.names = c("Training","Validation"), col.names = FitNamVec, sep="\t")

}

