PRINT_INI = function(ni_pop){

  for (i in 1:ni_pop){

    flow_prg = paste("prg",i,sep="")
    active_prg = get(flow_prg)

    # POLE PROGRAMU
    print("ARRAY")
    print(active_prg$arr)

    # STRUKTURA PROGRAMU
    print(paste("PROGRAM ",i, ":",sep=""))
    print(active_prg$drive_vec)

    # VYSLEDNA HODNOTA FITNESS
    print("FITNESS")
    print(active_prg$fit)

    # VYSLEDNY VZOREC
    print("EXPRESSION")
    print(active_prg$expr)

    print("************************")

  }

}

# POCATECNI POPULACE
# dale jsou jedinci k dispozici jako prg1, prg2,..., prgN

# ARITY FUNKCI
Functions$arity = GET_ARITY(Functions$typ)

# RAMPED_HALF_AND_HALF
if(MaxDepthIni > 1){
  n_groups = MaxDepthIni - 1
}
if(MaxDepthIni <= 1){
  n_groups = 1
}

np_in_grps = floor(NiPop / n_groups)

np_vec = rep(np_in_grps,n_groups)

np_vec[length(np_vec)] = np_vec[length(np_vec)] + (NiPop - sum(np_vec))

np_vec = cumsum(np_vec)

# PRIPRAVA POLE PRO FITNES A ID_PROGRAMU
Fit_arr = array(c(0),dim = c(NiPop,2))

# PRIPRAVA POLE PRO DELKU A ID_PROGRAMU
Len_arr = array(c(0),dim = c(NiPop,2))

# VYTVORENI POCATECNI POPULACE PROGRAMU METODOU RAMPED HALF AND HALF
max_depth_ramped = 2
j = 1
method = 0

for (i in 1:NiPop){

  if(i > np_vec[j]){
    
    max_depth_ramped = max_depth_ramped + 1
    j = j + 1

  }
  
  if(method == 0){

    method = 1

  } else{

    method = 0
  
  }

  # VYTVORENI JEDINCE, PROMENNA indX
  flow_ind = paste("ind",i,sep="")

  assign(flow_ind,CREATE_INDIVIDUAL(max_depth_ramped, Functions, Terminals, method))

  # VYPOCET JEDINCE, PROMENNA prgX
  flow_prg = paste("prg",i,sep="")

  assign(flow_prg,COMP_PRG(get(flow_ind),Terminals,inputs$inpT,inputs$obsT,FitType,0)) 

  # DOPLNENI POLE FITNESS
  active_prg = get(flow_prg)
  
  Fit_arr[i,] = c(i,active_prg$fit)
  Len_arr[i,] = c(i,active_prg$len)

}

# # PRINT VYSLEDKU
# PRINT_INI(NiPop)

