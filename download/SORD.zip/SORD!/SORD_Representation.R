
PROB_RAND = function(inp_list){

  cum_prob = cumsum(inp_list$prob)
  rand_val = runif(1,0,1)
  position = min(which(cum_prob >= rand_val))
  outval = inp_list$typ[position]
  outval

}


# NAHODNA VOLBA FUNKCE
RAND_F = function(functions){

  if(sum(functions$prob) == 0){

    F = sample(functions$typ,1)

  } else{

    F = PROB_RAND(functions)

  }

  F

}


# NAHODNA VOLBA TERMINALU
RAND_T = function(terminals){

  if(sum(terminals$prob) == 0){

    T = sample(terminals$typ,1)

  } else{

    T = PROB_RAND(terminals)

  }

  T

}


# NAHODNA VOLBA HODNOTY UZLU
RAND_FT = function(functions,terminals){

  x = rnorm(1,0,1)

  if(x > 0) {

    FT = RAND_F(functions)

  }

  if(x <= 0) {

    FT = RAND_T(terminals)

  } 

  FT

}


# HODNOTA UZLU
NODE = function(functions, terminals, method, terminal = FALSE){

  if(terminal == FALSE){

    #NAHODNY VYBER FUNKCE NEBO TERMINALU PRI RUSTOVE METODE
    if(method == 0){

      attributes = RAND_FT(functions, terminals)
      node_id = attributes
	  
    }

    #NAHODNY VYBER FUNKCE NEBO TERMINALU PRI UPLNE METODE
    if(method == 1){

      attributes = RAND_F(functions)
      node_id = attributes

    }

  } else{

    attributes = RAND_T(terminals)
    node_id = attributes

  }

  node_id

}


# DOPLNENI SOURADNIC UKAZATELU UZLU
NODE_IDENTIFY = function(functions, new_row, node_id){

  numcol = max(functions$arity)+1

  tuple = rep(-1,numcol)
  tuple[1] = node_id

  if(node_id > 900) {

    n_arit = functions$arity[which(functions$typ == tuple[1])]

    for (i in 1:n_arit){

	new_row = new_row + 1
	tuple[i+1] = new_row

    }

  }

  list(tuple = tuple, new_row = new_row)

}


# VYTVORENI JEDINCE
CREATE_INDIVIDUAL = function(max_depth, functions, terminals, method,  nc_data) {

  # MAX. ARITA FUNKCÍ
  max_ar = max(functions$arity)

  #POCET SLOUPCU POLE PROGRAMU
  numcol = max_ar+1

  # MAX POCET RADKU POLE PROGRAMU
  numrow = 1
  if(max_depth > 0){

    for(i in 1:max_depth){

      numrow = numrow + max_ar^i

    }

  }

  # PRIPRAVA POLE PROGRAMU
  PRG = array(c(-1), dim=c(numrow, numcol))

  # PRVNI RADEK PROGRAMU
  if(max_depth == 0){

    new_node = NODE(functions, terminals, method, terminal = TRUE)
    node_full = NODE_IDENTIFY(functions,1,new_node)
    PRG[1,1:numcol] = node_full$tuple
    vec_id = PRG[,1]
    return(list(fit = NA, drive_vec = vec_id, arr = PRG, len = 1, change = 0, comp_val = NA))

  } else{

    new_node = NODE(functions, terminals, method)
    node_full = NODE_IDENTIFY(functions,1,new_node)
    PRG[1,1:numcol] = node_full$tuple

  }

  # POCATECNI NASTAVENI AKTUALNI HLOUBKY A RADKU, MAXIMALNIHO RADKU V HLOUBCE, PROMENNE NOVEHO RADKU
  act_depth = 1
  act_row = 1
  max_row_level = 1
  new_row = node_full$new_row

  # KONSTRUKCE POLE PROGRAMU
  while(act_depth <= max_depth){
 
    act_col = 2

    # KONSTRUKCE CILOVYCH UZLU PRO UKAZATELE UZLU AKTUALNIHO
    while(act_col <= numcol && PRG[act_row,act_col] > -1 ){

      if(act_depth < max_depth){

	new_node = NODE(functions, terminals, method = method) 

      }

      if(act_depth == max_depth){

	new_node = NODE(functions, terminals, method = method, terminal = TRUE) 

      }

      node_full = NODE_IDENTIFY(functions, new_row, new_node)

      PRG[PRG[act_row,act_col],1:numcol] = node_full$tuple

      new_row = node_full$new_row

      act_col = act_col + 1

    }

    # ZMENA HLOUBKY STROMU
    if(act_row == max_row_level){

      max_row_level = max(PRG[1:act_row,2:numcol])

      act_depth = act_depth + 1
    
    }

    act_row = act_row + 1

    # UKONCENI HLAVNIHO CYKLU
    if(PRG[act_row,1] == -1) {

      act_depth = max_depth + 1

    }

  }

  # ZKRACENI POLE PROGRAMU
  prg_numrow = max(which(PRG[,1] > -1))
  PROGRAM = array(PRG[1:prg_numrow,], dim = c(prg_numrow, numcol))

  # RIDICI VEKTOR HODNOT V UZLECH
  vec_id = PROGRAM[,1]

  list(arr = PROGRAM, drive_vec = vec_id,  len = prg_numrow, change = 0, comp_val = NA, expr = NA, fit = NA, fit_arr = NA)

}
