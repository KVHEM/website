
source("SORD_Time.R")
start_time = PROC_TIME("start",NA)

# PRIPRAVA SLOZEK PRO VYSLEDKY
if(PrintOutput == "both" | PrintOutput == "file"){

  #ADRESAR VYSTUPU
  system("rm -rf Outputs")
  system("mkdir Outputs")

  for(run in 1:Runs){

    fold_create = paste("mkdir Outputs/run_", run, sep="")
    system(fold_create)
    
  }

}

cha_vec = c("+", "-", "*", "Pdiv", "Psqrt", "Plog", "Pexp", "Plog10", "sigmoid",
	    "sin", "cos", "tan", "tanh", "max", "min", "hstep", "sign",
	    "SMA", "RES", "DLY")
num_vec = c(901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 1001, 2001, 3001)
for (i in 1:length(Functions$typ)){

 Functions$typ[i] = num_vec[which(cha_vec == Functions$typ[i])]

}

Functions$typ = as.numeric(Functions$typ)

for(run in 1:Runs){

  print("*****************")
  print(paste(run,". PROGRAM RUN",sep=""))
  print("*****************")

  source("SORD_Inputs.R")
  source("SORD_Representation.R")
  source("SORD_Functions.R")
  source("SORD_Compute.R")
  source("SORD_InitPop.R")
  source("SORD_Selection.R")
  source("SORD_TreeVariate.R")
  source("SORD_Mutation.R")
  source("SORD_Crossover.R")
  source("SORD_Results.R")
  source("SORD_Plots.R")
  source("SORD_Saves.R")
  source("SORD_Run.R")

  best_prg = BEST_PRG(NiPop)
  validated_prg = VALIDATE(best_prg)


  PLOT_GRAPHS(fit_depth_list, Ngen, best_prg, validated_prg, inputs$obsT, inputs$obsV, run, PrintOutput)
  SAVE_VALUES(fit_depth_list, Ngen, best_prg, validated_prg, inputs$obsT, inputs$obsV, run)

  if( file.exists("Rplots.pdf") ){
    system("rm -rf Rplots.pdf")
  }
  
}

actual_folder = paste(Sys.Date(),format(Sys.time(), "%X"),sep="_")
actual_folder = gsub("[[:blank:]]+", "", actual_folder)

if(Clean){
  system("rm -rf All_runs_summary")
}

if( file.exists("All_runs_summary") ==  FALSE ){
  system("mkdir All_runs_summary")
}

system(paste("mkdir All_runs_summary/", actual_folder, sep = ""))

RUNS_RESULT(Runs, inputs$obsT, inputs$obsV)

stop_time = PROC_TIME("stop",start_time)


#################################################################
