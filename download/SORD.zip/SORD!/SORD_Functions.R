
GET_ARITY = function(ftype_vec){

  arity_vec = c()

  for(i in 1:length(ftype_vec)){

    if(any(c(901,902,903,904,914,915) == ftype_vec[i])){
      
      arity_vec = c(arity_vec,2)

    }

    if(any(c(905,906,907,908,909,910,911,912,913,916,917) == ftype_vec[i])){
      
      arity_vec = c(arity_vec,1)

    }

    if(ftype_vec[i] >= 1001){
      
      arity_vec = c(arity_vec,2)

    }

  }

  arity_vec

}


Pdiv = function(x1, x2){

  if(any(x2 == 0)){

    x2[which(x2 == 0)] = 1
  
  } 

  out = x1 / x2 

  out

}


Psqrt = function(x){

  out = sqrt(abs(x))

  out

}


Plog = function(x){

  x = abs(x)

  if(any(x == 0)){

    x[which(x == 0)] = 1e-9

  }

  out = log(x)

  out

}

Plog10 = function(x){

  x = abs(x)

  if(any(x == 0)){

    x[which(x == 0)] = 1e-9

  }

  out = log10(x)

  out

}


Pexp = function(x){

  if(any(x > 20)){

    x[which(x > 20)] = 20

  }

  out = exp(x)

  out

}

sigmoid = function(x){

  if(any(x < -20)){

    x[which(x < -20)] = -20

  }

  out = 1/(1+exp(-x))

  out

}

hstep = function(x){

  x[which(x >= 0)] = 1
  x[which(x < 0)] = 0

  out = x

  out

}


SMA = function(variable, shift){

  if(is.vector(variable) == FALSE | length(variable) == 1){

    return(variable)

  } else{

    shift = abs(round(shift,0))

    if(length(shift) == 1){

      mov_vec_starts = c(1:length(variable)) - rep(shift,length(variable))

    }
    
    if(length(shift) == length(variable)){

      mov_vec_starts = c(1:length(variable)) - shift[1:length(shift)]

    }

    mov_vec_ends = c(1:length(variable))

    mov_vec_starts[which(mov_vec_starts <= 0)] = 1

    out_vec = c()
    
    for(i in 1:length(mov_vec_starts)){

      out_vec = c(out_vec, mean(variable[mov_vec_starts[i]:mov_vec_ends[i]])) 

    }

    out_vec

  }

}



DLY = function(variable, shift){

  if(is.vector(variable) == FALSE | length(variable) == 1){

    return(variable)

  } else {

    shift = abs(round(shift,0))

    if(length(shift) == 1){

      dly_vec = c(1:length(variable)) - rep(shift,length(variable))

    }
    
    if(length(shift) == length(variable)){

      dly_vec = c(1:length(variable)) - shift[1:length(shift)]

    }

    dly_vec[which(dly_vec <= 0)] = 1

    out_vec = c()

    for(i in 1:length(dly_vec)){

      out_vec = c(out_vec, variable[dly_vec[i]]) 

    }

    out_vec

  }

}



RESERVOIR = function(input, lin_par, nonlin_par,  storage){

  outflow = 1/abs(lin_par) * (storage + input)^nonlin_par 
  storage = storage + input - outflow

  if(is.na(storage)){storage = 0}
  if(is.nan(storage)){storage = 0}

  if(storage  < 0){

    storage = 0

  }

  list(outflow = outflow, storage = storage)

}


RES = function(variable, lin_par){

  if(is.vector(variable) == FALSE  | length(variable) == 1){

    return(variable)

  } else {

    lin_par = abs(lin_par)

    out_vec = c()
    storage = variable[1]

    if(length(lin_par) == 1){

      if(lin_par == 0){

	lin_par = 1e-9

      }

      for(i in 1:length(variable)){

	outres = RESERVOIR(variable[i],lin_par,1,storage)

	storage = outres$storage

	out_vec = c(out_vec, outres$outflow)

      }

    }

    if(length(lin_par) == length(variable)){

      if(any(lin_par == 0)){

	lin_par[which(lin_par == 0)] = 1e-9

      }

      for(i in 1:length(variable)){

	outres = RESERVOIR(variable[i],lin_par[i],1,storage)

	storage = outres$storage

	out_vec = c(out_vec, outres$outflow)

      }

    }

    out_vec

  }

}



