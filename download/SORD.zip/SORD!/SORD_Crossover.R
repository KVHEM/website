CROSS_NODE = function(dvec){

  if(any(dvec > 900)) {

    cn_prob = sample(c(0,rep(1,9)), 1)

    if(cn_prob == 0){

      cn = sample(which(dvec < 900),1)
      
    } else{

      cn = sample(which(dvec > 900),1)

    }

  } else{

    cn = 1

  }

  cn

}


CROSSOVER = function(winners,max_depth,nc_data_in,terminals,functions){ 

  parent_1 = get(paste("prg",winners[1],sep=""))

  parent_2 = get(paste("prg",winners[2],sep=""))

  if(parent_1$len == 1 && parent_2$len == 1){

    parent_1$change = 0
    parent_2$change = 0

    return(list(offspring_1 = parent_1, offspring_2 = parent_2))

  }

  # URCENI UZLU KRIZENI
  cross_node_1 = CROSS_NODE(parent_1$drive_vec)
  cross_node_2 = CROSS_NODE(parent_2$drive_vec)

  # SEPARACE STROMU KE KRIZENI
  separed_1 = SEPARATE_PRG(parent_1, cross_node_1)
  separed_2 = SEPARATE_PRG(parent_2, cross_node_2)

  # ZACLENENI DO PUVODNIHO STROMU OPACNEHO RODICE
  offspring_1 = TREE_VARIATION(parent_1, separed_2, cross_node_1, Functions, Terminals)
  offspring_2 = TREE_VARIATION(parent_2, separed_1, cross_node_2, Functions, Terminals)

  offspring_1$change = 1
  offspring_2$change = 1

  # KONTROLA MAX. HLOUBKY
  act_depth_1 = NODE_DEPTH(offspring_1$arr, offspring_1$len)

  if(act_depth_1 > MaxDepthRun){

    offspring_1 = parent_1
    offspring_1$change = 0

  }

  act_depth_2 = NODE_DEPTH(offspring_2$arr, offspring_2$len)

  if(act_depth_2 > MaxDepthRun){

    offspring_2 = parent_2
    offspring_2$change = 0

  }

  list(offspring_1 = offspring_1, offspring_2 = offspring_1)

}