
# PRINT FITNESS A PRUMERNE DELKY JEDINCU POCATECNI GENERACE
g_res = GEN_RESULTS(NiPop, 0)

# PRIPRAVENI LISTU PRO VYSLEDKY
fit_depth_list = list(fit_mean = c(), fit_min = c(), depth_mean =  c(), depth_best_prg = c())

# VYSLEDKY Z POCATECNI GENERACE
fit_depth_list = RUN_RESULTS(fit_depth_list, g_res)

print("Initial generation")
print(min(fit_depth_list$fit_min))

# PRIPRAVA RIDICIHO VEKTORU PRO EDITACE
edit_gen = cumsum(rep(floor(Ngen/(Ngen/10)),(Ngen/10)))

if(edit_gen[length(edit_gen)] != Ngen){

  edit_gen = c(edit_gen,Ngen)

}

# TVORBA NOVE GENERACE
act_gen = 1
while(act_gen <= Ngen){

  # ZAPLNOVANI NOVE GENERACE
  i = 1
  while(i <= NiPop){ 

    # ELITISMUS
    if(Elitism && i == 1){

      flow_new_prg = paste("new_prg",i,sep="")

      winner = ELITE(Fit_arr,1)

      offspring = get(paste("prg",winner,sep=""))

      offspring$change = 0

      assign(flow_new_prg,offspring)
    
      i = i + 1

    }


    # VOLBA TYPU VARIACE
      var_type = runif(1,0,1)

    # REPRODUKCE
    if(var_type <= Variations$prob[1]){

      flow_new_prg = paste("new_prg",i,sep="")  
    
      winner = TOURNAMENT(Fit_arr, Len_arr, NiPop,TouSize,1, DoubleTour)

      offspring = get(paste("prg", winner,sep=""))

      offspring$change = 0

      if(is.na(offspring$fit)){
	stop("ZASTAVENO V REPRODUKCI")
      }

      assign(flow_new_prg,offspring)
    
      i = i + 1

    }

    var_type = runif(1,0,1)

	# KRIZENI
    if(var_type <= Variations$prob[2]){ 

      winners = TOURNAMENT(Fit_arr, Len_arr, NiPop, TouSize, 2, DoubleTour) 

      off_programs = CROSSOVER(winners, MaxDepth, (inputs$n_col-1), Terminals, Functions)

      crosser1 = off_programs$offspring_1
      crosser2 = off_programs$offspring_2	

      los = round(runif(1,0,1),0)

      if(los == 0){ 

	winner = winners[1]

	assign(paste("prg_old_save",winner,sep=""), get(paste("prg",winner,sep="")))
        assign(paste("prg",winner,sep=""),crosser1)

      } else {	

	winner = winners[2]

	assign(paste("prg_old_save",winner,sep=""), get(paste("prg",winner,sep="")))
        assign(paste("prg",winner,sep=""),crosser2)

     }
     
    } else {

      winner = TOURNAMENT(Fit_arr, Len_arr,  NiPop, TouSize, 1, DoubleTour)  
      assign(paste("prg_old_save",winner,sep=""), get(paste("prg",winner,sep="")))

    }

    # MUTACE PODSTROMU
    var_type = runif(1,0,1)
    if(var_type <= Variations$prob[3]){

      offspring = MUT_TREE(winner, MaxDepthRun, (inputs$n_col-1), Terminals, Functions)

      assign(paste("prg",winner,sep=""),offspring)

    }

    # MUTACE KONSTANT
    var_type = runif(1,0,1)
    if(var_type <= Variations$prob[4]){

      kontrol_prg = get(paste("prg",winner,sep=""))
      
      if(any(kontrol_prg$drive_vec == 100)){

	offspring = MUT_CONST(winner, MutKonstSd)

	assign(paste("prg",winner,sep=""),offspring)

      }

    }

    # MUTACE SEPARACI
    var_type = runif(1,0,1)
    if(var_type <= Variations$prob[5]){

      kontrol_prg = get(paste("prg",winner,sep=""))

      if(kontrol_prg$len != 1){

	offspring = MUT_SEPAR(winner)

	assign(paste("prg",winner,sep=""), offspring)

      }

    }

    flow_new_prg = paste("new_prg",i,sep="")

    assign(flow_new_prg,get(paste("prg",winner,sep="")))

    assign(paste("prg",winner,sep=""), get(paste("prg_old_save",winner,sep="")))

    i = i + 1

  }

  # NOVY VYPOCET PROGRAMU
  for (i in 1:NiPop){ 

    flow_prg = paste("prg",i,sep="")

    assign(flow_prg,get(paste("new_prg",i,sep="")))

    active_prg = get(flow_prg)

    if(active_prg$change == 1){

      assign(flow_prg,COMP_PRG(active_prg,Terminals,inputs$inpT,inputs$obsT,FitType,act_gen))
      new_comp_prg = get(flow_prg)

      # NOVE HODNOTY POLE FITNESS
      Fit_arr[i,2] = new_comp_prg$fit
      Len_arr[i,2] = new_comp_prg$len

    } else{

      comp_prg = get(flow_prg)

      Fit_arr[i,2] = comp_prg$fit
      Len_arr[i,2] = comp_prg$len

    }

  }

  # ZAPIS VYSLEDKU
  g_res = GEN_RESULTS(NiPop, act_gen)
  fit_depth_list = RUN_RESULTS(fit_depth_list, g_res)

  # PRUBEH VYPOCTU NA OBRAZOVCE
  if(any(seq(5,Ngen,5) == act_gen)){

    print(paste(round(act_gen/Ngen*100,0),"% done",sep = ""))
    print(min(fit_depth_list$fit_min))
  
  }

  # ZASTAVENI
  if(g_res$min_fit < StopCrit){

    print("*********************************")
    print(paste("STOPING CRITERION REACHED (gen ",act_gen,")",sep=""))
    print("*********************************")

    act_gen = Ngen + 1  

  }

  act_gen = act_gen + 1

}


