
COMP_FIT = function(data_comp, data_ref, nr_data, fit_type){

  if(fit_type == "MAE"){

    fitness = sum(abs(data_ref-data_comp))/nr_data

  }

  if(fit_type == "MSE"){

    fitness = sum((data_ref-data_comp)^2)/nr_data

  }

  if(fit_type == "RMSE"){

    fitness = sqrt(sum((data_ref-data_comp)^2)/nr_data)

  }

  if(fit_type == "CC0"){

    sd_comp = sd(data_comp)
    sd_ref = sd(data_ref)

    if(sd_comp == 0){

      sd_comp = 1e-9

    }

    pre_fit = cov(data_ref, data_comp)/(sd_comp*sd_ref)
    if(pre_fit < 0){

      fitness = 1

    } else{

      fitness = 1 - pre_fit

    }

  }

  if(fit_type == "NS0"){
    
    fitness = sum((data_comp-data_ref)^2)/sum((data_ref-mean(data_ref))^2)

  }

  if(fit_type == "PI0"){
    
    dat_len = length(data_ref)
    fitness = sum((data_comp[2:dat_len]-data_ref[2:dat_len])^2)/sum((data_ref[2:dat_len]-data_ref[1:(dat_len-1)])^2)

  }

  if(fit_type == "MSDE"){ 
    
    dat_len = length(data_ref)
    fitness = mean(((data_ref[2:dat_len]-data_ref[1:(dat_len-1)]) - (data_comp[2:dat_len]-data_comp[1:(dat_len-1)]))^2)

  }

  fitness

}


NR_NC_DATA = function(data_in){

  if(is.array(data_in)){

    nr_data_in = nrow(data_in)
    nc_data_in = ncol(data_in)

  } else{

    nr_data_in = length(data_in)
    nc_data_in = 1
    data_in = array(data_in,dim = c(nr_data_in,nc_data_in))

  }

  list(arr = data_in, nr = nr_data_in, nc = nc_data_in)

}


# DOPLNENI TERMINALU
INSERT_TERMINALS = function(program, terminals, nc_data){

  # OPRAVY OKRAJOVYCH HODNOT PRO POUZITI round + runif
  correction = 0
  if((terminals$range[2] - terminals$range[1]) > 2 & terminals$range[3] == 0){

    correction = 0.49

  }

  inp_max = 100 + nc_data
  for (i in 1:program$len){

    # DOPLNENI KONSTANT
    if(program$drive_vec[i] == 100){

      program$arr[i,1] = round(runif(1,(terminals$range[1]-correction),(terminals$range[2]+correction)),terminals$range[3])

    }
    
    # ZMENA TERMINALU
    if(program$drive_vec[i] == 101 & nc_data > 1){

      inp_rand = sample(seq(101,inp_max,1),1)

      program$arr[i,1] = inp_rand
      program$drive_vec[i] = inp_rand

    }

  }

  program

}



CHAR2NUM = function(num,char,char_arr,drive_vec){

  if(any(drive_vec == num)){

    to_chng = which(drive_vec == num)

    for(j in 1:length(to_chng)){

      char_arr[to_chng[j],1] = char

    }

  }

  char_arr

}



EXPRESSION = function(program){

  exp_arr = array(c(""), dim = c(program$len,1))
  exp_arr[,1] = program$drive_vec

  exp_arr = CHAR2NUM(901,"+",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(902,"-",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(903,"*",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(904,"Pdiv",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(905,"Psqrt",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(906,"Plog",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(907,"Pexp",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(908,"Plog10",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(909,"sigmoid",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(910,"sin",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(911,"cos",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(912,"tan",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(913,"tanh",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(914,"max",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(915,"min",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(916,"hstep",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(917,"sign",exp_arr,program$drive_vec)

  exp_arr = CHAR2NUM(1001,"SMA",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(2001,"RES",exp_arr,program$drive_vec)
  exp_arr = CHAR2NUM(3001,"DLY",exp_arr,program$drive_vec)

  if(any(program$drive_vec == 100)){

    to_chng = which(program$drive_vec == 100)

    for(j in 1:length(to_chng)){

      exp_arr[to_chng[j],1] = program$arr[to_chng[j],1]

    }

  }

  if(any(program$drive_vec >= 101 & program$drive_vec < 900)){

    to_chng = which(program$drive_vec >= 101 & program$drive_vec < 900)

    for(j in 1:length(to_chng)){

      variable = paste("x",(program$drive_vec[to_chng[j]]-100), sep="")
      exp_arr[to_chng[j],1] = variable

    }

  }

  # PREVOD PROGRAMU DO SYMBOLICKE FORMY
  for (i in program$len:1){

    if(program$drive_vec[i] >= 901){

      for(j in 2:ncol(program$arr)){

	if(program$arr[i,j] > -1){

	  if(j == 2 && program$arr[i,(j+1)] == -1){

	    if(program$drive_vec[i] < 1000){

	      exp_arr[i,1] = paste(exp_arr[i,1],"(",exp_arr[program$arr[i,j],1],sep="")

	    } else{

	      exp_arr[i,1] = paste(exp_arr[i,1],exp_arr[program$arr[i,j],1],sep="")

	    }

	  }

	  if(j == 2 && program$arr[i,(j+1)] > -1){
	    
	    if(any(c(904,914,915,1001,2001,3001) == program$drive_vec[i])){ # arita 2

	      first = paste(exp_arr[i,1],"(",exp_arr[program$arr[i,j],1],",",sep="")

	    } else{

	      first = paste("(",exp_arr[program$arr[i,j],1],sep="")

	    }

	  }

	  if(j > 2){

	    if(any(c(904,914,915,1001,2001,3001) == program$drive_vec[i])){

	      exp_arr[i,1] = paste(first,exp_arr[program$arr[i,j],1],sep="")

	    } else{

	      exp_arr[i,1] = paste(first,exp_arr[i,1],exp_arr[program$arr[i,j],1],sep="")

	    }

	  }

	}

      } 

      exp_arr[i,1] = paste(exp_arr[i,1],")",sep="")

   }

 }

  final_expr = paste("y = ", exp_arr[1,1], sep = "")

  final_expr

}



# VYPOCET JEDINCE
COMP_PRG = function(program, terminals, data_in, data_ref, fit_type, gen, fit_all = FALSE, values = FALSE){

  # ROZMER VSTUPU
  inp_data = NR_NC_DATA(data_in)

  # DOPLNENI TERMINALU
  if(gen == 0){

    program = INSERT_TERMINALS(program, terminals, inp_data$nc)

  }

  # PREVOD DO VYRAZU
  program$express = EXPRESSION(program)

  # PRIPRAVA PROMENNYCH
  for(i in 1:inp_data$nc){
  
    assign(paste("x",i,sep=""),inp_data$arr[,i])

  }

  # VYPOCET
  parsed_exp = parse(text = program$express)

  eval(parsed_exp) # vraci vypoctene hodnoty v promenne y 

  # ROZSIRENI PROGRAMU BEZ VSTUPNICH PROMENNYCH
  if(length(y) == 1){

    y = rep(y,inp_data$nr)
  
  }
  
  if(NoNegative){

    if(ChngNegative == 0){
      y[which(y < 0)] = 0
    }

    if(ChngNegative == "min"){
      y[which(y < 0)] = min(data_ref)
    }

  }

  # VYHODNOCENI
  fitness = COMP_FIT(y, data_ref, inp_data$nr, fit_type) 

  if(is.nan(fitness) | is.na(fitness)){

    fitness = 1e100
    warning("NA/NaN fitness produced, CHANGED TO 1e100")

  }

  # VYHODNOCENI VSECH KRITERII
  if(fit_all == TRUE){

    program$fit_arr = array(c(-1), dim = c(2, length(FitNamVec)))
    
    program$fit_arr[1,] = FitNamVec
    for(i in 1:length(FitNamVec)){
    
      program$fit_arr[2,i] = COMP_FIT(y, data_ref, inp_data$nr, FitNamVec[i]) 
      program$fit_arr[2,i] = round(as.numeric(program$fit_arr[2,i]),6)

    }

  }

  if(values){

    list(arr = program$arr, drive_vec = program$drive_vec, len = program$len, change = 0, comp_val = y, expr = program$express, fit = fitness, fit_arr = program$fit_arr) 

  } else{

    list(arr = program$arr, drive_vec = program$drive_vec, len = program$len, change = 0, comp_val = NA, expr = program$express, fit = fitness, fit_arr = program$fit_arr)

  }

}
