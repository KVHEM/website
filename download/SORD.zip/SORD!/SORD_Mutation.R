
# MUTACE PODSTROMU
MUT_TREE = function(winner,max_depth,nc_data_in,terminals,functions){

  offspring = get(paste("prg",winner,sep=""))

  # URCENI UZLU MUTACE 
  mut_node = sample(c(1:offspring$len),1)
  
  # URCENI HLOUBKY UZLU MUTACE
  mn_depth = NODE_DEPTH(offspring$arr, mut_node)
 
  # MAX. HLOUBKA NOVEHO MUTACNIHO STROMU
  mt_depth = max((max_depth - mn_depth), 0)

  #TVORBA NOVEHO STROMU MUTACNIHO
  mt_prg = CREATE_INDIVIDUAL(mt_depth, functions, terminals, method = 0)
  mt_prg = INSERT_TERMINALS(mt_prg, terminals, nc_data_in)

  # VLOZENI NOVEHO STROMU DO PUVODNIHO PROGRAMU
  offspring = TREE_VARIATION(offspring, mt_prg, mut_node, Functions, Terminals)


  offspring$change = 1

  if(offspring$len == 1 && offspring$drive_vec[1] > 900){
    print(offspring$arr)
    stop("PROBLEM MUTATION 1")
  }

  offspring

}


# MUTACE KONSTANT
MUT_CONST = function(winner,rand_sd){

  offspring = get(paste("prg",winner,sep=""))

  # VYBER UZLU K MUTACI
  mut_node = which(offspring$drive_vec == 100)
	
  if(length(mut_node) > 1){

    n_mut = sample(c(1:length(mut_node)),1)
    mutate_vec = sample(mut_node,n_mut)

  } else{

    mutate_vec = mut_node

  }

  for(i in mutate_vec){

    offspring$arr[i,1] = offspring$arr[i,1] + rnorm(1,0,rand_sd)

  }
      
  offspring$change = 1

  offspring

}


# MUTACE SEPARACI
MUT_SEPAR = function(winner){

  offspring = get(paste("prg",winner,sep=""))

  # URCENI UZLU MUTACE
  mut_node = sample(c(2:offspring$len),1)
  
  # SEPAROVANY PROGRAM
  offspring = SEPARATE_PRG(offspring, mut_node)

  offspring$change = 1

  offspring

}

