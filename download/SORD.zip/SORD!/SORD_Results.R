GEN_RESULTS = function(ni_pop, gen){

    fit_in_gen = array(c(0),dim = c(ni_pop,2))
    len_depths = c()

    for (i in 1:ni_pop){

      flow_prg = paste("prg",i,sep="")
      active_prg = get(flow_prg)

      fit_in_gen[i,] = c(i, active_prg$fit)
      len_depths = c(len_depths, NODE_DEPTH(active_prg$arr,active_prg$len))

    }

    min_fit = min(fit_in_gen[,2])
    mean_fit = mean(fit_in_gen[,2])
    mean_depth = mean(len_depths) 

    best_prg_depth = len_depths[which.min(fit_in_gen[,2])]

  list(mean_fit = mean_fit, min_fit = min_fit, mean_depth =  mean_depth, best_prg_depth = best_prg_depth)

}



RUN_RESULTS = function(fit_depth_list, actual){

  fit_mean = c(fit_depth_list$fit_mean, actual$mean_fit)

  fit_min = c(fit_depth_list$fit_min, actual$min_fit)

  depth_mean = c(fit_depth_list$depth_mean, actual$mean_depth)

  depth_best_prg = c(fit_depth_list$depth_best_prg, actual$best_prg_depth)

  list(fit_mean = fit_mean, fit_min = fit_min, depth_mean =  depth_mean, depth_best_prg = depth_best_prg)

}



BEST_PRG = function(ni_pop){

  which_best = 1
  program = get(paste("prg",which_best,sep=""))
  best_fit = program$fit
  best_program = program

  for (i in 2:ni_pop){

    program = get(paste("prg",i,sep=""))

    if(program$fit < best_fit){

      which_best = i
      best_fit = program$fit
      best_program = program

    }
    
  }

  best_program = COMP_PRG(best_program, Terminals, inputs$inpT, inputs$obsT, FitType, 1, fit_all = TRUE, values = TRUE)

  print("************************************")

  print("BEST PROGRAM EXPRESSION")
  print(best_program$expr)
  print("FITNESS")
  print(best_program$fit)
  print("ALL FITNESS TRAINING")
  print(best_program$fit_arr)

  print("************************************")

  best_program

}



VALIDATE = function(best_prg){

  val_prg = COMP_PRG(best_prg,Terminals,inputs$inpV,inputs$obsV,FitType,1, fit_all = TRUE,values=TRUE)

  print("ALL FITNESS VALIDATION")
  print(val_prg$fit_arr)
  print("************************************")

  val_prg

}



PLOT_BOXPLOT = function(obs_dataT, obs_dataV){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  boxplot(list(obs_dataT, obs_dataV), names = c("Train. data","Valid. data"), 
	  las=0, main = "Data sets comparison", outline = TRUE, width = c(0.5,0.5) , lwd = c(3,3))

}



LIST2ASCII <- function(x,file=paste(deparse(substitute(x)),".txt",sep="")) {

  tmp.wid = getOption("width")
  options(width=10000)
  sink(file) 
  print(x) 
  sink()
  options(width=tmp.wid)
  return(invisible(NULL))

} 


BEST_OF_THE_BEST = function(fit_runsT,fit_runsV,fold_name){

  which_bob = which.min(fit_runsT)
  bob_fitT = min(fit_runsT)
  bob_fitV= fit_runsV[which_bob]

  bob_f_name = paste("Outputs/run_",which_bob, sep="")

  expr = read.table(paste(bob_f_name,"/Expression_",which_bob,".txt",sep=""))

  crits = read.table(paste(bob_f_name,"/AllFitness_",which_bob,".txt",sep=""))

  Tvalues = read.table(paste(bob_f_name,"/Training_",which_bob,".txt",sep=""),skip = 1)
  colnames(Tvalues) = c("Observed","Computed")

  Vvalues = read.table(paste(bob_f_name,"/Validation_",which_bob,".txt",sep=""),skip = 1)
  colnames(Vvalues) = c("Observed","Computed")

  bob_prg = list(Prg.num = which_bob, Expression = expr, Criterions = crits, T_fit = bob_fitT, V_fit = bob_fitV, Training_values = Tvalues, Validation_values = Vvalues)

  to_save = paste(fold_name,"/Best_prg_overall.txt",sep="")

  LIST2ASCII(bob_prg, file = to_save)

  to_copy = paste("cp -r",bob_f_name,fold_name,sep = " ")
  system(to_copy)

  bob_prg

}



ENSEMBLES = function(runs, out_T_arr, out_V_arr, fold_name, obs_dataT, obs_dataV, bob_prg){

  par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  to_save = paste(fold_name,"/Ensembles_T.pdf",sep="")

  num_plot_T = length(ToPrintT)/2

  y_min_T = 0.9*min(min(obs_dataT),min(bob_prg$Training_values[,2]))
  y_max_T = 1.25*max(max(obs_dataT),max(bob_prg$Training_values[,2]))

  if(is.character(ToPrintT)){

    range = c(1,nrow(out_T_arr))

    xaxis = c(range[1]:range[2])

    main_text = "Training Ensembles"
                                                 
    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(xaxis, out_T_arr[,1], type = "l", main = main_text, xlab = Xlabel, ylab = Ylabel,  
       ylim = c(y_min_T, y_max_T),  lwd = 3, col = "grey")

    for(run in 1:runs){

      lines(xaxis, out_T_arr[,run], lwd = 3, col = "grey")

    }

    points(xaxis, obs_dataT , lwd = 3, col = "black")

    lines(xaxis, bob_prg$Training_values[,2] , lwd = 3, col = "red")

    legend("topleft", c("ensembles","observed",paste("best computed (",FitType,"=",round(bob_prg$T_fit,3),")",sep="")), 
	    col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

    dev.off()

  } else{

    to_plot_arr_T = matrix(c(ToPrintT), nrow=num_plot_T , ncol=2, byrow = TRUE)  

      for(i in 1:num_plot_T){

	range = c(to_plot_arr_T[i,])

	xaxis = c(range[1]:range[2])

	yaxis = out_T_arr[(range[1]:range[2]),1]

	to_save = paste(fold_name,"/Ensembles_T_",to_plot_arr_T[i,1],"-",to_plot_arr_T[i,2],".pdf",sep="")

	main_text = "Training Ensembles"

	pdf(file=to_save)
	par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
	plot(xaxis, yaxis, type = "l", main = main_text, xlab = Xlabel, ylab = Ylabel,  
             ylim = c(y_min_T, y_max_T),  lwd = 3, col = "grey")

	for(run in 1:runs){

	  yaxis = out_T_arr[(range[1]:range[2]),run]

	  lines(xaxis, yaxis, lwd = 3, col = "grey")

	}

	yaxis = obs_dataT[(range[1]:range[2])]	

	points(xaxis, yaxis , lwd = 3, col = "black")

	lines(xaxis, bob_prg$Training_values[(range[1]:range[2]),2] , lwd = 3, col = "red")

	legend("topleft", c("ensembles","observed",paste("best computed (",FitType,"=",round(bob_prg$T_fit,3),")",sep="")), 
	    col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

	dev.off()

      }
  
  }


  to_save = paste(fold_name,"/Ensembles_V.pdf",sep="")

  num_plot_V = length(ToPrintV)/2

  y_min_V =  0.9*min(min(obs_dataV),min(bob_prg$Validation_values[,2]))
  y_max_V =  1.25*max(max(obs_dataV),max(bob_prg$Validation_values[,2]))

  if(is.character(ToPrintV)){

    range = c(1,nrow(out_V_arr))

    xaxis = c(range[1]:range[2])

    main_text = "Validation Ensembles"

    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(xaxis, out_V_arr[,1], type = "l", main = main_text, xlab = Xlabel, ylab = Ylabel,  
       ylim = c(y_min_V, y_max_V),  lwd = 3, col = "grey")

    for(run in 1:runs){

      lines(xaxis, out_V_arr[,run],  lwd = 3, col = "grey")

    }

    points(xaxis, obs_dataV , lwd = 3, col = "black")

    lines(xaxis, bob_prg$Validation_values[,2] , lwd = 3, col = "red")

    legend("topleft", c("ensembles","observed",paste("best computed (",FitType,"=",round(bob_prg$V_fit,3),")",sep="")), 
	    col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

    dev.off()

  } else{

    to_plot_arr_V = matrix(c(ToPrintV), nrow=num_plot_V , ncol=2, byrow = TRUE)  

      for(i in 1:num_plot_V){

	range = c(to_plot_arr_V[i,])

	xaxis = c(range[1]:range[2])

	yaxis = out_V_arr[(range[1]:range[2]),1]

	to_save = paste(fold_name,"/Ensembles_V_",to_plot_arr_V[i,1],"-",to_plot_arr_V[i,2],".pdf",sep="")

	main_text = "Validation Ensembles"

	pdf(file=to_save)
	par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
	plot(xaxis, yaxis, type = "l", main = main_text, xlab = Xlabel, ylab = Ylabel,  
             ylim = c(y_min_V, y_max_V),  lwd = 3, col = "grey")

	for(run in 1:runs){

	  yaxis = out_V_arr[(range[1]:range[2]),run]

	  lines(xaxis, yaxis, lwd = 3, col = "grey")

	}

	yaxis = obs_dataV[(range[1]:range[2])]	

	points(xaxis, yaxis , lwd = 3, col = "black")

	lines(xaxis, bob_prg$Validation_values[(range[1]:range[2]),2] , lwd = 3, col = "red")

	legend("topleft", c("ensembles","observed",paste("best computed (",FitType,"=",round(bob_prg$V_fit,3),")",sep="")), 
	       col=c("grey","black","red"), lty = c(1,-1,1), pch = c(-1, 1,-1), lwd=c(3,3,3), cex = 1.2)

	dev.off()

      }    
  
  }

}



RUNS_RESULT = function(runs, obs_dataT, obs_dataV){

  fit_col = which(FitNamVec == FitType)

  # PRIPRAVA VEKTORU PRO HLOUBKY A FITNESS
  fit_runsT = c()
  fit_runsV = c()
  bp_depth = c()

  # POLE PRO RADY VYSLEDKU PRO ENSEMBLY
  out_T_arr = array(c(-9999), dim = c(length(obs_dataT),runs))
  out_V_arr = array(c(-9999), dim = c(length(obs_dataV),runs))

  # POLE PRO RIDICI VEKTORY PRO JEJICH POROVNANI
  drive_vecs_arr = array(c(-888), dim = c(runs,1))

  # POLE PRO VZORCE
  expr_arr = array(c(""), dim = c(runs,1))

  # NACITANI DAT Z JEDNOTLIVYCH RUNU
  for(run in 1:runs){

    source_f_name = paste("Outputs/run_", run, sep="")
    
    to_read = paste(source_f_name,"/AllFitness_", run, ".txt",sep="")
    fitnesses = read.table(to_read)

    fit_runsT = c(fit_runsT, fitnesses[1,fit_col])
    fit_runsV = c(fit_runsV, fitnesses[2,fit_col])

    to_read = paste(source_f_name,"/BestPrgDepth_", run, ".txt",sep="")
    depths = read.table(to_read, skip = 1)

    bp_depth = c(bp_depth,depths[nrow(depths),2])

    to_read = paste(source_f_name,"/DriveVector_", run, ".txt",sep="")
    dv = as.character(as.vector(read.table(to_read)))
    drive_vecs_arr[run,1] = dv

    to_read = paste(source_f_name,"/Expression_", run, ".txt",sep="")
    expr = read.table(to_read)
    expr_arr[run,1] = as.character(expr[1,1])


    to_read_T = paste(source_f_name,"/Training_", run, ".txt",sep="") 
    out_T= read.table(to_read_T, skip = 1)

    to_read_V = paste(source_f_name,"/Validation_", run, ".txt",sep="")  
    out_V= read.table(to_read_V, skip = 1)

    out_T_arr[,run] = out_T[,2]
    out_V_arr[,run] = out_V[,2]

  }

  fold_name = paste("All_runs_summary/",actual_folder, sep="")

  # FITNESS TRENOVANI
  to_save = paste(fold_name,"/Fit_in_runsT.txt",sep="")
  write.table(fit_runsT, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # FITNESS VALIDACE
  to_save = paste(fold_name,"/Fit_in_runsV.txt",sep="")
  write.table(fit_runsV, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # HLOUBKY
  to_save = paste(fold_name,"/Bp_depth_in_runs.txt",sep="")
  write.table(bp_depth, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

  # PLOT POROVNANI TRENOVACICH A VALIDACNICH DATOVYCH SOUBORU
  to_save = paste(fold_name,"/Boxplot_T_V_data.pdf",sep="")
  pdf(file=to_save)
  PLOT_BOXPLOT(obs_dataT, obs_dataV)
  dev.off()

  # BEST OF THE BEST PROGRAM
  bob_prg = BEST_OF_THE_BEST(fit_runsT,fit_runsV,fold_name)

  if(runs > 1){

    # VYHODNOCENI POLE S RIDICIMI VEKTORY, HLEDANI PODOBNYCH PROGRAMU
    similarity = array(c(0), dim = c(runs,2))
    similarity[,1] = c(1:runs)

    for(i in 1:runs){

      simil = which(drive_vecs_arr == drive_vecs_arr[i,1])
      similarity[c(i,simil),2] = length(simil)

    }

    sort_similar = similarity[sort.list(similarity[,2], decreasing = TRUE), ]
    
    to_save = paste(fold_name,"/TableSimilar.txt",sep="")
    write.table(sort_similar, file = to_save, row.names = FALSE, col.names = c("Run", "N similar in runs"), sep="\t")

    if(max(sort_similar[,2]) > 1){

      print("2 or more similar programs in runs")
      most_sim_prg = sort_similar[which(sort_similar[,2] == max(sort_similar[,2])),1]

      msp_arr = array(c(NA),dim = c(length(most_sim_prg),1))

      msp_arr[,1] = expr_arr[most_sim_prg,1]

      to_save = paste(fold_name,"/SimilarPrgs.txt",sep="")
      write.table(msp_arr, file = to_save, row.names = FALSE, col.names = FALSE, sep="\t")

    }

    Fit.train. = as.numeric(fit_runsT)
    Fit.valid. = as.numeric(fit_runsV)

    Depth = as.numeric(bp_depth)
    
    hist_fit_runs_T = hist(Fit.train., plot = FALSE)
    hist_fit_runs_V = hist(Fit.valid., plot = FALSE)
    hist_bp_depth = hist(Depth, plot = FALSE)

    to_save = paste(fold_name,"/HistFitT.txt",sep="")
    LIST2ASCII(hist_fit_runs_T, file = to_save)
    to_save = paste(fold_name,"/HistFitT.pdf",sep="")
    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(hist_fit_runs_T,col="orange1",lwd = 3, main = paste("Histogram of fitness (",FitType,"), training",sep = ""))
    dev.off()

    to_save = paste(fold_name,"/HistFitV.txt",sep="")
    LIST2ASCII(hist_fit_runs_V, file = to_save)
    to_save = paste(fold_name,"/HistFitV.pdf",sep="")
    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(hist_fit_runs_V, col="orange4", lwd = 3, main = paste("Histogram of fitness (",FitType,"), validation", sep = ""))
    dev.off()

    to_save = paste(fold_name,"/Hist_bp_depth.txt",sep="")
    LIST2ASCII(hist_bp_depth, file = to_save)
    to_save = paste(fold_name,"/Hist_bp_depth.pdf",sep="")
    pdf(file=to_save)
    par(mfrow = c(1,1),cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))
    plot(hist_bp_depth, col="green", lwd = 3, main = paste("Histogram of depths, best programs", sep = ""))
    dev.off()

    # ENSEMBLY
    ENSEMBLES(runs, out_T_arr, out_V_arr, fold_name, obs_dataT, obs_dataV, bob_prg)


  }

  settings = list(NiPop = NiPop, Ngen = Ngen, MaxDepthIni = MaxDepthIni, MaxDepthRun = MaxDepthRun, FitType = FitType, 
		  TouSize = TouSize, DoubleTour = DoubleTour, DoubleTourControl = DoubleTourControl, Elitism = Elitism, 
		  Variations_probability = Variations$prob, Functions = Functions$typ, 
		  TrainSet = TrainSet, ValidSet = ValidSet, ValRatio = ValRatio, Runs = Runs)

  to_save = paste(fold_name,"/Settings.txt",sep="")
  LIST2ASCII(settings, file = to_save)

}



