PLOT_RUN_FIT = function(x_gen, all_fit_min, all_fit_mean, fit_type, regime){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  if(regime == 1 | regime == 3){

    plot(x_gen, all_fit_min,  type = "s", col = "green", main = "Min. Fitness", 
	 xlab = "Number of generations", ylab = fit_type, lwd = 3)

  }

  if(regime == 2 | regime == 3){

    plot(x_gen, log10(all_fit_mean), type = "s", col = "darkgreen", main = "Mean fitness", 
	 xlab = "Number of generations", ylab = paste("log",fit_type), lwd = 3)

  }

}



PLOT_RUN_DEPTH = function(x_gen, all_depth_mean, all_depth_best_prg, regime){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  if(regime == 1 | regime == 3){

    plot(x_gen, all_depth_best_prg, type = "s", col = "blue", main = "Best prog. depth", 
	xlab = "Number of generations", ylab = "Best prog. depth", lwd = 3)

  }

  if(regime == 2 | regime == 3){

    plot(x_gen, all_depth_mean, type = "s", col = "darkblue", main = "Mean depth", 
	xlab = "Number of generations", ylab = "Prog. mean depth", lwd = 3)

  }



}



PLOT_DATA_T = function(best_fit, x_data_T, y_data_T, comp_data_T, y_min_T, y_max_T){

  par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

  main_text = paste("Training (fit = ",round(best_fit,3),")",sep = "" )

  plot(x_data_T, y_data_T, type = "p", main = main_text, xlab = Xlabel, ylab = Ylabel,  
       ylim = c(y_min_T, y_max_T),  lwd = 3)
  lines(x_data_T, comp_data_T, type = "l", col = "red", lwd = 3)
  legend("topleft", c("observed","computed"), col=c("black","red"), pch = c(1,-1), lty = c(-1,1), lwd=c(3,3), cex = 1.0)

}



PLOT_DATA_V = function(val_fit, x_data_V, y_data_V, comp_data_V, y_min_V, y_max_V){

    par(cex.main = 2, cex.axis= 2, cex.lab = 2, mar=c(5,5,5,3))

    main_text = paste("Validation (fit = ",round(val_fit,3),")",sep = "" )

    plot(x_data_V, y_data_V, type = "p", main = main_text, xlab = Xlabel, ylab = Ylabel, 
         ylim = c(y_min_V,y_max_V),  lwd = 3)
    lines(x_data_V, comp_data_V, type = "l", col = "red", lwd = 3)
    legend("topleft", c("observed","computed"), col=c("black","red"), pch = c(1,-1), lty = c(-1,1), lwd=c(3,3), cex = 1.0)

}



INPUTS_TO_PLOT = function(range, observed, computed){

  x_data = c(range[1]:range[2])
  y_data = observed[range[1]:range[2]]
  comp_data = computed[range[1]:range[2]]

  list(x_data = x_data, y_data = y_data, comp_data = comp_data)

}



DATA2PLOT = function(obs_data, program, ranges){

  y_min = 0.9*min(min(obs_data,program$comp_val))
  y_max = 1.2*max(max(obs_data,program$comp_val))

  # ROZSAH OS TRENOVANI
  if(is.character(ranges)){

    x_data = c(1:length(obs_data))
    y_data = obs_data
    comp_data = program$comp_val

  } else{

    to_plot = INPUTS_TO_PLOT(ranges[1:2], obs_data, program$comp_val)
    x_data = to_plot$x_data
    y_data = to_plot$y_data
    comp_data = to_plot$comp_data

  }

  list(x_data = x_data, y_data = y_data, comp_data = comp_data, y_min = y_min, y_max = y_max)

}



PLOT_GRAPHS = function(fit_depth_list, ngen, best_prg, val_prg, obs_dataT, obs_dataV, run, output){

  x_max = length(fit_depth_list$fit_min)-1
  x_gen = c(0:x_max)

  # ROZSAH OS TRENOVANI
  data_plot_T =  DATA2PLOT(obs_dataT, best_prg, ToPrintT)

  x_data_T = data_plot_T$x_data
  y_data_T = data_plot_T$y_data
  comp_data_T = data_plot_T$comp_data
  y_min_T = data_plot_T$y_min
  y_max_T = data_plot_T$y_max

  # ROZSAH OS VALIDACE
  data_plot_V =  DATA2PLOT(obs_dataV, val_prg, ToPrintV)

  x_data_V = data_plot_V$x_data
  y_data_V = data_plot_V$y_data
  comp_data_V = data_plot_V$comp_data
  y_min_V = data_plot_V$y_min
  y_max_V = data_plot_V$y_max

  if(output == "both" | output == "screen"){

    # PRIPRAVENI OBLASTI PRO PLOT
    par(mfrow = c(3,2), cex.main = 1.5, cex.axis= 1.5, cex.lab = 1.5)

    # PLOT PRUBEHU VYPOCTU
    PLOT_RUN_FIT(x_gen, fit_depth_list$fit_min, fit_depth_list$fit_mean, FitType, 3)
    PLOT_RUN_DEPTH(x_gen, fit_depth_list$depth_mean, fit_depth_list$depth_best_prg, 3)

    # PLOT DAT TRENOVANI
    PLOT_DATA_T(best_prg$fit, x_data_T, y_data_T, comp_data_T, y_min_T, y_max_T)

    # PLOT DAT VALIDACE
    PLOT_DATA_V(val_prg$fit, x_data_V, y_data_V, comp_data_V, y_min_V, y_max_V)

  }

  if(output == "both" | output == "file"){

    # UMISTENI VYSLEDKU
    fold_name = paste("Outputs/run_", run, sep="")

    # PLOT PRUBEHU MIN. FITNESS
    to_save = paste(fold_name,"/MinFit_", run, ".pdf",sep="")
    pdf(file=to_save)
    PLOT_RUN_FIT(x_gen, fit_depth_list$fit_min, fit_depth_list$fit_mean, FitType, 1)
    dev.off()

    # PLOT PRUBEHU MEAN FITNESS
    to_save = paste(fold_name,"/MeanFit_", run, ".pdf",sep="")
    # postscript(file=paste(name1,"_x_",name2,".ps",sep=""))
    pdf(file=to_save)
    PLOT_RUN_FIT(x_gen, fit_depth_list$fit_min, fit_depth_list$fit_mean, FitType, 2)
    dev.off()

    # PLOT PRUBEHU HLOUBEK STROMU NEJLEPSIHO PROGRAMU
    to_save = paste(fold_name,"/BestPrgDepth_", run, ".pdf",sep="")
    pdf(file=to_save)
    PLOT_RUN_DEPTH(x_gen, fit_depth_list$depth_mean, fit_depth_list$depth_best_prg, 1)
    dev.off()

    # PLOT PRUBEHU MEAN HLOUBEK STROMU
    to_save = paste(fold_name,"/MeanDepth_", run, ".pdf",sep="")
    pdf(file=to_save)
    PLOT_RUN_DEPTH(x_gen, fit_depth_list$depth_mean, fit_depth_list$depth_best_prg, 2)
    dev.off()

    # PLOT DAT
    num_plot_T = length(ToPrintT)/2
    if(num_plot_T <= 1){ # u "all" length = 1, proto neprojde tato podminka

      # PLOT DAT TRENOVANI
      to_save = paste(fold_name,"/Training_", run, ".pdf",sep="")

      pdf(file=to_save)
      PLOT_DATA_T(best_prg$fit, x_data_T, y_data_T, comp_data_T, y_min_T, y_max_T)
      dev.off()
      
    } else{

      to_plot_arr_T = matrix(c(ToPrintT), nrow=num_plot_T , ncol=2, byrow = TRUE)

      for(i in 1:num_plot_T){

	data_plot_T =  DATA2PLOT(obs_dataT, best_prg, to_plot_arr_T[i,1:2])

	x_data_T = data_plot_T$x_data
	y_data_T = data_plot_T$y_data
	comp_data_T = data_plot_T$comp_data

	# PLOT DAT TRENOVANI
	to_save = paste(fold_name,"/Training_", run,"_data_",to_plot_arr_T[i,1],"-",to_plot_arr_T[i,2],".pdf",sep="")

	pdf(file=to_save)
	PLOT_DATA_T(best_prg$fit, x_data_T, y_data_T, comp_data_T, y_min_T, y_max_T)
	dev.off()

      }

    }

    num_plot_V = length(ToPrintV)/2
    if(num_plot_V <= 1){
      
      # PLOT DAT VALIDACE
      to_save = paste(fold_name,"/Validation_", run, ".pdf",sep="")

      pdf(file=to_save)
      PLOT_DATA_V(val_prg$fit, x_data_V, y_data_V, comp_data_V, y_min_V, y_max_V)
      dev.off()

    } else{

      to_plot_arr_V = matrix(c(ToPrintV), nrow=num_plot_V , ncol=2, byrow = TRUE)

      for(i in 1:num_plot_V){

	data_plot_V =  DATA2PLOT(obs_dataV, val_prg, to_plot_arr_V[i,1:2])

	x_data_V = data_plot_V$x_data
	y_data_V = data_plot_V$y_data
	comp_data_V = data_plot_V$comp_data

	# PLOT DAT VALIDACE
	to_save = paste(fold_name,"/Validation_", run,"_data_",to_plot_arr_V[i,1],"-",to_plot_arr_V[i,2],".pdf",sep="")

	pdf(file=to_save)
	PLOT_DATA_V(val_prg$fit, x_data_V, y_data_V, comp_data_V, y_min_V, y_max_V)
	dev.off()

      }

    }
  
  }

}
