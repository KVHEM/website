# URCENI HLOUBKY UZLU
NODE_DEPTH = function(prg_arr, node){

  mn_lvl = 0

  max_n_lvl = max(prg_arr[1,2:ncol(prg_arr)])

  if(node > 1){

    mn_lvl = mn_lvl + 1

  }

  for(i in 1:node){

    if(i > max_n_lvl){
      
      if(max_n_lvl != max(prg_arr[1:(i-1),2:ncol(prg_arr)])){

	mn_lvl = mn_lvl + 1
	max_n_lvl = max(prg_arr[1:(i-1),2:ncol(prg_arr)])

      }

    }

  }

  mn_lvl

}



CHNG_COORD = function(chng_arr, arr_drive_vec, last_val, fromrow, torow){

  k = 1

  for (i in fromrow:torow){
    
    if(arr_drive_vec[i] > 900){
 
      for(j in 2:ncol(chng_arr)){

	if(chng_arr[i,j] > -1){

	  chng_arr[i,j] = last_val + k
	  k = k + 1

	}

      }

    }

  }

  chng_arr

}



CHNG_PRG = function(program, new_arr, new_dvec, new_len){

  program$arr = new_arr
  program$drive_vec = new_dvec
  program$len = new_len
  program$fit = NA
  program$expr = NA 
  program$comp_val = NA 

  program

}



TERM2TERM = function(program, mt_prg, mut_node){

  program$arr[mut_node,] = mt_prg$arr[1,]
  program$drive_vec[mut_node] = mt_prg$drive_vec[1]
  program$fit = NA
  program$expr = NA 
  program$comp_val = NA 

  program

}



TERM2FCN = function(program, mt_prg, mut_node){

  nc_prg = ncol(program$arr)

  # URCENI UZLU K VYMAZANI
  out_row = c()
  for(i in 2:nc_prg){

    if(program$arr[mut_node,i] > -1){

      out_row = c(out_row,program$arr[mut_node,i])

    }

  }
      
  # MAZANI UZLU
  while(is.null(out_row) == FALSE){

    out = out_row
    out_row = c()

    for(i in out){
	
      if(program$drive_vec[i] > 900){

	for(j in 2:nc_prg){

	  if(program$arr[i,j] > -1){

	    out_row = c(out_row,program$arr[i,j])

	  }

	}

      }

      program$drive_vec[i] = -1
      program$arr[i,1:nc_prg] = rep(-1,nc_prg)

    }

  }

  program$drive_vec[mut_node] = mt_prg$drive_vec[1]
  program$arr[mut_node,] = mt_prg$arr[1,]
  
  # UPRAVA UKAZATELU
  if(any(program$drive_vec[mut_node:program$len] > 900)){

    coord = which(program$drive_vec[mut_node:program$len] > 900) + mut_node - 1

    for (i in coord){

      k = 1
      last_max = max(program$arr[1:(i-1),2:nc_prg])
      for(j in 2:nc_prg){

	if(program$arr[i,j] > -1){

	  program$arr[i,j] = last_max + k
	  k = k + 1

	}

      }

    }

  }

  # ZMENA ATRIBUTU JEDINCE
  new_len = program$len - length(which(program$drive_vec == -1))
  new_arr = array(c(-1), dim = c(new_len,nc_prg))
  new_dvec = rep(-1,new_len)

  j = 1
  for (i in 1:program$len){

    if(program$drive_vec[i] > -1){

      new_arr[j,] = program$arr[i,]
      new_dvec[j] = program$drive_vec[i]
      j = j + 1

    }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)

  program

}



FCN2TERM = function(program, mt_prg, mut_node, functions){

  nc_prg = ncol(program$arr)

  # DELKA NOVEHO JEDINCE
  new_len = program$len + mt_prg$len - 1

  # POLE A RIDICI VEKTOR NOVEHO JEDINCE
  new_arr = array(c(-1),dim = c(new_len, nc_prg))
  new_dvec = rep(-1,new_len)

  # DOPLNOVANI NOVEHO POLE A RIDICIHO VEKTORU
  new_arr[1:program$len,] = program$arr
  new_dvec[1:program$len] = program$drive_vec

  # POMOCNY MUT. STROM
  mt_prg_help = mt_prg

  # 1. ZMENA UKAZATELU V MUTACNIM STROMU
  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, max(new_arr[1:(mut_node-1),2:nc_prg]), 1, mt_prg$len)

  # DOPLNENI UZLU MUTACE KORENEM MUT.STROMU
  new_arr[mut_node,] = mt_prg$arr[1,]
  new_dvec[mut_node] = mt_prg$drive_vec[1]

  # POSLEDNI HODNOTA UKAZATELE
  last_max = max(new_arr[1:mut_node,2:nc_prg])

  # ZMENA UKAZATELU V DUSLEDKU VLOZENI NOVE FCE
  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, (mut_node+1), new_len)

  flow_len = program$len

  for(i in 1:mt_prg$len){

    j = 2
    while(j <= nc_prg && mt_prg_help$arr[i,j] > -1){

      act_pos = mt_prg$arr[i,j]

      if(new_dvec[act_pos] == -1){

	new_arr[act_pos,] = mt_prg$arr[mt_prg_help$arr[i,j],]
	new_dvec[act_pos] = mt_prg$drive_vec[mt_prg_help$arr[i,j]]

	if(any(mt_prg$drive_vec[mt_prg_help$arr[i,j]:mt_prg$len] > 900)){ 

	  last_max = max(new_arr[1:(act_pos-1),2:nc_prg])
	  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, act_pos, new_len)
	  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, last_max, mt_prg_help$arr[i,j], mt_prg$len)

	}

      } else{
	
	new_arr[(act_pos+1):(flow_len+1),] = new_arr[act_pos:flow_len,]
	new_dvec[(act_pos+1):(flow_len+1)] = new_dvec[act_pos:flow_len]

	new_arr[act_pos,] = mt_prg$arr[mt_prg_help$arr[i,j],]
	new_dvec[act_pos] = mt_prg$drive_vec[mt_prg_help$arr[i,j]]   

	if(any(mt_prg$drive_vec[mt_prg_help$arr[i,j]:mt_prg$len] > 900)){

	  last_max = max(new_arr[1:(act_pos-1),2:nc_prg])
	  new_arr = CHNG_COORD(new_arr, new_dvec, last_max, act_pos, new_len)
	  mt_prg$arr = CHNG_COORD(mt_prg$arr, mt_prg$drive_vec, last_max, mt_prg_help$arr[i,j], mt_prg$len)

	}

	flow_len = flow_len + 1 

      }

      j = j + 1

    }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)

  program
}



TREE_VARIATION = function(program_1, program_2, variation_node, functions, terminals){
  # program_1 JE PUVODNI STROM, program_2 JE VKLADANY STROM

  if(variation_node == 1){ 

    program_1 = program_2
    
  } else{

    # PRIPAD 1: KOREN PROGRAMU 2 JE TERMINAL A NAHRAZUJE V PROGRAMU 1 TERMINAL
    if(program_1$drive_vec[variation_node] < 900 && program_2$drive_vec[1] < 900){

      program_1 = TERM2TERM(program_1, program_2, variation_node)

    }

    # PRIPAD 2: KOREN PROGRAMU 2 JE TERMINAL A NAHRAZUJE V PROGRAMU 1  FUNKCI
    if(program_1$drive_vec[variation_node] > 900 && program_2$drive_vec[1] < 900){

      program_1 = TERM2FCN(program_1, program_2, variation_node)

    }

    # PRIPAD 3: KOREN PROGRAMU 2 JE FUNKCE A NAHRAZUJE V PROGRAMU 1  TERMINAL
    if(program_1$drive_vec[variation_node] < 900 && program_2$drive_vec[1] > 900){

      program_1 = FCN2TERM(program_1, program_2, variation_node, functions)

    }

    # PRIPAD 4: KOREN PROGRAMU 2 JE FUNKCE A NAHRAZUJE V PROGRAMU 1  FUNKCI
    if(program_1$drive_vec[variation_node] > 900 && program_2$drive_vec[1] > 900){

      term2subst = CREATE_INDIVIDUAL(0, functions, terminals, method = 0)
      program_1 = TERM2FCN(program_1, term2subst, variation_node)
      program_1 = FCN2TERM(program_1, program_2, variation_node, functions)

    }
  
  }

  program_1

}



SEPARATE_PRG = function(program, id_node){

  help_prg = program

  nc_prg = ncol(program$arr)

  new_separe = c()

  if(program$drive_vec[id_node] > 900) {

    for(i in 2:nc_prg){

      if(help_prg$arr[id_node,i] > -1){

	new_separe  = c(new_separe, help_prg$arr[id_node,i])

      }

    }

  } else{

    new_len = 1
    new_dvec = c(-1)
    new_arr = array(c(-1), dim = c(new_len, nc_prg))
    new_dvec = program$drive_vec[id_node]
    new_arr[1,] = program$arr[id_node,]

    program = CHNG_PRG(program, new_arr, new_dvec, new_len)

    program$change = 1

    return(program)
    
  }

  # SEPARACE UZLU NA ZAKLDE UKAZATELU VYSSICH NAHRAZOVANYCH UZLU
  separed_rows = c() 
  while(is.null(new_separe) == FALSE){

    separed_rows = c(separed_rows, new_separe)
    old_separe = new_separe
    new_separe = c()

    for(i in old_separe){
	
      if(help_prg$drive_vec[i] > 900){

	for(j in 2:nc_prg){

	  if(help_prg$arr[i,j] > -1){

	    new_separe = c(new_separe,help_prg$arr[i,j])

	  }

	}

      }

      help_prg$drive_vec[i] = -1
      help_prg$arr[i,1:nc_prg] = rep(-1,nc_prg)

    }

  }

  separed_rows = c(id_node, separed_rows)

  # POLE A RIDICI VEKTOR NOVEHO JEDINCE
  new_len = length(separed_rows)
  new_dvec = rep(-1,new_len)
  new_arr = array(c(-1),dim = c(new_len, nc_prg))

  k = 2
  for(i in 1:new_len){

    new_dvec[i] = program$drive_vec[separed_rows[i]]
    new_arr[i,] = program$arr[separed_rows[i],]

      for(j in 2:nc_prg){

	if(new_arr[i,j] > -1){

	  new_arr[i,j] = k
	  k = k + 1

	}

      }

  }

  program = CHNG_PRG(program, new_arr, new_dvec, new_len)
  
  program

}

