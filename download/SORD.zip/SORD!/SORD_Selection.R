
# ELITISMUS
ELITE = function(fit_arr, n_required){

  winner = c()
  best_fit = c()

  for(i in 1:n_required){

    winner = c(winner,which.min(fit_arr[,2]))
    best_fit = c(best_fit,fit_arr[winner[length(winner)],2])

    fit_arr[winner[length(winner)],2] = NA
    
  }

winner

}


# TURNAJOVA SELEKCE
TOURNAMENT = function(fit_arr, len_arr, n_all, t_size, n_required, double_t){

  winners = c()

  for(i in 1:n_required){
    
    # DVOJITY TURNAJ
    if(double_t && n_required >= 2){

      group1 = array(c(-1), dim = c(t_size,2))
      group2 = array(c(-1), dim = c(t_size,2))
      
      all_group = sample(fit_arr[,1],2*t_size)

      #VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, PRVNI SKUPINA
      group1[,1] = sample(all_group,t_size)

      for (j in 1:nrow(group1)){

	all_group[which(all_group == group1[j,1])] = -1

      }

      #VYBER UCASTNIKU PRVNIHO KOLA TURNAJE, DRUHA SKUPINA
      k = 1
      for (j in 1:length(all_group)){

	if(all_group[j] != -1){

	  group2[k,1] = all_group[j]
	  k = k+1

	}

      }

      # DOPLNENI FITNESS
      for(j in 1:t_size){

		group1[j,2] = fit_arr[group1[j,1],2]
		group2[j,2] = fit_arr[group2[j,1],2]

      }

      # 1 KOLO TURNAJE NA FITNESS
      win1 = group1[which.min(group1[,2]),1]
      win2 = group2[which.min(group2[,2]),1]

      # 2 KOLO DLE DELKY PROGRAMU
      len_prg1 = len_arr[win1,2]
      len_prg2 = len_arr[win2,2]

      # ROZDIL FITNESS PRO KONTROLOVANY TURNAJ
      if(is.numeric(DoubleTourControl)){

	win1_fit = min(group1[,2], na.rm = TRUE)
	win2_fit = min(group2[,2], na.rm = TRUE)

	max_fit_win = max(win1_fit,win2_fit)

	if(max_fit_win > 0){
	  diff_fit = abs(win1_fit - win2_fit)/max(win1_fit,win2_fit) 
	} else {
	  diff_fit = 0
	}

	if(diff_fit > DoubleTourControl){

	  if(win1_fit > win2_fit){
	    winner = win1
	  } else{
	    winner = win2
	  }

	} else{

	  if(len_prg1 < len_prg2){
	    winner = win1
	  } else{
	    winner = win2
	  }

	}

      } else{

	if(len_prg1 < len_prg2){
	  winner = win1
	} else{
	  winner = win2
	}

      }

      winners = c(winners,winner)
      fit_arr[winners[length(winners)],2] = NA 

    } else{

      # OBYCEJNY TURNAJ
      group = array(c(-1),dim = c(t_size,2))

      group[,1] = sample(fit_arr[,1],t_size)

      for(j in 1:t_size){

	group[j,2] = fit_arr[group[j,1],2]

      }
  
      winners = c(winners,group[which.min(group[,2]),1])

      fit_arr[winners[length(winners)],2] = NA 

    }

  }

  winners

}
