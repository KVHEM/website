
############################################################################################
setwd("???")
############################################################################################

## NAZEV SOUBORU SE VSTUPNIMI DATY

InputFile = "???"

## TRENOVACI A VALIDACNI SETY - ("by_ValRatio" NEBO VEKTOR DVOJIC PRO SEPARACI DAT Z InputFiles)

TrainSet = "by_ValRatio"
ValidSet = "by_ValRatio"


## PROCENTO DAT PRO VALIDACI

ValRatio = 0.5


## MAX. HLOUBKA STROMU V POCATECNI GENERACI (uroven korene = 0)

MaxDepthIni = 5

## MAX. HLOUBKA STROMU V DALSICH GENERACICH

MaxDepthRun = 12


## POCET JEDINCU V POPULACI

NiPop = 500

## POCET GENERACI

Ngen = 50

## POCET BEHU PROGRAMU

Runs = 1


## FITNESS METRIKA (MAE, MSE, RMSE, CC0, NS0, PI0, MSDE) 

FitNamVec = c("MAE", "MSE", "RMSE", "CC0", "NS0", "PI0", "MSDE")
FitType = "NS0"

## ZAKAZ ZAPORNYCH HODNOT VE VYPOCTENYCH HODNOTACH (TRUE/FALSE)

NoNegative = TRUE

ChngNegative = "min"

## PLOT OPTIONS 

# PLOT DO SOUBORU (file) / OBRAZOVKA (screen) / OBOJE (both)
PrintOutput = "both"

# ROZSAH ZOBRAZENI VYPOCTENYCH HODNOT ("all" nebo vektor c(xmin,xmax)) T-trenovani, V-validace, POZOR, RELATIVNI K ROZSAHU VSTUPNICH DAT!
ToPrintT = "all"
ToPrintV = "all"

# POPISKY OS PRO PLOT DAT
Xlabel = "Time [day]"
Ylabel = "Q [mm/day]"

## SMAZANI SLOZKY PRO VYSLEDKY VSECH RUNU (TRUE, FALSE)

Clean = TRUE


## ZASTAVOVACI KRITERIUM NA ZAKLADE KVALITY

StopCrit = 0.01


## ELITISMUS (TRUE, FALSE)

Elitism = TRUE

## SELEKCE - VELIKOST TURNAJE

TouSize = 4

## DVOJITY TURNAJ (TRUE, FALSE)

DoubleTour = TRUE

## DVOJITY TURNAJ - KONROLNI PARAMETR ROZDILU KVALITY PRI SELEKCI DLE VELIKOSTI (%, FALSE)

DoubleTourControl = FALSE


##### PRIMITIVA #####

##FUNKCE

Functions = list(typ = c(), prob = c(), arity = c())
# FUNKCE: "+", "-", "*", "Pdiv", "Psqrt", "Plog", "Pexp", "Plog10", "sigmoid", 
#         "sin", "cos" ,"tan", "tanh", "max", "min", "hstep", "sign"
#         "SMA", "RES", "DLY"
Functions$typ = c("+", "-", "*", "Pdiv", "Psqrt", "Plog")

# PRAVDEPODOBNOSTI VYSKYTU FCI - "c(0)" = STEJNA PRAVDEPODOBNOST PRO VSECHNY, JINAK VEKTOR S PROCENTY (SUM = 1)
Functions$prob = c(0)

## TERMINALY

Terminals = list(typ = c(), prob = c(), range = c())
# TYP TERMINALU, 101 = PROMENA, 100 = NAHODNA KONSTANTA
Terminals$typ = c(100,101)

# PRAVDEPODOBNOSTI VYSKYTU TERMINALU - "c(0)" = STEJNA PRAVDEPODOBNOST PRO VSECHNY, JINAK VEKTOR S PROCENTY (SUM = 1)
Terminals$prob = c(0.5,0.5)

# ROZSAH HODNOT PRO NAHODNOU KONSTANTU, A ROUNDING FAKTOR c(min,max,round.fac.)
Terminals$range = c(-10,10,2)


## VARIACE

Variations = list(typ = c(), prob = c())

# TYP VARIACE 1 - reprodukce, 2 - krizeni, 3 - mutace (31-mutace podstromu, 32-mutace konstant, 33-separace)
Variations$typ = c(1, 2, 31, 32, 33)

# PRAVDEPODOBNOSTI VYSKYTU DANEHO TYPU VARIACE - VEKTOR S PROCENTY (SUM = 1)
Variations$prob = c(0.05, 0.7, 0.2, 0.1, 0.1)

# SMERODATNA ODCHYLKA MUTACE
MutKonstSd = 1

############################################################################################
source("SORD_Main.R")
############################################################################################

rm(list=ls())
