#include "../include/test_functions.h"

test_functions::test_functions()
{
    nParam = 0;
    C = 2000;

    nFunc = 0;

    trans_x.reset();
    norm_x.reset();
    temp_x1.reset();
    temp_x2.reset();
    temp_x3.reset();
    temp_x4.reset();

    norm_f.reset();
    basic_f.reset();
    weight.reset();
    sigma.reset();
    lambda.reset();
    bias.reset();

    o.reset();
    l.reset();
    g.reset();

    A.reset();
    B.reset();

    Problem = 0;

    lo_bound = 0;
    up_bound = 0;
    density = 0;
}


test_functions::test_functions(unsigned int N_parameters, unsigned int N_FUNC, unsigned int PROBLEM_TYPE)
{
    //ctor
    nParam = N_parameters;

    C = 2000.0;

    if(nParam <= 0) {
        cout << endl << "Spatne zadany pocet parametru u testovaci funkce." << endl;
        exit(EXIT_FAILURE);
    }

    nFunc = N_FUNC;

    trans_x.set_size(nParam);
    norm_x.set_size(nParam);
    temp_x1.set_size(nParam);
    temp_x2.set_size(nParam);
    temp_x3.set_size(nParam);
    temp_x4.set_size(nParam);

    norm_f.set_size(nFunc);
    basic_f.set_size(nFunc);
    weight.set_size(nFunc);
    sigma.set_size(nFunc);
    lambda.set_size(nFunc);
    bias.set_size(nFunc);

    norm_x.fill(5.0);
    trans_x.fill(1.0);
    temp_x1.fill(1.0);
    temp_x2.fill(1.0);
    temp_x3.fill(1.0);
    temp_x4.fill(1.0);

    norm_f.fill(0.0);
    basic_f.fill(0.0);
    weight.fill((1.0 / (static_cast<double>( nFunc))));
    sigma.fill(1.0);
    lambda.fill(1.0);

    for(unsigned int i=0;i<nFunc;i++){
       bias(i)    = 100 * (static_cast<double>(i));
    }

    o.set_size(nParam,nFunc);
    o.fill(0.0);

    g.set_size(nParam,nParam);
    g.fill(0.0);
    for(unsigned int i=0;i<nParam;i++)
        g(i,i) = 1.0;

    l.set_size(nFunc,nParam,nParam);
    l.fill(0.0);

    for(unsigned int j=0;j<nFunc;j++) {
      for(unsigned int i=0;i<nParam;i++)
          l(j,i,i) = 1.0;
    }

    A.set_size(nParam,nParam);
    A.fill(0.0);
    B.set_size(nParam);
    B.fill(0.0);

    Problem = PROBLEM_TYPE;

    lo_bound = -10;
    up_bound = 10;
    density = 10;
}

test_functions::~test_functions()
{
    //dtor
}

test_functions::test_functions(const test_functions& other)
{
    //copy ctor
    nParam = other.nParam;
    C = other.C;


    nFunc = other.nFunc;

    trans_x = other.trans_x;
    norm_x = other.norm_x;
    temp_x1 = other.temp_x1;
    temp_x2 = other.temp_x2;
    temp_x3 = other.temp_x3;
    temp_x4 = other.temp_x4;

    norm_f = other.norm_f;
    basic_f = other.basic_f;
    weight = other.weight;
    sigma = other.sigma;
    lambda = other.lambda;
    bias = other.bias;

    A =other.A;
    B = other.B;
    o = other.o;
    g = other.g;

    l = other.l;

    Problem = other.Problem;

    lo_bound = other.lo_bound;
    up_bound = other.up_bound;
    density = other.density;

}

test_functions& test_functions::operator=(const test_functions& other)
{
    if (this == &other) return *this; // handle self assignment
      else {

    nParam = other.nParam;
    C = other.C;


    nFunc = other.nFunc;

    trans_x = other.trans_x;
    norm_x = other.norm_x;
    temp_x1 = other.temp_x1;
    temp_x2 = other.temp_x2;
    temp_x3 = other.temp_x3;
    temp_x4 = other.temp_x4;

    norm_f = other.norm_f;
    basic_f = other.basic_f;
    weight = other.weight;
    sigma = other.sigma;
    lambda = other.lambda;
    bias = other.bias;

    A =other.A;
    B = other.B;
    o = other.o;
    g = other.g;

    l = other.l;

    Problem = other.Problem;

    lo_bound = other.lo_bound;
    up_bound = other.up_bound;
    density = other.density;

      }
    //assignment operator
    return *this;
}

/** The interface for calling the testproblem*/
void test_functions::initialize()
{
    switch (Problem)
    {
        case f1_sphere:
            initialize_f1_sphere();
            break;

        case f2_schwefel:
            initialize_f2_schwefel();
            break;

        case f3_elliptic:
            initialize_f3_elliptic();
            break;

        case f4_schwefel_noise:
            initialize_f4_schwefel_noise();
            break;

        case f5_schwefel_206:
            initialize_f5_schwefel_206();
            break;


        case f6_rosenbrook:
            initialize_f6_rosenbrook();
            break;

        case f7_griewank:
            initialize_f7_griewank();
            break;

        case f8_ackley:
            initialize_f8_ackley();
            break;

        case  f9_rastrigin:
            initialize_f9_rastrigin();
            break;

        case f10_rastrigin_rot:
            initialize_f10_rastrigin_rot();
            break;

        case  f11_weierstrass:
            initialize_f11_weierstrass();
            break;

//        case :
//            break;
//
//        default:
//            break;
    }

}

/** Interface for calculating the chosen problem */
double test_functions::calc_bench_func(colvec x)
{
    double res =0.0;
    switch (Problem)
    {
        case f1_sphere:
            res = calc_benchmark_f1(x);
            break;

        case f2_schwefel:
            res = calc_benchmark_f2(x);
            break;

        case f3_elliptic:
            res = calc_benchmark_f3(x);
            break;

        case f4_schwefel_noise:
            res = calc_benchmark_f4(x);
            break;

        case f5_schwefel_206:
            res = calc_benchmark_f5(x);
            break;

        case f6_rosenbrook:
            res = calc_benchmark_f6(x);
            break;

        case f7_griewank:
            res = calc_benchmark_f7(x);
            break;

        case f8_ackley:
            res = calc_benchmark_f8(x);
            break;

        case  f9_rastrigin:
            res = calc_benchmark_f9(x);
            break;

        case f10_rastrigin_rot:
            res = calc_benchmark_f10(x);
            break;

        case  f11_weierstrass:
            res = calc_benchmark_f11(x);
            break;

//        case :
//            break;
//
//        default:
//            break;
    }
    return (res);
}


/** Function for tranforming parametr vector */
void test_functions::trans_form(colvec x, unsigned int coun_t)
{

    for (unsigned int i=0; i<nParam; i++)
    {
        temp_x1(i) = x(i) - o(coun_t,i);
    }

//    cout << endl<< temp_x1 << " temp x1 " ;
    for (unsigned int i=0; i<nParam; i++)
    {
        temp_x2(i) = temp_x1(i)/lambda(coun_t);
    }
//    cout << endl<<temp_x2 << " temp x2 " ;
    for (unsigned int j=0; j<nParam; j++)
    {
        temp_x3(j) = 0.0;
        for (unsigned int i=0; i<nParam; i++)
        {
            temp_x3(j)+= g(i,j)*temp_x2(i);
        }
    }

//    cout << endl<<temp_x3 << " temp x3 " ;
    for (unsigned int j=0; j<nParam; j++)
    {
        trans_x(j) = 0.0;
        for (unsigned int i=0; i<nParam; i++)
        {
            trans_x(j) += l(coun_t,i,j)*temp_x3(i);
        }
    }
//    cout << endl<<trans_x << " trans x "  << endl;
}

/** Transfrom function */
void test_functions::trans_form_norm(unsigned int coun_t)
{

    for (unsigned int i=0; i<nParam; i++) {
        temp_x2(i) = 5.0/lambda(coun_t);
    }
    for (unsigned int j=0; j<nParam; j++){
        temp_x3(j) = 0.0;
        for (unsigned int i=0; i<nParam; i++){
            temp_x3(j) += g(i,j)*temp_x2(i);
        }
    }

    for (unsigned int j=0; j<nParam; j++){
        trans_x(j) = 0.0;
        for (unsigned int i=0; i<nParam; i++){
            trans_x(j) += l(coun_t,i,j)*temp_x3(i);
        }
    }
}

/** Code to evaluate ackley's function */
double test_functions::calc_ackley ( colvec x)
{
    double sum1 =0.0, sum2= 0.0, res= 0.0;

    for (unsigned int i=0; i<nParam; i++){
        sum1 += as_scalar(trans_x(i)*trans_x(i));
        sum2 += cos(2.0*PI*as_scalar(trans_x(i)));
    }
    sum1 = -0.2*sqrt(sum1/nParam);
    sum2 /= nParam;
    res = 20.0 + E - 20.0*exp(sum1) - exp(sum2);

    return (res);
}

/** Code to evaluate rastrigin's function */
double test_functions::calc_rastrigin ( colvec x)
{

    double res = 0.0;

    for (unsigned int i=0; i<nParam; i++)
    {
        res += (trans_x(i)*trans_x(i) - 10.0*cos(2.0*PI*trans_x(i)) + 10.0);
    }

    return (res);
}

/** Code to evaluate weierstrass's function */
double test_functions::calc_weierstrass (colvec x )
{
// according to java CEC 2005 implementation
    double res = 0.0, sum = 0.0, sum1 =0.0, a = 0.5, b = 3.0;
    unsigned int k_max = 20;

    for (unsigned int i=0; i<nParam; i++){
        sum = 0.0;
        for (unsigned int j=0; j<=k_max; j++){
            sum += pow(a,j)*cos(2.0*PI*pow(b,j)*(trans_x(i)+0.5));
        }
        res += sum;
    }

//    for (unsigned int i=0; i<nParam; i++){
        sum1 = 0.0;
        for (unsigned int j=0; j<=k_max; j++){
            sum1 += pow(a,j)*cos(2.0*PI*pow(b,j)*(0.5));
        }
        res -= (static_cast<double>(nParam))*sum1;
//    }

    return (res);
}

/** Code to evaluate griewank's function */
double test_functions::calc_griewank (colvec x)
{

    double s = 0.0, p = 1.0, res = 0.0;

    for (unsigned int i=0; i<nParam; i++){
        s += trans_x(i) * trans_x(i);
        p *= cos( trans_x(i) / sqrt(1.0+(static_cast<double>(i))));
    }
    res = 1.0 + s/4000.0 - p  ;

    return (res);
}

/** code to evaluate sphere function */
double test_functions::calc_sphere (colvec x )
{

    double res = 0.0;

    for (unsigned int i=0; i<nParam; i++){
        res += trans_x(i) * trans_x(i);
    }

    return (res);
}

/** Code to evaluate schwefel's function */
double test_functions::calc_schwefel ( colvec x)
{

   double sum1 = 0.0, sum2 = 0.0;

   for (unsigned int i=0; i<nParam; i++){
        sum2 = 0.0;
        for (unsigned int j=0; j<=i; j++){
            sum2 += trans_x(j);
        }
        sum1 += sum2*sum2;
    }

    return (sum1);
}

/** Code to evaluate rosenbrock's function */
double test_functions::calc_rosenbrock ( colvec x)
{

    double res = 0.0;
    trans_x += 1;
    for (unsigned int i=0; i<nParam-1; i++){
        res += 100.0 * pow((trans_x(i) * trans_x(i)-trans_x(i+1)),2.0) + 1.0*pow((trans_x(i)-1.0),2.0);
    }

    return (res);
}

/** Initializing of f1 sphere function max dimension of f1 problem 100*/
void test_functions::initialize_f1_sphere()
{

    o.load("./input_data/sphere_func_data.txt");

    bias(0) = -450.0;
}

/** Calculate function value for given input data stored in cloumn vector X f1 problem*/
double test_functions::calc_benchmark_f1(colvec X)
{
    double res =0.0;

    trans_form(X, 0);
 //   cout << trans_x << endl;
    basic_f(0) = calc_sphere(trans_x) ;
    res = as_scalar( basic_f(0) + bias(0) );

    return(res);

}

/** Initializing of f2 schwefel function max dimension of f2 problem 100*/
void test_functions::initialize_f2_schwefel()
{

    o.load("./input_data/schwefel_102_data.txt");
    //cout <<o << endl<<o.n_elem;
    bias(0) = -450.0;

}

/** Calculate function value for given input data stored in cloumn vector X f3 problem*/
double test_functions::calc_benchmark_f2(colvec X)
{
    double res =0.0;

    trans_form(X, 0);
    basic_f(0) = calc_schwefel(trans_x) ;
    res = as_scalar( basic_f(0) + bias(0) );

    return(res);

}

/** Initializing the f3 elliptic problem dimensions = 2, 10, 30 ,50, 100; only 2,10,30,50 D problem are rotated*/
void test_functions::initialize_f3_elliptic()
{
    if (nParam==2) g.load("./input_data/elliptic_M_D2.txt");
    if (nParam==10) g.load("./input_data/elliptic_M_D10.txt");
    if (nParam==30) g.load("./input_data/elliptic_M_D30.txt");
    if (nParam==50) g.load("./input_data/elliptic_M_D50.txt");

    o.load("./input_data/high_cond_elliptic_rot_data.txt");

    bias[0] = -450.0;

}

/** Calculate function value for given input data stored in cloumn vector X f3 problem*/
double test_functions::calc_benchmark_f3(colvec X)
{
    double res =0.0;

    trans_form(X, 0);
    basic_f(0) = 0.0;
    for (unsigned int i=0; i<nParam; i++){
        basic_f(0) += trans_x(i)*trans_x(i)*(pow(1.0e6, ((static_cast<double>(i))/((static_cast<double>(nParam))-1.0))));
    }
    res = as_scalar( basic_f(0) + bias(0) );

    return(res);
}

/** Initializing the f4 schwfel problem with noise max dim  = 100 */
void test_functions::initialize_f4_schwefel_noise()
{

    o.load("./input_data/schwefel_102_data.txt");

    bias(0) = -450.0;
    return;

}

/** Calculate function value for given input data stored in cloumn vector X f4 problem*/
double test_functions::calc_benchmark_f4(colvec X)
{
    double res =0.0;
    vec help_var;
    help_var.set_size(1);
    help_var.randn();

    trans_form(X, 0);
    basic_f(0) = calc_schwefel(trans_x)*(1.0 + 0.4*fabs(help_var(0))); ;
    res = as_scalar( basic_f(0) + bias(0) );

    return(res);

}

/** F5 problem initialization */
void test_functions::initialize_f5_schwefel_206()
{
    unsigned int index =0;
    mat help_var;
    help_var.load("./input_data/schwefel_206_data.txt");

    o=help_var.submat(0,0,0,nParam - 1);
    A=help_var.submat(1,0, nParam,nParam - 1);
 //   cout << o.n_cols;

    if (nParam%4==0) {
        index = nParam/4;
    } else {
        index = nParam/4 + 1;
    }

    for (unsigned int i=0; i<index; i++) {
        o(0,i) = -100.0;
    }
    index = (3*nParam)/4 - 1;
    for (unsigned int i=index; i<nParam; i++) {
        o(0,i) = 100.0;
    }
    for (unsigned int i=0; i<nParam; i++){
        B(i) = 0.0;
        for (unsigned int j=0; j<nParam; j++){
            B(i) += A(i,j)*o(0,j);
        }
    }

//    cout <<A << endl << A.n_rows;
//    cout << o;
//    cout << B;
//
    bias(0) = -310.0;
}

double test_functions::calc_benchmark_f5(colvec x)
{
    double res =0.0;
    basic_f(0) = -INF;

   for (unsigned int i=0; i<nParam; i++) {
        res=0.0;
        for (unsigned int j=0; j<nParam; j++) {
            res += A(i,j)*x(j);
        }
        res = fabs(res-B(i));
        if (basic_f(0) < res){
            basic_f(0) = res;
        }
    }
    res = basic_f(0) +bias(0);

    return(res);
}

/** Initialization of f6 Problem Rosenbrook function nDim = 100 */
void test_functions::initialize_f6_rosenbrook()
{
    o.load("./input_data/rosenbrock_func_data.txt");

    bias(0) = 390.0;
}

/** Calculation of Rosebrook function f6 problem nDim = 100 */
double test_functions::calc_benchmark_f6(colvec X)
{
    double res =0.0;

    trans_form (X, 0);
    basic_f(0) = calc_rosenbrock(trans_x);
    res = basic_f(0) + bias(0);

    return (res);
}

/** Initializing of f7 griewank problem Dim =100*/
void test_functions::initialize_f7_griewank()
{
    if (nParam==2) g.load("./input_data/griewank_M_D2.txt");
    if (nParam==10) g.load("./input_data/griewank_M_D10.txt");
    if (nParam==30) g.load("./input_data/griewank_M_D30.txt");
    if (nParam==50) g.load("./input_data/griewank_M_D50.txt");

    o.load("./input_data/griewank_func_data.txt");

    bias(0) = -180;
}

/** Calculation of f7 problem  griewank outcome given one input parameter vector */
double test_functions::calc_benchmark_f7(colvec X)
{
    double res = 0.0;

    trans_form(X, 0);
    basic_f(0) = calc_griewank(trans_x);
    res = basic_f(0) + bias(0);

    return (res);
}

/** Initialization of f8 Ackley problem */
void test_functions::initialize_f8_ackley()
{
    if (nParam==2) g.load("./input_data/ackley_M_D2.txt");
    if (nParam==10) g.load("./input_data/ackley_M_D10.txt");
    if (nParam==30) g.load("./input_data/ackley_M_D30.txt");
    if (nParam==50) g.load("./input_data/ackley_M_D50.txt");

    o.load("./input_data/ackley_func_data.txt");

    unsigned int index =0;
    index = nParam/2;
    for (unsigned int i=1; i<=index; i++) {
        o(0,2*i-2) = -32.0;
    }

    bias(0) = -140;
}

/** Calculation of f8 Ackley  problem dim = 100*/
double test_functions::calc_benchmark_f8(colvec X)
{
    double res = 0.0;
    trans_form(X, 0);
    basic_f(0) = calc_ackley(trans_x);
    res = basic_f(0) + bias(0);

    return (res);
}


/** Initializibng the f9 rastrigin function */
void test_functions::initialize_f9_rastrigin()
{
    o.load("./input_data/rastrigin_func_data.txt");

    bias(0) = -330.0;
}

/** Calculating the f9 problem Rastrigin function dim = 100*/
double test_functions::calc_benchmark_f9(colvec X)
{
    double res = 0.0;

    trans_form(X, 0);
    basic_f(0) = calc_rastrigin(trans_x);
    res = basic_f(0) + bias(0);

    return (res);
}

/** Initialzation of rotater rastrigin f 10 problem*/
void test_functions::initialize_f10_rastrigin_rot()
{
    if (nParam==2) g.load("./input_data/rastrigin_M_D2.txt");
    if (nParam==10) g.load("./input_data/rastrigin_M_D10.txt");
    if (nParam==30) g.load("./input_data/rastrigin_M_D30.txt");
    if (nParam==50) g.load("./input_data/rastrigin_M_D50.txt");

    o.load("./input_data/rastrigin_func_data.txt");

    bias(0) = -330;
}


/** Calculating the f10 problem rotated Rastrigin function dim = 100*/
double test_functions::calc_benchmark_f10(colvec X)
{
    double res = 0.0;

    trans_form(X, 0);
    basic_f(0) = calc_rastrigin(trans_x);
    res = basic_f(0) + bias(0);

    return (res);
}

/** Initializing of Shifted rotated Weierstrass f 11 problem */
void test_functions::initialize_f11_weierstrass()
{
    if (nParam==2) g.load("./input_data/weierstrass_M_D2.txt");
    if (nParam==10) g.load("./input_data/weierstrass_M_D10.txt");
    if (nParam==30) g.load("./input_data/weierstrass_M_D30.txt");
    if (nParam==50) g.load("./input_data/weierstrass_M_D50.txt");

    o.load("./input_data/weierstrass_data.txt");

    bias(0) = 90.0;
}


/** Calculating the f11 problem Shifted rotated Weierstrass dim = 100*/
double test_functions::calc_benchmark_f11(colvec X)
{
    double res = 0.0;

//    for (unsigned int i=0; i<nParam; i++) {
//        norm_x(i) = 0.0;
//    }

    trans_form(X, 0);
    basic_f(0) = calc_weierstrass(trans_x); //- calc_weierstrass(norm_x);
    res = basic_f(0) + bias(0);

    return (res);

}

/** Creates data for 3d plotting */
void test_functions::plot_data_3d()
{
    double step = 0.0, x,y;
//    double lx,ly,ux,uy, xstep,ystep;

    colvec dat;
    dat.set_size(2);

    density = 100;
    lo_bound = -0.5;
    up_bound = 0.5;
    x= lo_bound;
    y= lo_bound;
    step = (up_bound - lo_bound) / (static_cast<double>(density) );
//  rosenbrook
//    lx=78;
//    ux=82;
//    xstep = (ux-lx) / (static_cast<double>(density) );
//    ly=-52;
//    uy=-47;
//    ystep = (uy -ly)   / (static_cast<double>(density) );
//    x =lx;
//    y=ly;


//  griewank
//    lx=-350;
//    ux=-250;
//    xstep = (ux-lx) / (static_cast<double>(density) );
//    ly=-100;
//    uy=0;
//    ystep = (uy -ly)   / (static_cast<double>(density) );
//    x =lx;
//    y=ly;

    mat data_3d;
    data_3d.set_size(density,density);


//
    for (unsigned int i=0; i<density; i++ ){
      for (unsigned int j=0;j<density ;j++ ){
        dat(0) = x;
        dat(1) = y;
        data_3d(i,j) = calc_bench_func(dat);
        x +=step;
//        x +=xstep;
        }
        y += step;
        x = lo_bound;
//          y+= ystep;
//          x=lx;
      }

      data_3d.save("./pics/weierstrass_f11.dat", raw_ascii);
}
