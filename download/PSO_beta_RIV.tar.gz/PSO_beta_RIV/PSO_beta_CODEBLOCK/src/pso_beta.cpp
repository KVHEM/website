#include "../include/pso_beta.h"

pso_beta::pso_beta(string settings_file)
{
    string trash;

    ifstream pso_settings(settings_file.c_str());
    if(!pso_settings) { // osetreni jestli je soubor mozne otevrit
      cout << "\nUnable to open file :"<< settings_file.c_str() <<" with initial settings for PSO optimisation.";
      exit(EXIT_FAILURE);
    }

    pso_settings >> scientific;
    pso_settings >> trash >> trash >> all_n_Population;
    pso_settings >> trash >> lo_limit >> up_limit;
    pso_settings >> trash >> lo_vel_limit >> up_vel_limit;
    pso_settings >> trash >> reject_outside_bounds_constrait;
    pso_settings >> trash >> Dim;
    pso_settings >> trash >> PRoblem_Number;
    pso_settings >> trash >> lo_beta_limit >> up_beta_limit;
    pso_settings >> trash >> phi1 >> phi2;
    pso_settings >> trash >> maxiter;
    pso_settings >> trash >> omega;
    pso_settings >> trash >> directory;
    pso_settings >> trash >> PSO_selection;


    number_func_evaluation = 0;
    path_name_out_file += "INITIAL";

    if((PRoblem_Number >=0)&&(PRoblem_Number <=10)) Nfunc = 1;
    test_functions help_fittness(Dim,Nfunc,PRoblem_Number);
    help_fittness.initialize();

    OBj_function = help_fittness;

    //Sugnathan values of global minima
    switch (PRoblem_Number)
    {
        case 0:
            searched_minimum = -450.0;
            break;
         case 1:
            searched_minimum = -450.0;
            break;
        case 2:
            searched_minimum = -450.0;
            break;
        case 3:
            searched_minimum = -450.0;
            break;
        case 4:
            searched_minimum = -310.0;
            break;
         case 5:
            searched_minimum = 390.0;
            break;
        case 6:
            searched_minimum = -180.0;
            break;
        case 7:
            searched_minimum = -140.0;
            break;
        case 8:
            searched_minimum = -330.0;
            break;
        case 9:
            searched_minimum = -330.0;
            break;
        case 10:
            searched_minimum = 90.0;
            break;
        default:
            break;
    }

    all_n_Param = (Dim+1)*all_n_Population;
    cout << endl << "**** REVIEW of PSO_beta settings ****"<< endl;
    cout << scientific;
    cout << "\nPSO-beta initialization from file: " << settings_file.c_str();
    cout << "\nNumber of Models: " << all_n_Population;
    cout << "\nThe Dimension Problem: " << Dim;
    cout << "\nThe Lower and Upper Par Limits: " << lo_limit << "  " << up_limit;
    cout << "\nThe Lower and Upper vel Limits: " << lo_vel_limit << "  " << up_vel_limit;
    cout << "\nThe Constraints (1_cons. 0_uncons.): " << reject_outside_bounds_constrait;
    cout << "\nThe Problem Number: " << PRoblem_Number;
    cout << "\nThe Beta distribution init bounds: " << lo_beta_limit << "   " <<  up_beta_limit;
    cout << "\nThe_classical_phi1_phi2: " << phi1 << "   " << phi2;
    cout << "\nThe maximum number of iterations: " << maxiter;
    cout << "\nThe inertia weight omega: " << omega;
    cout << "\nDirectory_for_output: " << directory.c_str() ;
    cout << "\nPSO_type_0_OrigPSO_1_ConstOmegaPSO_2_OrigPSObeta_3_ConstOmegaPSObeta: "<< PSO_selection;

    cout << endl;

//    enum { OrigPSO, ConstOmegaPSO, OrigPSObeta, ConstOmegaPSO_beta} PSO_type;
    switch (PSO_selection)
    {
        case OrigPSO:
            PSO_NAME = "_OrigPSO";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 << "_POP-" << all_n_Population << "_ph1-" << phi1 <<"_ph2-" << phi2 <<"_VELlim-" << lo_vel_limit;
            EN_INFO <<"_" << up_vel_limit << "_PARlim-" << lo_limit<<"_" << up_limit << "_MAXiter-" << maxiter;
            break;
        case ConstOmegaPSO:
            PSO_NAME = "_ConstOmegaPSO";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 << "_POP-" << all_n_Population << "_ph1-" << phi1 <<"_ph2-" << phi2 <<"_OMEGA-" << omega;
            EN_INFO << "_PARlim-" << lo_limit<<"_" << up_limit << "_MAXiter-" << maxiter;
            break;
        case OrigPSObeta:
            PSO_NAME = "_OrigPSObeta";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 << "_POP-" << all_n_Population << "_ph1-" << phi1 <<"_ph2-" << phi2 <<"_VELlim-" << lo_vel_limit;
            EN_INFO <<"_" << up_vel_limit << "_PARlim-" << lo_limit<<"_" << up_limit << "_MAXiter-" << maxiter << "_BETlim-" << lo_beta_limit<<"_" << up_beta_limit;
            break;
        case ConstOmegaPSObeta:
            PSO_NAME = "_ConstOmegaPSObeta";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 << "_POP-" << all_n_Population << "_ph1-" << phi1 <<"_ph2-" << phi2 <<"_OMEGA-" << omega;
            EN_INFO << "_PARlim-" << lo_limit<<"_" << up_limit << "_MAXiter-" << maxiter << "_BETlim-" << lo_beta_limit<<"_" << up_beta_limit;
            break;
                }



    Model_param_Parents.set_size(Dim + 2, all_n_Population);
    Model_param_Parents.fill(99999999);

    Pbest_Model_param.set_size(Dim + 2, all_n_Population);
    Pbest_Model_param.fill(99999999);

    Velocities.set_size(Dim + 2, all_n_Population);
    Velocities.fill(99999999);

    Gbest.set_size(Dim+2);
    Gbest.fill(99999999);

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc (T);
}

pso_beta::~pso_beta()
{
    gsl_rng_free (r);
}

pso_beta::pso_beta(const pso_beta& other)
{
    //copy ctor
    all_n_Param = other.all_n_Param;
    lo_limit = other.lo_limit;
    up_limit = other.up_limit;
    lo_vel_limit = other.lo_vel_limit;
    up_vel_limit = other.up_vel_limit;
    reject_outside_bounds_constrait = other.reject_outside_bounds_constrait;
    Dim = other.Dim;
    number_func_evaluation = other.number_func_evaluation;
    path_name_out_file = other.path_name_out_file;
    searched_minimum = other.searched_minimum;
    PRoblem_Number = other.PRoblem_Number;
    Nfunc = other.Nfunc;
    lo_beta_limit = other.lo_beta_limit;
    up_beta_limit = other.up_beta_limit;
    Model_param_Parents = other.Model_param_Parents;
    Pbest_Model_param = other.Pbest_Model_param;
    Gbest = other.Gbest;
    Velocities = other.Velocities;
    phi1 = other.phi1;
    phi2 = other.phi2;
    maxiter = other.maxiter;
    omega = other.omega;
    directory = other.directory;
    PSO_selection = other.PSO_selection;
    PSO_NAME = other.PSO_NAME;
 //   EN_INFO =other.EN_INFO;
}

pso_beta& pso_beta::operator=(const pso_beta& rhs)
{
    if (this == &rhs) {
        return *this;
        } else {
        all_n_Param = rhs.all_n_Param;
        lo_limit = rhs.lo_limit;
        up_limit = rhs.up_limit;
        lo_vel_limit = rhs.lo_vel_limit;
        up_vel_limit = rhs.up_vel_limit;
        reject_outside_bounds_constrait = rhs.reject_outside_bounds_constrait;
        Dim = rhs.Dim;
        number_func_evaluation = rhs.number_func_evaluation;
        path_name_out_file =rhs.path_name_out_file;
        searched_minimum = rhs.searched_minimum;
        PRoblem_Number =rhs.PRoblem_Number;
        Nfunc = rhs.Nfunc;
        lo_beta_limit = rhs.lo_beta_limit;
        up_beta_limit = rhs.up_beta_limit;
        Model_param_Parents = rhs.Model_param_Parents;
        Pbest_Model_param = rhs.Pbest_Model_param;
        Gbest = rhs.Gbest;
        Velocities = rhs.Velocities;
        phi1 = rhs.phi1;
        phi2 = rhs.phi2;
        maxiter = rhs.maxiter;
        omega= rhs.omega;
        directory = rhs.directory;
        PSO_selection =rhs.PSO_selection;
        PSO_NAME =rhs.PSO_NAME;
  //      EN_INFO = rhs.EN_INFO;
        } // handle self assignment
    //assignment operator
    return *this;
}

/** The initialization of all random Population */
void pso_beta::initialize_Swarm()
{
    //Latin Hypercube Sampling Swarm model params
    colvec my_init = random_perm<colvec>(all_n_Param);
    colvec help_vec;

    help_vec.set_size(all_n_Param);
    help_vec.randu();

    my_init -= help_vec;
    my_init = (up_limit - lo_limit) * my_init / all_n_Param + lo_limit;

//Initializing the Model param Parents matrix
    unsigned int help_var =0;
    for (unsigned int i =0; i < all_n_Population ;i++ ){
       for (unsigned int j =0; j<Dim+1 ;j++ ){
         Model_param_Parents(j,i) = my_init(help_var);
         help_var++;
         }
      }
//      cout << endl<< "ups\n"<<Model_param_Parents;
      calc_swarm_fittness();
//
//    colvec help_col;
//    help_col.set_size(Dim);
//    for(unsigned int i=0; i< all_n_Population;i++){
//        help_col = Model_param_Parents.submat(0,i,Dim-1,i);
//       // cout <<endl <<help_col << endl;
//        Model_param_Parents(Dim+1,i) = fittnes(help_col);
//    }

    //Latin Hypercube Sampling for initialization of BETA distribution params
    rowvec my_init_bet = random_perm<rowvec>(all_n_Population);
    rowvec help_vec_bet;

    help_vec_bet.set_size(all_n_Population);
    help_vec_bet.randu();
 //   cout << endl << help_vec_bet;
 //   cout << endl<< my_init_bet;
    my_init_bet -= help_vec_bet;
 //   cout << endl << my_init_bet;
    my_init_bet = (up_beta_limit - lo_beta_limit) * my_init_bet / all_n_Population + lo_beta_limit;

    Model_param_Parents.row(Dim) = my_init_bet;
//    cout << my_init_bet;

    Pbest_Model_param = Model_param_Parents;

//cout << endl<< "\nups2\n"<< Model_param_Parents;
//cout << endl<< "\nupsrwrewrw\n"<< Pbest_Model_param;
}


/**
  * Random permutation according to Richard Durstenfeld in 1964 in Communications of the ACM volume 7, issue 7, as "Algorithm 235: Random permutation"
  */
  template <class my_vec> my_vec pso_beta::random_perm(unsigned int n)
{
  unsigned int j=0;
  my_vec shuffled_index, tmp;

  shuffled_index.set_size(n);
  for (unsigned int i=0;i<n ;i++ ){
    shuffled_index(i) = i+1;
    }

   tmp.set_size(1);
   tmp.fill(1);

  for (unsigned int i = n - 1; i > 0; i--) {
    j = rand_int(i);
    tmp(0) = shuffled_index(j);
    shuffled_index(j) = shuffled_index(i);
    shuffled_index(i) = tmp(0);
  }

  return(shuffled_index);
}

/** Wrapper for test_fuction class */
double pso_beta::fittnes(colvec X)
{
    double value =0.0;

    value = OBj_function.calc_bench_func(X);

    number_func_evaluation++;

//    out_fittness(value);

    return(value);
}

/** Random number generator provides double value in interval (0.1) */
double pso_beta::randunif()
{
    double value = 0.0;
    unsigned int LIM_MAX;

    LIM_MAX =   1+ (static_cast<unsigned int>( RAND_MAX ) );
    value = static_cast<double>(rand() ) / (static_cast<double>(LIM_MAX));

    return (value);
}

/** Random integer number generator */
unsigned int pso_beta::rand_int(unsigned int n)
{
  unsigned int limit = RAND_MAX - RAND_MAX % n;
  unsigned int rnd;

//  srand((unsigned)time(0));
  //cout << "\n time "<< time(0)<< endl;

  do {
    rnd = rand();
  } while (rnd >= limit);

  return rnd % n;
}

/** Writing the fitness to the out file */
void pso_beta::out_fittness(double value)
{
      ofstream out_stream(path_name_out_file.c_str(), ios::app);
      if (!out_stream) {
       cout << "\nIt is impossible to write to file  " << path_name_out_file;
       exit(EXIT_FAILURE);
     }
    out_stream << number_func_evaluation << "\t" << (value-searched_minimum) <<"\n";
    out_stream.close();
}

/**   Finding the Global best particle in swarm */
void pso_beta::update_GBEST()
{
    rowvec fit_ness;
    fit_ness = Model_param_Parents.row(Dim + 1);
    umat indexes = sort_index(fit_ness);
    mat Help_Model_param_parents;
    Help_Model_param_parents.set_size(Dim + 2, all_n_Population);

    for (unsigned int i = 0; i< 1 ;i++ ){
       Help_Model_param_parents.col(i) = Model_param_Parents.col(indexes(i));
      }
//    Model_param_Parents = Help_Model_param_parents;
//     cout << Model_param_Parents;

    if(Help_Model_param_parents(Dim+1,0) <= Gbest(Dim+1)) Gbest = Help_Model_param_parents.col(0);

//    cout << "\nbest of the best\n" << Gbest;

}

/**   Finding the Previous best particle position in swarm */
void pso_beta::update_PBEST()
{
//    cout << "\npbest1\n" << Pbest_Model_param;
    for (unsigned int i = 0; i< all_n_Population ;i++ ){
       if(as_scalar(Model_param_Parents(Dim+1,i)) <= as_scalar(Pbest_Model_param(Dim+1,i))) Pbest_Model_param.col(i) = Model_param_Parents.col(i);
      }
//    cout << "\npbest1\n" << Pbest_Model_param;
}

/** The random genrator from Beta distribution*/
double pso_beta::rand_beta(double a, double b)
{
    double value=999999;
    value = gsl_ran_beta(r,a,b);

    return(value);
}

/** Udating the new swarm position both model and hyper parameters*/
void pso_beta::update_swarm_position()
{
    Model_param_Parents = Model_param_Parents + Velocities;
    calc_swarm_fittness();
}

/** Udating the new swarm position only on model parameters not hyper parameters*/
void pso_beta::update_swarm_position_model_param()
{
    Model_param_Parents.submat(0,0,Dim-1,all_n_Population-1) = Model_param_Parents.submat(0,0,Dim-1,all_n_Population-1) + Velocities.submat(0,0,Dim-1,all_n_Population-1);
    calc_swarm_fittness();
}



/** Calculating the Swarm models fitnesses*/
void pso_beta::calc_swarm_fittness()
{
    colvec help_col;
    help_col.set_size(Dim);
    for(unsigned int i=0; i< all_n_Population;i++){
        help_col = Model_param_Parents.submat(0,i,Dim-1,i);
       // cout <<endl <<help_col << endl;
        Model_param_Parents(Dim+1,i) = fittnes(help_col);
    }
}

/** Velocities initilization by zero values*/
void pso_beta::initialize_Velocities()
{
    Velocities.fill(0.0);
}

/** Calculating the updating velocities */
void pso_beta::calc_velocities_ORIGINAL()
{
    mat help_Velociteies;
    help_Velociteies.set_size(Dim + 2, all_n_Population);

    for(unsigned i=0; i<all_n_Population;i++){
        for(unsigned j=0;j<Dim;j++){
            help_Velociteies(j,i) =  Velocities(j,i) + rand_beta(1,1) * phi1 *(Pbest_Model_param(j,i) - Model_param_Parents(j,i)) \
               + rand_beta(1,1) * phi2 * (Gbest(j) - Model_param_Parents(j,i));
            if((help_Velociteies(j,i)< lo_vel_limit)||(help_Velociteies(j,i)>up_vel_limit)) help_Velociteies(j,i) = Velocities(j,i);
        }
    }
    Velocities = help_Velociteies;

}

void pso_beta::ORIGINAL_PSO()
{
    string filet_names;
    filet_names +=directory + "/File_names" + PSO_NAME.c_str() + EN_INFO.str();
    ofstream bout(filet_names.c_str(), ios::app);
//    unsigned kk=0;
    initialize_Velocities();
    initialize_Swarm();
    while(number_func_evaluation<maxiter){
        update_GBEST();
        update_PBEST();
        calc_velocities_ORIGINAL();
        update_swarm_position();
        bout << number_func_evaluation << "  " << Gbest(Dim+1) - searched_minimum<< endl;
//        kk++;
    }
    bout.close();
}

/** Calculating the swarm velocities */
void pso_beta::calc_velocities_CONST_INERTIA()
{
    for(unsigned i=0; i<all_n_Population;i++){
        for(unsigned j=0;j<Dim;j++){
            Velocities(j,i) =  omega * Velocities(j,i) + rand_beta(1,1) * phi1 *(Pbest_Model_param(j,i) - Model_param_Parents(j,i)) \
               + rand_beta(1,1) * phi2 * (Gbest(j) - Model_param_Parents(j,i));
             }
    }
}

/**  The original POLi and KENNEDY PSO 2007 */
void pso_beta::CONST_INERTIA_PSO()
{
    string filet_names;
    filet_names +=directory + "/File_names" + PSO_NAME.c_str() + EN_INFO.str();
    ofstream bout(filet_names.c_str(), ios::app);
//    unsigned kk=0;
    initialize_Velocities();
    initialize_Swarm();
    while(number_func_evaluation<maxiter){
        update_GBEST();
        update_PBEST();
        calc_velocities_CONST_INERTIA();
        update_swarm_position();
        bout << number_func_evaluation << "  " << Gbest(Dim+1) - searched_minimum<< endl;
//        kk++;
    }
    bout.close();
}

/** Calculating the swarm velocities */
void pso_beta::calc_velocities_CONST_INERTIA_beta()
{
    double a=0.0;//,b=0.0;
    for(unsigned i=0; i<all_n_Population;i++){
        for(unsigned j=0;j<Dim+1;j++){
            a = as_scalar(  Model_param_Parents(Dim,i));
//            b=randunif();
            if((a<=lo_beta_limit)||(a>=up_beta_limit)) a=(up_beta_limit - lo_beta_limit) * (randunif()) + lo_beta_limit;
            Velocities(j,i) =  omega * Velocities(j,i) + rand_beta(a,a) * phi1 *(Pbest_Model_param(j,i) - Model_param_Parents(j,i)) \
               + rand_beta(a,a) * phi2 * (Gbest(j) - Model_param_Parents(j,i));
////             cout << a << " " << (up_beta_limit - lo_beta_limit) <<"  " << b << "  " << Model_param_Parents(Dim,i)<< "  " << Velocities(Dim,i) << endl;
             }

    }
}

/**  The original POLi and KENNEDY PSO 2007 */
void pso_beta::CONST_INERTIA_PSO_beta()
{
    string filet_names;
    filet_names +=directory + "/File_names" + PSO_NAME.c_str() + EN_INFO.str();
    ofstream bout(filet_names.c_str(), ios::app);
//    unsigned kk=0;
    initialize_Velocities();
    initialize_Swarm();
    while(number_func_evaluation<maxiter){
        update_GBEST();
        update_PBEST();
        calc_velocities_CONST_INERTIA_beta();
        update_swarm_position();
        bout << number_func_evaluation << "  " << Gbest(Dim+1) - searched_minimum<< endl;
//        cout << Model_param_Parents.row(Dim) << endl;
//        kk++;
    }
    bout.close();
}


/** Calculating the updating velocities */
void pso_beta::calc_velocities_ORIGINAL_beta()
{
    mat help_Velociteies;
    help_Velociteies.set_size(Dim + 2, all_n_Population);
    double a=1;
    for(unsigned i=0; i<all_n_Population;i++){
        for(unsigned j=0;j<Dim+1;j++){
            a =as_scalar(Model_param_Parents(Dim,i));
//            cout << "Prvni "<< a << endl;
            if((a<=lo_beta_limit)||(a>=up_beta_limit)) a=(up_beta_limit - lo_beta_limit) * randunif() + lo_beta_limit;
            help_Velociteies(j,i) =  Velocities(j,i) + rand_beta(a,a) * phi1 *(Pbest_Model_param(j,i) - Model_param_Parents(j,i)) \
               + rand_beta(a,a) * phi2 * (Gbest(j) - Model_param_Parents(j,i));
            if((help_Velociteies(j,i)< lo_vel_limit)||(help_Velociteies(j,i)>up_vel_limit)) help_Velociteies(j,i) = Velocities(j,i);
             }
//            // cout << a << endl;
    }
    Velocities = help_Velociteies;
}

void pso_beta::ORIGINAL_PSO_beta()
{
    string filet_names;
    filet_names +=directory + "/File_names" + PSO_NAME.c_str() + EN_INFO.str();
    ofstream bout(filet_names.c_str(), ios::app);
//    unsigned kk=0;
    initialize_Velocities();
    initialize_Swarm();
    while(number_func_evaluation<maxiter){
        update_GBEST();
        update_PBEST();
        calc_velocities_ORIGINAL_beta();
        update_swarm_position();
        bout << number_func_evaluation << "  " <<Gbest(Dim+1) - searched_minimum<< endl;
//        kk++;
    }
    bout.close();
}


void pso_beta::compute_PSO()
{
    switch (PSO_selection){
        case OrigPSO:
            ORIGINAL_PSO();
            break;
        case ConstOmegaPSO:
            CONST_INERTIA_PSO();
            break;
        case OrigPSObeta:
            ORIGINAL_PSO_beta();
            break;
        case ConstOmegaPSObeta:
            CONST_INERTIA_PSO_beta();
            break;
    }
}
