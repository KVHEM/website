#include"./include/pso_gama.h"

using namespace std;

int main()
{
    cout << "The PSO Gamma optimisation example" << endl;
    pso_Gamma PSO("settings/settings_PSO_gama");

//    PSO.initialize_Swarm();
//    PSO.update_GBEST();
//    PSO.update_PBEST();
//
//    PSO.initialize_Velocities();
//    PSO.calc_velocities_CLASSICAL();
//    PSO.update_swarm_position();
//    PSO.update_swarm_position_model_param();

//cout <<endl << PSO.Model_param_Parents;

//  PSO.ORIGINAL_PSO();
//  PSO.CONST_INERTIA_PSO();
//  PSO.CONST_INERTIA_PSO_Gamma();
//  PSO.ORIGINAL_PSO_Gamma();
   PSO.compute_PSO();
//for(unsigned int i=0;i<10;i++) cout << PSO.randunif()<< endl;

//    cout << endl << PSO.Gbest;

// //the test for Gamma distributions uniform distribution
//    ofstream out_s("test_Gamma_file", ios::app);
//    if (!out_s) {
//       cout << "\nIt is impossible to write to file  " ;
//       exit(EXIT_FAILURE);
//     }
//    for(unsigned i=0;i<100000;i++){
//        out_s  << PSO.rand_Gamma(1,1) << endl;
//     }
//    out_s.close();




    return 0;
}
