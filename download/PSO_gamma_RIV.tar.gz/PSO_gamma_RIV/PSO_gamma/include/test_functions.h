#ifndef TEST_FUNCTIONS_H
#define TEST_FUNCTIONS_H

#include<cmath>
#include<values.h>
#include<armadillo>

# define INF MAXDOUBLE
# define EPS 1.0e-10
# define E  2.7182818284590452353602874713526625
# define PI 3.1415926535897932384626433832795029

using namespace arma;

class test_functions
{
    public:
        /** Tests selection */
        enum {f1_sphere, f2_schwefel, f3_elliptic, f4_schwefel_noise, f5_schwefel_206, f6_rosenbrook, f7_griewank, f8_ackley, f9_rastrigin, f10_rastrigin_rot, f11_weierstrass} test_selection;

        /** Default constructor */
        test_functions(unsigned int N_parameters, unsigned int N_FUNC, unsigned int PROBLEM_TYPE);
        /**overloaded constructor*/
        test_functions();
        /** Default destructor */
        ~test_functions();
        /** Copy constructor
         *  \param other Object to copy from
         */
        test_functions(const test_functions& other);
        /** Assignment operator
         *  \param other Object to assign from
         *  \return A reference to this
         */
        test_functions& operator=(const test_functions& other);

        unsigned int nParam;//!< Number of Parameters -- dimension of the Problem
        unsigned int nFunc;//!< Number of Basic Functions for calculating the Problems
        unsigned int Problem;//!< Problem type

        double lo_bound;//!< Information for 3D plotting
        double up_bound;//!< Information for 3D plotting
        unsigned int density;//!< Density of grid points for 3D plotting

        double C;

        /** Size of nParam */
        colvec trans_x;
        colvec norm_x;
        colvec temp_x1;
        colvec temp_x2;
        colvec temp_x3;
        colvec temp_x4;

        /** Size of nFunc */
        rowvec norm_f;
        rowvec basic_f;
        rowvec weight;
        rowvec sigma;
        rowvec lambda;
        rowvec bias;

        mat A;
        colvec B;

        /**Combined information */
        mat o;//!< shift of minima
        mat g;//!< Rotation of the problem

        cube l;

        /** Initializing the test functions bias, and other properties */
        void initialize();

        void initialize_f1_sphere();
        void initialize_f2_schwefel();
        void initialize_f3_elliptic();
        void initialize_f4_schwefel_noise();
        void initialize_f5_schwefel_206();
        void initialize_f6_rosenbrook();
        void initialize_f7_griewank();
        void initialize_f8_ackley();
        void initialize_f9_rastrigin();
        void initialize_f10_rastrigin_rot();
        void initialize_f11_weierstrass();

        void trans_form(colvec x, unsigned int coun_t);
        void trans_form_norm(unsigned int count);

        double calc_rosenbrock ( colvec x);
        double calc_schwefel (colvec x);
        double calc_sphere ( colvec x);
        double calc_griewank ( colvec x);
        double calc_weierstrass ( colvec x);
        double calc_rastrigin ( colvec x);
        double calc_ackley (  colvec x);

        double calc_bench_func( colvec x);

        double calc_benchmark_f1(colvec X);
        double calc_benchmark_f2(colvec X);
        double calc_benchmark_f3(colvec X);
        double calc_benchmark_f4(colvec X);
        double calc_benchmark_f5(colvec X);
        double calc_benchmark_f6(colvec X);
        double calc_benchmark_f7(colvec X);
        double calc_benchmark_f8(colvec X);
        double calc_benchmark_f9(colvec X);
        double calc_benchmark_f10(colvec X);
        double calc_benchmark_f11(colvec X);

        void plot_data_3d();

    protected:
    private:
};

#endif // TEST_FUNCTIONS_H
