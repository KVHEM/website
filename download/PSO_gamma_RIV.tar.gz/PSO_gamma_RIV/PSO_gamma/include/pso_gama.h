#ifndef PSO_Gamma_H
#define PSO_Gamma_H

#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <armadillo>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include"test_functions.h"

using namespace arma;
using namespace std;

class pso_Gamma
{
    public:
        /** Default constructor */
        pso_Gamma(string settings_file);
        /** Default destructor */
        ~pso_Gamma();
        /** Copy constructor
         *  \param other Object to copy from
         */
        pso_Gamma(const pso_Gamma& other);
        /** Assignment operator
         *  \param other Object to assign from
         *  \return A reference to this
         */
        pso_Gamma& operator=(const pso_Gamma& other);

        enum { OrigPSO, ConstOmegaPSO, OrigPSOGamma, ConstOmegaPSOGamma} PSO_type;

        unsigned int PSO_selection;

        unsigned int all_n_Population;//!< The total sum of all Models in one Swarm Population
        unsigned int Dim;//!< Problem dimension -- number of model parameters
        unsigned int all_n_Param;//!< The total number of all parameters in Population = (Dim +1) * all_n_Population

        unsigned int maxiter;//!< Maximum number of iteration

        double lo_limit;//!< lower limit for initialization
        double up_limit;//!< upper limit for initialization
        double lo_Gamma1_limit;//!< lower limit for initialization
        double up_Gamma1_limit;//!< upper limit for initialization;
        double lo_Gamma2_limit;//!< lower limit for initialization
        double up_Gamma2_limit;//!< upper limit for initialization;
        double lo_vel_limit;//!< Limits for velocities Kennedy 2007 Swarm Inteligence
        double up_vel_limit;//!< Limits for velocities Kennedy 2007 Swarm Inteligence
        double omega;//!< The constant weight for
        bool reject_outside_bounds_constrait;//!< Rejection the outside bounds individuals

        double phi1;//!< Cognitive coefficient
        double phi2;//!< Social coefficient

        test_functions OBj_function;//!< Instances of the optimization problem
        unsigned int number_func_evaluation;//!< Number of function evaluations

        mat Model_param_Parents;//!< matrix(1:Dim +2 , 1:all_n_Population) -- stored parameter values of Parents models, LAST ROW FITTNES
        mat Pbest_Model_param;//!< matrix(1:Dim +2 , 1:all_n_Population) -- previous best position of models
        mat Velocities;//!< matrix(1:Dim +2 , 1:all_n_Population) -- model velocities
        colvec Gbest;//!< The global best model dimension (1:Dim +2)

        void initialize_Swarm();//!< Swarm initialization
        void initialize_Velocities();//!< Velocty inicitalization
        unsigned int rand_int(unsigned int n);//!< generates integer random number
        double randunif();//!< Uniform random number generator (0,1)

        template<class my_vec> my_vec random_perm(unsigned int n);//! Random permutations after Durstenfeld

        double fittnes(colvec X);//!< Compute Model fittnes
        void out_fittness(double value);//!< Writing the fittness to the file
        unsigned int PRoblem_Number;//!< Problem selection for calculating the fitness function
        double searched_minimum;//!< Forgiven problem searched value of global minimum
        unsigned int Nfunc;//!< Number of basic functions from which the fitness fucntion ois computed

        string path_name_out_file;//!< Directory for ensemble results outcome

        void update_GBEST();//!< Finding the global best particle in swarm
        void update_PBEST();//!< Finding previous best position
        void update_swarm_position();//!< Updating all parameters
        void update_swarm_position_model_param();//!< Updating only model parameters not hyperparams
        void calc_swarm_fittness();//!< Calculating the Swarm models fitnesses

        /**The classical PSO with the no inertia weigth and only max and min velocitie control */
        void calc_velocities_ORIGINAL();//!< Calculating the swarm velocities
        void ORIGINAL_PSO();//!< Th original EBERHART and KENNEDY PSO

         /**The classical PSO with the constant  inertia weigth*/
        void calc_velocities_CONST_INERTIA();//!< Calculating the swarm velocities
        void CONST_INERTIA_PSO();//!< Th original POLi and KENNEDY PSO 2007

        /**The classical PSO with the constant  inertia weigth moving Gamma distribution*/
        void calc_velocities_CONST_INERTIA_Gamma();//!< Calculating the swarm velocities
        void CONST_INERTIA_PSO_Gamma();//!< Th original POLi and KENNEDY PSO 2007

                /**The classical PSO with the no inertia weigth and only max and min velocitie control */
        void calc_velocities_ORIGINAL_Gamma();//!< Calculating the swarm velocities
        void ORIGINAL_PSO_Gamma();//!< Th original EBERHART and KENNEDY PSO

        gsl_rng *r;//!< The Gamma distribution random generator stuff
        const gsl_rng_type * T;//!< The Gamma distribution random generator stuff

        double rand_Gamma(double a, double b);//!< The random number generator from Gamma Distribution

        string directory;//!< Base directory for results output
        string PSO_NAME;//!< Indetification of PSO type
        stringstream EN_INFO;//!< Used parameters

        void compute_PSO();//!< The optimisation run


    protected:
    private:
};

#endif // PSO_Gamma_H
