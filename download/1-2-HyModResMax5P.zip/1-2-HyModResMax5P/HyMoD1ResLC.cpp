#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#define POCET_ZNAKU 8

/*funkce pro zjisteni poctu radku*/
int pocet_radku(FILE *f) {
    int pocet = 0;
    int c;  
    while ((c = getc(f)) != EOF) {
          if (c == '\n') {
             pocet++;
             }
          }
    return pocet;
    }
/*funkce MODEL 4*/
void model(double *Prep, double *PoE, double *SC1, double *P1, double *P2, double *P3, double *D_SC11, double *D_SC12, double *D_C) {
     /*deklarace promennych*/
     double E_SC1, NoI, RATIO, INPUT;     
     /*vypocet E1*/
     E_SC1 = *PoE * (*SC1 / *P1);
     if (E_SC1 < 0.0001) {
        E_SC1 = 0;
        }
     /*bilance 1 v SC1*/
     *SC1 = *SC1 - E_SC1;
     if (*SC1 < 0.0001) {
        *SC1 = 0;
        }                
     /*bilance 2 v SC1*/
     if (*SC1 == 0) {
        *D_SC11 = 0;
        }
     else {
          *D_SC11 = *SC1 * *P2;
          *SC1 = *SC1 - *D_SC11;
          }
     if (*SC1 < 0.0001) {
        *SC1 = 0;
        }
     *SC1 = *SC1 + *P3;
     if (*SC1 < 0.0001) {
        *SC1 = 0;
        }
     /*vypocet primeho odtoku*/
     RATIO = (*SC1) / (*P1);
     NoI = 0.2 * (RATIO * *Prep); 
     INPUT = *Prep - NoI;
     /*bilance 2 v SC1*/
     *SC1 = *SC1 + INPUT;
     if (*SC1 <= *P1) {
        *D_SC12 = 0;
        }
     else {
          *D_SC12 = *SC1 - *P1;
          *SC1 = *P1;
          }
     /*celkovy odtok puda*/
     *D_C = *D_SC11 + *D_SC12 + NoI;                   
     }
/*kalibrace modelu MODEL 1*/
int main (void) {   
    FILE *f;
    /*deklarace promennych*/
    char **pole_nazvu_povodi; char konec_radku; char vstup_data_povodi[] = "input_data/kalibrace/xxxxxxx"; char vstup_data_validace[] = "input_data/validace/xxxxxxx";
    char hydrogram_kal[] = "output_data/HyMoD1ResLC/kalibrace/hydrogram_xxxxxxx"; char hydrogram_val[] = "output_data/HyMoD1ReslC/validace/hydrogram_xxxxxxx";
    char graf_kal[] = "output_data/HyMoD1ResLC/kalibrace/hydrogram_xxx.GNU"; char graf_val[] = "output_data/HyMoD1ResLC/validace/hydrogram_xxx.GNU";    
    double **pole_parametru, **pole_validacnych_parametru, **pole_parametru_kal_val;
    double *Pr, *PE, *D_M, *T_minimum, *T_maximum, *D_Podp, *D_pov, *D_cn, *D_c;
    double *Pr_val, *PE_val, *D_M_val, *T_minimum_val, *T_maximum_val, *D_Podp_val, *D_pov_val, *D_cn_val, *D_c_val;
    double rozsah_P1, dolni_mez_P1, rozsah_P2, dolni_mez_P2, rozsah_P3, dolni_mez_P3;
    /*parametry modelu*/
    double P1, P2, P3;
    /*stavove promenne*/
    double SC1, SCC, Prep, PoE, D_SC11, D_SC12, D_NC, D_C;
    /*vypary*/
    double E_SC1;
    /*ostatni*/
    double suma1, suma2, suma3, suma4, prumer1, CE, CE_tr;
    double max_prep, max_mer_odtok, max_celk_odtok, max_odtok;
    int pocet_souboru, pocet_r_kalibrace, pocet_r_validace, pocet_sad_parametru, pocet_parametru, pocet_dobrych_sad;
    int a, b, c, d, e, g, h, i, j, k, l, m;
    
    /*nastaveni modelu*/
    pocet_parametru = 3;
    /*randomizace*/
    srand(time(NULL));            
    /*nacteni nastaveni optimalizacniho programu*/
    f = fopen ("settings/HyMoD1ResLC_settings.txt", "r");
    fscanf (f, "%d", &pocet_sad_parametru);
    fclose(f);
    printf ("pocet generovanych sad parametru: %d\n", pocet_sad_parametru);
    /*nacteni velikosti primarniho parametrickeho prostoru*/
    f = fopen ("settings/HyMoD1ResLC_limits.txt", "r");
    fscanf (f, "%lf %lf", &rozsah_P1, &dolni_mez_P1);
    fscanf (f, "%lf %lf", &rozsah_P2, &dolni_mez_P2);
    fscanf (f, "%lf %lf", &rozsah_P3, &dolni_mez_P3);
    fclose(f);    
    /*alokace pole parametru*/
    if ((pole_parametru = ((double**) malloc(pocet_sad_parametru * sizeof(double *)))) == NULL) {
       printf ("chyba pri alokaci pameti\n");
       return 1;
       }    
    for (e = 0; e < pocet_sad_parametru; e++) {
        if ((pole_parametru[e] = ((double*) malloc((pocet_parametru + 2) * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        }
    /*nacteni souboru vstupnich dat*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    if (f == NULL) {
       printf ("file file_of_ID.txt not found\n");
       system ("PAUSE");  
       return 1;
       }
    pocet_souboru = pocet_radku(f);    
    fclose(f);
    printf ("pocet testovanych povodi je %d\n", pocet_souboru);
    /*alokace pole parametru a vsech vysledku*/
    if ((pole_parametru_kal_val = ((double**) malloc(pocet_souboru * sizeof(double *)))) == NULL) {
       printf ("chyba pri alokaci pameti\n");
       return 1;
       }    
    for (c = 0; c < pocet_souboru; c++) {
        if ((pole_parametru_kal_val[c] = ((double*) malloc((pocet_parametru + 4) * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        }    
    /*alokace pole nazvu kalibracnich povodi*/
    if ((pole_nazvu_povodi = ((char**) malloc(pocet_souboru * sizeof(char *)))) == NULL) {
       printf("chyba pri alokaci pameti\n");
       return 1;
       }      
    for (a = 0; a < pocet_souboru; a++) {
        if ((pole_nazvu_povodi[a] = ((char*) malloc(POCET_ZNAKU * sizeof(char)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }      
        }
    /*nacteni nazvu kalibracnych povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    for (a = 0; a < pocet_souboru; a++) {
        for (b = 0; b < POCET_ZNAKU - 1; b++) {
            fscanf (f, "%c", &pole_nazvu_povodi[a][b]);
            }
        fscanf (f, "%c", &konec_radku);    
        pole_nazvu_povodi[a][7] = '\0';
        }
    fclose(f);
    /*for cyklus pro vsechna analyzovana povodi*/
    for (c = 0; c < pocet_souboru; c++) {
        for (d = 0; d < 7; d++) {
            vstup_data_povodi[d + 21] = pole_nazvu_povodi[c][d];
            }
        /*zjisteni poctu radku kazdeho kalibracniho souboru*/
        f = fopen (vstup_data_povodi, "r");
        printf ("\n");
        printf ("prave pocitam kalibracni soubor: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
        if (f == NULL) {
           printf ("soubor nenalezen\n");
           system ("PAUSE");  
           return 1;
           }    
        pocet_r_kalibrace = pocet_radku(f);        
        fclose(f);
        printf ("pocet radku kalibracniho souboru: %d\n", pocet_r_kalibrace);
        /*alokace poli vstupnich promennych*/
        if ((Pr = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((PE = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_M = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((T_minimum = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((T_maximum = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_Podp = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_pov = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_cn = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_c = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_povodi, "r");
          for (g = 0; g < pocet_r_kalibrace; g++) {
          fscanf (f, "%lf %lf %lf %lf %lf", &Pr[g], &PE[g], &D_M[g], &T_maximum[g], &T_minimum[g]);
          }
        fclose (f);
        /*naplneni pole parametru hodnotami*/
        for (e = 0; e < pocet_sad_parametru; e++) {
            pole_parametru[e][0] = ((double) (rand () % 10000) / 10000) * rozsah_P1 + dolni_mez_P1;
            pole_parametru[e][1] = ((double) (rand () % 10000) / 10000) * rozsah_P2 + dolni_mez_P2;
            pole_parametru[e][2] = ((double) (rand () % 10000) / 10000) * rozsah_P3 + dolni_mez_P3;
            pole_parametru[e][3] = 0;
            pole_parametru[e][4] = 0;
            }
        
        /*vypocet modelem*/
        for (e = 0; e < pocet_sad_parametru; e++) {
            P1 = pole_parametru[e][0];
            P2 = pole_parametru[e][1];
            P3 = pole_parametru[e][2];
            SC1 = D_SC11 = D_SC12 = D_C = 0;
            for (g = 0; g < pocet_r_kalibrace; g++) {
                /*prirazeni vtupnich hodnot*/
                Prep = Pr[g]; PoE = PE[g];
                /*volani funkce model*/
                model(&Prep, &PoE, &SC1, &P1, &P2, &P3, &D_SC11, &D_SC12, &D_C);
                /*ulozeni vypoctenych odtoku do pripravenych poli*/
                D_c[g] = D_C; D_Podp[g] = D_SC11; D_pov[g] = D_SC12;                
                }
            suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
            for (g = 200; g < pocet_r_kalibrace; g++) {
                suma1 = suma1 + ((D_c[g] - D_M[g]) * (D_c[g] - D_M[g]));    
                suma2 = suma2 + D_M[g];
                suma4 = suma4 + (D_c[g] - D_M[g]);
                }
            prumer1 = suma2 / (pocet_r_kalibrace - 200);
            for (g = 200; g < pocet_r_kalibrace; g++) {
                suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                }
            pole_parametru[e][3] = 1 - (suma1 / suma3);
            pole_parametru[e][4] = (suma4 / suma2) * 100;                
            }
        /*nalezeni nejlepsi hodnoty CE*/
        CE = -1000000;
        for (e = 0; e < pocet_sad_parametru; e++) {
            if (pole_parametru[e][3] > CE) {
               CE = pole_parametru[e][3];
               }
            }
        printf ("nejlepsi CE je %f\n", CE);
        /*zjisteni poctu dobrych sad, t.j. sad, ktere davaji max. o 5% horsi vysledek v CE nez nejlepsi sada*/
        CE_tr = 0;
        if (CE > 0) {
           CE_tr = CE - (0.05 * CE);
           }
        else {
             CE_tr = CE + (0.05 * CE);
             }
        pocet_dobrych_sad = 0;
        for (e = 0; e < pocet_sad_parametru; e++) {
            if (pole_parametru[e][3] >= CE_tr) {
               pocet_dobrych_sad++;
               }
            }
        printf ("pocet dobrych sad je %d\n", pocet_dobrych_sad);
        /*alokace pole pro nacteni validacnich parametru*/
        if ((pole_validacnych_parametru = ((double**) malloc(pocet_dobrych_sad * sizeof(double *)))) == NULL) {
           printf ("chyba pri alokaci pameti\n");
           return 1;
           }    
        for (h = 0; h < pocet_dobrych_sad; h++) {
            if ((pole_validacnych_parametru[h] = ((double*) malloc((pocet_parametru + 4) * sizeof(double)))) == NULL) {
               printf("chyba pri alokaci pameti\n");
               return 1;
               }
            }      
        for (h = 0; h < pocet_dobrych_sad; h++) {
            for (i = 0; i < (pocet_parametru + 4); i++) {
                pole_validacnych_parametru[h][i] = 0;
                }
            }
        /*nacteni validacnich parametru do vytvoreneho pole*/
        h = 0;
        for (e = 0; e < pocet_sad_parametru; e++) {
            if (h > pocet_dobrych_sad){
               break;
               }
            if (pole_parametru[e][3] >= CE_tr) {
               for (i = 0; i < (pocet_parametru + 2); i++) {
                   pole_validacnych_parametru[h][i] = pole_parametru[e][i];
                   }
               h++;
               }                                          
            }
        /*verifikace modelu*/
        /*nacteni validacni casove rady*/
        for (d = 0; d < 7; d++) {
            vstup_data_validace[d + 20] = pole_nazvu_povodi[c][d];
            }
        f = fopen (vstup_data_validace, "r");
        printf ("\n");
        printf ("prave pocitam validaci souboru: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
        if (f == NULL) {
           printf ("soubor nenalezen\n");
           system ("PAUSE");  
           return 1;
           }    
        pocet_r_validace = pocet_radku(f);
        fclose(f);
        printf ("pocet radku validacniho souboru: %d\n", pocet_r_validace);
        /*alokace poli vstupnich promennych*/
        if ((Pr_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((PE_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_M_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((T_minimum_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((T_maximum_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_Podp_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_pov_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_cn_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        if ((D_c_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
           printf("chyba pri alokaci pameti\n");
           return 1;
           }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_validace, "r");
        for (g = 0; g < pocet_r_validace; g++) {
            fscanf (f, "%lf %lf %lf %lf %lf", &Pr_val[g], &PE_val[g], &D_M_val[g], &T_maximum_val[g], &T_minimum_val[g]);
            }
        fclose (f);
        for (h = 0; h < pocet_dobrych_sad; h++) {
            P1 = pole_validacnych_parametru[h][0];
            P2 = pole_validacnych_parametru[h][1];
            P3 = pole_validacnych_parametru[h][2];
            SC1 = D_SC11 = D_SC12 = D_C = 0;
            for (g = 0; g < pocet_r_validace; g++) {
                /*prirazeni vtupnich hodnot*/
                Prep = Pr_val[g]; PoE = PE_val[g];
                /*volani funkce model*/
                model(&Prep, &PoE, &SC1, &P1, &P2, &P3, &D_SC11, &D_SC12, &D_C);
                /*ulozeni vypoctenych odtoku do pripravenych poli*/
                D_c_val[g] = D_C; D_Podp_val[g] = D_SC11; D_pov_val[g] = D_SC12;                
                }
            suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
            for (g = 200; g < pocet_r_validace; g++) {
                suma1 = suma1 + ((D_c_val[g] - D_M_val[g]) * (D_c_val[g] - D_M_val[g]));    
                suma2 = suma2 + D_M_val[g];
                suma4 = suma4 + (D_c_val[g] - D_M_val[g]);
                }
            prumer1 = suma2 / (pocet_r_validace - 200);
            for (g = 200; g < pocet_r_validace; g++) {
                suma3 = suma3 + ((D_M_val[g] - prumer1)*(D_M_val[g] - prumer1));
                }
            pole_validacnych_parametru[h][5] = 1 - (suma1 / suma3);
            pole_validacnych_parametru[h][6] = (suma4 / suma2) * 100;                        
            }
        /*vyber nejlepsi validace a jeji ulozeni do pole pro naslednou simulaci*/
        CE = - 100000;
        for (h = 0; h < pocet_dobrych_sad; h++) {
            if (pole_validacnych_parametru[h][5] > CE) {
               CE = pole_validacnych_parametru[h][5];
               }
            }
        printf ("nejlepsi validacni vysledek: %f\n", CE);
        for (h = 0; h < pocet_dobrych_sad; h++) {
            if (pole_validacnych_parametru[h][5] == CE) {
               for (i = 0; i < (pocet_parametru + 4); i++) {
                   pole_parametru_kal_val[c][i] = pole_validacnych_parametru[h][i];
                   }
               }     
            }                                                                                      
        /*vypocet kalibracnich hydrogramu*/        
        P1 = pole_parametru_kal_val[c][0];
        P2 = pole_parametru_kal_val[c][1];
        P3 = pole_parametru_kal_val[c][2];
        SC1 = D_SC11 = D_SC12 = D_C = 0;
        for (g = 0; g < pocet_r_kalibrace; g++) {
            /*prirazeni vtupnich hodnot*/
            Prep = Pr[g]; PoE = PE[g];
            /*volani funkce model*/
            model(&Prep, &PoE, &SC1, &P1, &P2, &P3, &D_SC11, &D_SC12, &D_C);
            /*ulozeni vypoctenych odtoku do pripravenych poli*/
            D_c[g] = D_C; D_Podp[g] = D_SC11; D_pov[g] = D_SC12;              
            }
        /*nalezeni mezi pro GNU sobor*/         
        max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
        for (g = 0; g < pocet_r_kalibrace; g++) {    
            if (Pr[g] > max_prep) {
               max_prep = Pr[g];
               }
            if (D_M[g] > max_mer_odtok) {
               max_mer_odtok = D_M[g];
               }
            if (D_c[g] > max_celk_odtok) {
               max_celk_odtok = D_c[g];
               }                                                                             
            }
        if (max_mer_odtok > max_celk_odtok) {
           max_odtok = max_mer_odtok;
           }
        else {
             max_odtok = max_celk_odtok;
             }                                                
        /*tisk dat pro hydrogram kalibrace*/
        for (d = 0; d < 7; d++) { 
            hydrogram_kal[d + 44] = pole_nazvu_povodi[c][d];
            }
        f = fopen (hydrogram_kal, "w");
        for (g = 0; g < pocet_r_kalibrace; g++) {       
            fprintf (f, "%.4f\t %.4f\t %.4f\n", Pr[g], D_M[g], D_c[g]);
            }
        fclose (f);
        /*tisk davkoveho souboru pro Gnuplot*/
        for (d = 0; d < 3; d++) { 
            graf_kal[d + 44] = pole_nazvu_povodi[c][d];
            }
        f = fopen (graf_kal, "w");
        fprintf (f, "cd 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\kalibrace'\n");
        fprintf (f, "set grid\n");
        fprintf (f, "set xlabel 'den'\n");
        fprintf (f, "set xrange [0:%d]\n", pocet_r_kalibrace);
        fprintf (f, "set xtics %d\n", 180);
        fprintf (f, "set ylabel 'odtok [mm]'\n");
        fprintf (f, "set yrange [0:%.2f]\n", max_odtok / 0.6);
        fprintf (f, "set ytics %.2f\n", (max_odtok / 0.6) / 10);
        fprintf (f, "set y2label 'srazka [mm]'\n");
        fprintf (f, "set y2range [%.2f:0]\n", max_prep / 0.3);               
        fprintf (f, "set y2tics %.2f\n", (max_prep / 0.3) / 10);
        fprintf (f, "set style fill solid\n");
        fprintf (f, "set key outside below\n");
        fprintf (f, "plot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\kalibrace\\hydrogram_%s' u 2 w steps title 'D_{mer}' lt 2\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\kalibrace\\hydrogram_%s' u 3 w steps title 'D_{sim}' lt 1\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\kalibrace\\hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);              
        fprintf (f, "set out 'hydrogram_graf_%s.ps'\n", pole_nazvu_povodi[c]);
        fprintf (f, "set terminal post solid enhanced color\n");
        fprintf (f, "replot\n");
        fprintf (f, "set out\n");
        fprintf (f, "set terminal windows\n");
        fclose(f);                                                                                                                                                          
        /*vypocet validacnich hydrogramu*/                        
        P1 = pole_parametru_kal_val[c][0];
        P2 = pole_parametru_kal_val[c][1];
        P3 = pole_parametru_kal_val[c][2];
        SC1 = D_SC11 = D_SC12 = D_NC = D_C = 0;
        for (g = 0; g < pocet_r_validace; g++) {
            /*prirazeni vtupnich hodnot*/
            Prep = Pr_val[g]; PoE = PE_val[g];
            /*volani funkce model*/
            model(&Prep, &PoE, &SC1, &P1, &P2, &P3, &D_SC11, &D_SC12, &D_C);
            /*ulozeni vypoctenych odtoku do pripravenych poli*/
            D_c_val[g] = D_C; D_Podp_val[g] = D_SC11; D_pov_val[g] = D_SC12;               
            }        
        /*nalezeni mezi pro GNU sobor*/         
        max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
        for (g = 0; g < pocet_r_validace; g++) {    
            if (Pr_val[g] > max_prep) {
               max_prep = Pr_val[g];
               }
            if (D_M_val[g] > max_mer_odtok) {
               max_mer_odtok = D_M_val[g];
               }
            if (D_c_val[g] > max_celk_odtok) {
               max_celk_odtok = D_c_val[g];
               }                                                                             
            }
        if (max_mer_odtok > max_celk_odtok) {
           max_odtok = max_mer_odtok;
           }
        else {
             max_odtok = max_celk_odtok;
             }                                                
        /*tisk dat pro hydrogram validace*/
        for (d = 0; d < 7; d++) { 
            hydrogram_val[d + 43] = pole_nazvu_povodi[c][d];
            }
        f = fopen (hydrogram_val, "w");
        for (g = 0; g < pocet_r_validace; g++) {       
            fprintf (f, "%.4f\t %.4f\t %.4f\n", Pr_val[g], D_M_val[g], D_c_val[g]);
            }
        fclose (f);
        /*tisk davkoveho souboru pro Gnuplot*/
        for (d = 0; d < 3; d++) { 
            graf_val[d + 43] = pole_nazvu_povodi[c][d];
            }
        f = fopen (graf_val, "w");
        fprintf (f, "cd 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\validace'\n");
        fprintf (f, "set grid\n");
        fprintf (f, "set xlabel 'den'\n");
        fprintf (f, "set xrange [0:%d]\n", pocet_r_validace);
        fprintf (f, "set xtics %d\n", 180);
        fprintf (f, "set ylabel 'odtok [mm]'\n");
        fprintf (f, "set yrange [0:%.2f]\n", max_odtok / 0.6);
        fprintf (f, "set ytics %.2f\n", (max_odtok / 0.6) / 10);
        fprintf (f, "set y2label 'srazka [mm]'\n");
        fprintf (f, "set y2range [%.2f:0]\n", max_prep / 0.3);               
        fprintf (f, "set y2tics %.2f\n", (max_prep / 0.3) / 10);
        fprintf (f, "set style fill solid\n");
        fprintf (f, "set key outside below\n");
        fprintf (f, "plot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\validace\\hydrogram_%s' u 2 w steps title 'D_{mer}' lt 2\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\validace\\hydrogram_%s' u 3 w steps title 'D_{sim}' lt 1\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\1-2-HyModResMax5P\\output_data\\HyMoD1ResLC\\validace\\hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);              
        fprintf (f, "set out 'hydrogram_graf_%s.ps'\n", pole_nazvu_povodi[c]);
        fprintf (f, "set terminal post solid enhanced color\n");
        fprintf (f, "replot\n");
        fprintf (f, "set out\n");
        fprintf (f, "set terminal windows\n");
        fclose(f);                                
        }        
    /*tisk nejlepsi parametricke sady - kalibrace*/
    f = fopen ("output_data/HyMoD1ResLC/kalibrace/nejlepsi_sady.txt", "w");
    for (c = 0; c < pocet_souboru; c++) {
        fprintf (f, "%s\t", pole_nazvu_povodi[c]);
        for (i = 0; i < (pocet_parametru + 2); i++) {        
            fprintf (f, "%.4f\t", pole_parametru_kal_val[c][i]);
            } 
        fprintf (f, "\n");
        }
    /*tisk nejlepsi parametricke sady - validace*/
    f = fopen ("output_data/HyMoD1ResLC/validace/nejlepsi_sady.txt", "w");
    for (c = 0; c < pocet_souboru; c++) {
        fprintf (f, "%s\t", pole_nazvu_povodi[c]);
        for (i = 0; i < (pocet_parametru + 4); i++) {        
            fprintf (f, "%.4f\t", pole_parametru_kal_val[c][i]);
            } 
        fprintf (f, "\n");
        }
    fclose (f);          
    system ("PAUSE");
    }
