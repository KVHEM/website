#ifndef OSTATNI_H_INCLUDED
#define OSTATNI_H_INCLUDED

#include <fstream>
#include <iostream>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <string>

using namespace std;

enum {MOMENTUM, ETA, POCET_EPOCH, ALFA, VSTUPY};
enum {ANO_NE, MIN, MAX, POCET, VYCHOZI, DOPLNEK};
enum {RADKU, SLOUPCU};


/**
 * nastavení výpočtu - věci, které nebudou nutně v každé síti (na rozdíl od nastavení, které je v nastaveni_site)
 */
class nastaveni_testu {
  public:
    nastaveni_testu();
    ~nastaveni_testu();
    nastaveni_testu(const nastaveni_testu& orig);
    nastaveni_testu operator=(nastaveni_testu& orig);
    void nacti_soubor(ifstream *proud); //!< načte soubor (cesta v proměnné soubor)
    string soubor; //!< cesta k souboru pro načítání nebo ukládání nastavení (nastavení výpočtu a taky sítě)
    int celkem_par; //!< celkový počet parametrů (PAR)
    int **pocet_par; //!< velikost pole par (+par, +2 - počet řádků a sloupců)
    double ***param; //!< parametry pro 1D citlivostní analýzu (+druh parametru = PAR, další rozměr parametru (např. počet sloupců u vstupů) = RADP, +ano/ne, min, max, počet, výchozí = SLP)
    string *jmena_par; //!< slovní označení parametrů, načítá se ze souboru
};



#endif // OSTATNI_H_INCLUDED
