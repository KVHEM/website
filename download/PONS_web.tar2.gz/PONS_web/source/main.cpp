/**
 * hlavní spouštěcí část programu HYDROMOZEK
 *
 */

#include "hydromozek.h"

int main ()
{
  cout << "PONS 2008\n";
  cout << "Predikce Odtoku neuronovymi Sitemi" << endl <<"Modelovaci system predikce povodnoveho odtoku\n\n" << "Autori: Petr Maca, Stanislav Horacek -- KVHEM FZP CZU  Praha" << endl << endl;

  cout  <<"Varianta pro webovskou prezentaci," << endl  << "v pripade zajmu o modelovani systemem PONS s rozsirenou funcionalitou," << endl << "prosim obratte se na autory softwaru."<< endl << endl;


  hydromozek mozekI("nastaveni/cesty.txt");
  //cout << "A ted masakr:\n";

  cout << "\nZvolte prosim variantu vypoctu:\n\n\n";
  cout << "1. Jednoduche trenovani site - kalibrace.\n2. Simulace natrenovanou siti na validacnich datech.\n3. Citlivostni analyza - test parametru.\nVarianta vypoctu: ";

  char ch;
  cin >> ch;
  cout << "\n";

  switch (ch) {
    case '1':
      mozekI.vypocti_sit(true, true);
     	break;
    case '2':
      mozekI.vypocti_sit(false, false);
	    break;
    case '3':
      mozekI.testuj_parametry_site();
    	break;
    default:
      cout << "Zmacknul jste jine cislo, nic se k nasi spolecne litosti nevypocetlo.";
	    break;
  }
  cout << "\n\nVypocet ukoncen.\n";

}
