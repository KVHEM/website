#ifndef NEURON_H_INCLUDED
#define NEURON_H_INCLUDED

#define POCET_TYPU_AFCE 4

typedef enum {SIGMOIDA, LINEARNI, HTANGENTA, GAUSS} typ_akt_fce;

/**
 * neuron - základní třída reprezentuje jednotku, ze které se skládá neuronová síť programu Hydromozek
 */
class neuron
{
  public:
	  neuron();
    ~neuron();
    neuron(const neuron& orig);
    neuron operator=(neuron& orig);
//    void vypis(std::ofstream proud);
    void inicializuj_vahy(int n_vstupu, double *pom_vahy);
    void afce(double vstup_do_afce);
    double der_afce();
    double vytvor_vstup_do_afce();
    void inicializuj_vstup(double *vstup_do_neuronu, int pocet_vstupu_do_neuronu);
    void zmen_bias(bool pom_bias); //!< vypne nebo zapne bias u neuronu, tj. přealokuje pole vstup, vahy a zmena_vahy

    int vstupu_neuron; //!< počet vstupů do neuronu, nepočítají se do toho vstupy z biasových neuronů
    double *vstup; //!< hodnoty vstupující do neuronu, včetně biasových (o 1 větší než vstupu_neuron)
    double *vahy; //!< váhy přiřazené k synapsím vstupů, včetně biasových
    double vystup; //!< výsledek - aktivační funkcí prohnaná lineární kombinace vstupů a vah
    int typ_afce; //!< typ aktivační fce
    double vstup_do_afce; //!< vstup do aktivační funkce
    double chyba; //!< chyba pro daný neuron, pro poslední vrstvu určená typem chybové funkce a hodnotami výstupu a vzorového výstupu
    double *zmena_vahy;//!< zmena vah pro uceni s momentem, včetně biasových
    bool bias; //!< zda se počítá s biasovými vahami

};

#endif // NEURON_H_INCLUDED
