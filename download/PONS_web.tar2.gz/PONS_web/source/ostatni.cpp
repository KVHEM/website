#include "ostatni.h"
#include "neuron.h"

nastaveni_testu::nastaveni_testu()
{
  soubor = "";
  //při načtení ze souboru se počet přepíše
  celkem_par = 0;
  pocet_par = 0;
  jmena_par = 0;
  param = 0;
}

nastaveni_testu::nastaveni_testu(const nastaveni_testu& orig)
{
  soubor = orig.soubor;
  celkem_par = orig.celkem_par;

  int par, radsl, radp, slp;

  jmena_par = new string[celkem_par];
  pocet_par = new int*[celkem_par];
  param = new double**[celkem_par];

  for (par = 0; par < celkem_par; par++) {
    jmena_par[par] = orig.jmena_par[par];
    pocet_par[par] = new int[2]; //pro počet řádků a sloupců

    for (radsl = 0; radsl < 2; radsl++)
      pocet_par[par][radsl] = orig.pocet_par[par][radsl];
    jmena_par[par] = orig.jmena_par[par];

    param[par] = new double*[pocet_par[par][RADKU]];

    for (radp = 0; radp < pocet_par[par][RADKU]; radp++) {
      param[par][radp] = new double[pocet_par[par][SLOUPCU]];
      for (slp = 0; slp < pocet_par[par][SLOUPCU]; slp++)
        param[par][radp][slp] = orig.param[par][radp][slp];
    }
  }
}

nastaveni_testu nastaveni_testu::operator=(nastaveni_testu& orig)
{
  if (this != &orig) {
    int par, radp, slp;

    soubor = orig.soubor;
    celkem_par = orig.celkem_par;

    for (par = 0; par < celkem_par; par++)
      for (radp = 0; radp < pocet_par[par][RADKU]; radp++)
        delete[] param[par][radp];
      delete[] param[par];
    delete[] param;

    for (par = 0; par < celkem_par; par++)
      delete[] pocet_par[par];
    delete[] pocet_par;

    delete[] jmena_par;

    pocet_par = new int*[celkem_par];
    param = new double**[celkem_par];
    jmena_par = new string[celkem_par];

    for (par = 0; par < celkem_par; par++) {
      jmena_par[par] = orig.jmena_par[par];
      pocet_par[par] = new int[2]; //pro počet řádků a sloupců

      for (int radsl = 0; radsl < 2; radsl++)
        pocet_par[par][radsl] = orig.pocet_par[par][radsl];
      jmena_par[par] = orig.jmena_par[par];

      param[par] = new double*[pocet_par[par][RADKU]];

      for (radp = 0; radp < pocet_par[par][RADKU]; radp++) {
        param[par][radp] = new double[pocet_par[par][SLOUPCU]];
        for (slp = 0; slp < pocet_par[par][SLOUPCU]; slp++)
          param[par][radp][slp] = orig.param[par][radp][slp];
      }
    }
  }
  return *this;
}

nastaveni_testu::~nastaveni_testu()
{
  int par, radp;
  for (par = 0; par < celkem_par; par++) {
    for (radp = 0; radp < pocet_par[par][RADKU]; radp++)
      delete[] param[par][radp];
    delete[] param[par];
  }
  delete[] param;

  for (par = 0; par < celkem_par; par++)
    delete[] pocet_par[par];
  delete[] pocet_par;

  delete[] jmena_par;

}

/**
 * načtení nastavení výpočtu ze souboru - parametry pro analýzu citlivosti
 * @param proud vstupní proud
 */
void nastaveni_testu::nacti_soubor(ifstream *proud)
{
  string odpad;
  int par, radp, slp;
  int pom_pocet_par; //, pom_druhu_par;
  *proud >> odpad >> pom_pocet_par;

  if (pom_pocet_par <= 0) { // || pom_druhu_par <= 0) {
	  cout << "\nPocet parametru musi byt vetsi nez 0.";
	  exit(EXIT_FAILURE);
  }

  //realokace
  if (celkem_par != 0) {
    for (par = 0; par < celkem_par; par++)
      for (radp = 0; radp < pocet_par[par][RADKU]; radp++)
        delete[] param[par][radp];
      delete[] param[par];
    delete[] param;

    for (par = 0; par < celkem_par; par++)
      delete[] pocet_par[par];
    delete[] pocet_par;

    delete[] jmena_par;
  }

  celkem_par = pom_pocet_par;

  pocet_par = new int*[celkem_par];
  for (par = 0; par < celkem_par; par++)
    pocet_par[par] = new int[2]; //pro počet řádků a sloupců

  param = new double**[celkem_par];
  jmena_par = new string[celkem_par];

  for (par = 0; par < celkem_par; par++) {
    *proud >> odpad >> jmena_par[par] >> odpad;
    for (int radsl = 0; radsl < 2; radsl++)
      *proud >> pocet_par[par][radsl];

    param[par] = new double*[pocet_par[par][RADKU]];
    for (radp = 0; radp < pocet_par[par][RADKU]; radp++) {
      param[par][radp] = new double[pocet_par[par][SLOUPCU]];
      for (slp = 0; slp < pocet_par[par][SLOUPCU]; slp++)
        *proud >> param[par][radp][slp];

      if (param[par][radp][MAX] < param[par][radp][MIN]) {
        cout << "\nMinimum 1D testu nesmí být větší nez maximum 1D testu.";
        exit(EXIT_FAILURE);
      }
      if (param[par][radp][POCET] <= 0) {
        cout << "\nPocet realizaci typu 1D testu musí být větší než 0.";
        exit(EXIT_FAILURE);
      }
    }
  }
}
