#include "hydromozek.h"

/**
 * konstruktor - defaultně nastaví počet vstupů na 0 a typ afce na sigmoidu
 */
neuron::neuron()
{
  bias = false;
  vstupu_neuron = 0;
  //vstup = vahy = zmena_vahy = 0;
  vstup = new double[vstupu_neuron + bias];
  vahy = new double[vstupu_neuron + bias];
  zmena_vahy = new double[vstupu_neuron + bias];
  typ_afce = 999;
  chyba = 99999;
  vstup_do_afce = 99999;

}

/**
 * destruktor - uvolní paměť, pokud je zabíraná vstupy a váhami
 */
neuron::~neuron()
{
  if (vstupu_neuron != 0) {
	  delete[] vstup;
	  delete[] vahy;
	  delete[] zmena_vahy;
  }
}

/**
 * kopírovací konstruktor
 */
neuron::neuron(const neuron& orig)
{
  int vst;
  bias = orig.bias;
  vstupu_neuron = orig.vstupu_neuron;
  vstup = new double[vstupu_neuron + bias];
  for (vst = 0; vst < vstupu_neuron + bias; vst++)
    vstup[vst] = orig.vstup[vst];
  //vstup[vstupu_neuron] = 1; //z biasovského, ale stejně to je pak natvrdo ve vstup_do_afce

  vahy = new double[vstupu_neuron + bias];
  for (vst = 0; vst < vstupu_neuron + bias; vst++)
    vahy[vst] = orig.vahy[vst];

  zmena_vahy = new double[vstupu_neuron + bias];
  for (vst = 0; vst < vstupu_neuron + bias; vst++)
    zmena_vahy[vst] = orig.zmena_vahy[vst];

  vystup = orig.vystup;
  typ_afce = orig.typ_afce;
  vstup_do_afce = orig.vstup_do_afce;
  chyba = orig.chyba;
}

/**
 * funkce pro kopirovani objektu neuron pretizenim operatoru =
 */
neuron neuron::operator=(neuron& orig)
{
  if (this != &orig) {
    int vst;
    bias = orig.bias;
    vstupu_neuron = orig.vstupu_neuron;
    delete[] vstup;
    vstup = new double[vstupu_neuron + bias];
    for (vst = 0; vst < vstupu_neuron + bias; vst++)
      vstup[vst] = orig.vstup[vst];
    //vstup[vstupu_neuron] = 1; //z biasovského, ale stejně to je pak natvrdo ve vstup_do_afce

    delete[] vahy;
    vahy = new double[vstupu_neuron + bias];
    for (vst = 0; vst < vstupu_neuron + bias; vst++)
      vahy[vst] = orig.vahy[vst];

    delete[] zmena_vahy;
    zmena_vahy = new double[vstupu_neuron + bias];
    for (vst = 0; vst < vstupu_neuron + bias; vst++)
      zmena_vahy[vst] = orig.zmena_vahy[vst];

    vystup = orig.vystup;
    typ_afce = orig.typ_afce;
    vstup_do_afce = orig.vstup_do_afce;
    chyba = orig.chyba;
  }
  return *this;
}

/**
 * vypíše do coutu počet vstupů, vstupní hodnoty, váhy a hodnotu výstupu
 */
// void neuron::vypis(std::ofstream proud) {
//
//   proud << "pocet vstupu: " << vstupu_neuron << "\n";
//   proud << "vstupni hodnoty: ";
//   for (int vs = 0; vs < vstupu_neuron; vs++)
// 	proud << "\t" << vstup[vs];
//   proud << "\nvahy: ";
//   for (int vs = 0; vs < vstupu_neuron; vs++)
// 	proud << "\t" << vahy[vs];
//   proud << "\nvystup: " << "\t" << vystup;
//
// }

/**
 * spočítá výstup z neuronu pomocí afce
 * pro sigmoidu:
 * \f[ f(a) =\frac{1}{1+e^{-a}} \f]
 * pro lineární:
 * \f[ f(a) = a \f]
 * pro hyperbolickou tangentu:
 * \f[ f(a) = tanh(a) \f]
 * pro Gaussovu křivku:
 * \f[ f(a) = e^{-a^2} \f]
 * @param vstup_do_afce lineární kombinace vstupů a vah
 */
void neuron::afce(double vstup_do_afce)
{
  switch (typ_afce) {
    case SIGMOIDA:
      vystup =1 / (1 + exp(-0.5*vstup_do_afce));
      break;
    case LINEARNI:
      vystup = vstup_do_afce;
      break;
    case HTANGENTA:
      vystup = tanh(vstup_do_afce);
      break;
    case GAUSS:
      vystup = exp(-(vstup_do_afce * vstup_do_afce));
      break;
    default:
      break;
    }
}

/**
 * spočítá derivace aktivační fce
 * pro sigmoidu:
 * \f[ \frac{df(a)}{da} = f(a) \cdot (1 - f(a)) \f]
 * pro lineární:
 * \f[ \frac{df(a)}{da} = 1 \f]
 * pro hyperbolickou tangentu:
 * \f[ \frac{df(a)}{da} = \frac{1}{cosh^2(f(a))} = 1 - f(a)^2\f]
 * pro Gaussovu křivku:
 * \f[ \frac{df(a)}{da} = -2 \cdot a \cdot f(a)  \f]
 *
 */
double neuron::der_afce() {
  double derivace = 0;
  switch (typ_afce) {
    case SIGMOIDA:
      derivace = 0.5 * vystup * (1 - vystup);
      break;
    case LINEARNI:
      derivace = 1;
      break;
    case GAUSS:
      derivace = - 2 * vystup * vstup_do_afce;
      break;
    case HTANGENTA:
      derivace = 1 - vystup * vystup;
      break;
    default:
      break;
  }

  return derivace;
}



/**
 * vypne nebo zapne bias u neuronu, tj. přealokuje pole vstup, vahy a zmena_vahy
 * @param pom_bias jaký má být bias
 */
void neuron::zmen_bias(bool pom_bias)
{
  if (pom_bias != bias) {
	  delete[] vstup;
	  delete[] vahy;
	  delete[] zmena_vahy;

    bias = pom_bias;
    vstup = new double[vstupu_neuron + bias];
    vahy = new double[vstupu_neuron + bias];
    zmena_vahy = new double[vstupu_neuron + bias];
  }
}

/**
 * dynamicky alokuje váhy, změna_vahy a vstupy podle počtu vstupů do neuronu a inicializuje je (natvrdo)
 * @param n_vstupu počet vstupů do neuronu
 * @param *pom_vahy pole s váhami generovanými náhodně z rovnoměrného rozdělení od 0 do 1, ukazatel na místo, kde začíná úsek s váhami pro daný neuron - úsek je dlouhý n_vstupu
 */
void neuron::inicializuj_vahy(int n_vstupu, double *pom_vahy)
{
  if (vstupu_neuron != 0) {
	  delete[] vstup;
	  delete[] vahy;
	  delete[] zmena_vahy;
  }
  vstupu_neuron = n_vstupu;
  vahy = new double[vstupu_neuron + bias];
  vstup = new double[vstupu_neuron + bias];
  zmena_vahy = new double[vstupu_neuron + bias];
  for (int vs = 0; vs < vstupu_neuron + bias; vs++) {
  	vahy[vs] = pom_vahy[vs]; //uz to tam zustane
    vstup[vs] = 5; //stejne se bude menit
    zmena_vahy[vs] = 0; //bude se menit pri spusteni BP
  }
}

/**
 * přiřadí do neuronu aktuální vstupní hodnoty
 * @param *vstup_do_neuronu pole, ze kterého se vstupní hodnoty berou
 * @param pocet_vstupu_do_neuronu počet vstupů, kontroluje se s tím, co je ve třídě neuron
 */
void neuron::inicializuj_vstup(double *vstup_do_neuronu, int pocet_vstupu_do_neuronu)
{
  if (pocet_vstupu_do_neuronu != vstupu_neuron)
    cout << "Pocet vstupu do neuronu neodpovida puvodne zadanemu cislu.";

  for (int vs = 0; vs < vstupu_neuron + bias; vs++) {
    if (vs == vstupu_neuron)
      vstup[vs] = 1; //z biasovského neuronu jde vždy 1
    else
      vstup[vs] = vstup_do_neuronu[vs];
  }
}

/**
 * spočítá vstup do aktivační fce: \f$\sum_i w_i \cdot x_i\f$
 */
double neuron::vytvor_vstup_do_afce()
{
  double vstup_do_afce = 0;

  for (int vs = 0; vs < vstupu_neuron + bias; vs++) {
    vstup_do_afce += vahy[vs] * vstup[vs]; //vstup z biasovského už je předtím 1
  }

  return vstup_do_afce;
}



