#include "neural_net.h"
#include "hydromozek.h"

/**
 * všechno nastavení na 0
 */
nastaveni_site::nastaveni_site()
{
  eta = 0;
  momentum = 0;
  pocet_epoch = 0;
  soubor = "";
  bias = false;

  pocet_vrstev = 0;
  pocet_neuronu_ve_vrstve = 0;
  typ_afce = 0;
  pocet_vstupu = 0;
  pocet_vystupu = 0;
}

nastaveni_site::nastaveni_site(const nastaveni_site& orig)
{
  eta = orig.eta;
  momentum = orig.momentum;
  pocet_epoch = orig.pocet_epoch;
  bias = orig.bias;
  soubor = orig.soubor;

  pocet_vrstev = orig.pocet_vrstev;
  pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
  typ_afce = new int[pocet_vrstev];
  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    pocet_neuronu_ve_vrstve[vrs] = orig.pocet_neuronu_ve_vrstve[vrs];
    typ_afce[vrs] = orig.typ_afce[vrs];
  }

  pocet_vstupu = orig.pocet_vstupu;
  pocet_vystupu = orig.pocet_vystupu;
}

nastaveni_site nastaveni_site::operator=(nastaveni_site& orig)
{
  if (this != &orig) {
    eta = orig.eta;
    momentum = orig.momentum;
    pocet_epoch = orig.pocet_epoch;
    bias = orig.bias;
    soubor = orig.soubor;

    pocet_vrstev = orig.pocet_vrstev;
    delete[] pocet_neuronu_ve_vrstve;
    delete[] typ_afce;
    pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
    typ_afce = new int[pocet_vrstev];
    for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
      pocet_neuronu_ve_vrstve[vrs] = orig.pocet_neuronu_ve_vrstve[vrs];
      typ_afce[vrs] = orig.typ_afce[vrs];
    }

    pocet_vstupu = orig.pocet_vstupu;
    pocet_vystupu = orig.pocet_vystupu;
  }
  return *this;
}

nastaveni_site::~nastaveni_site()
{
  if (pocet_vrstev != 0) {
    delete[] pocet_neuronu_ve_vrstve;
    delete[] typ_afce;
  }
}

/**
 * načte nastavení sítě ze souboru a podle něj síť vytvoří
 * @param soubor_nastaveni_site soubor s nastavením sítě
 * @return *this vytvořená síť
 */
neural_net neural_net::vytvor_sit(string soubor_nastaveni_site)
{
  ifstream proud_nas_sit(soubor_nastaveni_site.c_str());
  if(!proud_nas_sit) {
    cout << "\nNeexistuje soubor s nastavenim sítě - " << soubor_nastaveni_site;
    exit(EXIT_FAILURE);
  }
  nacti_nastaveni_soubor(&proud_nas_sit);
  proud_nas_sit.close();
  zmen_sit();

  return *this;
}

/**
 * načtení nastavení ze souboru
 * @param proud vstupní proud
 */
void nastaveni_site::nacti_nastaveni_soubor(ifstream *proud)
{
  string odpad;
  int vrs, pom_pocet_vrstev, *pom_pocet_neuronu_ve_vrstve, *pom_typ_afce, pom_pocet_vstupu, pom_pocet_epoch;
  bool pom_bias;
  double pom_eta, pom_momentum;

  *proud >> odpad >> pom_eta >> odpad  >> pom_momentum >> odpad >> pom_pocet_epoch;
  *proud >> odpad >> pom_bias;
  //pocet vrstev
  *proud >> odpad >> pom_pocet_vrstev >> odpad;
  if (pom_pocet_vrstev < 1) {
  	cout << "\nPocet vrstev musi byt vetsi nez 0.";
    exit(EXIT_FAILURE);
  }
  pom_pocet_neuronu_ve_vrstve = new int[pom_pocet_vrstev];
  pom_typ_afce = new int[pom_pocet_vrstev];
  for (vrs = 0; vrs < pom_pocet_vrstev; vrs++) {
    *proud >> pom_pocet_neuronu_ve_vrstve[vrs];
  }
  *proud >> odpad;
  //afce
  for (vrs = 0; vrs < pom_pocet_vrstev; vrs++) {
    *proud >> pom_typ_afce[vrs];
  }
  //pocet vstupu
  *proud >> odpad;
  *proud >> pom_pocet_vstupu;

  if (pom_pocet_vstupu < 1) {
  	cout << "\nPocet vstupu musi byt vetsi nez 0.";
    exit(EXIT_FAILURE);
  }

  zmen_nastaveni_site(pom_pocet_vrstev, pom_pocet_neuronu_ve_vrstve, pom_typ_afce, pom_pocet_vstupu, pom_eta, pom_momentum, pom_pocet_epoch, pom_bias);

  delete[] pom_pocet_neuronu_ve_vrstve;
  delete[] pom_typ_afce;

}

/**
 * vypíše nastavení do souboru
 * @param proud výstupní proud
 */
void nastaveni_site::vypis_nastaveni_soubor(ofstream *proud)
{
	*proud << "#ucici_kostanta_(eta_learning_rate)\n" << eta;
  *proud << "\n\n#momentum\n" << momentum;
  *proud << "\n\n#pocet_epoch\n" << pocet_epoch;
  *proud << "\n\n#bias_(0_ne,_1_ano)\n" << bias;
  *proud << "\n\n#pocet_vrstev_bez_vstupni\n" << pocet_vrstev;
  *proud << "\n\n#pocty_neuronu_v_jednotlivych_vrstvach_(od_prvni_do_posledni_vystupni)\n";

  int vrs;
	for (vrs = 0; vrs < pocet_vrstev; vrs++) {
		*proud << pocet_neuronu_ve_vrstve[vrs];
		if (vrs < pocet_vrstev - 1)
		  *proud << "\t";
	}
	*proud << "\n\n#typy_afci_v_jednotlivych_vrstvach_(0_sigmoida,1_linearni,2_htangenta,3_gauss)\n";

	for (vrs = 0; vrs < pocet_vrstev; vrs++) {
		*proud << typ_afce[vrs];
		if (vrs < pocet_vrstev - 1)
		  *proud << "\t";
	}
	*proud << "\n\n#pocet_vstupu\n" << pocet_vstupu;

	*proud << "\n";
}

/**
 * změní nastavení sítě na to, které je předané v parametrech
 * aby se změnila síť, je pak potřeba zavolat zmen_sit()
 */
void nastaveni_site::zmen_nastaveni_site(int pom_pocet_vrstev, int *pom_pocet_neuronu_ve_vrstve, int *pom_typ_afce, int pom_pocet_vstupu, double pom_eta, double pom_momentum, int pom_pocet_epoch, bool pom_bias)
{
  //ošetřeno, když se nemění architektura sítě a afce, aby se nemazala a znovu nealokovala pole a nepřiřazovaly hodnoty (které by se při smazání ztratily)
  bool stejne_neuronu = false, stejne_afce = false;
  if (pom_pocet_neuronu_ve_vrstve == pocet_neuronu_ve_vrstve)
    stejne_neuronu = true;
  if (pom_typ_afce == typ_afce)
  	stejne_afce = true;

  if (pocet_vrstev != 0) {
    if (!stejne_neuronu)
      delete[] pocet_neuronu_ve_vrstve;
    if (!stejne_afce)
      delete[] typ_afce;
  }

  if (pom_pocet_epoch < 1) {
  	cout << "\nMoc toho s poctem epoch mensim nez 1 nenatrenujete, vazeni kolegove.";
    exit(EXIT_FAILURE);
  }
  if (pom_eta <= 0) {
  	cout << "\nMoc toho s etou mensi nebo rovno 0 nenatrenujete, vazeni kolegove.";
    exit(EXIT_FAILURE);
  }
  pocet_epoch = pom_pocet_epoch;
  bias = pom_bias;
  eta = pom_eta;
  momentum = pom_momentum;

  if (pom_pocet_vrstev < 1) {
  	cout << "\nPocet vrstev musi byt vetsi nez 0.";
    exit(EXIT_FAILURE);
  }
  pocet_vrstev = pom_pocet_vrstev;

  if (!stejne_neuronu)
    pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
  if (!stejne_afce)
    typ_afce = new int[pocet_vrstev];

  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    if (!stejne_neuronu) {
      if (pom_pocet_neuronu_ve_vrstve[vrs] < 1) {
        cout << "\nPocet neuronu ve vrstve " << vrs << " musi byt vetsi nez 0.";
        exit(EXIT_FAILURE);
      }
      pocet_neuronu_ve_vrstve[vrs] = pom_pocet_neuronu_ve_vrstve[vrs];
    }
    if (!stejne_afce) {
      if (pom_typ_afce[vrs] < 0 || pom_typ_afce[vrs] > POCET_TYPU_AFCE - 1) {
        cout << "\nTyp afce pro vrstvu " << vrs << " musi byt v rozmezi 0 az " << POCET_TYPU_AFCE - 1 << ".";
        exit(EXIT_FAILURE);
      }
      typ_afce[vrs] = pom_typ_afce[vrs];
    }
  }
  if (pom_pocet_vstupu < 1) {
  	cout << "\nPocet vstupu musi byt vetsi nez 0.";
    exit(EXIT_FAILURE);
  }
  pocet_vstupu = pom_pocet_vstupu;
  pocet_vystupu = pocet_neuronu_ve_vrstve[pocet_vrstev - 1];
}


/**
 * nový konstruktor - jen přiřadí 0 do počtu vrstev, vstupů a výstupů
 */
neural_net::neural_net()
{
  skutecny_pocet_vrstev = 0;
  neuron_ve_vrstve = 0;
  vstup = 0;
  vystup = 0;
  vystup_vzor = 0;
}


neural_net::neural_net(const neural_net& orig)
{
  eta = orig.eta;
  momentum = orig.momentum;
  pocet_epoch = orig.pocet_epoch;
  soubor = orig.soubor;
  bias = orig.bias;

  int vrs, neur;
  pocet_vrstev = orig.pocet_vrstev;
  pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
  typ_afce = new int[pocet_vrstev];
  neuron_ve_vrstve = new neuron*[pocet_vrstev];
  for (vrs = 0; vrs < pocet_vrstev; vrs++) {
    pocet_neuronu_ve_vrstve[vrs] = orig.pocet_neuronu_ve_vrstve[vrs];
    neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrstve[vrs] + bias];
    for (neur = 0; neur < pocet_neuronu_ve_vrstve[vrs] + bias; neur++) {
      neuron_ve_vrstve[vrs][neur] = orig.neuron_ve_vrstve[vrs][neur];
    }
  }
  pocet_vstupu = orig.pocet_vstupu;
  pocet_vystupu = orig.pocet_vystupu;
  celkem_vah = orig.celkem_vah;

  vstup = new double[pocet_vstupu];
  vystup = new double[pocet_vystupu];
  vystup_vzor = new double[pocet_vystupu];
  int vs;
  for (vs = 0; vs < pocet_vstupu; vs++) {
    vstup[vs] = orig.vstup[vs];
  }
  for (vs = 0; vs < pocet_vystupu; vs++) {
    vystup[vs] = orig.vystup[vs];
    vystup_vzor[vs] = orig.vystup_vzor[vs];
  }
  skutecny_pocet_vrstev = orig.skutecny_pocet_vrstev;
}



/**
 * funkce pro kopirovani objektu neural_net pretizenim operatoru =
 */
neural_net neural_net::operator=(neural_net& orig)
{
  if (this != &orig) {
    eta = orig.eta;
    momentum = orig.momentum;
    pocet_epoch = orig.pocet_epoch;
    bias = orig.bias;
    soubor = orig.soubor;

    int vrs, neur;
    for (vrs = 0; vrs < skutecny_pocet_vrstev; vrs++)
      delete[] neuron_ve_vrstve[vrs];
    delete[] neuron_ve_vrstve;
    delete[] typ_afce;
    pocet_vrstev = orig.pocet_vrstev;
    delete[] pocet_neuronu_ve_vrstve;
    pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
    typ_afce = new int[pocet_vrstev];
    neuron_ve_vrstve = new neuron*[pocet_vrstev];
    for (vrs = 0; vrs < pocet_vrstev; vrs++) {
      pocet_neuronu_ve_vrstve[vrs] = orig.pocet_neuronu_ve_vrstve[vrs];
      neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrstve[vrs] + bias];
      for (neur = 0; neur < pocet_neuronu_ve_vrstve[vrs] + bias; neur++) {
        neuron_ve_vrstve[vrs][neur] = orig.neuron_ve_vrstve[vrs][neur];
      }
    }
    pocet_vstupu = orig.pocet_vstupu;
    pocet_vystupu = orig.pocet_vystupu;
    celkem_vah = orig.celkem_vah;
    delete[] vstup;
    delete[] vystup;
    delete[] vystup_vzor;

    vstup = new double[pocet_vstupu];
    vystup = new double[pocet_vystupu];
    vystup_vzor = new double[pocet_vystupu];
    int vs;
    for (vs = 0; vs < pocet_vstupu; vs++) {
      vstup[vs] = orig.vstup[vs];
    }
    for (vs = 0; vs < pocet_vystupu; vs++) {
      vystup[vs] = orig.vystup[vs];
      vystup_vzor[vs] = orig.vystup_vzor[vs];
    }
    skutecny_pocet_vrstev = orig.skutecny_pocet_vrstev;
  }
  return *this;
}

/**
 * stejné jako následující fce, jen se parametry berou odjinud - podle toho, co je aktuálně v nastavení
 * bývalý konstruktor - podle nastavení (zděděném z nastaveni_site) přiřadí počet vrstev, počty neuronů ve vrstvě a počet vstupů
 * dynamicky alokuje všechny neurony sítě - neinicializuje je
 * dynamicky alokuje vstupy a inicializuje je na 0
 */
void neural_net::zmen_sit()
{
  //cout << "pocet vrstev" << skutecny_pocet_vrstev << " " << pocet_vrstev;
  if (skutecny_pocet_vrstev != 0) {
    for (int vrs = 0; vrs < skutecny_pocet_vrstev; vrs++) {  //pocet_vrstev už nová hodnota - neodpovídá!!!
      delete[] neuron_ve_vrstve[vrs]; //a tady to spadne
    }
    delete[] neuron_ve_vrstve;
  }

  delete[] vstup;
  delete[] vystup;
  delete[] vystup_vzor;

  int vrs;

  neuron_ve_vrstve = new neuron*[pocet_vrstev];
  for (vrs = 0; vrs < pocet_vrstev; vrs++) {
	  neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrstve[vrs] + bias];
	  for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs] + bias; neur++) {
      neuron_ve_vrstve[vrs][neur].zmen_bias(bias); //nastavení biasu pro síť stejné pro neurony
	  	neuron_ve_vrstve[vrs][neur].typ_afce = typ_afce[vrs];
	  }
  }
  //vytvoření pole vstupů - je nutné (vstupní vrstva není první vrstvou sítě)
  vstup = new double[pocet_vstupu];
  for (int n = 0; n < pocet_vstupu; n++)
	  vstup[n] = 999999;
  //vytvoření pole výstupů - není nutné, ale přehlednější (výsledky jsou u výstupu z neuronu poslední vrstvy)
  vystup = new double[pocet_vystupu];
  for (int n = 0; n < pocet_vystupu; n++)
	  vystup[n] = 999999;

  vystup_vzor = new double[pocet_vystupu];
  for (int n = 0; n < pocet_vystupu; n++)
	  vystup_vzor[n] = 999999;

  skutecny_pocet_vrstev = pocet_vrstev;

	pocet_vah();

	//aby se inicializovaly i vahy
	inicializuj();

}

/**
 * bývalý konstruktor - podle parametrů přiřadí počet vrstev, počty neuronů ve vrstvě a počet vstupů
 * dynamicky alokuje všechny neurony sítě - neinicializuje je
 * dynamicky alokuje vstupy a inicializuje je na 0
 * @param vrstev počet vrstev sítě
 * @param *neuronu pole s počty neuronů v jednotlivých vrstvách - pole se nekopíruje, používá se předávané do fce
 * @param pocet_vstupnich počet hodnot vstupujících do sítě
 * @param *typ_afce_pro_vrstvu typ aktivační fce pro jednotlivé vrstvy (velikost pole je počet vrstev)
 */
void neural_net::zmen_sit(int vrstev, int *neuronu, int pocet_vstupnich, int *typ_afce_pro_vrstvu)
{
  delete[] pocet_neuronu_ve_vrstve;

  for (int vrs = 0; vrs < skutecny_pocet_vrstev; vrs++) {
    delete[] neuron_ve_vrstve[vrs];
  }
  delete[] neuron_ve_vrstve;

  delete[] vstup;
  delete[] vystup;
  delete[] vystup_vzor;

  int vrs;
  pocet_vrstev = vrstev;

  pocet_neuronu_ve_vrstve = new int[pocet_vrstev];
  for (vrs = 0; vrs < pocet_vrstev; vrs++)
  	pocet_neuronu_ve_vrstve[vrs] = neuronu[vrs];

  neuron_ve_vrstve = new neuron*[pocet_vrstev];
  for (vrs = 0; vrs < pocet_vrstev; vrs++) {
	  neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrstve[vrs] + bias];
	  for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs] + bias; neur++) {
	    neuron_ve_vrstve[vrs][neur].zmen_bias(bias);
	  	neuron_ve_vrstve[vrs][neur].typ_afce = typ_afce_pro_vrstvu[vrs];
	  }
  }
  //vytvoření pole vstupů - je nutné (vstupní vrstva není první vrstvou sítě)
  pocet_vstupu = pocet_vstupnich;
  vstup = new double[pocet_vstupu];
  for (int n = 0; n < pocet_vstupu; n++)
	  vstup[n] = 999999;
  //vytvoření pole výstupů - není nutné, ale přehlednější (výsledky jsou u výstupu z neuronu poslední vrstvy)
  pocet_vystupu = pocet_neuronu_ve_vrstve[pocet_vrstev - 1];
  vystup = new double[pocet_vystupu];
  for (int n = 0; n < pocet_vystupu; n++)
	  vystup[n] = 999999;

  vystup_vzor = new double[pocet_vystupu];
  for (int n = 0; n < pocet_vystupu; n++)
	  vystup_vzor[n] = 999999;

  skutecny_pocet_vrstev = pocet_vrstev;

	pocet_vah();

  //aby se inicializovaly i vahy
	inicializuj();

}

/**
 * uvolní paměť zabranou neurony a vstupními daty z objektu neuronové sítě
 */
neural_net::~neural_net()
{
  for (int vrs = 0; vrs < skutecny_pocet_vrstev; vrs++) {
    delete[] neuron_ve_vrstve[vrs];
  }
  delete[] neuron_ve_vrstve;

  if (pocet_vstupu != 0)
    delete[] vstup;

  if (pocet_vystupu != 0) {
    delete[] vystup;
    delete[] vystup_vzor;
  }
}

/**
 * zjistí celkový počet všech vah v neuronové síti
 */
void neural_net::pocet_vah() {
  celkem_vah = 0;
  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) { //nedává se váha od předchozích k biasovým neuronům
      if (vrs == 0)
        celkem_vah += pocet_vstupu + bias;
      else
        celkem_vah += pocet_neuronu_ve_vrstve[vrs - 1] + bias; //normální neurony jsou propojeny s biasovými z předchozí vrstvy
    }
  }

}
/**
 * vypíše počet vrstev sítě, počty neuronů v jednotlivých vrstvách, typ afce použitý ve vrstvách a váhy jednotlivých neuronů
 *@param soubor_se_siti jméno souboru s vypisovanou sítí
 */
void neural_net::vypis_sit(string soubor_se_siti)
{
  ofstream proud(soubor_se_siti.c_str());
	if(!proud) {
		cout << "\nNeexistuje soubor do ktereho je vypisovana sit - " << soubor_se_siti;
		exit(0);
	}
	vypis_nastaveni_soubor(&proud);

	int vrs, neur;
	proud.width(10);
	proud.precision(10);

	for (vrs = 0; vrs < pocet_vrstev; vrs++) {
		proud << "\n\nvrstva_cislo_" << vrs << ":\n";
//		proud << "Typ_aktivace_v_jednotlivych_vrstvach_(0_sigmoida,1_linearni,2_htangenta,3_gauss): " << neuron_ve_vrstve[vrs][0].typ_afce << "\n";
		for (neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) { //není pro biasový neuron
      proud << "\nneuron_cislo_" << neur << ":\n";
      proud << "vahy: ";
			for (int vs = 0; vs < neuron_ve_vrstve[vrs][neur].vstupu_neuron + bias; vs++)
				proud << "\t" << neuron_ve_vrstve[vrs][neur].vahy[vs];
			proud << "\n";
    }
  }
	proud.close();
}

/**
 * načte počet vrstev sítě, počty neuronů v jednotlivých vrstvách, typ afce použitý ve vrstvách a váhy jednotlivých neuronů
 * @param soubor_se_siti jméno souboru s vypisovanou sítí
 */
void neural_net::nacti_sit(string soubor_se_siti)
{
	string odpad;

	int vrs, neur, vah;
	double *pole_s_vahami;

	ifstream proud(soubor_se_siti.c_str());

	if(!proud) {
		cout << "\nNeexistuje soubor, ze ktereho je nacitana sit - " << soubor_se_siti;
		exit(EXIT_FAILURE);
	}
	nacti_nastaveni_soubor(&proud);

	//	vypis_sit("data/pokus/sit_po_nacti_nast.txt");
	zmen_sit(); //podle nastavení vytvoří síť

	pole_s_vahami = new double[celkem_vah];

	int pom_prom = 0;
	int pom_pocet_vah;

	for (vrs = 0; vrs < pocet_vrstev; vrs++) {
  	proud >> odpad;
		for(neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) {
		  proud >> odpad;
		  if (vrs == 0)
		    pom_pocet_vah = pocet_vstupu + bias;
			else
			  pom_pocet_vah = pocet_neuronu_ve_vrstve[vrs - 1] + bias;

			for(vah = 0; vah < pom_pocet_vah; vah++) {
			  if (vah == 0)
			    proud >> odpad;
			  proud >> pole_s_vahami[pom_prom];
        pom_prom++;
			}
		}
	}

	proud.close();

	//z pomocných do sítě
	prirad_vahy(pole_s_vahami); //tahle funkce zajistí, že se vždy alokuje pro neuron daný počet vah (proto se nepřiřazuje tady přímo váha neuronům)

	delete [] pole_s_vahami;

	skutecny_pocet_vrstev = pocet_vrstev;
}

/**
 * pro všechny neurony sítě inicializuje jejich váhy a vstupní hodnoty pomocí inicializuj_vahy
 * pro inicializaci vah používá náhodný generátor - rovnoměrné rozdělení od 0 do 1, inicializace generátoru podle aktuálního času
 */
void neural_net::inicializuj()
{
  double *pom_vahy = new double[celkem_vah];

  gsl_rng_env_setup();

 // cout << "vah celkem " << celkem_vah << "\n";

  long int l = time(NULL);
  int vah;

  for (vah = 0; vah < celkem_vah; vah++) {
    gsl_rng_default_seed = ++l;
    gsl_rng *nah_gen = gsl_rng_alloc(gsl_rng_default);

    pom_vahy[vah] = gsl_rng_uniform(nah_gen);

    gsl_rng_free(nah_gen);
  }

  int posun_vah = 0;
  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) { //nedělá se pro biasovské neurony
      if (vrs == 0)
        vah = pocet_vstupu;
      else
        vah = pocet_neuronu_ve_vrstve[vrs - 1];

      neuron_ve_vrstve[vrs][neur].inicializuj_vahy(vah, &pom_vahy[posun_vah]);

      posun_vah += vah;
    }
  }
  delete[] pom_vahy;
}

/**
 * Přiřadí váhy do sítě
 * @param *pole_vahy 1d pole s váhami, které jsou přiřazeny
 */
void neural_net::prirad_vahy(double *pole_vahy)
{
  int posun_vah = 0, vah;

  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) {
      if (vrs == 0)
        vah = pocet_vstupu; //není bias, ten se přičítá až v neuronu - inicializuj_vahy
      else
        vah = pocet_neuronu_ve_vrstve[vrs - 1];

      neuron_ve_vrstve[vrs][neur].inicializuj_vahy(vah, &pole_vahy[posun_vah]);

      posun_vah += vah;
    }
  }
}
/**
 * naplní se pole vstup nebo vystup_vzor hodnotami z parametru prvni_vstup_vystup
 * kontroluje, zda zadaný počet vstupů/výstupů odpovídá počtu definovaném ve třídě neural_net
 * @param typ_pole vstup nebo vzorový výstup
 * @param prvni_vstup_vystup pole se vstupními hodnotami, překopíruje se do pole vstup dané sítě
 * @param pocet_prv_vstupu_vystupu velikost pole se vstupními hodnotami
 */
void neural_net::inicializuj_vstup_vystup(int typ_pole, double *prvni_vstup_vystup, int pocet_prv_vstupu_vystupu)
{
  int pocet = 0;
  double *pom_pole = NULL;
  switch (typ_pole) {
  	case VSTUP_VZOR:
  	  pocet = pocet_vstupu;
  	  pom_pole = vstup;
  		break;
  	case VYSTUP_VZOR:
  	  pocet = pocet_vystupu;
  	  pom_pole = vystup_vzor;
  		break;
  	default:
  		break;
  }
  if (pocet_prv_vstupu_vystupu != pocet)
    cout << "Pocet vstupu nebo vzor. vystupu do neuronove site neodpovida puvodne zadanemu cislu.";

  for (int vs = 0; vs < pocet; vs++)
    pom_pole[vs] = prvni_vstup_vystup[vs];
}

/**
 * ke každému neuronu sítě vypočte výstup ve 3 krocích:
 * 1. zjistí počet vstupů a hodnoty vstupů z výstupů z předchozích vrstev (příp. pro 1. vrstvu ze vstupních dat)
 * 2. vytvoří vstup do afce - lineární kombinace vstupů a vah
 * 3. prožene lin. kombinaci aktivační fcí - výsledek v objektu neuron jako vystup, výsledek z poslední vrstvy přiřazen do pole vystup
 */
void neural_net::vypocti()
{
  for (int vrs = 0; vrs < pocet_vrstev; vrs++) {
    double *pom_vstup;
    int pom_pocet_vstupu;
    if (vrs == 0) {
      pom_vstup = vstup;
      pom_pocet_vstupu = pocet_vstupu;
    }
    else {
      pom_vstup = new double[pocet_neuronu_ve_vrstve[vrs - 1]];
      for (int predvrs = 0; predvrs < pocet_neuronu_ve_vrstve[vrs - 1]; predvrs++)
        pom_vstup[predvrs] = neuron_ve_vrstve[vrs - 1][predvrs].vystup;
      pom_pocet_vstupu = pocet_neuronu_ve_vrstve[vrs-1];
    }
    for (int neur = 0; neur < pocet_neuronu_ve_vrstve[vrs] + bias; neur++) {
      if (neur == pocet_neuronu_ve_vrstve[vrs]) { //biasovský neuron
        //neinicializuje se vstup a nepočítá se vstup_do_afce, nezáleží na něm, když výstup je vždy 1
        neuron_ve_vrstve[vrs][neur].vystup = 1;
      }
      else {
        neuron_ve_vrstve[vrs][neur].inicializuj_vstup(pom_vstup, pom_pocet_vstupu);
        neuron_ve_vrstve[vrs][neur].vstup_do_afce = neuron_ve_vrstve[vrs][neur].vytvor_vstup_do_afce();
        neuron_ve_vrstve[vrs][neur].afce(neuron_ve_vrstve[vrs][neur].vstup_do_afce);
      }
      //výstup z poslední vrstvy do výstupního pole
      if (vrs == pocet_vrstev - 1 && neur != pocet_neuronu_ve_vrstve[vrs]) //není výstup pro biasovský neuron (který navíc ve výstupní vrstvě není k ničemu)
        vystup[neur] = neuron_ve_vrstve[vrs][neur].vystup;

    }

    if (vrs != 0)
      delete[] pom_vstup;
  }

}

/**
 * základní krok backpropagation algoritmu - změní váhy v celé neuronové síti
 * 1. vypočte chybu pro neuron
 * 2. změní váhy neuronu podle chyby, derivace afce (napsat rovnici)
 */
void neural_net::zmen_vahy()
{
  double pom_vstup, pom_vystup;
  int neur, v;
  for (int vrs = pocet_vrstev - 1; vrs >= 0; vrs--) {
    for (neur = 0; neur < pocet_neuronu_ve_vrstve[vrs]; neur++) { //biasovský neuron nemá váhy a nepočítá se pro něj chyba - proto tady není +bias
      if (vrs == pocet_vrstev - 1) { //pro posledni = výstupní vrstvu se chyba pocita jinak
    	  neuron_ve_vrstve[vrs][neur].chyba = neuron_ve_vrstve[vrs][neur].vystup - vystup_vzor[neur];
//        if (neur == 0)
//          cout << "\n" << neuron_ve_vrstve[vrs][neur].chyba << "\n";
      }
      else {
        neuron_ve_vrstve[vrs][neur].chyba = 0;
        for (v = 0; v < pocet_neuronu_ve_vrstve[vrs + 1]; v++) { //z biasového neuronu nešíří chyba zpátky, proto není + bias
          neuron_ve_vrstve[vrs][neur].chyba += neuron_ve_vrstve[vrs + 1][v].chyba * neuron_ve_vrstve[vrs + 1][v].vahy[neur];
        }
      }

      int pom_pocet_vah;
      if (vrs == 0) //počet vstupů do nebiasovského neuronu i z biasovských z předchozí vrstvy
        pom_pocet_vah = pocet_vstupu + bias;
      else
        pom_pocet_vah = pocet_neuronu_ve_vrstve[vrs - 1] + bias;

      for (v = 0; v < pom_pocet_vah; v++) {
        if (vrs == 0) {
          if (v == pom_pocet_vah - 1) //vstup z biasovského v nulté=vstupní vrstvě musí být 1
            pom_vstup = 1;
          else {
            pom_vstup = vstup[v];
            if (neur == 0 && v == pom_pocet_vah - 2) {
//              cout << vstup[v] << "--- vvxxxxxxxxxx\n";
//              cout << pom_vstup << "--- pomvstupxxxxxxxxxx\n";
            }
          }

          neuron_ve_vrstve[vrs][neur].vahy[v] += -eta * neuron_ve_vrstve[vrs][neur].der_afce() * neuron_ve_vrstve[vrs][neur].chyba * pom_vstup + momentum * neuron_ve_vrstve[vrs][neur].zmena_vahy[v];
          neuron_ve_vrstve[vrs][neur].zmena_vahy[v] = -eta * neuron_ve_vrstve[vrs][neur].der_afce() * neuron_ve_vrstve[vrs][neur].chyba * pom_vstup + momentum * neuron_ve_vrstve[vrs][neur].zmena_vahy[v];

if (neur == 0 && v == pom_pocet_vah - 2) {

//        cout << vstup[0] << "--- VSTUPzac\n";
//      cout << vstup[1] << "--- VSTUPzac\n";
//      cout << vstup[2] << "--- VSTUPzac\n";
//
//cout << pocet_vstupu << "pocet vstupu\n";
//cout << bias << "bias\n";
//cout << v << "vvv\n";
//cout << pom_pocet_vah << "pompocetvah\n";
//  cout <<-eta << "--- 1\n";
//  cout << neuron_ve_vrstve[vrs][neur].der_afce()<< "--- 2\n";
//  cout << neuron_ve_vrstve[vrs][neur].chyba<< "--- 3\n";
//  cout << pom_vstup<< "--- 4\n";
//  cout << momentum<< "--- 5\n";
//  cout << neuron_ve_vrstve[vrs][neur].zmena_vahy[v]<< "\n";
//  cout << neuron_ve_vrstve[vrs][neur].der_afce() << "\n";
//  cout << neuron_ve_vrstve[vrs][neur].vahy[v] << "\t";
//  cout << neuron_ve_vrstve[vrs][neur].zmena_vahy[v] << "\n";
//
//
//        cout << vstup[0] << "--- VSTUPkonec\n";
//      cout << vstup[1] << "--- VSTUPkonec\n";
//      cout << vstup[2] << "--- VSTUPkonec\n";
}

        }
        else {
          if (v == pom_pocet_vah - 1) //z biasovského neuronu výstup vždy 1 (už tam je někde předtím, ale pro přehlednost)
          	pom_vystup = 1;
          else
            pom_vystup = neuron_ve_vrstve[vrs - 1][v].vystup;

          neuron_ve_vrstve[vrs][neur].vahy[v] += -eta * neuron_ve_vrstve[vrs][neur].der_afce() * neuron_ve_vrstve[vrs][neur].chyba * pom_vystup + momentum * neuron_ve_vrstve[vrs][neur].zmena_vahy[v];

//          if (vrs >= pocet_vrstev)
//            cout << "\npocet vrstev " << pocet_vrstev << "vrs " << vrs;
//          if (neur >= pocet_neuronu_ve_vrstve[vrs])
//          cout << "\nneuronu ve vrstve " << pocet_neuronu_ve_vrstve[vrs] << " neur " << neur;

          neuron_ve_vrstve[vrs][neur].zmena_vahy[v] = -eta * neuron_ve_vrstve[vrs][neur].der_afce() * neuron_ve_vrstve[vrs][neur].chyba * pom_vystup + momentum * neuron_ve_vrstve[vrs][neur].zmena_vahy[v];
        }
      }
    } //neuron
  } //vrstva


}

/**
 * natrénuje neuronovou síť podle daných vzorů
 * výsledek - v síti budou konečné váhy
 * @param vzor_vstup vstupní vzory do sítě
 * @param vzor_vystup výstupní vzory do sítě
 */
void neural_net::trenuj(vzory_site *vzor_vstup, vzory_site *vzor_vystup)
{
  for (int epocha = 0; epocha < pocet_epoch; epocha++) {
    for (int vzor = 0; vzor < vzor_vstup->pocet_vzoru; vzor++) { //vzorů stejně vstupních a výstupních, je to jedno
      inicializuj_vstup_vystup(VSTUP_VZOR, vzor_vstup->vzor[vzor], pocet_vstupu);
      inicializuj_vstup_vystup(VYSTUP_VZOR, vzor_vystup->vzor[vzor], pocet_vystupu);
      vypocti();
      zmen_vahy();
    }
  }
}

/**
 * provede jeden výpočet sítí s váhami (které jsou v síti) pro všechny vzory
 * @param vzor_vstup vstupní vzory do sítě
 * @param vzor_vystup výstupní vzory do sítě
 * @param zda_vystup zda se budou ukládat výsledky
 * @param vystup_sim kam se ukládají výsledky, pole musí už být alokováno příslušně
 */
void neural_net::simuluj(vzory_site *vzor_vstup, vzory_site *vzor_vystup, bool zda_vystup, vzory_site *vystup_sim)
{
  for (int vzor = 0; vzor < vzor_vstup->pocet_vzoru; vzor++) { //vzorů stejně vstupních a výstupních, je to jedno
    inicializuj_vstup_vystup(VSTUP_VZOR, vzor_vstup->vzor[vzor], pocet_vstupu);
    inicializuj_vstup_vystup(VYSTUP_VZOR, vzor_vystup->vzor[vzor], pocet_vystupu);
    vypocti();
    if (zda_vystup) {
      if (pocet_vystupu != vystup_sim->pocet) {
        cout << "Pocet vystupu v poli vystup_sim neodpovida poctu vystupu ze site.\n";
        exit(EXIT_FAILURE);
      }
      for (int vys = 0; vys < pocet_vystupu; vys++) {
    	  vystup_sim->vzor[vzor][vys] = vystup[vys];
    	}
    }
  }
}
