#include "merena.h"
#include "hydromozek.h"

/**
 * všechno nastavení na 0
 */
data_pro_sit::data_pro_sit()
{
  pocet_souboru_s_daty = 0;
}

data_pro_sit::~data_pro_sit()
{
  int soub, sl;

  if (pocet_souboru_s_daty != 0) {
    for (soub = 0; soub < pocet_souboru_s_daty; soub++) {
      if (pocet_sloupcu[soub] != 0) {
        if (pocet_radku[soub] != 0) {
          for (sl = 0; sl < pocet_sloupcu[soub]; sl++)
            delete[] zdroj[soub][sl];
        }
        delete[] zdroj[soub];
      }
    }
    delete[] zdroj;
  }

  if (pocet_souboru_s_daty != 0) {
    delete[] pocet_sloupcu;
    delete[] pocet_radku;
  }
  if (pocet_souboru_s_daty != 0)
  	delete[] soubory_s_daty;


}

/**
 * načte ze souborů s daty hodnoty do pole zdroj_vstup
 * do pole zdroj_vystup přiřadí 99999
 * @param cesta cesta k souborům s daty (datové soubory musí být v jednom adresáři)
 * @param soubor_s_nazvy_souboru jméno souboru, kde je seznam s názvy souborů s daty
 */
void data_pro_sit::nacti_ze_souboru(string cesta, string soubor_s_nazvy_souboru)
{
  int soub;
  ifstream proud(soubor_s_nazvy_souboru.c_str());
  if(!proud) {
    cout << "\nNeexistuje soubor s nazvy souboru s daty - " << soubor_s_nazvy_souboru;
    exit(EXIT_FAILURE);
  }
  string odpad;
  pocet_souboru_s_daty = 0;
  while (!proud.eof()) {
    getline(proud, odpad);
    pocet_souboru_s_daty++;
  }
  pocet_souboru_s_daty--;
  cout << "\nPocet souboru s daty: " << pocet_souboru_s_daty;

  zdroj = new double**[pocet_souboru_s_daty];
  soubory_s_daty = new string[pocet_souboru_s_daty];
  pocet_radku = new int[pocet_souboru_s_daty];
  pocet_sloupcu = new int[pocet_souboru_s_daty];

  //vracime se na začátek
  proud.clear();
  proud.seekg(0, ios::beg);

  for (soub = 0; soub < pocet_souboru_s_daty; soub++) {
    proud >> soubory_s_daty[soub];
    cout << "\n" << soubory_s_daty[soub];
  }
  proud.close();

  int pom_pocet_radku, pom_pocet_sloupcu, rad, sl;
  double pom = 0;
  cout << "\n\nDetailni informace o souborech se vstupnimi daty:\n";
  for (soub = 0; soub < pocet_souboru_s_daty; soub++) {
    ifstream proud((cesta + soubory_s_daty[soub]).c_str());

    if(!proud) {
      cout << "\nNeexistuje soubor s nazvy souboru s daty - " << cesta + soubory_s_daty[soub];
      exit(EXIT_FAILURE);
    }

    int pozice = 0;

    //počet řádků v souboru
    pom_pocet_radku = 0;
    getline(proud, odpad);
    pom_pocet_radku++;
    pozice = proud.tellg();
    while (!proud.eof()) {
      getline(proud, odpad);
      pom_pocet_radku++;
    }
    pom_pocet_radku--;

    //počet sloupců v souboru
    proud.clear();
    proud.seekg(0, ios::beg);
    pom_pocet_sloupcu = 0;
    while (proud.tellg() < pozice) {
      proud >> odpad;
      pom_pocet_sloupcu++;
    }
    pom_pocet_sloupcu--;

    proud.clear();
    proud.seekg(0, ios::beg);

    cout << "V souboru " << soubory_s_daty[soub] << " je " << pom_pocet_radku << " radku a " << pom_pocet_sloupcu << " sloupcu." << "\n";

    pocet_radku[soub] = pom_pocet_radku;
    pocet_sloupcu[soub] = pom_pocet_sloupcu;

    zdroj[soub] = new double*[pocet_sloupcu[soub]];
    for (sl = 0; sl < pocet_sloupcu[soub]; sl++) {
      zdroj[soub][sl] = new double[pocet_radku[soub]];
    }

    for (rad = 0; rad < pocet_radku[soub]; rad++) {
      for (sl = 0; sl < pocet_sloupcu[soub]; sl++) {
        proud >> odpad;
        if (string2double(odpad.c_str(), pom)) {
          zdroj[soub][sl][rad] = pom;
        }
        else {
          cout << "\nChyba ve vstupnim souboru " << soubory_s_daty[soub] << " na radku " << rad << " a ve sloupci " << sl << ".";
          proud.close();
          exit(EXIT_FAILURE);
        }
      }
    }
    proud.close();
  }
}

/**
 * převádí string na double - je to z Fredosaura (Fred Swartz 2000) http://www.fredosaurus.com/notes-cpp/algorithms/string2int-ans.html
 * @param digit vstupní string
 * @param result výsledek - převedený string
 * \return false, když tam jsou nečíselné znaky
 */
bool data_pro_sit::string2double(const char* digit, double& result)
{
	int sign = 1;
	result = 0;

   // check sign
	if (*digit == '-') {
		sign = -1;
		digit++;
	}

   //--- get integer portion
	while (*digit >= '0' && *digit <='9') {
		result = (result * 10) + *digit-'0';
		digit++;
	}

   //--- get decimal point and fraction, if aeta.
	if (*digit == '.') {
		digit++;
		double scale = 0.1;
		while (*digit >= '0' && *digit <='9') {
			result += (*digit-'0') * scale;
			scale *= 0.1;
			digit++;
		}
	}

   //--- error if we're not at the end of the number
	if (*digit != 0) {
		return false;
	}

   //--- set to sign given at the front
	result = result * sign;
	return true;
}



/**
 * VZORY SÍTĚ
 */
vzory_site::vzory_site()
{
  pocet = 0;
  pocet_vzoru = 0;
  max_radek = 0;
  sloupec = radek = 0;
  vzor = 0;
  alfa = maximum = minimum = prah = 0;
  typ_transformace = 0;
  vzor_vytvoren = false;
}

vzory_site::~vzory_site()
{
  if (pocet != 0) {
    delete[] sloupec;
    delete[] radek;
  }
  if (pocet_vzoru != 0) {
    for (int vz = 0; vz < pocet_vzoru; vz++) {
      delete[] vzor[vz];
    }
    delete[] vzor;
  }

}

/**
 * kopírovací konstruktor
 */
vzory_site::vzory_site(const vzory_site& orig)
{
  pocet = orig.pocet;
  pocet_vzoru = orig.pocet_vzoru;
  max_radek = orig.max_radek;
  alfa = orig.alfa;
  maximum = orig.maximum;
  minimum = orig.minimum;
  prah = orig.prah;
  typ_transformace = orig.typ_transformace;
  vzor_vytvoren = orig.vzor_vytvoren;

  radek = new int[pocet];
  sloupec = new int[pocet];
  int radsl, vz, vsvy;
  for (radsl = 0; radsl < pocet; radsl++) {
    sloupec[radsl] = orig.sloupec[radsl];
    radek[radsl] = orig.radek[radsl];
  }
  vzor = new double*[pocet_vzoru];
  for (vz = 0; vz < pocet_vzoru; vz++) {
    vzor[vz] = new double[pocet];
  }
  for (vz = 0; vz < pocet_vzoru; vz++) {
    for (vsvy = 0; vsvy < pocet; vsvy++)
      vzor[vz][vsvy] = orig.vzor[vz][vsvy];
  }
}

/**
 * přiřazovací operátor
 */
vzory_site vzory_site::operator=(vzory_site& orig)
{
  if (this != &orig) {
    delete[] sloupec;
    delete[] radek;

    for (int vz = 0; vz < pocet_vzoru; vz++) {
      delete[] vzor[vz];
    }
    delete[] vzor;

    pocet = orig.pocet;
    pocet_vzoru = orig.pocet_vzoru;
    max_radek = orig.max_radek;
    alfa = orig.alfa;
    maximum = orig.maximum;
    minimum = orig.minimum;
    prah = orig.prah;
    typ_transformace = orig.typ_transformace;
    vzor_vytvoren = orig.vzor_vytvoren;

    radek = new int[pocet];
    sloupec = new int[pocet];
    int radsl, vz, vsvy;
    for (radsl = 0; radsl < pocet; radsl++) {
      sloupec[radsl] = orig.sloupec[radsl];
      radek[radsl] = orig.radek[radsl];
    }
    vzor = new double*[pocet_vzoru];
    for (vz = 0; vz < pocet_vzoru; vz++) {
      vzor[vz] = new double[pocet];
    }
    double x,y;
    for (vz = 0; vz < pocet_vzoru; vz++) {
      for (vsvy = 0; vsvy < pocet; vsvy++) {
        x = vzor[vz][vsvy];
        y = orig.vzor[vz][vsvy];
        vzor[vz][vsvy] = orig.vzor[vz][vsvy];
        x = vzor[vz][vsvy];
        y = orig.vzor[vz][vsvy];
      }
    }
  }
  return *this;
}


/**
 * načtení nastavení vzorů (vstupů nebo výstupů) ze souboru
 * @param proud vstupní proud s nastavením vzorů
 */
void vzory_site::nacti_nastaveni_ze_souboru(ifstream *proud)
{
  string odpad;
  if (pocet != 0) {
    delete[] sloupec;
    delete[] radek;
  }
  if (vzor_vytvoren) {
    for (int vz = 0; vz < pocet_vzoru; vz++) {
      delete[] vzor[vz];
    }
    delete[] vzor;
    vzor_vytvoren = false;
  }
  *proud >> odpad >> typ_transformace;
  *proud >> odpad >> alfa >> odpad >> prah;

  if (alfa < 0) {
  	cout << "\nParametr alfa pro transformaci vzorů musí být větší než 0.";
    exit(EXIT_FAILURE);
  }
  if (prah < 0) {
  	cout << "\nParametr prah pro transformaci vzorů musí být větší než 0.";
    exit(EXIT_FAILURE);
  }

  *proud >> odpad >> pocet;
  if (pocet <= 0) {
	  cout << "\nPocet vstupu nebo vystupu v nastaveni vzoru musi byt vetsi nez 0.";
	  exit(EXIT_FAILURE);
  }
  radek = new int[pocet];
  sloupec = new int[pocet];
  int radsl;
  *proud >> odpad;
  for (radsl = 0; radsl < pocet; radsl++) {
  	*proud >> sloupec[radsl];
  }
  *proud >> odpad;
  for (radsl = 0; radsl < pocet; radsl++) {
  	*proud >> radek[radsl];
  }

}

/**
 * vypíše nastavení vzorů (vstupů nebo výstupů) do souboru
 * @param proud výstupní proud do souboru
 * @param vstup zda vstup nebo výstup (pro výpis textu)
 */
void vzory_site::vypis_nastaveni_do_souboru(ofstream *proud, bool vstup)
{
  string text = "vstupu";
  if (!vstup)
  	text = "vystupu";

  *proud << "#typ_transformace_(0_EXP,_1_LIN)\n" << typ_transformace << "\n\n";;
  *proud << "#alfa_parametr_transformace_vzoru_g=1-exp(-alpha*x)\n" << alfa << "\n\n#prah_pro_linearni_transformaci_pomer_(napr_0.2)" << prah << "\n\n";
  *proud << "#pocet_" << text << "\n" << pocet << "\n\n";
  int radsl;
  *proud << "#sloupec_" << text << "_(minimum_je_1)\n";
  for (radsl = 0; radsl < pocet; radsl++) {
  	*proud << sloupec[radsl] << "\t";
  }
  *proud << "\n\n#radek_" << text << "_(minimum_je_1)\n";
  for (radsl = 0; radsl < pocet; radsl++) {
  	*proud << radek[radsl] << "\t";
  }
  *proud << "\n\n";
}

/**
 * změní nastavení vzorů podle předaných parametrů
 * nemění pole vzory - nutno pak vytvořit pomocí kontroluj_nastaveni_vzoru() a vytvor_vzory()
 * maximum, minimum a max. radek zůstávají stejné!!!
 * @param pom_pocet
 * @param pom_sloupec
 * @param pom_radek
 * @param pom_prah
 * @param pom_alfa
 * @param pom_typ
 */
void vzory_site::zmen_nastaveni_vzoru(int pom_pocet, int *pom_sloupec, int *pom_radek, double pom_prah, double pom_alfa, int pom_typ)
{
  prah = pom_prah;
  alfa = pom_alfa;
  typ_transformace = pom_typ;

  if (pocet != 0) {
    delete[] sloupec;
    delete[] radek;
  }
  if (vzor_vytvoren) {
    for (int vz = 0; vz < pocet_vzoru; vz++) {
      delete[] vzor[vz];
    }
    delete[] vzor;
    vzor_vytvoren = false;
  }
  if (pom_pocet <= 0) {
	  cout << "\nPocet vstupu nebo vystupu v nastaveni vzoru musi byt vetsi nez 0.";
	  exit(EXIT_FAILURE);
  }
  pocet = pom_pocet;

  radek = new int[pocet];
  sloupec = new int[pocet];
  int radsl;
  for (radsl = 0; radsl < pocet; radsl++) {
  	sloupec[radsl] = pom_sloupec[radsl];
  	radek[radsl] = pom_radek[radsl];
  }
}

/**
 * kontrola, zda odpovídá nastavení vstupních vzorů a nastavení výstupních vzorů
 * kontrola, zda odpovídá nastavení vzorů počtu řádků ve zdrojových souborech
 * je-li počáteční řádek > 1, posune nastavení na 1. řádek (pro nastavní vstupního i výstupního vzor)
 * pro vstupní i výstupní vzory spočítá počet vzorů
 * *this vstupní vzory
 * @param vystup výstupní vzory
 * @param zdroj data, ze kterých se budou sestavovat vzory
 */
void vzory_site::kontroluj_nastaveni_vzoru(vzory_site *vystup, data_pro_sit *zdroj)
{
  //int rad, sl;
  //zjištění maximálního sloupce a radku z obou vzoru - vstupu i vystupu zároveň
  int max_sloupec, max_radek, min_radek_vystup, max_radek_vstup;
  //kontrola sloupcu
  max_sloupec = *max_element(sloupec, sloupec + pocet);
  //ani max. pro vystup nesmi byt vetsi nez pocet sloupcu v souborech
  if (max_sloupec < *max_element(vystup->sloupec, vystup->sloupec + vystup->pocet))
  	max_sloupec = *max_element(vystup->sloupec, vystup->sloupec + vystup->pocet);

  //kontrola řádků - maximum vstupu musí být menší než minimum výstupu
  max_radek_vstup = *max_element(radek, radek + pocet);

  min_radek_vystup = *min_element(vystup->radek, vystup->radek + vystup->pocet);
  if (max_radek_vstup > min_radek_vystup) {
    cout << "\nChyba v nastaveni vzoru - max. radek vstupu " << max_radek_vstup << "je vetsi nez minimalni radek vystupu " << min_radek_vystup << ".";
    exit(EXIT_FAILURE);
  }

  //kontrola řádků - max. musí být menší než počet v souborech
  max_radek = *max_element(vystup->radek, vystup->radek + vystup->pocet);
  for (int soub = 0; soub < zdroj->pocet_souboru_s_daty; soub++) {
    if (max_sloupec > zdroj->pocet_sloupcu[soub]) {
      cout << "\nMax. pocet sloupcu v nastaveni vzoru je vetsi nez pocet sloupcu v souboru " << zdroj->soubory_s_daty[soub] << ".";
      exit(EXIT_FAILURE);
    }
    if (max_radek > zdroj->pocet_radku[soub]) {
      cout << "\nMax. pocet radku v nastaveni vzoru je vetsi nez pocet radku v souboru " << zdroj->soubory_s_daty[soub] << ".";
      exit(EXIT_FAILURE);
    }
  }

  //zjištění počtu vzorů
  //když je v nastavení min. řádek > 1, může se nastavení posunout tak, aby minimum bylo 1 (o rozdíl min - 1)
  int min_radek_vstup = *min_element(radek, radek + pocet);
  if (min_radek_vstup > 1) {
    int posun = min_radek_vstup - 1;
    int rad;
    for (rad = 0; rad < pocet; rad++)
      radek[rad] -= posun;
    for (rad = 0; rad < vystup->pocet; rad++)
      vystup->radek[rad] -= posun;
  }


  max_radek_vstup = *max_element(radek, radek + pocet); //znovu max. po posunu

  //znova maxima a minimum
  int max_radek_vystup = *max_element(vystup->radek, vystup->radek + vystup->pocet);
  //v 1 souboru je vzorů tolik jako řádků zmenšených o rozdíl:
  // nahoře o rozdíl rovný max. řádků výstup
  //pocet_vzoru = 0;
  int soub;
  pocet_vzoru = 0;
  for (soub = 0; soub < zdroj->pocet_souboru_s_daty; soub++) {
    pocet_vzoru += zdroj->pocet_radku[soub] - max_radek_vystup + 1; //divna +1???
  }
  vystup->pocet_vzoru = pocet_vzoru;

  //přiřazení do členských proměnných na další použití
  vystup->max_radek = max_radek_vystup;
  max_radek = max_radek_vstup;
}

/**
 * vytvoří vzory pro síť ze zdrojových dat ze všech souborů podle nastavení vzorů (které se načte fcí nacti_nastaveni_ze_souboru)
 * musí se znát už pocet_vzoru
 * @param zdroj kvádrové pole s měřenými daty
 * @param max_radek_vystup max. řádek pro výstupní vzor
 */
void vzory_site::vytvor_vzory(data_pro_sit *zdroj, int max_radek_vystup)
{
  if (vzor_vytvoren) {
    cout << "\nVzor je uz vytvoren!";
    exit(EXIT_FAILURE);
  }

  int vz;
  vzor = new double*[pocet_vzoru];
  for (vz = 0; vz < pocet_vzoru; vz++) {
    vzor[vz] = new double[pocet];
  }
  int pozice_vzor = 0; //jaka pozice v poli vzoru (poradove cislo vzoru)

  maximum = -99999;
  minimum = 99999;
  for (int soub = 0; soub < zdroj->pocet_souboru_s_daty; soub++) {
    for (int pozice = 0; pozice < zdroj->pocet_radku[soub] - max_radek_vystup + 1; pozice++) {
      for (int rad = 0; rad < pocet; rad++) {
        vzor[pozice_vzor][rad] = zdroj->zdroj[soub][sloupec[rad] - 1][pozice + radek[rad] - 1]; //-1, protoze v souboru s nastavenim jsou min. 1
        if (vzor[pozice_vzor][rad] < minimum)
          minimum = vzor[pozice_vzor][rad];
        else if (vzor[pozice_vzor][rad] > maximum)
          maximum = vzor[pozice_vzor][rad];

//        cout << vzor_vstup[pozice_vzor][rad] << "\t";
      }
//      cout << "\n";
      pozice_vzor++;
    }
  }
  vzor_vytvoren = true;

  cout << "\nPocet vzoru je: " << pocet_vzoru << "\n";

}

/**
 * funkce vyjadřující matematickou transfomaci vzorů
 * exponenciální:  \f[ g(y) = 1 - e^{(-\alpha\cdot y)}\f] a pro parametr  platí \f[ \alpha > 0 \f]
 * lineární:  \f[ g(y) = 1 - e^{(-\alpha\cdot y)}\f] a pro parametr  platí \f[ \alpha > 0 \f]
 * @param cislo je vzor, který bude transformováno
 */
double vzory_site::funkce_transfomace_vzoru(double cislo)
{

  if (cislo < 0) {
    cout << "Ve vzoru jsou hodnoty mensi nez 0.";
    return 0;
  }
  double pom;
  switch (typ_transformace) {
  	case EXP:
  	  pom = 1.0 - exp(-alfa * cislo);
  	  if (pom == 1) { //nemůže dát 1, protože pak se to nedá transformovat zpětně, ale zaokrouhluje se to, proto zpátky na nejvýš 0.999...
  	  	pom = 0.9999999;
  	  }
      return pom;
  		break;
  	case LIN:
  	  return cislo / ((maximum - minimum) * prah); ////TOHLE JE ROZDELAN!!!!!!!!!!!!!!!!!!!!!!!!!!
  		break;
  	default:
  	  cout << "Neni zadan typ transformace.";
  	  return cislo;
  		break;
  }
  return 9999;

}

/**
 * Funkce vyjadřující inverzní matematickou transfomaci \f[ g^{-1}(y) = \frac{1}{\alpha} \cdot ln \frac{1}{1-y} \f]
 * @param cislo vzor číslo které bude transformováno
 *
 */
double vzory_site::funkce_transfomace_zpetna(double cislo)
{
  if (cislo < 0) {
    //cout << "\nVe vzoru pri zpetne transformaci jsou hodnoty mensi nez 0, coz muze byt (vypocetla to sit).\n";

    return 0;
  }
  switch (typ_transformace) {
  	case EXP:
  	  if (cislo == 1) //aby nebylo dělení 0
  	  	return 1 / alfa * log(1 / (1 - 0.999999999));
      else
        return 1 / alfa * log(1 / (1 - cislo));
  		break;
  	case LIN:
  	  return cislo; ////TOHLE JE ROZDELAN!!!!!!!!!!!!!!!!!!!!!!!!!!
  		break;
  	default:
  	  cout << "Neni zadan typ transformace.";
  	  return cislo;
  		break;
  }
  return 9999;

}

/**
 * transformuje vzory do intervalu \f[ \left( 0;1\right) \f] nebo zpětně
 * @param zpetne zda bude transformace zpětná
 */
void vzory_site::transformuj(bool zpetne)
{
  for (int vz = 0; vz < pocet_vzoru; vz++) {
    for (int vs = 0; vs < pocet; vs++) {
      if (!zpetne)
        vzor[vz][vs] = funkce_transfomace_vzoru(vzor[vz][vs]);
      else
        vzor[vz][vs] = funkce_transfomace_zpetna(vzor[vz][vs]);
    }
  }
}

/**
 * vypíše vzor do souboru
 * @param soubor jméno souboru
 */
void vzory_site::vypis_soubor(string soubor)
{
  ofstream proud(soubor.c_str());
	if(!proud) {
		cout << "\nNeexistuje soubor do ktereho jsou vypisovany vzory - " << soubor;
		exit(EXIT_FAILURE);
	}
  for(int vz = 0; vz < pocet_vzoru; vz++) {
    for (int vs = 0; vs < pocet; vs++) {
      proud << vzor[vz][vs] << "  ";
    }
    proud << "\n";
  }
	proud.close();
}

/**
 * rozdělí vzor do kvádrového pole a vypíše do souborů
 * @param pocet_souboru_s_daty  počet souborů s daty
 * @param pocet_radku  počet řádků v jednotlivých souborech
 * @param cesta adresář pro výpis souborů
 * @param nazvy_souboru názvy vstupních souborů, jejichž jména se použijí s přidaným "VYSTUP" na začátek
 * @param koncovka_soub koncovka pro soubory (odlišení měřených a simulovaných)
 * @param max_radek_vstup max_radek v nastavení výstupních vzorů (pro kontrolu, zda odpovídá počet řádků v souborech s počtem vzorů, kolik je vstupních, je v tom zahrnuto)
 */
void vzory_site::vypis_do_vice_souboru(int pocet_souboru_s_daty, int *pocet_radku, string cesta, string *nazvy_souboru, string koncovka_soub, int max_radek_vystup)
{
  int akt_radek = 0, soub, suma = 0;
  int vynechanych_radku; //o kolik řádků bude výstupní soubor kratší než vstupní - kvůli tomu, že se předpovídá dopředu a berou se hodnoty z historie
  for (soub = 0; soub < pocet_souboru_s_daty; soub++)
    suma += pocet_radku[soub];

  vynechanych_radku = max_radek_vystup - 1;

  if (pocet_vzoru != suma - vynechanych_radku * pocet_souboru_s_daty) {
    cout << "\nPocet vzoru se neshoduje s celkovym poctem vypisovanych radku do jednotlivych souboru.\n";
    exit(EXIT_FAILURE);
  }

  for (int soub = 0; soub < pocet_souboru_s_daty; soub++) {
    ofstream proud((cesta + "VYSTUP_"  + koncovka_soub + nazvy_souboru[soub]).c_str());
    if(!proud) {
      cout << "\nNeexistuje soubor do ktereho jsou vypisovany vzory - " << (cesta + nazvy_souboru[soub]).c_str();
      exit(EXIT_FAILURE);
    }
    proud.precision(10);
    for(int r = 0; r < pocet_radku[soub] - vynechanych_radku; r++) {
      for (int sl = 0; sl < pocet; sl++) {
        proud << vzor[akt_radek][sl] << "\t";
      }
      akt_radek++;
      proud << "\n";
    }
    proud.close();
  }


}
