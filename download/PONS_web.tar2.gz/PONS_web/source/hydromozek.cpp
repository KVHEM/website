#include "hydromozek.h"

#ifdef KNIHOVNY
//pridani do toho VTK knihovnu
#include "/home/pavel/Projects/nn_nazv/plot/generic_plot/matplot.h"
//pridani knihovny mtl
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>

//pridani boost knihovny
#include <boost/filesystem/config.hpp>
#include <boost/filesystem/convenience.hpp>
#include <boost/filesystem/exception.hpp>
#include <boost/filesystem/fstream.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>
#endif


#ifdef KNIHOVNY
//pridani prostoru jmen knihovny boost
namespace ublas = boost::numeric::ublas;

typedef ublas::vector<double> Vector;
typedef ublas::matrix<double> Matrix;

using namespace matplot;


using namespace hydro_main_net;
#endif

/**
 * ze souboru načte názvy souborů s cestami ke všem nastavením
 * vytvoří podle nastavení v souboru vzorovou síť
 * @param soubor_cesty soubor s nastavením cest k souborům s nastaveními jednotlivých tříd (síť, vstupy atd.)
 */
hydromozek::hydromozek(string soubor_cesty)
{
  string odpad;

  ifstream proud_cesty(soubor_cesty.c_str());
  if(!proud_cesty) {
    cout << "\nNeexistuje soubor s nastavenim cest - " << soubor_cesty;
    exit(EXIT_FAILURE);
  }
  proud_cesty >> odpad >> cest;
  if(cest <= 0) {
    cout << "\nPocet cest v souboru " << soubor_cesty << " musi byt vetsi nez 0.";
    exit(EXIT_FAILURE);
  }
  cesty = new string[cest];
  cesty_popis = new string[cest];
  for (int c = 0; c < cest; c++)
    proud_cesty >> cesty_popis[c] >> cesty[c];
  proud_cesty.close();


  //otevření proudu informací, kam se průběžně vypisuje, co se dělá
  proud_informaci.open(cesty[CESTA_PROUD_INFORMACI].c_str());
  if(!proud_informaci) {
    cout << "\nNeexistuje soubor s proudem informaci - " << cesty[CESTA_PROUD_INFORMACI];
    exit(EXIT_FAILURE);
  }

  proud_informaci << "Proud informaci Hydromozku:\n";
	proud_informaci << "Soubor s cestami ke vsem vstupnim, vystupnim a konfiguracnim souborum:\n";
	proud_informaci << soubor_cesty << "\n";

}

/**
 * vymaže pole se zdrojovými vstupy a výstupy a názvy souborů s daty
 */
hydromozek::~hydromozek()
{
  delete[] cesty;
  delete[] cesty_popis;
  proud_informaci.close();
}

/**
 * kontroluje, jestli počty vstupů a výstupů sítě se shodují s počty vstupů a výstupu v nastavení vzorů
 * @param sit
 * @param vzor_vstup
 * @param vzor_vystup
 */
void hydromozek::kontroluj_vstupy_vystupy_sit_vzor(nastaveni_site *sit, vzory_site *vzor_vstup, vzory_site *vzor_vystup)
{
  if (vzor_vstup->pocet != sit->pocet_vstupu || vzor_vystup->pocet != sit->pocet_vystupu) {
    cout << "\nPocet vstupu nebo vystupu v souboru " << cesty[CESTA_NAS_SITE] << " se neshoduje s poctem vstupu nebo vystupu v souboru " << cesty[CESTA_NAS_VZORU] << ".";
    exit(EXIT_FAILURE);
  }
}

/**
 * připraví vstupní a výstupní vzory podle nastavení, načte k tomu i vstupní data + zkontroluje, zda to sedí na síť
 * není v tom transformace vzorů!
 * @param soubor_nas_vzoru soubor s nastavením vzorů
 * @param vstup vstupní data - kvádrové pole (už tam musí být načtená data)
 * @param vzor_vstup vytvářené vzory pro vstup
 * @param vzor_vystup vytvářené vzory pro výstup
 * @param sit síť, pro kterou se vzory vytvářejí
 */
void hydromozek::priprav_vzory(string soubor_nas_vzoru, data_pro_sit *vstup, vzory_site *vzor_vstup, vzory_site *vzor_vystup, neural_net *sit)
{
  //načtení nastavení vzorů - pro vzory pro vstupy a výstupy
  ifstream proud_vzor(soubor_nas_vzoru.c_str());
  if(!proud_vzor) {
    cout << "\nNeexistuje soubor s nastavenim vzoru - " << soubor_nas_vzoru;
    exit(EXIT_FAILURE);
  }
  vzor_vstup->nacti_nastaveni_ze_souboru(&proud_vzor);
  vzor_vystup->nacti_nastaveni_ze_souboru(&proud_vzor);

  proud_vzor.close();

  vzor_vstup->kontroluj_nastaveni_vzoru(vzor_vystup, vstup);

  //kontroluje, jestli počty vstupů a výstupů sítě se shodují s počty vstupů a výstupu v nastavení vzorů
  kontroluj_vstupy_vystupy_sit_vzor(sit, vzor_vstup, vzor_vystup);

  //ve vstupních i výstupních vzorech se bere maximum z výstupních
  vzor_vstup->vytvor_vzory(vstup, vzor_vystup->max_radek);
  vzor_vystup->vytvor_vzory(vstup, vzor_vystup->max_radek);

}

/**
 * připraví vstupní a výstupní vzory podle nastavení (předávané jako parametr - jen pro vstupní!, výstupní ze souboru)
 * načte k tomu i vstupní data + zkontroluje, zda to sedí na síť
 * není v tom transformace vzorů!
 * parametry pro přípravu vstupních vzorů (předávané do fce zmen_vzory)
 * @param pom_pocet počet vstupů ve vstupních vzorech
 * @param *pom_sloupec pořadová čísla sloupců
 * @param *pom_radek pořadová čísla řádků
 * @param pom_prah
 * @param pom_alfa
 * @param pom_typ
 * @param soubor_nas_vystupnich_vzoru soubor s nastavením výstupních vzorů - musí být ale stejně nastavení obě, bere se to druhé!
 * @param vstup vstupní data - kvádrové pole (už tam musí být načtená data)
 * @param vzor_vstup vytvářené vzory pro vstup
 * @param vzor_vystup vytvářené vzory pro výstup
 * @param sit síť, pro kterou se vzory vytvářejí
 * @param znicit_diru zda se posunou hodnoty řádků pro výstupní vzor tak, aby nebyla díra mezi vstupními a výstupnímu řádky (tj. bude se předpovídat na 1 hodinu dopředu v 1. neuronu výstupním)
 */
void hydromozek::priprav_vzory(int pom_pocet, int *pom_sloupec, int *pom_radek, double pom_prah, double pom_alfa, int pom_typ, string soubor_nas_vystupnich_vzoru, data_pro_sit *vstup, vzory_site *vzor_vstup, vzory_site *vzor_vystup, neural_net *sit, bool znicit_diru)
{
  //vstupní vzor dle předávaných parametrů, neurčuje se maximum, minimum a max_radek
  vzor_vstup->zmen_nastaveni_vzoru(pom_pocet, pom_sloupec, pom_radek, pom_prah, pom_alfa, pom_typ);

  //výstupní vzor ze souboru
  ifstream proud_vzor(soubor_nas_vystupnich_vzoru.c_str());
  if(!proud_vzor) {
    cout << "\nNeexistuje soubor s nastavenim vzoru - " << soubor_nas_vystupnich_vzoru;
    exit(EXIT_FAILURE);
  }
  vzor_vystup->nacti_nastaveni_ze_souboru(&proud_vzor); //nastavení vstupních vzorů ze souboru se vyhazuje
  vzor_vystup->nacti_nastaveni_ze_souboru(&proud_vzor);
  proud_vzor.close();

  //mezi maximem vstupu a minimem výstupu je díra
  if (znicit_diru) {
    if ((*min_element(vzor_vystup->radek, vzor_vystup->radek + vzor_vystup->pocet) - 1) > *max_element(vzor_vstup->radek, vzor_vstup->radek + vzor_vstup->pocet)) {
      int posun = *min_element(vzor_vystup->radek, vzor_vystup->radek + vzor_vystup->pocet) - *max_element(vzor_vstup->radek, vzor_vstup->radek + vzor_vstup->pocet) - 1;
      for (int rad = 0; rad < vzor_vystup->pocet; rad++)
        vzor_vystup->radek[rad] -= posun;
    }
  }

  //tady si určí max_radek
  vzor_vstup->kontroluj_nastaveni_vzoru(vzor_vystup, vstup);

  //kontroluje, jestli počty vstupů a výstupů sítě se shodují s počty vstupů a výstupu v nastavení vzorů
  kontroluj_vstupy_vystupy_sit_vzor(sit, vzor_vstup, vzor_vystup);

  //ve vstupních i výstupních vzorech se bere maximum z výstupních
  //uruje si to taky maximum a minimum
  vzor_vstup->vytvor_vzory(vstup, vzor_vystup->max_radek);
  vzor_vystup->vytvor_vzory(vstup, vzor_vystup->max_radek);

}


/**
 * načte potřebná nastavení, zdrojová data apod.
 * vytvoří síť a vzory
 * simuluje (příp. předtím natrénuje) síť jednoho typu podle vzorů
 * @param trenuj zda se bude trénovat (jinak jen simulovat)
 * @param kalibrace budou použita kalibrační data, jináč validační
 */
void hydromozek::vypocti_sit(bool trenuj, bool kalibrace)
{
  //výpis do proudu informací
  for (int c = 0; c < cest; c++) {
    proud_informaci << cesty_popis[c] << "\t" << cesty[c] << "\n";
  }
  string cesta_datove_soubory, oznaceni;
  if (kalibrace) {
    cesta_datove_soubory = cesty[CESTA_DATOVE_SOUBORY_KAL];
    oznaceni = "_kal_";
  }
  else {
    cesta_datove_soubory = cesty[CESTA_DATOVE_SOUBORY_VAL];
    oznaceni = "_val_";
  }

  //vytvoření sítě dle nastavení
  neural_net onlineBP_sit;
  onlineBP_sit.vytvor_sit(cesty[CESTA_NAS_SITE]);

  //zatim pole pro vystupy stejny jako pro vstupy, pak se musi zmenit
  //načtení měřených dat
  data_pro_sit vstupy;
  vstupy.nacti_ze_souboru(cesty[CESTA_VSTUP_ADRESAR], cesta_datove_soubory);

  //vzory z měřených dat
  vzory_site vzor_vstup;
  vzory_site vzor_vystup;
  vzory_site vystup_sim;

  priprav_vzory(cesty[CESTA_NAS_VZORU], &vstupy, &vzor_vstup, &vzor_vystup, &onlineBP_sit);

  vzor_vstup.transformuj(false);
  vzor_vystup.transformuj(false);

  //síť se buď natrénuje, nebo se načte předtím natrénovaná ze souboru
  if (trenuj)
    onlineBP_sit.trenuj(&vzor_vstup, &vzor_vystup);
  else
    onlineBP_sit.nacti_sit(cesty[CESTA_VYSTUP_SIT]);

  vystup_sim = vzor_vystup; //příprava pole pro výsledky

  onlineBP_sit.simuluj(&vzor_vstup, &vzor_vystup, true, &vystup_sim); //výpočet včetně uložení výsledků do pole

  vystup_sim.transformuj(true);
  vzor_vystup.transformuj(true); //pro porovnání

  vystup_sim.vypis_do_vice_souboru(vstupy.pocet_souboru_s_daty, vstupy.pocet_radku, cesty[CESTA_VYSTUP_ADRESAR], vstupy.soubory_s_daty, "_sim_" + oznaceni, vzor_vystup.max_radek);
  vzor_vystup.vypis_do_vice_souboru(vstupy.pocet_souboru_s_daty, vstupy.pocet_radku, cesty[CESTA_VYSTUP_ADRESAR], vstupy.soubory_s_daty, "_mer_" + oznaceni, vzor_vystup.max_radek);

  //kritéria pro kalibraci, pro předpověď na různou dobu
  if (trenuj) {
    vypis_kriteria(&vzor_vystup, &vystup_sim, &onlineBP_sit, true, false, "", "");
    onlineBP_sit.vypis_sit(cesty[CESTA_VYSTUP_SIT]);
  }
  else
    vypis_kriteria(&vzor_vystup, &vystup_sim, &onlineBP_sit, false, false, "", "");

//pokus na comparison workshop
//  neural_net pokus;
//  pokus = onlineBP_sit;
//
//  pokus.nacti_sit("data/pokus/sit.txt");

//  pokus.vypis_sit("data/pokus/sit2.txt");
//        cout << "\nPO NACTENI\nvstup neuron1: " << pokus.neuron_ve_vrstve[0][0].vstup[0] << endl;
//        cout << "\nvstup neuron2: " << pokus.neuron_ve_vrstve[0][0].vstup[1] << endl;
//        cout << "\nvstup neuron3: " << pokus.neuron_ve_vrstve[0][0].vstup[2] << endl;
//        cout << "\nvaha neuron1: " << pokus.neuron_ve_vrstve[0][0].vahy[0] << endl;
//        cout << "\nvaha neuron2: " << pokus.neuron_ve_vrstve[0][0].vahy[1] << endl;
//        cout << "\nvaha neuron3: " << pokus.neuron_ve_vrstve[0][0].vahy[2] << endl;
//        cout << "\nvstup do afce: " << pokus.neuron_ve_vrstve[0][0].vstup_do_afce << endl;
//        cout << "\nvystup neuron: " << pokus.neuron_ve_vrstve[0][0].vystup << endl;

//  vzor_vystup.transformuj(false);
//  pokus.simuluj(&vzor_vstup, &vzor_vystup, true, &vystup_sim);
//  vzor_vystup.transformuj(true);
//  vystup_sim.transformuj(true);

//        cout << "\nvstup neuron[0]: " << pokus.neuron_ve_vrstve[0][0].vstup[0] << endl;
//        cout << "\nvaha neuron[0]: " << pokus.neuron_ve_vrstve[0][0].vahy[0] << endl;
//        cout << "\nvstup do afce neuron: " << pokus.neuron_ve_vrstve[0][0].vstup_do_afce << endl;
//        cout << "\vystup z afce neuron: " << pokus.neuron_ve_vrstve[0][0].vystup << endl;
//        cout << "\nvstup neuron[0]: " << pokus.neuron_ve_vrstve[1][0].vstup[0] << endl;
//        cout << "\nvaha neuron[0]: " << pokus.neuron_ve_vrstve[1][0].vahy[0] << endl;
//        cout << "\nvstup do afce neuron: " << pokus.neuron_ve_vrstve[1][0].vstup_do_afce << endl;
//        cout << "\vystup z afce neuron: " << pokus.neuron_ve_vrstve[1][0].vystup << endl;

//  pokus.vypis_sit("data/pokus/sit3.txt");

}

/**
 * vytvoří objekt kritéria a vypíše je do souboru
 * @param mer měřené vzory
 * @param sim simulované vzory - výstup ze sítě
 * @param sit síť, kterou byly vzory nasimulovány
 * @param kalibrace zda se jedna o kalibraci nebo validaci
 * @param test_par zda se jedna o výpis pro test parametrů
 * @param par hodnota parametru - řetězec
 * @param jmeno_par označení parametru
 */
void hydromozek::vypis_kriteria(vzory_site *mer, vzory_site *sim, neural_net *sit, bool kalibrace, bool test_par, string par, string jmeno_par)
{
	double *Qsim, *Qmer; //pomocné, protože vzory mají prohozené rozměry
	string zac_nazvu_soub;
	int k, typ_souboru;

	if (kalibrace)
	  typ_souboru = CESTA_VYSTUP_KRIT_KAL;
	else
	  typ_souboru = CESTA_VYSTUP_KRIT_VAL;

  Qsim = new double[mer->pocet_vzoru];
  Qmer = new double[mer->pocet_vzoru];

  kriteria prum_krit;
  for (k = 0; k < kriteria::pocet_kriterii; k++)
  	prum_krit.krit[k] = 0;

	for (int vyst = 0; vyst < mer->pocet; vyst++) { //pocet v mer a sim stejný
		for (int vzor = 0; vzor < mer->pocet_vzoru; vzor++) {
			Qsim[vzor] = sim->vzor[vzor][vyst];
			Qmer[vzor] = mer->vzor[vzor][vyst];
			//cout << Qsim[vzor] << "\t" << Qmer[vzor] << "\n";
		}

		char c[3];
    sprintf(c, "%02d", vyst + 1);
    zac_nazvu_soub = c;
    zac_nazvu_soub += "h_";

    kriteria krit(Qmer, Qsim, mer->pocet_vzoru);

    krit.vypocti_vsechna(sit->celkem_vah, sim->pocet, 0.2, 0.9);

    if (!test_par)
      krit.vypis(cesty[CESTA_VYSTUP_ADRESAR] + zac_nazvu_soub + cesty[typ_souboru]);
    else {
      krit.vypis(cesty[CESTA_VYSTUP_ADRESAR_TEST] + "test" + zac_nazvu_soub + jmeno_par + "_" + cesty[typ_souboru], par);
    }
    for (k = 0; k < kriteria::pocet_kriterii; k++)
      prum_krit.krit[k] += krit.krit[k];
  }
  for (k = 0; k < kriteria::pocet_kriterii; k++) {
    prum_krit.krit[k] /= mer->pocet;
  }
  if (!test_par)
    prum_krit.vypis(cesty[CESTA_VYSTUP_ADRESAR] + "prum_" + cesty[typ_souboru]);
  else {
    prum_krit.vypis(cesty[CESTA_VYSTUP_ADRESAR_TEST] + "test_prum_" + jmeno_par + "_" + cesty[typ_souboru], par);
  }

  delete [] Qsim;
  delete [] Qmer;

}

/**
 * zkouší pro různá nastavení trénovat síť a zjišťuje závislost kritérií na měněných parametrech
 * co se bude testovat, rozsahy atd. vezme z nastavení testu
 * data si to vezme ze seznamu kalibračních a validačních souborů
 * síť načte z nastavení sítě
 */
void hydromozek::testuj_parametry_site()
{
  nastaveni_testu nas_testu;

  //načtení nastavení testu - tam má všechno potřebné (co se bude testovat, rozsahy atd.)
  nas_testu.soubor = cesty[CESTA_NAS_TESTU];

  ifstream proud(nas_testu.soubor.c_str());
  if(!proud) {
    cout << "\nNeexistuje soubor s nastavenim vypoctu - " << nas_testu.soubor;
    exit(EXIT_FAILURE);
  }
  nas_testu.nacti_soubor(&proud);
  proud.close();

  //načtení měřených dat - pro všechny testy stejné, kalibrační a validační
  data_pro_sit vstupy[2];
  vstupy[KAL].nacti_ze_souboru(cesty[CESTA_VSTUP_ADRESAR], cesty[CESTA_DATOVE_SOUBORY_KAL]);
  vstupy[VAL].nacti_ze_souboru(cesty[CESTA_VSTUP_ADRESAR], cesty[CESTA_DATOVE_SOUBORY_VAL]);

  //vytvořit vzory pro kalibrační a validační atd. - originální, které se netransformují
  vzory_site pom_vzor_vstup[2];
  vzory_site pom_vzor_vystup[2];

  //vzory, se kterými se pracuje - transformace atd.
  vzory_site vzor_vstup[2];
  vzory_site vzor_vystup[2];
  vzory_site vystup_sim[2];

  //pomocná síť, jen pro kontrolu vzorů - dle nastavení v CESTA_NAS_SITE
  neural_net *pom_sit = new neural_net;
  pom_sit->vytvor_sit(cesty[CESTA_NAS_SITE]);

  for (int kv = 0; kv < 2; kv++)
    priprav_vzory(cesty[CESTA_NAS_VZORU], &vstupy[kv], &pom_vzor_vstup[kv], &pom_vzor_vystup[kv], pom_sit);

  delete pom_sit;

  int **kombinace, *pom_pole, kombinaci, radp; //kombinace pro test vstupů

  for (int par = 0; par < nas_testu.celkem_par; par++) {
	  if (!nas_testu.param[par][0][ANO_NE]) //není-li nastaven výpočet
	    continue;
    //načíst síť z nastavení
    neural_net test_sit; //bude se měnit dle parametrů
    test_sit.vytvor_sit(cesty[CESTA_NAS_SITE]);

    cout << "\nTest parametru " << nas_testu.jmena_par[par] << endl;

    double p = 0, p_krok = 0, p_max;
    //přiřazení původních netransformovaných vzorů, při testu vstupů až ve vnitřním cyklu
    if (par != VSTUPY) {
      //upravit síť podle výchozích par.
      test_sit.zmen_nastaveni_site(test_sit.pocet_vrstev, test_sit.pocet_neuronu_ve_vrstve, test_sit.typ_afce, test_sit.pocet_vstupu, nas_testu.param[ETA][0][VYCHOZI], nas_testu.param[MOMENTUM][0][VYCHOZI], nas_testu.param[POCET_EPOCH][0][VYCHOZI], test_sit.bias);
      test_sit.zmen_sit();

      for (int kv = 0; kv < 2; kv++) {
        vzor_vstup[kv] = pom_vzor_vstup[kv];
        vzor_vystup[kv] = pom_vzor_vystup[kv];

        //změna alfy a transformace, pokud není alfa parametr
        if (par != ALFA) {
          vzor_vstup[kv].alfa = nas_testu.param[ALFA][0][VYCHOZI];
          vzor_vystup[kv].alfa = nas_testu.param[ALFA][0][VYCHOZI];
          vystup_sim[kv].alfa = nas_testu.param[ALFA][0][VYCHOZI];
          vzor_vstup[kv].transformuj(false);
          vzor_vystup[kv].transformuj(false);
        }
      }

      p_krok = (nas_testu.param[par][0][MAX] - nas_testu.param[par][0][MIN]) / (nas_testu.param[par][0][POCET]);
      p_max = static_cast<int>(nas_testu.param[par][0][POCET]) + 1;

      cout << "\nHodnota parametru " << nas_testu.param[par][0][MAX] << " " << nas_testu.param[par][0][MIN] << " " << nas_testu.param[par][0][POCET] << " " << p_krok << endl;

      p = nas_testu.param[par][0][MIN];
    }
    else {
      //až nebude co dělat, odstranit pom_pole, bez kterého to nejde - záhadná věc
      int radp, ko;

      pom_pole = new int[nas_testu.pocet_par[par][RADKU]];

      //zjištění počtu kombinací
      kombinaci = nas_testu.param[par][0][MAX] - nas_testu.param[par][0][MIN] + 1;
      for (radp = 1; radp < nas_testu.pocet_par[par][RADKU]; radp++) {
        kombinaci = kombinaci * (nas_testu.param[par][radp][MAX] - nas_testu.param[par][radp][MIN] + 1);
      }

      kombinace = new int*[kombinaci]; //pole, z kterého se budou brát všechny možné kombinace vstupu
      for (ko = 0; ko < kombinaci; ko++)
        kombinace[ko] = new int[nas_testu.pocet_par[par][RADKU]];  //z kolika sloupců/veličin se bere

      for (radp = 0; radp < nas_testu.pocet_par[par][RADKU]; radp++)
        kombinace[0][radp] = pom_pole[radp] = nas_testu.param[par][radp][MIN];

      //všechny kombinace, kolik se bude brát hodnot pro danou veličinu = sloupec
      //vždy se bere od prvního do n-tého předchozího času chronologicky
      //počet n se určuje v tomto cyklu
      bool konec = false;
      ko = 0;
      while (!konec) {
        radp = nas_testu.pocet_par[par][RADKU] - 1;

        for (int radp2 = 0; radp2 < nas_testu.pocet_par[par][RADKU]; radp2++) {
         // proud_informaci << pom_pole[radp2] << "\t";
          kombinace[ko][radp2] = pom_pole[radp2]; //bez pom_pole to nejde a nikdo neví proč - nešahat!!!
        }
        ko++;
        if (ko == kombinaci)
          break;
        proud_informaci << "\n";

        while (1) {
          if (pom_pole[radp] > nas_testu.param[par][radp][MAX] - 1) { //nebo krok
            pom_pole[radp] = nas_testu.param[par][radp][MIN];

            if (radp == 0) {
              konec = true;
              break;
            }
          }
          else {
            pom_pole[radp]++; //nebo krok
            break;
          }
          radp--;
        }
      }


//      cerr << "\n\n\nKOKOKOKOKO\n";
//      cerr << kombinaci << "\t" << nas_testu.pocet_par[par][RADKU] << "\n";
//      for (ko = 0; ko < kombinaci; ko++) {
//        for (int radp2 = 0; radp2 < nas_testu.pocet_par[par][RADKU]; radp2++) {
//          cerr << kombinace[ko][radp2] << "\t";
//        }
//        cerr << "\n";
//      }

      p_max = kombinaci; //pro test vstupů je kr stejné jako pořadové číslo kombinace
    } //podmínka pro vstupy

    //cyklus pro hodnoty parametru
    for (int kr = 0; kr < p_max; kr++) {
      cout << "\rHodnota parametru " << nas_testu.jmena_par[par] << " " << p << "                       ";

      //změna sítě nebo transformace vzorů podle parametrů
      switch (par) {
      	case MOMENTUM:
      	  test_sit.momentum = p;
      		break;
      	case ETA:
      	  test_sit.eta = p;
      		break;
      	case POCET_EPOCH:
      	  test_sit.pocet_epoch = p;
      		break;
      	case ALFA:
          for (int kv = 0; kv < 2; kv++) { //aby se mohlo transformovat z původních hodnot ve vzorech
            vzor_vstup[kv] = pom_vzor_vstup[kv];
            vzor_vystup[kv] = pom_vzor_vystup[kv];
            vzor_vstup[kv].alfa = p;
            vzor_vystup[kv].alfa = p;
            vystup_sim[kv].alfa = p;
            vzor_vstup[kv].transformuj(false);
            vzor_vystup[kv].transformuj(false);
          }
      		break;
        case VSTUPY: {
          //změna počtu vstupů sítě
          int pom_pocet_vstupu = 0;
          for (radp = 0; radp < nas_testu.pocet_par[par][RADKU]; radp++) {
            pom_pocet_vstupu += kombinace[kr][radp];
          }

          //upravit síť podle výchozích par. a změna počtu vstupů
          test_sit.zmen_nastaveni_site(test_sit.pocet_vrstev, test_sit.pocet_neuronu_ve_vrstve, test_sit.typ_afce, pom_pocet_vstupu, nas_testu.param[ETA][0][VYCHOZI], nas_testu.param[MOMENTUM][0][VYCHOZI], nas_testu.param[POCET_EPOCH][0][VYCHOZI], test_sit.bias);
          test_sit.zmen_sit();

          //nastavení vzorů
          int *pom_radek_vzoru = new int[pom_pocet_vstupu];
          int *pom_sloupec_vzoru = new int[pom_pocet_vstupu];

          //z kombinace se zjišťují řádky a sloupce pro nastavení vzorů
          int max_vstupu_sl = 0; //maximum řádků pro daný sloupec/veličinu
          for (radp = 0; radp < nas_testu.pocet_par[par][RADKU]; radp++) {
            if (kombinace[kr][radp] > max_vstupu_sl)
            	max_vstupu_sl = kombinace[kr][radp];
          }
          int vs = 0; //max. dosáhne pom_pocet_vstupu
          for (radp = 0; radp < nas_testu.pocet_par[par][RADKU]; radp++) {
            for (int vssl = 0; vssl < kombinace[kr][radp]; vssl++) { //vstupy pro danou veličinu/sloupec
              pom_sloupec_vzoru[vs] = nas_testu.param[par][radp][DOPLNEK];
              pom_radek_vzoru[vs] = max_vstupu_sl - vssl;
              vs++;
            }
          }

          for (int kv = 0; kv < 2; kv++) {
            //vstupní vzory - nastavení podle kombinace vstupů, práh a typ transformace z původních vstupních vzorů
            //výstupní vzory - ze souboru, proto se pak musí změnit alfa podle výchozí
            priprav_vzory(pom_pocet_vstupu, pom_sloupec_vzoru, pom_radek_vzoru, pom_vzor_vstup[kv].prah, nas_testu.param[ALFA][0][VYCHOZI], pom_vzor_vstup[kv].typ_transformace, cesty[CESTA_NAS_VZORU], &vstupy[kv], &vzor_vstup[kv], &vzor_vystup[kv], &test_sit, true);
            vzor_vystup[kv].alfa = nas_testu.param[ALFA][0][VYCHOZI];

            vzor_vstup[kv].transformuj(false);
            vzor_vystup[kv].transformuj(false);
          }

          delete[] pom_radek_vzoru;
          delete[] pom_sloupec_vzoru;

          break;
        }

       	default:
      		break;

      }

      test_sit.trenuj(&vzor_vstup[0], &vzor_vystup[0]); //na kalibračních datech

      for (int kv = 0; kv < 2; kv++) { //pro kalibraci a validaci

        vystup_sim[kv] = vzor_vystup[kv]; //příprava pole pro výsledky

        test_sit.simuluj(&vzor_vstup[kv], &vzor_vystup[kv], true, &vystup_sim[kv]); //výpočet napřed pro kalibrační a pak pro validační data, aby byly vystup_sim
        vystup_sim[kv].transformuj(true); //simulované se musí transformovat zpětně, měřené se berou z původních pomocných


        //hodnota parametru pro výpis do souboru
        string hodnota_par = "";

        stringstream proud_hodnota_par;

        if (par != VSTUPY) {
          proud_hodnota_par << p;
        }
        else {
          for (radp = 0; radp < nas_testu.pocet_par[par][RADKU]; radp++)
            proud_hodnota_par << kombinace[kr][radp] << "_";
        }
        hodnota_par = proud_hodnota_par.str();

        vzor_vystup[kv].transformuj(true); //aby se mohl porovnat s vystup_sim

        vypis_kriteria(&vzor_vystup[kv], &vystup_sim[kv], &test_sit, !kv, true, hodnota_par, nas_testu.jmena_par[par]);

        //nedělá se pro alfu a počet vstupů, protože pro ně se vzory připravují včetně transformace ve switchi výše
        //podmínka by nemusela být, protože u vstupů a alfy se vzory stejnak tvoří znova ve switchi
        if (par != VSTUPY && par != ALFA)
          vzor_vystup[kv].transformuj(false); //transformace vzoru zpátky, protože pak se používá v dalším cyklu kr - přiřazuje se do vystup_sim apod.
      }

      p = p + p_krok;

    }

    if (par == VSTUPY) {
      for (int ko = 0; ko < kombinaci; ko++)
        delete[] kombinace[ko];
      delete[] kombinace;
      delete[] pom_pole;
    }

	} //parametr

}
