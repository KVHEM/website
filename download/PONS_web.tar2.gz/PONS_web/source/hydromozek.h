#ifndef HYDROMOZEK_H_INCLUDED
#define HYDROMOZEK_H_INCLUDED

#include <fstream>
#include <iostream>
#include <sstream> //pro proud do řetězce
#include <cmath>
#include <ctime>
#include <algorithm>

#include "neuron.h"
#include "neural_net.h"
#include "merena.h"
#include "ostatni.h"
#include "kriteria.h"

#include <gsl/gsl_rng.h>

using namespace std;

//typedef enum {MOMENTUM, ETA, ALPHA};

#ifdef KNIHOVNY
namespace hydro_main_net
{
#endif

//void trenovani_site();//!< Jednoduche trenovani jednoho typu site
//
//void simulace();//!< Jednoduch simulace natrenovanou siti
//
//void test_1D_architektury();//!< Test architektury NN site
//
//void test_poctu_vstupu();//!< Test architektury NN site

//void simuluj();//!< Simulace siti

/**
 * zakladni trida programu hydromozek poskytujici ...
 *
 *
 */
class hydromozek {
  public:
    //neural_net vzorova_sit; //!< vzorová síť
    //data_pro_sit mer_vstup; //!< měřená data do vzorových vstupů
    //data_pro_sit mer_vystup; //!< měřená data do vzorových výstupů
    //nastaveni_site nas; //!< nastavení sítě a výpočtu
    //vysledky vys; //!< vypočtená data a hodnota a typ objektivní fce

    //! nastavení a data, se kterými se počítá
    int cest;
    string *cesty; //!< cesty k jednotlivým souborům s nastaveními, daty apod.
    string *cesty_popis; //!< označení cest k souborům s nastaveními apod.
    enum {CESTA_NAS_SITE, CESTA_NAS_TESTU, CESTA_NAS_VZORU, CESTA_DATOVE_SOUBORY_KAL, CESTA_DATOVE_SOUBORY_VAL, CESTA_VSTUP_ADRESAR,
    CESTA_VYSTUP_VZOR_SOUBOR, CESTA_VYSTUP_ADRESAR, CESTA_VYSTUP_KRIT_KAL, CESTA_VYSTUP_KRIT_VAL, CESTA_VYSTUP_SIT, CESTA_PROUD_INFORMACI,
    CESTA_VYSTUP_ADRESAR_TEST};
    enum {KAL, VAL};
    ofstream proud_informaci; //!< proud informací - průběžně se tam vypisuje, co se počítá, otevírá se v konstruktoru, zavírá v destruktoru

    hydromozek(string soubor_cesty);
    ~hydromozek();
    void kontroluj_vstupy_vystupy_sit_vzor(nastaveni_site *sit, vzory_site *vzor_vstup, vzory_site *vzor_vystup); //!< kontroluje, zda odpovídají počty vstupů a výstupu v nastavení sítě a ve vzorech
    void priprav_vzory(string soubor_nas_vzoru, data_pro_sit *vstup, vzory_site *vzor_vstup, vzory_site *vzor_vystup, neural_net *sit); //!< připraví vzory ze vstupních dat - oboje, vstupní i výstupní
    void priprav_vzory(int pom_pocet, int *pom_sloupec, int *pom_radek, double pom_prah, double pom_alfa, int pom_typ, string soubor_nas_vystupnich_vzoru, data_pro_sit *vstup, vzory_site *vzor_vstup, vzory_site *vzor_vystup, neural_net *sit, bool znicit_diru); //!< příprava vstupního vzoru dle předaných parametrů, výstupního ze souboru
    void vypocti_sit(bool trenuj, bool kalibrace); //!< vypočte síť (pomocí načtené nebo natrénované), předtím načte vše potřebné
    void vypis_kriteria(vzory_site *mer, vzory_site *sim, neural_net *sit, bool kalibrace, bool test_par, string par, string jmeno_par); //!< z daných vzorů vytvoří objekt s kritérii a vypíše je do souboru
    void testuj_parametry_site(); //!< zjišťoování závislosti kritérií na měněném nastavení

    //void nacti_zdroj_vstup(string soubor_s_nazvy_souboru); //!< načte ze souborů data do zdroj_vstup
    void vytvor_vzory(); //!< vytvoří vzory pro síť ze zdroj_vstup ze všech souborů podle nastavení vstupu

    string test_R2_gnuplot(string soubor1, string soubor2);
};
#ifdef KNIHOVNY
}//konec prostoru jmen hydromozek
#endif
#endif // HYDROMOZEK_H_INCLUDED
