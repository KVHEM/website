#ifndef VSTUP_INCLUDED
#define VSTUP_INCLUDED

#include <string>
using namespace std;

/**
 * data pro síť - zdrojové vstupy a výstupy (z nich se vytváří vzory)
 */
class data_pro_sit {
  public:
    data_pro_sit();
    ~data_pro_sit();
    void nacti_ze_souboru(string cesta, string soubor_s_nazvy_souboru); //!< načte ze souboru do kvádrového pole
    bool string2double(const char* digit, double& result); //!< převede string na double včetně kontroly, zda to je číslo

    int pocet_souboru_s_daty; //!< počet vstupních souborů s daty nebo výstupních s výsledky
    string *soubory_s_daty; //!< soubor s názvy souborů se vstupními daty
    double ***zdroj; //!< kvádrové pole s původním vstupem (+soubor, +radek, +sloupec) nebo s výsledky
    int *pocet_sloupcu; //!< počet sloupců vstupu nebo výstupu pro jednotlivé soubory
    int *pocet_radku; //!< počet řádků vstupu nebo výstupu pro jednotlivé soubory
};

/**
 * vzory z měřených dat - objekt pro vzorový vstup a pro vzorový výstup
 */
class vzory_site {
  public:
    vzory_site();
    ~vzory_site();
    vzory_site(const vzory_site& orig);
    vzory_site operator=(vzory_site& orig);
    void nacti_nastaveni_ze_souboru(ifstream *proud); //!< načte pocet, sloupec a radek z nastavení vzorů
    void vypis_nastaveni_do_souboru(ofstream *proud, bool vstup); //!< vypíše pocet, sloupec a radek z nastavení vzorů do souboru
    void zmen_nastaveni_vzoru(int pom_pocet, int *pom_sloupec, int *pom_radek, double pom_prah, double pom_alfa, int pom_typ); //!< změní nastavení zdrojů dle parametrů, nedělá vzor ze zdrojových dat
    void kontroluj_nastaveni_vzoru(vzory_site *vystup, data_pro_sit *zdroj); //!< zda odpovídá nastavení vstupů a výstupů
    void vytvor_vzory(data_pro_sit *zdroj, int max_radek_vystup); //!< vytvoří vzory z kvádrového pole
    void vypis_soubor(string soubor); //!< vypíše **vzor do sítě
    void vypis_do_vice_souboru(int pocet_souboru_s_daty, int *pocet_radku, string cesta, string *nazvy_souboru, string koncovka_soub, int max_radek_vystup); //!< rozdělí vzor do kvádrového pole a vypíše do souborů

    //!nastavení vzorů - vstupu nebo výstupu z nich
    int pocet; //!< počet vstupů do sítě nebo výstupů ze sítě (musí se shodovat s nastavením sítě)
    int *sloupec; //!< z kolikátých sloupců jsou načítány vstupy/výstupy do vzorů
    int *radek; //!< z kolikátých řádků jsou načítány vstupy/výstupy do vzorů (pro první vzor)
    int max_radek; //!< maximum z pole radek

    //! transformace vzorů
    //! parametry transformace
    double maximum, minimum, prah; //!< maximální a minimální hodnota ve vzorech, o kolik se zvětší maximum intervalu (poměr - např. 0.2)
    double alfa;//!< parametr transformace vstupů do intervalu \f[ \left( 0,1\right) \f] podmínka pro parametr je \f[ \alpha > 0 \f]

    enum {EXP, LIN} typ_transf;
    int typ_transformace; //!< typ transformace vzorů
    double funkce_transfomace_vzoru(double cislo); //!< transformuje jedno číslo zvolenou metodou
    double funkce_transfomace_zpetna(double cislo); //!< transformuje jedno číslo zpětně
    void transformuj(bool zpetne); //!< transformuje celý vzor

    //!pole se vzory - rozměry jsou počet vzorů (pocet_vzoru) a počet hodnot ve vzoru (pocet), buď na vstupu nebo výstupu
    int pocet_vzoru;

    bool vzor_vytvoren; //!< zda existuje pole vzor - při načtení nastavení se totiž vzor nevytvoří a nejde pak zjistit, zda existuje
    double **vzor;
};

#endif // VSTUP_INCLUDED
