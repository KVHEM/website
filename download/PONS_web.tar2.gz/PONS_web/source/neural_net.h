#ifndef NEURAL_NET_H_INCLUDED
#define NEURAL_NET_H_INCLUDED

#include "neuron.h"
#include "merena.h"

//using namespace std;

typedef enum {VSTUP_VZOR, VYSTUP_VZOR} typ_vzoru;
//typedef enum {TRENOVANI,SIMULACE};

/**
 * nastavení sítě a výpočtu
 */
class nastaveni_site
{
  public:
    nastaveni_site();
    ~nastaveni_site();
    nastaveni_site(const nastaveni_site& orig);
    nastaveni_site operator=(nastaveni_site& orig);
    void nacti_nastaveni_soubor(ifstream *proud); //!< načte soubor
    void vypis_nastaveni_soubor(ofstream *proud); //!< vypíše nastavení sítě do soubor
    void zmen_nastaveni_site(int pom_pocet_vrstev, int *pom_pocet_neuronu_ve_vrstve, int *pom_typ_afce, int pom_vstupu, double pom_eta, double pom_momentum, int pom_pocet_epoch, bool pom_bias); //!< změní síť podle daných parametrů
    string soubor; //!< cesta k souboru pro načítání nebo ukládání nastavení (nastavení výpočtu a taky sítě)

    double eta; //!< učící konstanta \f[ \eta \f]
    double momentum;//!< momentum \f[ \mu \f]
    int pocet_epoch; //!< počet epoch při učení

    //! parametry sítě - to se dědí do neural_net
    int pocet_vrstev; //!< počet vrstev sítě skrytých + výstupní, nepočítá se vstupní (= data)
    int *pocet_neuronu_ve_vrstve; //!< počet neuronů dynamicky alokovaných pro danou síť podle pocet_vrstev - nezapočítává se do toho biasový neuron
    int *typ_afce; //!< typ aktivační funkce pro jednotlivé vrstvy
    int pocet_vstupu; //!< počet vstupních hodnot
    int pocet_vystupu; //!< počet výstupních hodnot
    bool bias; //!< zda se bude používat bias (tj. v každé vrstvě mimo výstupní neuron navíc s výstupem 1)
};


/**
 * neuronová síť - základní objekt složený z neuronů
 * nastavení se dědí z nastaveni_site
 */
class neural_net : public nastaveni_site
{
  public:
    neural_net();
    ~neural_net();
    neural_net(const neural_net& orig);
    neural_net operator=(neural_net& orig);
    neural_net vytvor_sit(string soubor_nastaveni_site); //!< vytvoří síť na základě nastavení ze souboru
    void zmen_sit(); //!< změní síť podle parametrů zděděných z nastaveni_site
    void zmen_sit(int vrstev, int *neuronu, int pocet_vstupnich, int *typ_afce_pro_vrstvu); //!< změní síť podle parametrů předaných do fce
    void vypis_sit(std::string soubor_se_siti);
    void nacti_sit(std::string soubor_se_siti); //!< načte konkrétní síť s váhami ze souboru
    void inicializuj();
    void vypocti();
    void inicializuj_vstup_vystup(int typ_pole, double *prvni_vstup_vystup, int pocet_vstupu_vystupu);
    void pocet_vah();
    void prirad_vahy(double *pole_vahy);
    void zmen_vahy();
    void trenuj(vzory_site *vzor_vstup, vzory_site *vzor_vystup); //!< natrénuje síť podle vzorů
    void simuluj(vzory_site *vzor_vstup, vzory_site *vzor_vystup, bool zda_vystup, vzory_site *vystup_sim); //!< provede jednu simulaci s danými vahami, případně přiřadí výstupy do simulovaných výsledků

    int skutecny_pocet_vrstev; //!< velikost polí neuron_ve_vrstve atd. - podle toho se pak uvolňuje - nejde uvolňovat podle nastavení, to se může samostatně změnit
    neuron **neuron_ve_vrstve; //!< dynamicky alokované neurony v síti - index podle vrstvy (celkem počet vrstev) a neuronu ve vrstvě (celkem počet neuronů ve vrstvě), včetně biasového neuronu, i když v pocet_neuronu_ve_vrstve není zahrnut
    double *vstup; //!< pole vstupních dat = nultá, nepočítaná vstupní vrstva, velikost podle pocet_vstupu
    double *vystup; //!< pole výstupních hodnot spočtené sítí, stejné jako v poslední vrstvě sítě
    double *vystup_vzor; //!< pole výstupních hodnot předem dané, porovnává se s vypočteným výstupem ze sítě
    int celkem_vah; //!< celkový počet vah v celé neuronové síti, včetně vah k biasovým neuronům
};


#endif // NEURAL_NET_H_INCLUDED
