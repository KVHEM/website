#include "kriteria.h"

/**
 * Konstruktor pro inicalizuje vsechny kriteria konstantou 9999999.0
 * dynamicky alokuje pole Qsim, Qmer a zaplni je predavanymi hodnotami 
 * stanovi odhad rezidui a zaplni jimi dynamicky alokovane pole RES
 * provede  kontrolu poctu dat a inicializuje promennou pocet pocetD
 * @param *Q_mer mereny prutok
 * @param *Q_sim vypocteny prutok
 * @param pocet_dat pocet dat
 */
kriteria::kriteria(double *Q_mer, double *Q_sim, int pocet_dat)
{

R_2 = 9999999.0;
C_C = 9999999.0;
ME = 9999999.0;
MSE = 9999999.0;
MAE = 9999999.0;
RMSE = 9999999.0;
R4M4E =  9999999.0;
AIC =  9999999.0;
BIC =  9999999.0;
PI =   9999999.0;
PLC = 9999999.0;
MSRE = 9999999.0;
RVE = 9999999.0;
MRE = 9999999.0;
MARE = 9999999.0;
MSDE = 9999999.0;

pocet = pocet_dat;

if (pocet == 0){   
	cout << "\nPocet dat pro vyhodnoceni vypoctu " << pocet << " musi byt vetsi nez 0.";
  //  	exit(0);
		}

Qsim = new double[pocet];
Qmer = new double[pocet];
Res =  new double[pocet];

for(int i = 0; i< pocet; i++ ){
Qsim[i] = Q_sim[i];
Qmer[i] = Q_mer[i];
Res[i] = Qmer[i] - Qsim[i];
}

pocetD = ((double) pocet);

}
/**
 * Destruktor, uvolni pole
 *
 */
kriteria::~kriteria()
{

  delete [] Qmer;
  delete [] Qsim;
  delete [] Res;

  cout << "\nUkoncuji kriteria\n";

}

/**
 * Stanovi koeficent determinace - Nash-Sutcliffova ucinnost -a priradi jej do promene R_2
 *  \f[ r^2 = 1 -\frac{ \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))^2}{ \sum \limits_{i=1}^{N} ( Q_{mer}(i) - \bar{Q})^2}   \f] \f[ kde \quad \bar{Q} =\frac{1}{N} \cdot  \sum \limits_{i=1}^{N} Q_{mer}(i) \f]  
 * \return rr_2 double hodnota koeficentu determinace
 */
//void kriteria::koef_det( )
double kriteria::koef_det()
{
	double  F = 0.0, Fo = 0.0, mean = 0.0, sumME = 0.0, rr_2 = 99999.099;

	for(int i = 0; i < pocet; i++)
	{
		sumME +=Qmer[i];
		F += Res[i]*Res[i];
	}

	mean = sumME/pocetD;

	for(int i = 0; i < pocet ; i++)
	{
		Fo += (Qmer[i]-mean)*(Qmer[i]-mean);
	}

	if (Fo==0.0) {R_2 = (999999.9);}
	else {R_2 = 1-(F/Fo);}

	rr_2 = R_2;

	return rr_2;
	
}

/**
 * Vypocte korelacni koeficient  a priradi jej do promene C_C
 *  \f[ r = \frac{ N \cdot \sum \limits_{i=1}^{N} Q_{mer}(i) \cdot Q_{sim}(i)- \sum \limits_{i=1}^{N} Q_{mer}(i) \cdot \sum \limits_{i=1}^{N} Q_{sim}(i)}{ \sqrt{N \cdot \sum \limits_{i=1}^{N} Q_{mer}(i)^2- ({\sum \limits_{i=1}^{N} Q_{mer}(i)})^2}  \cdot \sqrt{N \cdot \sum \limits_{i=1}^{N} Q_{sim}(i)^2- ({\sum \limits_{i=1}^{N} Q_{sim}(i)})^2}} \f] 
 * \return c_c vraci hodnotu double korelacniho koeficentu 
 */
double kriteria::koef_kor()
{
	double  sumSI = 0.0 , ME_SI = 0.0, sumME = 0.0 , sumSI2 = 0.0 , sumME2 = 0.0, c_c = 999999.0;

	for(int i = 0; i < pocet; i++)
	{
		sumME +=Qmer[i];
		sumSI +=Qsim[i];
		ME_SI +=Qsim[i]*Qmer[i];
		sumSI2 +=Qsim[i]*Qsim[i];
		sumME2 +=Qmer[i]*Qmer[i];
	}

	if ((sumME==0.0) && (sumSI==0.0)) C_C=999999.9;
	else C_C=((pocetD * ME_SI - sumME * sumSI)/((sqrt(pocetD*sumME2 - (sumME*sumME)))*( sqrt(pocetD*sumSI2 - (sumSI*sumSI)))));

	c_c = C_C;

	return c_c;
	
}

/**
 * Vypocte stredni chybu  a priradi ji do promene ME
 *  \f[ ME = \frac{1}{N} \cdot \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))               \f]
 * \return ME double hodnota stredni chyby
 */
double kriteria::me()
{

	double sumRE = 0.0, me = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE += Res[i];
	}


	ME = sumRE / pocetD;

	me = ME;

	return me;

}

/**
 * Vypocte stredni chybu  a priradi ji do promene MAE
 *  \f[ MAE = \frac{1}{N} \cdot \sum \limits_{i=1}^{N} ( | Q_{mer}(i) - Q_{sim}(i) |)               \f]
 * \return MAE double hodnota stredni chyby
 */
double kriteria::mae( )
{

	double sumREAB = 0.0, mae = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumREAB += fabs(Res[i]);
	}


	MAE = sumREAB / pocetD;

	mae = MAE;

	return mae;

}

/**
 * Vypocte stredni kvadratickou chybu  a priradi ji do promene MSE
 *  \f[ MSE = \frac{1}{N} \cdot \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))^2               \f]
 * \return MSE double hodnota stredni chyby
 */
double kriteria::mse()
{

	double sumRE2 = 0.0, mse = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE2 += Res[i]*Res[i];
	}

	MSE = sumRE2 / pocetD;

	mse = MSE;

	return mse;

}

/**
 * Vypocte odmocninu stredni kvadratickou chybu  a priradi ji do promene RMSE
 *  \f[ RMSE = \sqrt{\frac{1}{N} \cdot \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))^2    }           \f]
 * \return RMSE double hodnota stredni chyby
 */
double kriteria::rmse()
{

	double sumRE2 = 0.0, rmse = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE2 += Res[i]*Res[i];
	}

	RMSE = sqrt( sumRE2 / pocetD);

	rmse = RMSE;

	return rmse;

}

/**
 * Vypocte odmocninu stredni kvadratickou chybu  a priradi ji do promene R4M4E
 *  \f[ RMSE = \sqrt[4]{\frac{1}{N} \cdot \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))^4    }           \f]
 * \return R4M4E double hodnota stredni chyby
 */
double kriteria::r4m4e()
{

	double sumRE4 = 0.0, r4m4e = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE4 += Res[i]*Res[i]*Res[i]*Res[i];
	}

	R4M4E = pow(( sumRE4 / pocetD),.25);

	r4m4e = R4M4E;

	return r4m4e;

}

/**
 * Vypocte AIC  a priradi ji do promene AIC
 *  \f[ AIC = N \cdot ln(RMSE) + 2\cdot p           \f]
 * \param pocet_parametru_modelu pocet parametru daneho modelu  \f$ p \f$
 * \return AIC double hodnota Akaikeho kriteria
 */
double kriteria::aic(int pocet_parametru_modelu)
{

	double sumRE2 = 0.0, aic = 9999999.0, n_parametru_modelu = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE2 += Res[i]*Res[i];
	}


	RMSE = sqrt( sumRE2 / pocetD);

	n_parametru_modelu = (double) pocet_parametru_modelu;

	AIC = pocetD * log(RMSE) + 2 * n_parametru_modelu;

	aic = AIC;

	return aic;

}

/**
 * Vypocte BIC  a priradi ji do promene BIC
 *  \f[ BIC = N \cdot ln(RMSE) + p  \cdot ln(N)         \f]
 * \param pocet_parametru_modelu pocet parametru daneho modelu  \f$ p \f$
 * \return BIC double hodnota Bayesova informacniho kriteria
 */
double kriteria::bic(int pocet_parametru_modelu)
{

	double sumRE2 = 0.0, bic = 9999999.0, n_parametru_modelu = 9999999.0;

	for(int i = 0; i < pocet; i++)
	{
	sumRE2 += Res[i]*Res[i];
	}

	RMSE = sqrt( sumRE2 / pocetD);

	n_parametru_modelu = (double) pocet_parametru_modelu;

	BIC = pocetD * log(RMSE) +  n_parametru_modelu * log(pocetD);

	bic = BIC;

	return bic;

}

/**
 * Stanovi hodnotu koeficentu persistence a priradi ji do PI
 *  \f[ PI = 1 -\frac{ \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{sim}(i))^2}{ \sum \limits_{i=1}^{N} ( Q_{mer}(i) - Q_{mer}(i-lag))^2}   \f]  
 * \param lag parameter kontrolujici casovy posun (resp. predikcni interval)
 * \return pi double hodnota koeficentu persistence
 */
double  kriteria::pi(int lag)
{
  double F = 0.0, Fo = 0.0, pi = 99999.099;

	for(int i = 0; i < pocet-lag; i++)
	{
		F += (Qmer[i+lag]-Qsim[i+lag])*(Qmer[i+lag]-Qsim[i+lag]);
		Fo += (Qmer[i+lag]-Qmer[i])*(Qmer[i+lag]-Qmer[i]);
	}


	if (Fo==0.0) {PI = (999999.9);}
	else {PI = 1-(F/Fo);}

	pi = PI;


   return pi;

}

/**
 * Stanovi hodnotu PLC koeficentu  a priradi ji do PLC
 *  \f[ PLC = pk \cdot lk   \f]  kde \f[ pk = \frac{\displaystyle{\left(\sum \limits_{i=1}^{n_p} (Q_{p-mer}(i) -Q_{p-sim}(i))^2\cdot Q_p(i)^2 \right)^{1/4}}}{\displaystyle{\left(\sum \limits_{i=1}^{n_p} Q_p(i)^2\right)^{1/2}}}\f] a 
\f[ lk = \frac{\displaystyle{\left(\sum \limits_{i=1}^{n_l} (Q_{l-mer}(i) -Q_{l-sim}(i))^2\cdot Q_l(i)^2 \right)^{1/4}}}{\displaystyle{\left(\sum \limits_{i=1}^{n_l} Q_l(i)^2\right)^{1/2}}}\f]
 * \param  peak_portion parametr kontrolujici odhad velkych prutoku -- pomer vzhledem k mean(prutok)
 * \param  lowF_portion parametr kontrolujici odhad malych prutoku -- pomer vzhledem k mean(prutok)
 * \return plc double hodnota koeficentu persistence
 */
double  kriteria::plc(double peak_portion, double lowF_portion)
{
  double Pk = 0.0, sumPd = 0.0, sumLd = 0.0, sumP = 0.0, sumL = 0.0, Lk = 0.0, plc = 999999.9, \
		sumME = 0.0, mean = 0.0;


	for(int i = 0; i < pocet; i++)
	{
		sumME +=Qmer[i];
	}

	mean = sumME / pocetD;

	for(int i = 0; i < pocet; i++)
	{
		if (Qmer[i] > peak_portion * mean) {
			sumPd += Res[i]*Res[i]*Qmer[i]*Qmer[i];
			sumP += Qmer[i]*Qmer[i];
			}

		if (Qmer[i] < lowF_portion * mean) {
			sumLd += Res[i]*Res[i]*Qmer[i]*Qmer[i];
			sumL += Qmer[i]*Qmer[i];
			}
	}

	sumPd = pow(sumPd,0.25);
	sumLd = pow(sumLd,0.25);

	if ((sumP == 0.0)||(sumL == 0.0)) {
			Pk = (999999.9);
			Lk = (999999.9);
			}
	else {
		sumP = pow(sumP,0.5);
		sumL = pow(sumL,0.5);
		Pk = (sumPd/sumP);
		Lk = (sumLd/sumL);
		}

	PLC = Pk * Lk;

	plc = PLC;


   return plc;rmse();

}

/**
 * Provede odhad stredni relativni chyby
 * nulove hodnoty merenych prutoku neuvazuje
 * \f[ MSRE = \frac{1}{n} \cdot \sum \limits_{i=1}^{n} \left( \frac{Q_{mer}(i) - Q_{sim}(i)}{Q_{mer}(i)} \right)^2 \f]
 * @return msre hodnota double msre
 */
double  kriteria::msre()
{
double msre = 999999.9, SumRelRes = 0.0, pocet_dat_po_kontrole = 0.0;

for (int i =0; i<pocet; i++)
{
	if (Qmer[i] != 0) {
		pocet_dat_po_kontrole++;
		SumRelRes += ((Res[i] / Qmer[i]) * (Res[i] / Qmer[i]));
//		cout << SumRes << "\t"<< pocet_dat_po_kontrole << "\t" << Res[i] << "\t"<< Qmer[i]<<"\n";
		}

}
	if (pocet_dat_po_kontrole != 0.0) MSRE = SumRelRes / pocet_dat_po_kontrole;
		else MSRE = 9999999.9;

	msre = MSRE;

return msre;

}

/**
 * Provede odhad celkove relativni chyby dle 
 * \f[ RVE =  \left( \frac{  \sum \limits_{i=1}^{n} (Q_{mer}(i) - Q_{sim}(i))}{ \sum \limits_{i=1}^{n} Q_{mer}(i)} \right) \f]
  * @return rve hodnota double rve
 */
double  kriteria::rve()
{
double rve = 0.0, SumRes = 0.0, SumMer = 0.0;

for (int i =0; i<pocet; i++)
{
		SumRes += Res[i];
		SumMer += Qmer[i];
}

	if (SumMer != 0.0 ) RVE = SumRes / SumMer;
		else RVE = 9999999.9;

	rve = RVE;

return rve;

}

/**
 * Provede odhad stredni relativni chyby
 * nulove hodnoty merenych prutoku neuvazuje
 * \f[ MRE = \frac{1}{n} \cdot \sum \limits_{i=1}^{n} \left( \frac{Q_{mer}(i) - Q_{sim}(i)}{Q_{mer}(i)} \right) \f]
 * @return mre hodnota double msre
 */
double  kriteria::mre()
{
double mre = 999999.9, SumRelRes = 0.0, pocet_dat_po_kontrole = 0.0;

for (int i =0; i<pocet; i++)
{
	if (Qmer[i] != 0) {
		pocet_dat_po_kontrole++;
		SumRelRes += ((Res[i] / Qmer[i]) );
		}

}
	if (pocet_dat_po_kontrole != 0.0) MRE = SumRelRes / pocet_dat_po_kontrole;
		else MRE = 9999999.9;

	mre = MRE;

return mre;

}

/**
 * Provede odhad stredni absolutni relativni chyby
 * nulove hodnoty merenych prutoku neuvazuje
 * \f[ MARE = \frac{1}{n} \cdot \sum \limits_{i=1}^{n} \left(  \frac{|Q_{mer}(i) - Q_{sim}(i)|}{Q_{mer}(i)} \right) \f]
 * @return mare hodnota double mare
 */
double  kriteria::mare()
{
double mare = 999999.9, SumRelRes = 0.0, pocet_dat_po_kontrole = 0.0;

for (int i =0; i<pocet; i++)
{
	if (Qmer[i] != 0) {
		pocet_dat_po_kontrole++;
		SumRelRes += (fabs(Res[i]) / Qmer[i] );
		}

}
	if (pocet_dat_po_kontrole != 0.0) MARE = SumRelRes / pocet_dat_po_kontrole;
		else MARE = 9999999.9;

	mare = MARE;

return mare;

}

/**
 * Provede odhad odchyleni prvnich diferenci
 * nulove hodnoty merenych prutoku neuvazuje
 * \f[ MSDE = \frac{1}{n} \cdot \sum \limits_{i=1}^{n} \left( (Q_{mer}(i) - Q_{mer}(i-1)) - (Q_{sim}(i) - Q_{sim}(i-1))  \right)^2 \f]
 * @return msde hodnota double msde
 */
double  kriteria::msde()
{
double msde = 999999.9, SumDifRes = 0.0;

for (int i =0; i< (pocet-1) ; i++)
{
		SumDifRes += ((Qmer[i+1] - Qmer[i]) - (Qsim[i+1] - Qsim[i])) * ((Qmer[i+1] - Qmer[i]) - (Qsim[i+1] - Qsim[i]));
}


	if ((pocetD - 1.0) != 0.0) MSDE = SumDifRes / (pocetD - 1.0);
		else MSDE = 9999999.9;

	msde = MSDE;

return msde;

}

/**
 * Provede vypis kriterii do souboru
 *
 */
void kriteria::vypis(string nazev_souboru, int pocet_parametru_modelu, int lag, double peak_portion, double lowF_portion)
{

  ofstream proud(nazev_souboru.c_str(),ios::app);
  if(!proud) {
    cout << "\nNeexistuje soubor pro vypis vyhodnocovovacich kriterii - " << nazev_souboru;
  //  exit(0);
  }

  proud << koef_det() << "     " << koef_kor() << "     " << me() << "     "<< mse() << "     "<< mae() << "     "; 
  proud << rmse() << "     " << r4m4e() << "     " << aic(pocet_parametru_modelu) << "     "<< bic(pocet_parametru_modelu) << "     "<< pi(lag) << "     "; 
  proud << plc(peak_portion, lowF_portion) << "     " << msre() << "     " << rve() << "     "<< mre() << "     "<< mare() << "     " << msde() << "\n"; 

  proud.close();

}

/**
 * 
 *
 */


