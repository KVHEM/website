#ifndef KRITERIA_H_INCLUDED
#define KRITERIA_H_INCLUDED

#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

/**
 * Trida kriteria definuje a poskytuje odhad vyhodnocovacich ukazatelu pro kalibracni a validacni vypocet
 *
 */
class kriteria {
  public:

  double R_2;//!< Hodnota koeficientu determinace
  double C_C;//!< Hodnota korelacniho koeficientu
  double ME;//!< Hodnota stredni chyby
  double MSE;//!< Hodnota stredni kvadraticke chyby
  double MAE;//!< Hodnota stredni absolutni chyby
  double RMSE;//!< Hodnota odmocniny stredni kvadraticke chyby
  double R4M4E;//!< Hodnota ctvrte odmocniny stredu ctvrtych mocnin rezidui
  double AIC;//!< Hodnota Akaikeho informacniho kriteria
  double BIC;//!< Hodnota Bayesova informacniho kriteria
  double PI;//!< Hodnota koeficientu persitence (dle  Kitinadis a Bras WRR 1980)
  double PLC;//!< Hodnota PLC koeficentu (Peak and Low flow Coefficient dle. Coulibaly, Bobee and Anctil HP 2001)
  double MSRE;//!< Hodnota stredni relativni chyby -- (suma ctvercu (reziduum / merena hodnota)) / pocet
  double RVE;//!< Hodnota celkove relativni chyby -- suma rezidui / suma merenych dat
  double MRE;//!< Hodnota   stredni relativni chyby - suma relativnich chyb / pocet dat
  double MARE;//!< Hodnota   stredni absolutni relativni chyby - suma (absolutnich hodnot residui / merenou hodnotou ) normovana pocet dat
  double MSDE;//!< Hodnota odchyleni prvnich diferenci mezi merenymi a simulovanymi daty

  double *Qsim;//!< Simulovane prutoky
  double *Qmer;//!< Merene prutoky
  double *Res;//!<  Rezidua
  double pocetD;//!< Pocet dat v promenne double
  int pocet;//!< Pocet dat

//!<
//  void koef_det(double *Qmer, double *Qsim, int pocet);//!< Vypocte koeficient determinace
  double koef_det();//!< Provede odhad koeficientu determinace
  double koef_kor();//!< Provede odhad vyberoveho korelacniho koeficientu
  double me();//!< Provede odhad stredni hodnoty rezidui
  double mse();//!< Provede odhad stredni hodnoty ctvercu rezidui (stredni kvadraticka chyba)
  double mae();//!< Provede odhad stredni hodnoty absolutnich hodnot rezidui
  double rmse();//!< Provede odhad odmocniny stredni kvadraticke chyby
  double r4m4e();//!< Provede odhad ctvrte odmocniny stredu ctvrtych mocnin rezidui
  double aic(int pocet_parametru_modelu);//!< Provede odhad Akaikeho informacniho kriteria
  double bic(int pocet_parametru_modelu);//!< Provede odhad Bayesova informacniho kriteria
  double pi(int lag);//!< Provede odhad koeficientu persitence (dle Kitinadis a Bras WRR 1980)
  double plc(double peak_portion, double lowF_portion);//!< Provede odhad PLC koeficentu (Peak and Low flow Coefficent dle. Coulibaly, Bobee and Anctil HP 2001) 
  double msre();//!< Provede odhad stredni relativni chyby - (suma ctvercu (reziduum / merena hodnota)) / pocet
  double rve();//!< Provede odhad celkove relativni chyby - suma rezidui / suma merenych dat
  double mre();//!< Provede odhad stredni relativni chyby - suma relativnich chyb / pocet dat
  double mare();//!< Provede odhad stredni absolutni relativni chyby - suma (absolutnich hodnot residui / merenou hodnotou ) normovana pocet dat
  double msde();//!< Provede odhad ochyleni prvnich diferenci

  void vypis(string nazev_souboru, int pocet_parametru_modelu, int lag, double peak_portion, double lowF_portion);//!< Provede vypis do souboru

  kriteria(double *Qmer, double *Qsim, int pocet_dat);//!< Konstruktor 
  ~kriteria();

};//konec tridy kriteria
#endif
