#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <cstdlib>
#include <armadillo>

using namespace std;

#include "kriteria.h"

int main()
{

int pocet_dat = 0;

string odpad;

double *Qm,*Qs;

ifstream proud("Soubor");
	if(!proud) {
		cout << "\nNeexistuje soubor pro nacteni kontrolnich dat." ;
                //exit(EXIT_FAILURE);
	}


  while (!proud.eof()) {
    getline(proud, odpad);
    pocet_dat++;
  }

  proud.clear();
  proud.seekg(0, ios::beg);

  pocet_dat--;

  cout << "\nKONTROLNI VYPOCET PRO TRIDU KRITERIA\nPocet dat je: "<< pocet_dat <<"\n"; 

  double pocetD;

  pocetD =(double) pocet_dat;

  Qm = new double[pocet_dat];
  Qs = new double[pocet_dat];

  for (int i = 0; i < pocet_dat; i++) {
    proud >> Qm[i] >> Qs[i];
  }

  proud.close();

  kriteria kriteria(Qm,Qs,pocet_dat);

  cout << "\nVypis kriterii z konstant tridy kriteria\n\n";

 
double rr3 = 999;

 rr3 = kriteria.koef_det();
 kriteria.koef_kor();
 kriteria.me();
 kriteria.mse();
 kriteria.mae();
 kriteria.rmse();
 kriteria.aic(1);
 kriteria.bic(1);
 kriteria.r4m4e();
 kriteria.pi(1);
 kriteria.plc(0.66,0.33);
 kriteria.msre();
 kriteria.rve();
 kriteria.mre();
 kriteria.mare();
 kriteria.msde();

 cout << kriteria.R_2 << "\t" << kriteria.C_C << "\t" << kriteria.ME << "\t" << kriteria.MSE << "\t" << kriteria.MAE <<  "\t" << kriteria.RMSE << "\t" <<  kriteria.R4M4E <<  "\t" << kriteria.AIC << "\t" << kriteria.BIC  << "\t" << kriteria.PI << "\t" << kriteria.PLC << "\t" << kriteria.MSRE  <<  "\t" << kriteria.RVE << "\t" << kriteria.MRE << "\t" << kriteria.MARE << "\t" << kriteria.MSDE << "\n";


 cout << "\nVypis kriterii z clenskych funkci tridy kriteria\n\n";

 cout << "NASH SUTCLIFFE " << kriteria.koef_det() << "\n";
 cout << "Korelacni koeficent " << kriteria.koef_kor() << "\n";
 cout << "Stredni chyba " << kriteria.me() << "\n";
 cout << "Stredni kvadraticka chyba " << kriteria.mse() << "\n";
 cout << "Stredni absolutni chyba " << kriteria.mae() << "\n";
 cout << "Odmocnina stredni kvadraticke chyby " << kriteria.rmse() << "\n";
 cout << "R4M4E " << kriteria.r4m4e() << "\n";
 cout << "AIC " << kriteria.aic(1) << "\n";
 cout << "BIC " << kriteria.bic(1) << "\n";
 cout << "PI " << kriteria.pi(1) << "\n";
 cout << "PLC " <<  kriteria.plc(0.66,0.33) << "\n";
 cout << "MSRE " << kriteria.msre() << "\n";
 cout << "RVE " << kriteria.rve() << "\n";
 cout << "MRE " << kriteria.mre() << "\n";
 cout << "MARE " << kriteria.mare() << "\n";
 cout << "MSDE " << kriteria.msde() << "\n";

  kriteria.vypis("soubor1",1,1, 0.66,0.33);

  delete [] Qm;
  delete [] Qs;
}
