#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#define POCET_ZNAKU 8

/*funkce pro zjisteni poctu radku*/
int pocet_radku(FILE *f) {
    int pocet = 0;
    int c;  
    while ((c = getc(f)) != EOF) {
          if (c == '\n') {
             pocet++;
             }
          }
    return pocet;
    }
/*funkce model Dharma*/
void model(double *T_min, double *T_max, double *Prep, double *SC, double *DDF, double *NoI, 
           double *SC1, double *PoE, double *MAX1, double *D_SC1, double *SC2, double *MAX2,
           double *K2, double *D_SC2, double *D_Sur, double *SC3, double *MAX3, double *K3,
           double *D_SC3, double *D_Totnt) {
           /*deklarace promennych*/
           double T_prum, Sn, TSM, Melt, Rf, INPUT, RATIO, E_SC1, RED, E_SC2, E_SC3;
           double percol, CHECK, exponent1, exponent2, exponent3;
           /*vypocet prumerne teploty*/
           T_prum = (*T_min + *T_max) / 2;
           /*prepocet vstupni srazky na dest a snih*/
           if (*T_max < 0) {
              Sn = *Prep;
              Rf = 0;
              }
           if (T_prum < 0 && *T_max > 0) {                                  
              Sn = ((0 - *T_min) / (*T_max - *T_min)) * *Prep;
              Rf = (1 - (0 - *T_min) / (*T_max - *T_min)) * *Prep;
              }
           if (*T_min < 0 && T_prum > 0) {
              Sn = 0;
              Rf = *Prep;
              }
           if (*T_min >= 0) {
              Sn = 0;
              Rf = *Prep;
              }
           /*vypocet akumulace snehove pokryvky a tani snehu*/
           if (*T_max < 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }
           if (T_prum < 0 && *T_max >= 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }       
           if (*T_min < 0 && T_prum >= 0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           if (*T_min >=0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           /*vypocet vsupu do pudnich zasobniku*/
           INPUT = Rf + Melt;
           if (INPUT <= 0.00001) {
              INPUT = 0;
              }
           /*vypocet vyparu z SC1*/
           E_SC1 = (*SC1 / *MAX1) * *PoE;
           RED = *PoE - E_SC1;
           /*bilance 1 v SC1*/
           *SC1 = *SC1 - E_SC1;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 < 0) {
              E_SC1 = E_SC1 + *SC1;
              RED = *PoE - E_SC1;
              *SC1 = 0;
              }
           /*vypocet vyparu v SC2*/
           if (*SC2 < RED) {
              E_SC2 = *SC2;
              *SC2 = 0;
              RED = RED - E_SC2;
              }
           else {
                E_SC2 = RED;
                RED = 0;
                }
           /*bilance 1 v SC2*/
           *SC2 = *SC2 - E_SC2;
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              }
           if (*SC2 < 0) {
              E_SC1 = E_SC1 + *SC1;
              *SC1 = 0;
              }
           /*vypocet neinfiltrovatelneho vstupu*/
           RATIO = (*SC1 + *SC2) / (*MAX1 + *MAX2);
           *NoI = RATIO * INPUT * 0.25;
           if (*NoI <= 0.00001) {
              *NoI = 0;
              }
           /*bilance 2 v SC1*/
           *SC1 = *SC1 + INPUT - *NoI;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 <= *MAX1) {
              *D_SC1 = 0;
              }
           else {
                *D_SC1 = *SC1 - *MAX1;
                *SC1 = *MAX1;
                }
           /*bilance 2 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              percol = 0;
              }
           else {
                percol = *SC2 * (1 - (*SC3 / *MAX3));
                *SC2 = *SC2 - percol;
                }
           /*kontrola mnozstvi perkolovane vody*/
           CHECK = *SC3 + percol - *MAX3;
           if (CHECK > 0) {
              percol = percol - CHECK;
              *SC2 = *SC2 + CHECK;
              }
           /*bilance 3 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              *D_SC2 = 0;
              }
           else {
                exponent2 = *SC2 / *MAX2;
                *D_SC2 = *K2 * pow (*SC2, exponent2);
                if (*D_SC2 > *SC2) {
                   *D_SC2 = *SC2;
                   }
                *SC2 = *SC2 - *D_SC2;
                }
           /*bilance 4 v SC2*/
           *SC2 = *SC2 + *D_SC1;
           if (*SC2 <= *MAX2) {
              *D_Sur = 0;
              }
           else {
                *D_Sur = *SC2 - *MAX2;
                *SC2 = *MAX2;
                }             
           /*billance 1 v SC3*/
           *SC3 = *SC3 + percol;
           if (*SC3 > 0.00001) {
              exponent3 = *SC3 / *MAX3;              
              *D_SC3 = *K3 * pow (*SC3, exponent3);
              if (*D_SC3 > *SC3) {
                 *D_SC3 = *SC3;
                 }
              *SC3 = *SC3 - *D_SC3;
              }
           else {
                *SC3 = 0;
                *D_SC3 = 0;
                }
           /*vypocet celkoveho netransformovaneho odtoku*/
           *D_Totnt = *NoI + *D_SC2 + *D_SC3 + *D_Sur;              
           }
/**/
int main (void) {
    /*delkarace promennych*/
    FILE *f;
    /*nastaveni programu*/
    int test_parametr, velikost_pole_parametr_a_CE; double zacatek_intervalu, konec_intervalu, krok;
    double **pole_parametrickych_sad, **pole_parametr_a_CE, **pole_odtoku;
    /*vstupni data*/
    int pocet_souboru, pocet_r, pocet_sad_parametru; char **pole_nazvu_povodi; char konec_radku;
    char vstup_data_povodi[] = "input_data/kalibrace/xxxxxxx";    
    double *Pr, *PE, *D_M, *T_minimum, *T_maximum;
    /*parametry modelu*/
    double DDF, MAX1, MAX2, K2, MAX3, K3, X, K; 
    int pocet_parametru = 8;
    /*promenne v modelu*/
    double T_min, T_max, Prep, SC, NoI, SC1, PoE, D_SC1, SC2, D_SC2, D_Sur, SC3, D_SC3, D_Totnt;
    double C0, C1, C2, suma1, suma2, suma3, suma4, prumer1, CE, ETV;
    /*vystupni z modelu*/
    double *D_prm, *D_sbsr, *D_surf, *D_base, *D_tonetr, *D_tottr; 
    /*pomocne promenne*/
    double chyba1, chyba2;
    double max_prep, max_mer_odtok, max_celk_odtok, max_odtok;
    int a, b, c, d, e, g, h, i, j, k, l;
    /*tisk vysledku*/
    char parametr_DDF[] = "output_data/sens_anl/parametr_DDF_xxxxxxx"; char graf_DDF[] = "output_data/sens_anl/DDF_xxx.GNU";
    char hydrogram_DDF[] = "output_data/sens_anl/DDF_hydrogram_xxxxxxx"; char odtoky_DDF[] = "output_data/sens_anl/DDF_hydrogram_xxx.GNU";    
    char parametr_MAX1[] = "output_data/sens_anl/parametr_MAX1_xxxxxxx"; char graf_MAX1[] = "output_data/sens_anl/MAX1_xxx.GNU";
    char hydrogram_MAX1[] = "output_data/sens_anl/MAX1_hydrogram_xxxxxxx"; char odtoky_MAX1[] = "output_data/sens_anl/MAX1_hydrogram_xxx.GNU";        
    char parametr_MAX2[] = "output_data/sens_anl/parametr_MAX2_xxxxxxx"; char graf_MAX2[] = "output_data/sens_anl/MAX2_xxx.GNU";
    char hydrogram_MAX2[] = "output_data/sens_anl/MAX2_hydrogram_xxxxxxx"; char odtoky_MAX2[] = "output_data/sens_anl/MAX2_hydrogram_xxx.GNU";            
    char parametr_K2[] = "output_data/sens_anl/parametr_K2_xxxxxxx"; char graf_K2[] = "output_data/sens_anl/K2_xxx.GNU";
    char hydrogram_K2[] = "output_data/sens_anl/K2_hydrogram_xxxxxxx"; char odtoky_K2[] = "output_data/sens_anl/K2_hydrogram_xxx.GNU";            
    char parametr_MAX3[] = "output_data/sens_anl/parametr_MAX3_xxxxxxx"; char graf_MAX3[] = "output_data/sens_anl/MAX3_xxx.GNU";
    char hydrogram_MAX3[] = "output_data/sens_anl/MAX3_hydrogram_xxxxxxx"; char odtoky_MAX3[] = "output_data/sens_anl/MAX3_hydrogram_xxx.GNU";            
    char parametr_K3[] = "output_data/sens_anl/parametr_K3_xxxxxxx"; char graf_K3[] = "output_data/sens_anl/K3_xxx.GNU";
    char hydrogram_K3[] = "output_data/sens_anl/K3_hydrogram_xxxxxxx"; char odtoky_K3[] = "output_data/sens_anl/K3_hydrogram_xxx.GNU";            
    char parametr_K[] = "output_data/sens_anl/parametr_K_xxxxxxx"; char graf_K[] = "output_data/sens_anl/K_xxx.GNU";
    char hydrogram_K[] = "output_data/sens_anl/K_hydrogram_xxxxxxx"; char odtoky_K[] = "output_data/sens_anl/K_hydrogram_xxx.GNU";            
    char parametr_X[] = "output_data/sens_anl/parametr_X_xxxxxxx"; char graf_X[] = "output_data/sens_anl/X_xxx.GNU";
    char hydrogram_X[] = "output_data/sens_anl/X_hydrogram_xxxxxxx"; char odtoky_X[] = "output_data/sens_anl/X_hydrogram_xxx.GNU";                        
    /*nacteni nastaveni programu pro citlivostni analyzu*/
    f = fopen ("settings/UVSA_settings.txt", "r");
    if (f == NULL) {
        printf ("file UVSA_settings.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    fscanf (f, "%d %lf %lf %lf", &test_parametr, &zacatek_intervalu, &konec_intervalu, &krok);
    fclose(f);
    printf ("testovany parametr: %d\n", test_parametr);
    printf ("testovany interval: od %.4f\t do %.4f\t v kroku %.4f\n", zacatek_intervalu, konec_intervalu, krok);
    /*zjisteni poctu radku souboru s nazvy povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    if (f == NULL) {
        printf ("file file_of_ID.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    pocet_souboru = pocet_radku(f);    
    fclose(f);
    printf ("pouzity pocet povodi pri citlivostni analyze: %d\n", pocet_souboru);
    /*alokace pole nazvu analyzovanych povodi*/
    if ((pole_nazvu_povodi = ((char**) malloc(pocet_souboru * sizeof(char *)))) == NULL) {
        printf("chyba pri alokaci pameti\n");
        return 1;
        }      
    for (a = 0; a < pocet_souboru; a++) {
        if ((pole_nazvu_povodi[a] = ((char*) malloc(POCET_ZNAKU * sizeof(char)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }      
        }
    /*nacteni nazvu analyzovanych povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    for (a = 0; a < pocet_souboru; a++) {
        for (b = 0; b < POCET_ZNAKU - 1; b++) {
            fscanf (f, "%c", &pole_nazvu_povodi[a][b]);
            }
        fscanf (f, "%c", &konec_radku);    
        pole_nazvu_povodi[a][7] = '\0';
        }
    fclose(f);
    /*zjisteni poctu radku souboru s optimalnimi parametry modelu*/
    f = fopen ("input_data/sens_anl/sens_anl.txt", "r");
    if (f == NULL) {
        printf ("file sens_anl.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    pocet_sad_parametru = pocet_radku(f);    
    fclose(f);
    printf ("pocet parametrickych sad v souboru nejlepsi_sady.txt: %d\n", pocet_sad_parametru);
    if (pocet_souboru != pocet_sad_parametru) {
        printf ("nesouhlasi pocet analyzovanych povodi a pocet parametrickych sad\n");
        system ("PAUSE");
        return 2;
        }
    /*alokace pole parametrickych sad*/
    if ((pole_parametrickych_sad = ((double**) malloc(pocet_sad_parametru * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (a = 0; a < pocet_sad_parametru; a++) {
        if ((pole_parametrickych_sad[a] = ((double*) malloc((pocet_parametru + 2) * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    /*nacteni optimalnich sad parametru do pole*/
    f = fopen ("input_data/sens_anl/sens_anl.txt", "r");
    for (a = 0; a < pocet_sad_parametru; a++) {
        for (b = 0; b < (pocet_parametru + 2); b++) {
            fscanf (f, "%lf", &pole_parametrickych_sad[a][b]);
            }
        }
    fclose(f);
    /*alokace pole vystupu - OF + analyzovany parametr*/
    velikost_pole_parametr_a_CE = (int) ((zacatek_intervalu + konec_intervalu + krok) / krok);
    printf ("velikost pole: %d\n", velikost_pole_parametr_a_CE);
    if ((pole_parametr_a_CE = ((double**) malloc(velikost_pole_parametr_a_CE * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
        if ((pole_parametr_a_CE[e] = ((double*) malloc(3 * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }    
    /*for cyklus pro vsechna analyzovana povodi*/
    for (c = 0; c < pocet_souboru; c++) {
        for (d = 0; d < 7; d++) {
            vstup_data_povodi[d + 21] = pole_nazvu_povodi[c][d];
            }
        /*zjisteni poctu radku kazdeho kalibracniho souboru*/
        f = fopen (vstup_data_povodi, "r");
        printf ("\n");
        printf ("prave pocitam kalibracni soubor: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
        if (f == NULL) {
            printf ("soubor nenalezen\n");
            system ("PAUSE");  
            return 1;
            }    
        pocet_r = pocet_radku(f);        
        fclose(f);
        printf ("pocet radku kalibracniho souboru: %d\n", pocet_r);
        /*alokace pole pro odtoky pri ruznuch hodnotach analyzovaneho parametru*/
        if ((pole_odtoku = ((double**) malloc(pocet_r * sizeof(double *)))) == NULL) {
            printf ("chyba pri alokaci pameti\n");
            return 1;
            }    
        for (g = 0; g < pocet_r; g++) {
            if ((pole_odtoku[g] = ((double*) malloc((velikost_pole_parametr_a_CE + 2) * sizeof(double)))) == NULL) {
                printf("chyba pri alokaci pameti\n");
                return 1;
                }
            } 
        /*alokace poli vstupnich promennych*/
        if ((Pr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((PE = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_M = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_minimum = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_maximum = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_povodi, "r");
        for (g = 0; g < pocet_r; g++) {
            fscanf (f, "%lf %lf %lf %lf %lf", &Pr[g], &PE[g], &D_M[g], &T_maximum[g], &T_minimum[g]);
            }
        fclose (f);                            
        /*kontrola vstupnich dat*/
        /*kontrola teplot*/
        for (g = 0; g < pocet_r; g++) {
            if (T_maximum[g] < T_minimum[g]) {
                chyba1 = T_maximum[g];
                chyba2 = T_minimum[g];
                T_minimum[g] = chyba1;
                T_maximum[g] = chyba2;
                }
            }
        /*kontrola srazek*/
        for (g = 0; g < pocet_r; g++) {
            if (Pr[g] == -99.00) {
                Pr[g] = 0;
                }
            }
        /*alokace poli pomocnych promennych*/    
        if ((D_prm = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_sbsr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_surf = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_base = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }    
        if ((D_tonetr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_tottr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        switch (test_parametr) {
               case 1:
                    printf ("resim parametr DDF\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    DDF = zacatek_intervalu - krok;                
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        DDF = DDF + krok;
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = DDF;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_DDF[d + 34] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_DDF, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_DDF[d + 25] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_DDF, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru DDF' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'DDF' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character 0, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:80]\n");
                    fprintf (f, "set y2tics 16 font ',35' offset character -1, 0, 0\n");                
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_DDF_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_DDF_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_DDF_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_DDF[d + 35] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_DDF, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_DDF[d + 35] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_DDF, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru DDF' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\DDF_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\DDF_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\DDF_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'DDF_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               case 2:
                    printf ("resim parametr MAX1\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    MAX1 = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        MAX1 = MAX1 + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (pocet_r - 730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = MAX1;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                   /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_MAX1[d + 35] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_MAX1, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_MAX1[d + 26] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_MAX1, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX1' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'MAX1' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:80]\n");
                    fprintf (f, "set y2tics 16 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX1_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX1_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_MAX1_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_MAX1[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_MAX1, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_MAX1[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_MAX1, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX1' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX1_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX1_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX1_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'MAX1_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);                                               
                    break;
               case 3:
                    printf ("resim parametr MAX2\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    MAX2 = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        MAX2 = MAX2 + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (pocet_r - 730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = MAX2;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_MAX2[d + 35] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_MAX2, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_MAX2[d + 26] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_MAX2, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX2' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'MAX2' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:80]\n");
                    fprintf (f, "set y2tics 16 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX2_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX2_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_MAX2_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_MAX2[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_MAX2, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_MAX2[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_MAX2, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX2' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX2_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX2_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX2_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'MAX2_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);                                                                                
                    break;
               case 4:
                    printf ("resim parametr K2\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    K2 = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        K2 = K2 + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (pocet_r - 730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = K2;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                            
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_K2[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_K2, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_K2[d + 24] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_K2, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K2' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'K2' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:30]\n");
                    fprintf (f, "set y2tics 6 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K2_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K2_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_K2_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                    
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_K2[d + 34] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_K2, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_K2[d + 34] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_K2, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K2' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\K2_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K2_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K2_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'K2_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               case 5:
                    printf ("resim parametr MAX3\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    MAX3 = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        MAX3 = MAX3 + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (pocet_r - 730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = MAX3;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_MAX3[d + 35] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_MAX3, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_MAX3[d + 26] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_MAX3, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX3' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'MAX3' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:30]\n");
                    fprintf (f, "set y2tics 6 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX3_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_MAX3_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_MAX3_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_MAX3[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_MAX3, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_MAX3[d + 36] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_MAX3, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru MAX3' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX3_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX3_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\MAX3_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'MAX3_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               case 6:
                    printf ("resim parametr K3\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    K3 = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        K3 = K3 + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        X = pole_parametrickych_sad[c][6];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = K3;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_K3[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_K3, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_K3[d + 24] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_K3, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K3' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'K3' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:30]\n");
                    fprintf (f, "set y2tics 6 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K3_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K3_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_K3_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_K3[d + 34] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_K3, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_K3[d + 34] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_K3, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K3' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\K3_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K3_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K3_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'K3_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               case 7:
                    printf ("resim parametr X\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    X = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        X = X + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        K = pole_parametrickych_sad[c][7];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = X;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_X[d + 32] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_X, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_X[d + 23] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_X, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru X' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'X' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:30]\n");
                    fprintf (f, "set y2tics 6 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_X_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_X_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_X_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_X[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_X, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_X[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_X, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru X' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\X_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\X_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\X_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'X_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               case 8:
                    printf ("resim parametr K\n");
                    for (g = 0; g < pocet_r; g++) {
                        pole_odtoku[g][0] = Pr[g];
                        pole_odtoku[g][1] = D_M[g];
                        }
                    K = zacatek_intervalu - krok; 
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        K = K + krok;
                        DDF = pole_parametrickych_sad[c][0];
                        MAX1 = pole_parametrickych_sad[c][1];
                        MAX2 = pole_parametrickych_sad[c][2];
                        K2 = pole_parametrickych_sad[c][3];
                        MAX3 = pole_parametrickych_sad[c][4];
                        K3 = pole_parametrickych_sad[c][5];
                        X = pole_parametrickych_sad[c][6];
                        SC = SC1 = SC2 = SC3 = 0;
                        for (g = 0; g < pocet_r; g++) {        
                            /*prirazeni vstupnich hodnot*/
                            T_min = T_minimum[g]; T_max = T_maximum[g]; Prep = Pr[g]; PoE = PE[g];                    
                            /*volani funkce model*/
                            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                            &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                            /*ulozeni vypoctenych odtoku do pripravenych poli*/
                            D_prm[g] = NoI; D_sbsr[g] = D_SC2; D_surf[g] = D_Sur; D_base[g] = D_SC3; D_tonetr[g] = D_Totnt;                
                            }
                        /*transformace korytem*/
                        D_tottr[0] = D_tonetr[0];
                        for (g = 1; g < pocet_r; g++) {
                            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                            D_tottr[g] = C0 * D_tonetr[g] + C1 * D_tonetr[g - 1] + C2 * D_tottr[g - 1];
                            }
                        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                        for (g = 366; g < 1096; g++) {
                            suma1 = suma1 + ((D_tottr[g] - D_M[g]) * (D_tottr[g] - D_M[g]));    
                            suma2 = suma2 + D_M[g];
                            suma4 = suma4 + (D_tottr[g] - D_M[g]);
                            }
                        prumer1 = suma2 / (730);
                        for (g = 366; g < 1096; g++) {
                            suma3 = suma3 + ((D_M[g] - prumer1)*(D_M[g] - prumer1));
                            }
                        for (g = 366; g < 1096; g++) {
                            pole_odtoku[g][e + 2] = D_tottr[g];
                            }      
                        pole_parametr_a_CE[e][0] = K;
                        pole_parametr_a_CE[e][1] = 1 - (suma1 / suma3);
                        ETV = (suma4 / suma2) * 100;
                        if (ETV > 0) {
                            pole_parametr_a_CE[e][2] = ETV;
                            }
                        else {
                            pole_parametr_a_CE[e][2] = ETV * -1.0;
                            }                                                                             
                        }
                    /*nalezeni mezi pro GNU sobor s odtoky*/         
                    max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
                    for (g = 366; g < 1096; g++) {    
                        if (Pr[g] > max_prep) {
                            max_prep = Pr[g];
                            }
                        if (D_M[g] > max_mer_odtok) {
                            max_mer_odtok = D_M[g];
                            }
                        }
                    for (g = 366; g < 1096; g++) {
                        for (e = 2; e < (velikost_pole_parametr_a_CE + 2); e++) {    
                            if (pole_odtoku[g][e] > max_celk_odtok) {
                                max_celk_odtok = pole_odtoku[g][e];
                                }
                            }
                        }                                                                                                                                 
                    if (max_mer_odtok > max_celk_odtok) {
                        max_odtok = max_mer_odtok;
                        }
                    else {
                        max_odtok = max_celk_odtok;
                        }
                    /*tisk vysledku parametr + OF*/
                    for (d = 0; d < 7; d++) {
                        parametr_K[d + 32] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (parametr_K, "w");
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {
                        for (h = 0; h < 3; h++) {
                            fprintf (f, "%.3f\t", pole_parametr_a_CE[e][h]);
                            }
                        fprintf (f, "\n");
                        }
                    fclose(f);
                    /*tisk GNU souboru - parametr + OF*/
                    for (d = 0; d < 3; d++) {
                        graf_K[d + 23] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (graf_K, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'K' font ',35' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [%.3f:%.3f]\n", zacatek_intervalu, konec_intervalu);
                    fprintf (f, "set xtics %.3f font ',35' offset character 0, -1, 0\n", konec_intervalu / 5);
                    fprintf (f, "set ylabel 'CE' font ',35' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:1]\n");
                    fprintf (f, "set ytics 0.2 font ',35' offset character -1, 0, 0\n");
                    fprintf (f, "set y2label 'ETV' font ',35' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [0:30]\n");
                    fprintf (f, "set y2tics 6 font ',35' offset character -1, 0, 0\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K_%s' u 1:2 axis x1y1 w points title 'CE' lc 1 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\parametr_K_%s' u 1:3 axis x2y2 w points title 'ETV' lc 3 pt 7\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set out 'parametr_K_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");
                    fclose(f);
                    /*tisk hydrogramu*/
                    for (d = 0; d < 7; d++) {
                        hydrogram_K[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (hydrogram_K, "w");
                    for (g = 366; g < 1096; g++) {
                        for (e = 0; e < (velikost_pole_parametr_a_CE + 2); e++) {                                
                            fprintf (f, "%.4f\t", pole_odtoku[g][e]);
                            }
                        fprintf (f, "\n");
                        } 
                    fclose(f);
                    /*tisk GNU souboru pro hydrogramy*/
                    for (d = 0; d < 3; d++) {
                        odtoky_K[d + 33] = pole_nazvu_povodi[c][d];
                        }
                    f = fopen (odtoky_K, "w");
                    fprintf (f, "reset\n");
                    fprintf (f, "cd 'C:\\CKSOM1\\output_data\\sens_anl'\n");
                    fprintf (f, "set title 'citl. analyza parametru K' font ',35' offset character 0, 1, 0\n");
                    fprintf (f, "set grid\n");
                    fprintf (f, "set xlabel 'casovy krok' font ',30' offset character 0, -3, 0\n");
                    fprintf (f, "set xrange [0:730]\n");
                    fprintf (f, "set xtics 120 font ',30' offset character 0, -1, 0\n");
                    fprintf (f, "set ylabel 'odtok [mm]' font ',30' offset character -4, 0, 0\n");
                    fprintf (f, "set yrange [0:%.0f]\n", max_odtok / 0.7);
                    fprintf (f, "set ytics %.0f font ',30' offset character -1, 0, 0\n", (max_odtok / 0.7) / 5);
                    fprintf (f, "set y2label 'srazky [mm]' font ',30' offset character 5, 0, 0\n");
                    fprintf (f, "set y2range [%.0f:0]\n", max_prep / 0.3);               
                    fprintf (f, "set y2tics %.0f font ',30' offset character 1, 0, 0\n", (max_prep / 0.3) / 5);
                    fprintf (f,"set style fill solid\n");
                    fprintf (f,"set key outside below center samplen 5 width 10 height 3 spacing 2 font ',30'\n");
                    fprintf (f, "plot 'C:\\CKSOM1\\output_data\\sens_anl\\K_hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);
                    for (e = 0; e < velikost_pole_parametr_a_CE; e++) {    
                        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K_hydrogram_%s' u %d w steps title '' lt 9\n", pole_nazvu_povodi[c], e + 3);
                        }                
                    fprintf (f, "replot 'C:\\CKSOM1\\output_data\\sens_anl\\K_hydrogram_%s' u 2 w steps title 'D_{mer}' lt 1 lw 2\n", pole_nazvu_povodi[c]);             
                    fprintf (f, "set out 'K_hydrogram_%s.ps'\n", pole_nazvu_povodi[c]);
                    fprintf (f, "set terminal post solid enhanced color\n");
                    fprintf (f, "replot\n");
                    fprintf (f, "set out\n");
                    fprintf (f, "set terminal windows\n");                                
                    fclose(f);
                    break;
               }    
        }//konec cyklu pro vsechna analyzovana povodi
    system ("PAUSE");
    return 0;
}
