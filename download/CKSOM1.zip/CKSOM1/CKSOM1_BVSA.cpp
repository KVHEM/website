#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#define POCET_ZNAKU 8
#define POCET_ZNAKU2 4

/*funkce pro zjisteni poctu radku*/
int pocet_radku(FILE *f) {
    int pocet = 0;
    int c;  
    while ((c = getc(f)) != EOF) {
          if (c == '\n') {
             pocet++;
             }
          }
    return pocet;
    }
/*funkce model Dharma*/
void model(double *T_min, double *T_max, double *Prep, double *SC, double *DDF, double *NoI, 
           double *SC1, double *PoE, double *MAX1, double *D_SC1, double *SC2, double *MAX2,
           double *K2, double *D_SC2, double *D_Sur, double *SC3, double *MAX3, double *K3,
           double *D_SC3, double *D_Totnt) {
           /*deklarace promennych*/
           double T_prum, Sn, TSM, Melt, Rf, INPUT, RATIO, E_SC1, RED, E_SC2, E_SC3;
           double percol, CHECK, exponent1, exponent2, exponent3;
           /*vypocet prumerne teploty*/
           T_prum = (*T_min + *T_max) / 2;
           /*prepocet vstupni srazky na dest a snih*/
           if (*T_max < 0) {
              Sn = *Prep;
              Rf = 0;
              }
           if (T_prum < 0 && *T_max > 0) {                                  
              Sn = ((0 - *T_min) / (*T_max - *T_min)) * *Prep;
              Rf = (1 - (0 - *T_min) / (*T_max - *T_min)) * *Prep;
              }
           if (*T_min < 0 && T_prum > 0) {
              Sn = 0;
              Rf = *Prep;
              }
           if (*T_min >= 0) {
              Sn = 0;
              Rf = *Prep;
              }
           /*vypocet akumulace snehove pokryvky a tani snehu*/
           if (*T_max < 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }
           if (T_prum < 0 && *T_max >= 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }       
           if (*T_min < 0 && T_prum >= 0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           if (*T_min >=0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           /*vypocet vsupu do pudnich zasobniku*/
           INPUT = Rf + Melt;
           if (INPUT <= 0.00001) {
              INPUT = 0;
              }
           /*vypocet vyparu z SC1*/
           E_SC1 = (*SC1 / *MAX1) * *PoE;
           RED = *PoE - E_SC1;
           /*bilance 1 v SC1*/
           *SC1 = *SC1 - E_SC1;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 < 0) {
              E_SC1 = E_SC1 + *SC1;
              RED = *PoE - E_SC1;
              *SC1 = 0;
              }
           /*vypocet vyparu v SC2*/
           if (*SC2 < RED) {
              E_SC2 = *SC2;
              *SC2 = 0;
              RED = RED - E_SC2;
              }
           else {
                E_SC2 = RED;
                RED = 0;
                }
           /*bilance 1 v SC2*/
           *SC2 = *SC2 - E_SC2;
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              }
           if (*SC2 < 0) {
              E_SC1 = E_SC1 + *SC1;
              *SC1 = 0;
              }
           /*vypocet neinfiltrovatelneho vstupu*/
           RATIO = (*SC1 + *SC2) / (*MAX1 + *MAX2);
           *NoI = RATIO * INPUT * 0.25;
           if (*NoI <= 0.00001) {
              *NoI = 0;
              }
           /*bilance 2 v SC1*/
           *SC1 = *SC1 + INPUT - *NoI;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 <= *MAX1) {
              *D_SC1 = 0;
              }
           else {
                *D_SC1 = *SC1 - *MAX1;
                *SC1 = *MAX1;
                }
           /*bilance 2 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              percol = 0;
              }
           else {
                percol = *SC2 * (1 - (*SC3 / *MAX3));
                *SC2 = *SC2 - percol;
                }
           /*kontrola mnozstvi perkolovane vody*/
           CHECK = *SC3 + percol - *MAX3;
           if (CHECK > 0) {
              percol = percol - CHECK;
              *SC2 = *SC2 + CHECK;
              }
           /*bilance 3 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              *D_SC2 = 0;
              }
           else {
                exponent2 = *SC2 / *MAX2;
                *D_SC2 = *K2 * pow (*SC2, exponent2);
                if (*D_SC2 > *SC2) {
                   *D_SC2 = *SC2;
                   }
                *SC2 = *SC2 - *D_SC2;
                }
           /*bilance 4 v SC2*/
           *SC2 = *SC2 + *D_SC1;
           if (*SC2 <= *MAX2) {
              *D_Sur = 0;
              }
           else {
                *D_Sur = *SC2 - *MAX2;
                *SC2 = *MAX2;
                }             
           /*billance 1 v SC3*/
           *SC3 = *SC3 + percol;
           if (*SC3 > 0.00001) {
              exponent3 = *SC3 / *MAX3;              
              *D_SC3 = *K3 * pow (*SC3, exponent3);
              if (*D_SC3 > *SC3) {
                 *D_SC3 = *SC3;
                 }
              *SC3 = *SC3 - *D_SC3;
              }
           else {
                *SC3 = 0;
                *D_SC3 = 0;
                }
           /*vypocet celkoveho netransformovaneho odtoku*/
           *D_Totnt = *NoI + *D_SC2 + *D_SC3 + *D_Sur;              
           }
/**/
int main (void) {
    /*delkarace promennych*/
    FILE *f;
    /*nastaveni programu*/
    int test_parametr_1; double dolni_mez_1, horni_mez_1, krok_1, parametr_1;
    int test_parametr_2; double dolni_mez_2, horni_mez_2, krok_2, parametr_2;
    int pocet_radku_pole_OF_CE, pocet_sloupcu_pole_OF_CE; 
    /*vstupni data*/
    int pocet_souboru, pocet_r, pocet_sad_parametru; char **pole_nazvu_povodi; char konec_radku;
    char vstup_data_povodi[] = "input_data/kalibrace/xxxxxxx";    
    double *Pr, *PE, *D_M, *T_minimum, *T_maximum;
    /*parametry modelu*/
    char p_DDF, p_MAX1, p_MAX2, p_K2, p_MAX3, p_K3, p_X, p_K;
    double **pole_parametrickych_sad, **pole_vystupu_OF_CE, **pole_vystupu_OF_ETV;
    double DDF, MAX1, MAX2, K2, MAX3, K3, X, K; 
    int pocet_parametru = 8;
    /*promenne v modelu*/
    double T_min, T_max, Prep, SC, NoI, SC1, PoE, D_SC1, SC2, D_SC2, D_Sur, SC3, D_SC3, D_Totnt;
    double C0, C1, C2, suma1, suma2, suma3, suma4, prumer1, CE, ETV;
    /*vystupni data z modelu*/
    double *D_prm, *D_sbsr, *D_surf, *D_base, *D_tonetr, *D_tottr; 
    /*pomocne promenne*/
    double chyba1, chyba2;
    double max_prep, max_mer_odtok, max_celk_odtok, max_odtok;
    int a, b, c, d, e, g, h, i, j, k, l;
    /*tisk vysledku*/
    char parametr_p1_p2_CE[] = "output_data/sens_anl/parametr_xxxx_xxxx_CE_xxxxxxx";
    char parametr_p1_p2_ETV[] = "output_data/sens_anl/parametr_xxxx_xxxx_ETV_xxxxxxx";
    /**/
    
    /*nacteni nastaveni programu pro citlivostni analyzu*/
    f = fopen ("settings/BVSA_settings.txt", "r");
    if (f == NULL) {
        printf ("file BVSA_settings.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    fscanf (f, "%d %lf %lf %lf %d %lf %lf %lf", &test_parametr_1, &horni_mez_1, &dolni_mez_1, &krok_1, &test_parametr_2, &horni_mez_2, &dolni_mez_2, &krok_2);
    fclose(f);
    /*zjisteni poctu radku souboru s nazvy povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    if (f == NULL) {
        printf ("file file_of_ID.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    pocet_souboru = pocet_radku(f);    
    fclose(f);
    printf ("pouzity pocet povodi pri citlivostni analyze: %d\n", pocet_souboru);
    /*alokace pole nazvu analyzovanych povodi*/
    if ((pole_nazvu_povodi = ((char**) malloc(pocet_souboru * sizeof(char *)))) == NULL) {
        printf("chyba pri alokaci pameti\n");
        return 1;
        }      
    for (a = 0; a < pocet_souboru; a++) {
        if ((pole_nazvu_povodi[a] = ((char*) malloc(POCET_ZNAKU * sizeof(char)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }      
        }
    /*nacteni nazvu analyzovanych povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    for (a = 0; a < pocet_souboru; a++) {
        for (b = 0; b < POCET_ZNAKU - 1; b++) {
            fscanf (f, "%c", &pole_nazvu_povodi[a][b]);
            }
        fscanf (f, "%c", &konec_radku);    
        pole_nazvu_povodi[a][7] = '\0';
        }
    fclose(f);
    /*zjisteni poctu radku souboru s optimalnimi parametry modelu*/
    f = fopen ("input_data/sens_anl/sens_anl.txt", "r");
    if (f == NULL) {
        printf ("file file_of_ID.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    pocet_sad_parametru = pocet_radku(f);    
    fclose(f);
    printf ("pocet parametrickych sad v souboru nejlepsi_sady.txt: %d\n", pocet_sad_parametru);
    if (pocet_souboru != pocet_sad_parametru) {
        printf ("nesouhlasi pocet analyzovanych povodi a pocet parametrickych sad\n");
        system ("PAUSE");
        return 2;
        }
    /*alokace pole parametrickych sad*/
    if ((pole_parametrickych_sad = ((double**) malloc(pocet_sad_parametru * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (a = 0; a < pocet_sad_parametru; a++) {
        if ((pole_parametrickych_sad[a] = ((double*) malloc((pocet_parametru + 2) * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    /*nacteni optimalnich sad parametru do pole*/
    f = fopen ("input_data/sens_anl/sens_anl.txt", "r");
    for (a = 0; a < pocet_sad_parametru; a++) {
        for (b = 0; b < (pocet_parametru + 2); b++) {
            fscanf (f, "%lf", &pole_parametrickych_sad[a][b]);
            }
        }
    fclose(f);
    /*alokace pole vystupnich OF - CE a ETV*/
    printf ("%f\t %f\t %f\n", dolni_mez_1, horni_mez_1, krok_1);
    printf ("%f\t %f\t %f\n", dolni_mez_2, horni_mez_2, krok_2);
    double mezivypocet_1 = round (((dolni_mez_1 + horni_mez_1 + krok_1) / krok_1));
    double mezivypocet_2 = round (((dolni_mez_2 + horni_mez_2 + krok_2) / krok_2));
    pocet_radku_pole_OF_CE = (int) mezivypocet_1;
    pocet_sloupcu_pole_OF_CE = (int) mezivypocet_2;
    printf ("pocet_radku_pole_OF_CE: %d\n", pocet_radku_pole_OF_CE);
    printf ("pocet_sloupcu_pole_OF_CE: %d\n", pocet_sloupcu_pole_OF_CE);    
    if ((pole_vystupu_OF_CE = ((double**) malloc(pocet_radku_pole_OF_CE * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (e = 0; e < pocet_radku_pole_OF_CE; e++) {
        if ((pole_vystupu_OF_CE[e] = ((double*) malloc(pocet_sloupcu_pole_OF_CE * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    if ((pole_vystupu_OF_ETV = ((double**) malloc(pocet_radku_pole_OF_CE * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (e = 0; e < pocet_radku_pole_OF_CE; e++) {
        if ((pole_vystupu_OF_ETV[e] = ((double*) malloc(pocet_sloupcu_pole_OF_CE * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    /*for cyklus pro vsechna analyzovana povodi*/
    for (c = 0; c < pocet_souboru; c++) {
        for (d = 0; d < 7; d++) {
            vstup_data_povodi[d + 21] = pole_nazvu_povodi[c][d];
            }
        /*zjisteni poctu radku kazdeho kalibracniho souboru*/
        f = fopen (vstup_data_povodi, "r");
        printf ("\n");
        printf ("prave pocitam kalibracni soubor: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
        if (f == NULL) {
            printf ("soubor nenalezen\n");
            system ("PAUSE");  
            return 1;
            }    
        pocet_r = pocet_radku(f);        
        fclose(f);
        /*alokace poli vstupnich promennych*/
        if ((Pr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((PE = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_M = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_minimum = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_maximum = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_povodi, "r");
        for (h = 0; h < pocet_r; h++) {
            fscanf (f, "%lf %lf %lf %lf %lf", &Pr[h], &PE[h], &D_M[h], &T_maximum[h], &T_minimum[h]);
            }
        fclose (f);                            
        /*kontrola vstupnich dat*/
        /*kontrola teplot*/
        for (h = 0; h < pocet_r; h++) {
            if (T_maximum[h] < T_minimum[h]) {
                chyba1 = T_maximum[h];
                chyba2 = T_minimum[h];
                T_minimum[h] = chyba1;
                T_maximum[h] = chyba2;
                }
            }
        /*kontrola srazek*/
        for (h = 0; h < pocet_r; h++) {
            if (Pr[h] == -99.00) {
                Pr[h] = 0;
                }
            }
        /*alokace poli pomocnych promennych*/    
        if ((D_prm = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_sbsr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_surf = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_base = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }    
        if ((D_tonetr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_tottr = ((double*) malloc(pocet_r * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*tisk informace do okna jake parametrz se prave resi*/         
        if (test_parametr_1 == 1) {
            printf ("resim parametry DDF\t");
            }
        if (test_parametr_1 == 2) {
            printf ("resim parametry MAX1\t");
            }
        if (test_parametr_1 == 3) {
            printf ("resim parametry MAX2\t");
            }
        if (test_parametr_1 == 4) {
            printf ("resim parametry K2\t");
            }
        if (test_parametr_1 == 5) {
            printf ("resim parametry MAX3\t");
            }
        if (test_parametr_1 == 6) {
            printf ("resim parametry K3\t");
            }
        if (test_parametr_1 == 7) {
            printf ("resim parametry X\t");
            }
        if (test_parametr_1 == 8) {
            printf ("resim parametry K\t");
            }    
        if (test_parametr_2 == 1) {
            printf (" a DDF\n");
            }
        if (test_parametr_2 == 2) {
            printf (" a MAX1\n");
            }
        if (test_parametr_2 == 3) {
            printf (" a MAX2\n");
            }
        if (test_parametr_2 == 4) {
            printf (" a K2\n");
            }
        if (test_parametr_2 == 5) {
            printf (" a MAX3\n");
            }
        if (test_parametr_2 == 6) {
            printf (" a K3\n");
            }
        if (test_parametr_2 == 7) {
            printf (" a X\n");
            }
        if (test_parametr_2 == 8) {
            printf ("r a K\n");
            }
        /*prirazeni defaultni hodnoty (-99.99) parametrum, ktere se testuji*/
        for (b = 0; b < 8; b++) {
            if ((test_parametr_1 - 1) == b) {
                pole_parametrickych_sad[c][b] = -99.99;
                printf ("parametr 1\n");
                }
            if ((test_parametr_2 - 1) == b) {
                pole_parametrickych_sad[c][b] = -99.99;
                printf ("parametr 2\n");
                }
            }
        /*prirazeni hodnot z pole parametrum modelu, ktere se netestuji*/
        if (pole_parametrickych_sad[c][0] != -99.99) {
            DDF = pole_parametrickych_sad[c][0];
            }                
        if (pole_parametrickych_sad[c][1] != -99.99) {
            MAX1 = pole_parametrickych_sad[c][1];
            }
        if (pole_parametrickych_sad[c][2] != -99.99) {
            MAX2 = pole_parametrickych_sad[c][2];
            }
        if (pole_parametrickych_sad[c][3] != -99.99) {
            K2 = pole_parametrickych_sad[c][3];
            }
        if (pole_parametrickych_sad[c][4] != -99.99) {
            MAX3 = pole_parametrickych_sad[c][4];
            }
        if (pole_parametrickych_sad[c][5] != -99.99) {
            K3 = pole_parametrickych_sad[c][5];
            }
        if (pole_parametrickych_sad[c][6] != -99.99) {
            X = pole_parametrickych_sad[c][6]; 
            }
        if (pole_parametrickych_sad[c][8] != -99.99) {
            K = pole_parametrickych_sad[c][7];
            }
        /*for cyklus pro prvni testovany parametr*/
        parametr_1 = dolni_mez_1 - krok_1;
        for (e = 0; e < pocet_radku_pole_OF_CE; e++) { 
            parametr_1 = parametr_1 + krok_1;
            /*prirazeni hodnoty testovanemu parametru 1*/
            if (test_parametr_1 == 1) {
                DDF = parametr_1;
                }
            if (test_parametr_1 == 2) {
                MAX1 = parametr_1;
                }
            if (test_parametr_1 == 3) {
                MAX2 = parametr_1;
                }
            if (test_parametr_1 == 4) {
                K2 = parametr_1;
                }
            if (test_parametr_1 == 5) {
                MAX3 = parametr_1;
                }
            if (test_parametr_1 == 6) {
                K3 = parametr_1;
                }
            if (test_parametr_1 == 7) {
                X = parametr_1;
                }
            if (test_parametr_1 == 8) {
                K = parametr_1;
                }                
            parametr_2 = dolni_mez_2 - krok_2;
            /*for cyklus pro druhy testovany parametr*/
            for (g = 0; g < pocet_sloupcu_pole_OF_CE; g++) {
                parametr_2 = parametr_2 + krok_2;
                /*prirazeni hodnoty testovanemu parametru 2*/
                if (test_parametr_2 == 1) {
                    DDF = parametr_2;
                    }
                if (test_parametr_2 == 2) {
                    MAX1 = parametr_2;
                    }
                if (test_parametr_2 == 3) {
                    MAX2 = parametr_2;
                    }
                if (test_parametr_2 == 4) {
                    K2 = parametr_2;
                    }
                if (test_parametr_2 == 5) {
                    MAX3 = parametr_2;
                    }
                if (test_parametr_2 == 6) {
                    K3 = parametr_2;
                    }
                if (test_parametr_2 == 7) {
                    X = parametr_2;
                    }
                if (test_parametr_2 == 8) {
                    K = parametr_2;
                    }                
                SC = SC1 = SC2 = SC3 = 0;
                for (h = 0; h < pocet_r; h++) {        
                    /*prirazeni vstupnich hodnot*/
                    T_min = T_minimum[h]; T_max = T_maximum[h]; Prep = Pr[h]; PoE = PE[h];                    
                    /*volani funkce model*/
                    model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                    &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                    /*ulozeni vypoctenych odtoku do pripravenych poli*/
                    D_prm[h] = NoI; D_sbsr[h] = D_SC2; D_surf[h] = D_Sur; D_base[h] = D_SC3; D_tonetr[h] = D_Totnt;                
                    }
                D_tottr[0] = D_tonetr[0];
                for (h = 1; h < pocet_r; h++) {
                    C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                    C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                    C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                    D_tottr[h] = C0 * D_tonetr[h] + C1 * D_tonetr[h - 1] + C2 * D_tottr[h - 1];
                    }
                /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                for (h = 366; h < 1096; h++) {
                    suma1 = suma1 + ((D_tottr[h] - D_M[h]) * (D_tottr[h] - D_M[h]));    
                    suma2 = suma2 + D_M[h];
                    suma4 = suma4 + (D_tottr[h] - D_M[h]);
                    }
                prumer1 = suma2 / (730);
                for (h = 366; h < 1096; h++) {
                    suma3 = suma3 + ((D_M[h] - prumer1)*(D_M[h] - prumer1));
                    }
                pole_vystupu_OF_CE[e][g] = 1 - (suma1 / suma3);
                pole_vystupu_OF_ETV[e][g] = (suma4 / suma2) * 100;            
                }
            }
        /*tisk vysledku*/                                                            
        for (d = 0; d < 7; d++) {
            parametr_p1_p2_CE[d + 43] = pole_nazvu_povodi[c][d];
            }
        f = fopen (parametr_p1_p2_CE, "w");
        for (e = 0; e < pocet_radku_pole_OF_CE; e++) {
            for (g = 0; g < pocet_sloupcu_pole_OF_CE; g++) {
                fprintf (f, "%.3f\t", pole_vystupu_OF_CE[e][g]);
                }
            fprintf (f, "\n");
            }
        fclose (f);
        for (d = 0; d < 7; d++) {
            parametr_p1_p2_ETV[d + 44] = pole_nazvu_povodi[c][d];
            }
        f = fopen (parametr_p1_p2_ETV, "w");
        for (e = 0; e < pocet_radku_pole_OF_CE; e++) {
            for (g = 0; g < pocet_sloupcu_pole_OF_CE; g++) {
                fprintf (f, "%.3f\t", pole_vystupu_OF_ETV[e][g]);
                }
            fprintf (f, "\n");
            }
        fclose (f);    
        }// konec cyklu pro vsechna analyzovana povodi    
    system ("PAUSE");
    return 0;
}
