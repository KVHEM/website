#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
#define POCET_ZNAKU 8
/*funkce pro zjisteni poctu radku*/
int pocet_radku(FILE *f) {
    int pocet = 0;
    int c;  
    while ((c = getc(f)) != EOF) {
          if (c == '\n') {
             pocet++;
             }
          }
    return pocet;
    }
/*funkce pro stanoveni vahy pouzite pri vypoctu teziste zmenceneho parametrickeho prostoru*/
double vypocet_vahy(double pole) {
       double vaha = 0;
       if (pole < 0.4) {
          vaha = 0.0001;
          }
       else {
            vaha = pow (100, pole);
            }
       return vaha;
       }
/*funkce model Dharma*/
void model(double *T_min, double *T_max, double *Prep, double *SC, double *DDF, double *NoI, 
           double *SC1, double *PoE, double *MAX1, double *D_SC1, double *SC2, double *MAX2,
           double *K2, double *D_SC2, double *D_Sur, double *SC3, double *MAX3, double *K3,
           double *D_SC3, double *D_Totnt) {
           /*deklarace promennych*/
           double T_prum, Sn, TSM, Melt, Rf, INPUT, RATIO, E_SC1, RED, E_SC2, E_SC3;
           double percol, CHECK, exponent1, exponent2, exponent3;
           /*vypocet prumerne teploty*/
           T_prum = (*T_min + *T_max) / 2;
           /*prepocet vstupni srazky na dest a snih*/
           if (*T_max < 0) {
              Sn = *Prep;
              Rf = 0;
              }
           if (T_prum < 0 && *T_max > 0) {                                  
              Sn = ((0 - *T_min) / (*T_max - *T_min)) * *Prep;
              Rf = (1 - (0 - *T_min) / (*T_max - *T_min)) * *Prep;
              }
           if (*T_min < 0 && T_prum > 0) {
              Sn = 0;
              Rf = *Prep;
              }
           if (*T_min >= 0) {
              Sn = 0;
              Rf = *Prep;
              }
           /*vypocet akumulace snehove pokryvky a tani snehu*/
           if (*T_max < 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }
           if (T_prum < 0 && *T_max >= 0) {
              *SC = *SC + Sn;
              TSM = 0;
              Melt = 0;
              }       
           if (*T_min < 0 && T_prum >= 0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           if (*T_min >=0) {
              TSM = *DDF * (T_prum - 0);
              *SC = *SC + Sn - TSM;
              if (*SC >= 0) {
                 Melt = TSM;
                 }
              else {
                   Melt = TSM + *SC;
                   *SC = 0;
                   }
              }
           /*vypocet vsupu do pudnich zasobniku*/
           INPUT = Rf + Melt;
           if (INPUT <= 0.00001) {
              INPUT = 0;
              }
           /*vypocet vyparu z SC1*/
           E_SC1 = (*SC1 / *MAX1) * *PoE;
           RED = *PoE - E_SC1;
           /*bilance 1 v SC1*/
           *SC1 = *SC1 - E_SC1;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 < 0) {
              E_SC1 = E_SC1 + *SC1;
              RED = *PoE - E_SC1;
              SC1 = 0;
              }
           /*vypocet vyparu v SC2*/
           if (*SC2 < RED) {
              E_SC2 = *SC2;
              *SC2 = 0;
              RED = RED - E_SC2;
              }
           else {
                E_SC2 = RED;
                RED = 0;
                }
           /*bilance 1 v SC2*/
           *SC2 = *SC2 - E_SC2;
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              }
           if (*SC2 < 0) {
              E_SC1 = E_SC1 + *SC1;
              *SC1 = 0;
              }
           /*vypocet neinfiltrovatelneho vstupu*/
           RATIO = (*SC1 + *SC2) / (*MAX1 + *MAX2);
           *NoI = RATIO * INPUT * 0.25;
           if (*NoI <= 0.00001) {
              *NoI = 0;
              }
           /*bilance 2 v SC1*/
           *SC1 = *SC1 + INPUT - *NoI;
           if (*SC1 <= 0.00001) {
              *SC1 = 0;
              }
           if (*SC1 <= *MAX1) {
              *D_SC1 = 0;
              }
           else {
                *D_SC1 = *SC1 - *MAX1;
                *SC1 = *MAX1;
                }
           /*bilance 2 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              percol = 0;
              }
           else {
                percol = *SC2 * (1 - (*SC3 / *MAX3));
                *SC2 = *SC2 - percol;
                }
           /*kontrola mnozstvi perkolovane vody*/
           CHECK = *SC3 + percol - *MAX3;
           if (CHECK > 0) {
              percol = percol - CHECK;
              *SC2 = *SC2 + CHECK;
              }
           /*bilance 3 v SC2*/
           if (*SC2 <= 0.00001) {
              *SC2 = 0;
              *D_SC2 = 0;
              }
           else {
                exponent2 = *SC2 / *MAX2;
                *D_SC2 = *K2 * pow (*SC2, exponent2);
                if (*D_SC2 > *SC2) {
                   *D_SC2 = *SC2;
                   }
                *SC2 = *SC2 - *D_SC2;
                }
           /*bilance 4 v SC2*/
           *SC2 = *SC2 + *D_SC1;
           if (*SC2 <= *MAX2) {
              *D_Sur = 0;
              }
           else {
                *D_Sur = *SC2 - *MAX2;
                *SC2 = *MAX2;
                }             
           /*billance 1 v SC3*/
           *SC3 = *SC3 + percol;
           if (*SC3 > 0.00001) {
              exponent3 = *SC3 / *MAX3;              
              *D_SC3 = *K3 * pow (*SC3, exponent3);
              if (*D_SC3 > *SC3) {
                 *D_SC3 = *SC3;
                 }
              *SC3 = *SC3 - *D_SC3;
              }
           else {
                *SC3 = 0;
                *D_SC3 = 0;
                }
           /*vypocet celkoveho netransformovaneho odtoku*/
           *D_Totnt = *NoI + *D_SC2 + *D_SC3 + *D_Sur;              
           }
/**/
int main (void) {   
    FILE *f;
    /*nastaveni ARSO*/
    
    /*pomocne promenne v ARSO*/
    double **pole_parametru, **pole_vysledek, **pole_dobrych_parametru, *souradnice_teziste;
    double rozsah_DDF, rozsah_MAX1, rozsah_MAX2, rozsah_K2, rozsah_MAX3, rozsah_K3, rozsah_X, rozsah_K;    
    double dolni_mez_DDF, dolni_mez_MAX1, dolni_mez_MAX2, dolni_mez_K2, dolni_mez_MAX3, dolni_mez_K3, dolni_mez_X, dolni_mez_K;    
    double novy_rozsah_DDF, novy_rozsah_MAX1, novy_rozsah_MAX2, novy_rozsah_K2, novy_rozsah_MAX3, novy_rozsah_K3, novy_rozsah_X, novy_rozsah_K;    
    double nova_dolni_mez_DDF, nova_dolni_mez_MAX1, nova_dolni_mez_MAX2, nova_dolni_mez_K2, nova_dolni_mez_MAX3, nova_dolni_mez_K3, nova_dolni_mez_X, nova_dolni_mez_K;
    double konstanta_redukce;
    int pocet_cyklu, pocet_redukci, pocet_sad_parametru;
    /*vstupni data*/
    char **pole_nazvu_povodi; char konec_radku; char vstup_data_povodi[] = "input_data/kalibrace/xxxxxxx"; char vstup_data_validace[] = "input_data/validace/xxxxxxx";
    double *Pr_kal, *PE_kal, *D_M_kal, *T_minimum_kal, *T_maximum_kal, *T_kontrola;
    double *Pr_val, *PE_val, *D_M_val, *T_minimum_val, *T_maximum_val;
    int pocet_souboru, pocet_r_kalibrace, pocet_r_validace;
    double kontrolni_ukazatel;
    /*vystupni data*/
    double *D_prm_kal, *D_sbsr_kal, *D_surf_kal, *D_base_kal, *D_tonetr_kal, *D_tottr_kal;
    double *D_prm_val, *D_sbsr_val, *D_surf_val, *D_base_val, *D_tonetr_val, *D_tottr_val;
    /*parametry modelu*/
    int pocet_parametru = 8;
    double DDF, MAX1, MAX2, K2, MAX3, K3, X, K;
    /*promenne v modelu*/
    double T_min, T_max, Prep, SC, NoI, SC1, PoE, D_SC1, SC2, D_SC2, D_Sur, SC3, D_SC3, D_Totnt;
    double chyba1, chyba2, C0, C1, C2, CE, suma1, suma2, suma3, suma4, prumer1, suma_CE, suma_par;
    double max_prep, max_mer_odtok, max_celk_odtok, max_odtok;
    int a, b, c, d, e, g, h, i, j, k, l, m;
    char hydrogram_kal[] = "output_data/kalibrace/hydrogram_xxxxxxx";  char graf_kal[] = "output_data/kalibrace/hydrogram_xxx.GNU";
    char hydrogram_val[] = "output_data/validace/hydrogram_xxxxxxx";  char graf_val[] = "output_data/validace/hydrogram_xxx.GNU";
    /*randomizace*/
    srand(time(NULL));
    /*nacteni nastaveni optimalizacniho programu*/
    f = fopen ("settings/ARSO_settings.txt", "r");
    fscanf (f, "%d %d %d %lf", &pocet_sad_parametru, &pocet_cyklu, &pocet_redukci, &konstanta_redukce);
    fclose(f);
    printf ("pocet generovanych sad parametru: %d\n", pocet_sad_parametru);
    printf ("pocet cyklu v ramci jedne redukce: %d\n", pocet_cyklu);
    printf ("pocet redukci par. prostoru: %d\n", pocet_redukci);
    printf ("rekukcni konstanta: %.3f\n", konstanta_redukce);
    /*nacteni velikosti primarniho parametrickeho prostoru*/
    f = fopen ("settings/ARSO_limits.txt", "r");
    fscanf (f, "%lf %lf", &rozsah_DDF, &dolni_mez_DDF);
    fscanf (f, "%lf %lf", &rozsah_MAX1, &dolni_mez_MAX1);
    fscanf (f, "%lf %lf", &rozsah_MAX2, &dolni_mez_MAX2);
    fscanf (f, "%lf %lf", &rozsah_K2, &dolni_mez_K2);
    fscanf (f, "%lf %lf", &rozsah_MAX3, &dolni_mez_MAX3);
    fscanf (f, "%lf %lf", &rozsah_K3, &dolni_mez_K3);
    fscanf (f, "%lf %lf", &rozsah_X, &dolni_mez_X);
    fscanf (f, "%lf %lf", &rozsah_K, &dolni_mez_K);
    fclose(f);
    /*alokace pole parametru v ramci jednoho cyklu*/
    if ((pole_parametru = ((double**) malloc(pocet_sad_parametru * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (i = 0; i < pocet_sad_parametru; i++) {
        if ((pole_parametru[i] = ((double*) malloc((pocet_parametru + 2) * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    for (i = 0; i < pocet_sad_parametru; i++) {
        for (j = 0; j < (pocet_parametru + 2); j++) {
            pole_parametru[i][j] = 0;
            }
        }    
    /*alokace pole pro nejlepsi sady parametru ze vsech cyklu*/
    if ((pole_dobrych_parametru = ((double**) malloc(pocet_cyklu * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (h = 0; h < pocet_cyklu; h++) {
        if ((pole_dobrych_parametru[h] = ((double*) malloc((pocet_parametru + 2) * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    for (h = 0; h < pocet_cyklu; h++) {
        for (j = 0; j < (pocet_parametru + 2); j++) {
            pole_dobrych_parametru[h][j] = 0;
            }
        }        
    /*alokace pole teziste dobrych parametru z jednoho cyklu...stred redukce parametrickeho prostoru*/
    if ((souradnice_teziste = ((double*) malloc((pocet_parametru) * sizeof(double)))) == NULL) {
        printf("chyba pri alokaci pameti\n");
        return 1;
        }        
    /*zjisteni poctu radku souboru s nazvy povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    if (f == NULL) {
        printf ("file file_of_ID.txt not found\n");
        system ("PAUSE");  
        return 1;
        }
    pocet_souboru = pocet_radku(f);    
    fclose(f);
    printf ("pouzity pocet povodi pri kalibraci: %d\n", pocet_souboru);
    /*alokace pole celkovych vysledku*/
    if ((pole_vysledek = ((double**) malloc(pocet_souboru * sizeof(double *)))) == NULL) {
        printf ("chyba pri alokaci pameti\n");
        return 1;
        }    
    for (c = 0; c < pocet_souboru; c++) {
        if ((pole_vysledek[c] = ((double*) malloc((pocet_parametru + 4) * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        }
    for (c = 0; c < pocet_souboru; c++) {
        for (j = 0; j < (pocet_parametru + 4); j++) {
            pole_vysledek[c][j] = 0;
            }
        }        
    /*alokace pole nazvu kalibracnich povodi*/
    if ((pole_nazvu_povodi = ((char**) malloc(pocet_souboru * sizeof(char *)))) == NULL) {
        printf("chyba pri alokaci pameti\n");
        return 1;
        }      
    for (a = 0; a < pocet_souboru; a++) {
        if ((pole_nazvu_povodi[a] = ((char*) malloc(POCET_ZNAKU * sizeof(char)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }      
        }
    /*nacteni nazvu kalibracnych povodi*/
    f = fopen ("input_data/kalibrace/file_of_ID.txt", "r");
    for (a = 0; a < pocet_souboru; a++) {
        for (b = 0; b < POCET_ZNAKU - 1; b++) {
            fscanf (f, "%c", &pole_nazvu_povodi[a][b]);
            }
        fscanf (f, "%c", &konec_radku);    
        pole_nazvu_povodi[a][7] = '\0';
        }
    fclose(f);
    /*for cyklus pro vsechna analyzovana povodi*/
    for (c = 0; c < pocet_souboru; c++) {
        for (d = 0; d < 7; d++) {
        vstup_data_povodi[d + 21] = pole_nazvu_povodi[c][d];
        }
        /*zjisteni poctu radku kazdeho kalibracniho souboru*/
        f = fopen (vstup_data_povodi, "r");
        printf ("\n");
        printf ("prave pocitam kalibracni soubor: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
        if (f == NULL) {
            printf ("soubor nenalezen\n");
            system ("PAUSE");  
            return 1;
            }    
        pocet_r_kalibrace = pocet_radku(f);
        fclose(f);
        /*alokace poli vstupnich dat*/
        if ((Pr_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((PE_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_M_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_minimum_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_maximum_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*pole pro kontrolu prumerne teploty...zda na povodi snezi nebo pouze prsi*/
        if ((T_kontrola = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_povodi, "r");
        for (e = 0; e < pocet_r_kalibrace; e++) {
            fscanf (f, "%lf %lf %lf %lf %lf", &Pr_kal[e], &PE_kal[e], &D_M_kal[e], &T_maximum_kal[e], &T_minimum_kal[e]);
            }
        fclose (f);                            
        /*kontrola vstupnich dat*/
        /*kontrola teplot*/
        for (e = 0; e < pocet_r_kalibrace; e++) {
            if (T_maximum_kal[e] < T_minimum_kal[e]) {
                chyba1 = T_maximum_kal[e];
                chyba2 = T_minimum_kal[e];
                T_minimum_kal[e] = chyba1;
                T_maximum_kal[e] = chyba2;
                }
            }
        /*kontrola srazek*/
        for (e = 0; e < pocet_r_kalibrace; e++) {
            if (Pr_kal[e] == -99.00) {
                Pr_kal[e] = 0;
                }
            }
        /*alokace poli pomocnych promennych*/    
        if ((D_prm_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_sbsr_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_surf_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_base_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }    
        if ((D_tonetr_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_tottr_kal = ((double*) malloc(pocet_r_kalibrace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*pocet opakovani vypocetniho cyklu s generatorem a modelem*/
        for (h = 0; h < pocet_cyklu; h++) {
            printf ("prave pocitam cyklus: %d\n", h + 1);
            /*generator paramerickych sad*/
            for (i = 0; i < pocet_sad_parametru; i++) {
                pole_parametru[i][0] = ((double) (rand () % 10000) / 10000) * rozsah_DDF + dolni_mez_DDF;
                pole_parametru[i][1] = ((double) (rand () % 10000) / 10000) * rozsah_MAX1 + dolni_mez_MAX1;
                pole_parametru[i][2] = ((double) (rand () % 10000) / 10000) * rozsah_MAX2 + dolni_mez_MAX2;
                pole_parametru[i][3] = ((double) (rand () % 10000) / 10000) * rozsah_K2 + dolni_mez_K2;
                pole_parametru[i][4] = ((double) (rand () % 10000) / 10000) * rozsah_MAX3 + dolni_mez_MAX3;
                pole_parametru[i][5] = ((double) (rand () % 10000) / 10000) * rozsah_K3 + dolni_mez_K3;
                pole_parametru[i][6] = ((double) (rand () % 10000) / 10000) * rozsah_X + dolni_mez_X;
                pole_parametru[i][7] = ((double) (rand () % 10000) / 10000) * rozsah_K + dolni_mez_K;
                pole_parametru[i][8] = 0;
                pole_parametru[i][9] = 0;
                }
            for (e = 0; e < pocet_r_kalibrace; e++) {
                T_kontrola[e] = (T_maximum_kal[e] + T_minimum_kal[e]) / 2;
                }
            int kontrola = 0;    
            for (e = 0; e < pocet_r_kalibrace; e++) {
                if (T_kontrola[e] <= 0) {
                    kontrola ++;
                    }
                }
            kontrolni_ukazatel = double (kontrola) / (pocet_r_kalibrace / 365);
            if (kontrolni_ukazatel <= 60) {
                for (i = 0; i < pocet_sad_parametru; i++) {
                    pole_parametru[i][0] = rozsah_DDF + dolni_mez_DDF;
                    }
                }
            /*testovani vygenerovanych sad parametru*/
            for (i = 0; i < pocet_sad_parametru; i++) {
                DDF = pole_parametru[i][0];
                MAX1 = pole_parametru[i][1];
                MAX2 = pole_parametru[i][2];
                K2 = pole_parametru[i][3];
                MAX3 = pole_parametru[i][4];
                K3 = pole_parametru[i][5];
                X = pole_parametru[i][6];
                K = pole_parametru[i][7];
                SC = SC1 = SC2 = SC3 = 0;
                for (e = 0; e < pocet_r_kalibrace; e++) {        
                /*prirazeni vstupnich hodnot*/
                    T_min = T_minimum_kal[e]; T_max = T_maximum_kal[e]; Prep = Pr_kal[e]; PoE = PE_kal[e];                    
                    /*volani funkce model*/
                    model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                                  &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                    /*ulozeni vypoctenych odtoku do pripravenych poli*/
                    D_prm_kal[e] = NoI; D_sbsr_kal[e] = D_SC2; D_surf_kal[e] = D_Sur; D_base_kal[e] = D_SC3; D_tonetr_kal[e] = D_Totnt;                
                    }
                /*transformace korytem*/
                D_tottr_kal[0] = D_tonetr_kal[0];
                for (e = 1; e < pocet_r_kalibrace; e++) {
                    C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                    C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                    C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                    D_tottr_kal[e] = C0 * D_tonetr_kal[e] + C1 * D_tonetr_kal[e - 1] + C2 * D_tottr_kal[e - 1];
                    }
                /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                for (e = 200; e < pocet_r_kalibrace; e++) {
                    suma1 = suma1 + ((D_tottr_kal[e] - D_M_kal[e]) * (D_tottr_kal[e] - D_M_kal[e]));    
                    suma2 = suma2 + D_M_kal[e];
                    suma4 = suma4 + (D_tottr_kal[e] - D_M_kal[e]);
                    }
                prumer1 = suma2 / (pocet_r_kalibrace - 200);
                for (e = 200; e < pocet_r_kalibrace; e++) {
                    suma3 = suma3 + ((D_M_kal[e] - prumer1)*(D_M_kal[e] - prumer1));
                    }
                pole_parametru[i][8] = 1 - (suma1 / suma3);
                pole_parametru[i][9] = (suma4 / suma2) * 100;    
                }
            CE = -100000;
            for (i = 0; i < pocet_sad_parametru; i++) {
                if (pole_parametru[i][8] > CE) {
                    CE = pole_parametru[i][8];
                    }
                }
            printf ("%f\n", CE);
            /*ulozeni dobrych parametrickych sad z kazdeho cyklu do pole dobrych sad*/
            for (i = 0; i < pocet_sad_parametru; i++) {
                if (pole_parametru[i][8] == CE) {
                    for (j = 0; j < (pocet_parametru + 2); j++) {
                        pole_dobrych_parametru[h][j] = pole_parametru[i][j];
                        }
                    }
                }     
            }//konec cyklu pro vsechny cykly
        /*vypocet souradnic teziste kolem ktereho se bude zmensovat parametricky prostor*/
        suma_CE = 0;
        for (h = 0; h < pocet_cyklu; h++) {
            suma_CE = suma_CE + vypocet_vahy (pole_dobrych_parametru[h][8]);
            }
        for (j = 0; j < pocet_parametru; j++) {
            suma_par = 0;
            for (h = 0; h < pocet_cyklu; h++) {
                suma_par = suma_par + (pole_dobrych_parametru[h][j] * vypocet_vahy (pole_dobrych_parametru[h][8]));
                }
            souradnice_teziste[j] = suma_par / suma_CE;
            }
        /*vypocet mezi ktere definuji novy zmenseni parametricky prostor*/
        novy_rozsah_DDF = konstanta_redukce * (rozsah_DDF + dolni_mez_DDF - souradnice_teziste[0] + souradnice_teziste[0] - dolni_mez_DDF);
        nova_dolni_mez_DDF = souradnice_teziste[0] - ((souradnice_teziste[0] - dolni_mez_DDF) * konstanta_redukce);            
        novy_rozsah_MAX1 = konstanta_redukce * (rozsah_MAX1 + dolni_mez_MAX1 - souradnice_teziste[1] + souradnice_teziste[1] - dolni_mez_MAX1);
        nova_dolni_mez_MAX1 = souradnice_teziste[1] - ((souradnice_teziste[1] - dolni_mez_MAX1) * konstanta_redukce);            
        novy_rozsah_MAX2 = konstanta_redukce * (rozsah_MAX2 + dolni_mez_MAX2 - souradnice_teziste[2] + souradnice_teziste[2] - dolni_mez_MAX2);
        nova_dolni_mez_MAX2 = souradnice_teziste[2] - ((souradnice_teziste[2] - dolni_mez_MAX2) * konstanta_redukce);            
        novy_rozsah_K2 = konstanta_redukce * (rozsah_K2 + dolni_mez_K2 - souradnice_teziste[3] + souradnice_teziste[3] - dolni_mez_K2);
        nova_dolni_mez_K2 = souradnice_teziste[3] - ((souradnice_teziste[3] - dolni_mez_K2) * konstanta_redukce);            
        novy_rozsah_MAX3 = konstanta_redukce * (rozsah_MAX3 + dolni_mez_MAX3 - souradnice_teziste[4] + souradnice_teziste[4] - dolni_mez_MAX3);
        nova_dolni_mez_MAX3 = souradnice_teziste[4] - ((souradnice_teziste[4] - dolni_mez_MAX3) * konstanta_redukce);            
        novy_rozsah_K3 = konstanta_redukce * (rozsah_K3 + dolni_mez_K3 - souradnice_teziste[5] + souradnice_teziste[5] - dolni_mez_K3);
        nova_dolni_mez_K3 = souradnice_teziste[5] - ((souradnice_teziste[5] - dolni_mez_K3) * konstanta_redukce);            
        novy_rozsah_X = konstanta_redukce * (rozsah_X + dolni_mez_X - souradnice_teziste[6] + souradnice_teziste[6] - dolni_mez_X);
        nova_dolni_mez_X = souradnice_teziste[6] - ((souradnice_teziste[6] - dolni_mez_X) * konstanta_redukce);            
        novy_rozsah_K = konstanta_redukce * (rozsah_K + dolni_mez_K - souradnice_teziste[7] + souradnice_teziste[7] - dolni_mez_K);
        nova_dolni_mez_K = souradnice_teziste[7] - ((souradnice_teziste[7] - dolni_mez_K) * konstanta_redukce);
        /*beh ARSO - postupne redukce parametrickeho prostoru*/
        for (g = 0; g < pocet_redukci; g++) {
            printf ("\n");
            printf ("prave resim redukci parametrickeho prostoru cislo: %d\n", g + 1);
            printf ("\n");
            for (h = 0; h < pocet_cyklu; h++) {
                printf ("prave pocitam cyklus: %d\n", h + 1);    
                for (i = 0; i < pocet_sad_parametru; i++) {
                    pole_parametru[i][0] = ((double) (rand () % 10000) / 10000) * novy_rozsah_DDF + nova_dolni_mez_DDF;
                    pole_parametru[i][1] = ((double) (rand () % 10000) / 10000) * novy_rozsah_MAX1 + nova_dolni_mez_MAX1;
                    pole_parametru[i][2] = ((double) (rand () % 10000) / 10000) * novy_rozsah_MAX2 + nova_dolni_mez_MAX2;
                    pole_parametru[i][3] = ((double) (rand () % 10000) / 10000) * novy_rozsah_K2 + nova_dolni_mez_K2;
                    pole_parametru[i][4] = ((double) (rand () % 10000) / 10000) * novy_rozsah_MAX3 + nova_dolni_mez_MAX3;
                    pole_parametru[i][5] = ((double) (rand () % 10000) / 10000) * novy_rozsah_K3 + nova_dolni_mez_K3;
                    pole_parametru[i][6] = ((double) (rand () % 10000) / 10000) * novy_rozsah_X + nova_dolni_mez_X;
                    pole_parametru[i][7] = ((double) (rand () % 10000) / 10000) * novy_rozsah_K + nova_dolni_mez_K;
                    pole_parametru[i][8] = 0;
                    pole_parametru[i][9] = 0;
                    }
                if (kontrolni_ukazatel <= 60) {
                    for (i = 0; i < pocet_sad_parametru; i++) {
                        pole_parametru[i][0] = rozsah_DDF + dolni_mez_DDF;
                        }
                    }
                /*testovani vygenerovanych sad parametru*/
                for (i = 0; i < pocet_sad_parametru; i++) {
                    DDF = pole_parametru[i][0];
                    MAX1 = pole_parametru[i][1];
                    MAX2 = pole_parametru[i][2];
                    K2 = pole_parametru[i][3];
                    MAX3 = pole_parametru[i][4];
                    K3 = pole_parametru[i][5];
                    X = pole_parametru[i][6];
                    K = pole_parametru[i][7];
                    SC = SC1 = SC2 = SC3 = 0;
                    for (e = 0; e < pocet_r_kalibrace; e++) {        
                        /*prirazeni vstupnich hodnot*/
                        T_min = T_minimum_kal[e]; T_max = T_maximum_kal[e]; Prep = Pr_kal[e]; PoE = PE_kal[e];                    
                        /*volani funkce model*/
                        model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                                      &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
                        /*ulozeni vypoctenych odtoku do pripravenych poli*/
                        D_prm_kal[e] = NoI; D_sbsr_kal[e] = D_SC2; D_surf_kal[e] = D_Sur; D_base_kal[e] = D_SC3; D_tonetr_kal[e] = D_Totnt;                
                        }
                    /*transformace korytem*/
                    D_tottr_kal[0] = D_tonetr_kal[0];
                    for (e = 1; e < pocet_r_kalibrace; e++) {
                        C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
                        C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
                        C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
                        D_tottr_kal[e] = C0 * D_tonetr_kal[e] + C1 * D_tonetr_kal[e - 1] + C2 * D_tottr_kal[e - 1];
                        }
                    /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
                    suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
                    for (e = 200; e < pocet_r_kalibrace; e++) {
                        suma1 = suma1 + ((D_tottr_kal[e] - D_M_kal[e]) * (D_tottr_kal[e] - D_M_kal[e]));    
                        suma2 = suma2 + D_M_kal[e];
                        suma4 = suma4 + (D_tottr_kal[e] - D_M_kal[e]);
                        }
                    prumer1 = suma2 / (pocet_r_kalibrace - 200);
                    for (e = 200; e < pocet_r_kalibrace; e++) {
                        suma3 = suma3 + ((D_M_kal[e] - prumer1)*(D_M_kal[e] - prumer1));
                        }
                    pole_parametru[i][8] = 1 - (suma1 / suma3);
                    pole_parametru[i][9] = (suma4 / suma2) * 100;    
                    }//konec cyklu pro vsechny generovane parametry v ramci jednoho cyklu
                CE = -100000;
                for (i = 0; i < pocet_sad_parametru; i++) {
                    if (pole_parametru[i][8] > CE) {
                        CE = pole_parametru[i][8];
                        }
                    }
                printf ("%f\n", CE);
                /*ulozeni dobrych parametrickych sad z kazdeho cyklu do pole dobrych sad*/
                for (i = 0; i < pocet_sad_parametru; i++) {
                    if (pole_parametru[i][8] == CE) {
                        for (j = 0; j < (pocet_parametru + 2); j++) {
                            pole_dobrych_parametru[h][j] = pole_parametru[i][j];
                            }
                        }
                    }            
                }//konec cyklu pro pocet cyklu
            /*vypocet souradnic teziste kolem ktereho se bude zmensovat parametricky prostor*/
            suma_CE = 0;
            for (h = 0; h < pocet_cyklu; h++) {
                suma_CE = suma_CE + vypocet_vahy (pole_dobrych_parametru[h][8]);
                }
            for (j = 0; j < pocet_parametru; j++) {
                suma_par = 0;
                for (h = 0; h < pocet_cyklu; h++) {
                    suma_par = suma_par + (pole_dobrych_parametru[h][j] * vypocet_vahy (pole_dobrych_parametru[h][8]));
                    }
                souradnice_teziste[j] = suma_par / suma_CE;
                }
            /*vypocet mezi ktere definuji novy zmenseni parametricky prostor*/
            novy_rozsah_DDF = konstanta_redukce * (novy_rozsah_DDF + nova_dolni_mez_DDF - souradnice_teziste[0] + souradnice_teziste[0] - nova_dolni_mez_DDF);
            nova_dolni_mez_DDF = souradnice_teziste[0] - ((souradnice_teziste[0] - nova_dolni_mez_DDF) * konstanta_redukce);            
            novy_rozsah_MAX1 = konstanta_redukce * (novy_rozsah_MAX1 + nova_dolni_mez_MAX1 - souradnice_teziste[1] + souradnice_teziste[1] - nova_dolni_mez_MAX1);
            nova_dolni_mez_MAX1 = souradnice_teziste[1] - ((souradnice_teziste[1] - nova_dolni_mez_MAX1) * konstanta_redukce);            
            novy_rozsah_MAX2 = konstanta_redukce * (novy_rozsah_MAX2 + nova_dolni_mez_MAX2 - souradnice_teziste[2] + souradnice_teziste[2] - nova_dolni_mez_MAX2);
            nova_dolni_mez_MAX2 = souradnice_teziste[2] - ((souradnice_teziste[2] - nova_dolni_mez_MAX2) * konstanta_redukce);            
            novy_rozsah_K2 = konstanta_redukce * (novy_rozsah_K2 + nova_dolni_mez_K2 - souradnice_teziste[3] + souradnice_teziste[3] - nova_dolni_mez_K2);
            nova_dolni_mez_K2 = souradnice_teziste[3] - ((souradnice_teziste[3] - nova_dolni_mez_K2) * konstanta_redukce);            
            novy_rozsah_MAX3 = konstanta_redukce * (novy_rozsah_MAX3 + nova_dolni_mez_MAX3 - souradnice_teziste[4] + souradnice_teziste[4] - nova_dolni_mez_MAX3);
            nova_dolni_mez_MAX3 = souradnice_teziste[4] - ((souradnice_teziste[4] - nova_dolni_mez_MAX3) * konstanta_redukce);            
            novy_rozsah_K3 = konstanta_redukce * (novy_rozsah_K3 + nova_dolni_mez_K3 - souradnice_teziste[5] + souradnice_teziste[5] - nova_dolni_mez_K3);
            nova_dolni_mez_K3 = souradnice_teziste[5] - ((souradnice_teziste[5] - nova_dolni_mez_K3) * konstanta_redukce);            
            novy_rozsah_X = konstanta_redukce * (novy_rozsah_X + nova_dolni_mez_X - souradnice_teziste[6] + souradnice_teziste[6] - nova_dolni_mez_X);
            nova_dolni_mez_X = souradnice_teziste[6] - ((souradnice_teziste[6] - nova_dolni_mez_X) * konstanta_redukce);            
            novy_rozsah_K = konstanta_redukce * (novy_rozsah_K + nova_dolni_mez_K - souradnice_teziste[7] + souradnice_teziste[7] - nova_dolni_mez_K);
            nova_dolni_mez_K = souradnice_teziste[7] - ((souradnice_teziste[7] - nova_dolni_mez_K) * konstanta_redukce);
            }//konec cyklu pro redukce
        /*overeni vysledku kalibrace*/
        /*ulozeni souradnic teziste do pole celkovych vysledku*/
        for (j = 0; j < pocet_parametru; j++) {
            pole_vysledek[c][j] = souradnice_teziste[j];
            }    
        /*vypocet CE pro souradnice teziste u kalibracni sady*/
        /*definovani parametru*/
        DDF = souradnice_teziste[0];
        MAX1 = souradnice_teziste[1];
        MAX2 = souradnice_teziste[2];
        K2 = souradnice_teziste[3];
        MAX3 = souradnice_teziste[4];
        K3 = souradnice_teziste[5];
        X = souradnice_teziste[6];
        K = souradnice_teziste[7];
        SC = SC1 = SC2 = SC3 = 0;
        for (e = 0; e < pocet_r_kalibrace; e++) {        
            /*prirazeni vstupnich hodnot*/
            T_min = T_minimum_kal[e]; T_max = T_maximum_kal[e]; Prep = Pr_kal[e]; PoE = PE_kal[e];                    
            /*volani funkce model*/
            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                          &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
            /*ulozeni vypoctenych odtoku do pripravenych poli*/
            D_prm_kal[e] = NoI; D_sbsr_kal[e] = D_SC2; D_surf_kal[e] = D_Sur; D_base_kal[e] = D_SC3; D_tonetr_kal[e] = D_Totnt;                
            }
        /*transformace korytem*/
        D_tottr_kal[0] = D_tonetr_kal[0];
        for (e = 1; e < pocet_r_kalibrace; e++) {
            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
            D_tottr_kal[e] = C0 * D_tonetr_kal[e] + C1 * D_tonetr_kal[e - 1] + C2 * D_tottr_kal[e - 1];
            }
        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
        for (e = 200; e < pocet_r_kalibrace; e++) {
            suma1 = suma1 + ((D_tottr_kal[e] - D_M_kal[e]) * (D_tottr_kal[e] - D_M_kal[e]));    
            suma2 = suma2 + D_M_kal[e];
            suma4 = suma4 + (D_tottr_kal[e] - D_M_kal[e]);
            }
        prumer1 = suma2 / (pocet_r_kalibrace - 200);
        for (e = 200; e < pocet_r_kalibrace; e++) {
            suma3 = suma3 + ((D_M_kal[e] - prumer1)*(D_M_kal[e] - prumer1));
            }
        pole_vysledek[c][8] = 1 - (suma1 / suma3);
        pole_vysledek[c][9] = (suma4 / suma2) * 100;
        printf ("\n");
        printf ("kalibracni CE: %f\n", pole_vysledek[c][8]);
        /*nalezeni mezi pro GNU sobor*/         
        max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
        for (e = 0; e < pocet_r_kalibrace; e++) {    
            if (Pr_kal[e] > max_prep) {
                max_prep = Pr_kal[e];
                }
            if (D_M_kal[e] > max_mer_odtok) {
                max_mer_odtok = D_M_kal[e];
                }
            if (D_tottr_kal[e] > max_celk_odtok) {
                max_celk_odtok = D_tottr_kal[e];
                }                                                                             
            }
        if (max_mer_odtok > max_celk_odtok) {
            max_odtok = max_mer_odtok;
            }
        else {
            max_odtok = max_celk_odtok;
            }
        /*tisk hydrogramu*/
        for (d = 0; d < 7; d++) { 
            hydrogram_kal[d + 32] = pole_nazvu_povodi[c][d];
            }
        f = fopen (hydrogram_kal, "w");
        for (e = 0; e < pocet_r_kalibrace; e++) {
            fprintf (f, "%.4f\t %.4f\t %.4f\n", Pr_kal[e], D_M_kal[e], D_tottr_kal[e]);
            }
        fclose (f);
        /*vytvoreni davkoveho souboru pro GNU*/
        for (d = 0; d < 3; d++) { 
            graf_kal[d + 32] = pole_nazvu_povodi[c][d];
            }
        f = fopen (graf_kal, "w");
        fprintf (f, "cd 'C:\\CKSOM1\\output_data\\kalibrace'\n");
        fprintf (f, "set grid\n");
        fprintf (f, "set xlabel 'time step'\n");
        fprintf (f, "set xrange [0:%d]\n", pocet_r_kalibrace);
        fprintf (f, "set xtics %d\n", pocet_r_kalibrace / 10);
        fprintf (f, "set ylabel 'discharge [mm]'\n");
        fprintf (f, "set yrange [0:%.2f]\n", max_odtok / 0.6);
        fprintf (f, "set ytics %.2f\n", (max_odtok / 0.6) / 10);
        fprintf (f, "set y2label 'precipitation [mm]'\n");
        fprintf (f, "set y2range [%.2f:0]\n", max_prep / 0.3);               
        fprintf (f, "set y2tics %.2f\n", (max_prep / 0.3) / 10);
        fprintf (f,"set style fill solid\n");
        fprintf (f,"set key outside below\n");
        fprintf (f, "plot 'C:\\CKSOM1\\output_data\\kalibrace\\hydrogram_%s' u 2 w steps title 'D_{mer}' lt 2\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\kalibrace\\hydrogram_%s' u 3 w steps title 'D_{sim}' lt 1\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\kalibrace\\hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);              
        fprintf (f, "set out 'hydrogram_graf_%s.ps'\n", pole_nazvu_povodi[c]);
        fprintf (f, "set terminal post solid enhanced color\n");
        fprintf (f, "replot\n");
        fprintf (f, "set out\n");
        fprintf (f, "set terminal windows\n");
        fclose(f);
        /*validace modelu*/
        /*nacteni validacni casove rady*/
        for (d = 0; d < 7; d++) {
            vstup_data_validace[d + 20] = pole_nazvu_povodi[c][d];
            }
        f = fopen (vstup_data_validace, "r");
        printf ("\n");
        printf ("prave pocitam validaci souboru: %s\n", pole_nazvu_povodi[c]);
        printf ("\n");
            if (f == NULL) {
            printf ("soubor nenalezen\n");
            system ("PAUSE");  
            return 1;
            }    
        pocet_r_validace = pocet_radku(f);    
        fclose(f);
        /*alokace poli vstupnich promennych*/
        if ((Pr_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((PE_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_M_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_minimum_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((T_maximum_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*nacteni vstupnich dat do pripravenych poli*/
        f = fopen (vstup_data_validace, "r");
        for (e = 0; e < pocet_r_validace; e++) {
            fscanf (f, "%lf %lf %lf %lf %lf", &Pr_val[e], &PE_val[e], &D_M_val[e], &T_maximum_val[e], &T_minimum_val[e]);
            }
        fclose(f);
        /*kontrola vstupnich dat*/
        /*kontrola teplot*/
        for (e = 0; e < pocet_r_validace; e++) {
            if (T_maximum_val[e] < T_minimum_val[e]) {
                chyba1 = T_maximum_val[e];
                chyba2 = T_minimum_val[e];
                T_minimum_val[e] = chyba1;
                T_maximum_val[e] = chyba2;
                }
            }
        /*kontrola srazek*/
        for (e = 0; e < pocet_r_validace; e++) {
            if (Pr_val[e] == -99.00) {
                Pr_val[e] = 0;
                }
            }
        /*alokace poli pomocnych promennych*/    
        if ((D_prm_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_sbsr_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_surf_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_base_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }    
        if ((D_tonetr_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        if ((D_tottr_val = ((double*) malloc(pocet_r_validace * sizeof(double)))) == NULL) {
            printf("chyba pri alokaci pameti\n");
            return 1;
            }
        /*definovani parametru*/
        DDF = souradnice_teziste[0];
        MAX1 = souradnice_teziste[1];
        MAX2 = souradnice_teziste[2];
        K2 = souradnice_teziste[3];
        MAX3 = souradnice_teziste[4];
        K3 = souradnice_teziste[5];
        X = souradnice_teziste[6];
        K = souradnice_teziste[7];
        SC = SC1 = SC2 = SC3 = 0;
        for (e = 0; e < pocet_r_validace; e++) {        
        /*prirazeni vstupnich hodnot*/
            T_min = T_minimum_val[e]; T_max = T_maximum_val[e]; Prep = Pr_val[e]; PoE = PE_val[e];                    
            /*volani funkce model*/
            model(&T_min, &T_max, &Prep, &SC, &DDF, &NoI, &SC1, &PoE, &MAX1, &D_SC1, &SC2, 
                          &MAX2, &K2, &D_SC2, &D_Sur, &SC3, &MAX3, &K3, &D_SC3, &D_Totnt);
            /*ulozeni vypoctenych odtoku do pripravenych poli*/
            D_prm_val[e] = NoI; D_sbsr_val[e] = D_SC2; D_surf_val[e] = D_Sur; D_base_val[e] = D_SC3; D_tonetr_val[e] = D_Totnt;                
            }
        /*transformace korytem*/
        D_tottr_val[0] = D_tonetr_val[0];
        for (e = 1; e < pocet_r_validace; e++) {
            C0 = ((24 / K) - (2 * X)) / (2 * (1 - X) + (24 / K));
            C1 = ((24 / K) + (2 * X)) / (2 * (1 - X) + (24 / K));
            C2 = (2 * (1 - X) - (24 / K)) / (2 * (1 - X) + (24 / K));
            D_tottr_val[e] = C0 * D_tonetr_val[e] + C1 * D_tonetr_val[e - 1] + C2 * D_tottr_val[e - 1];
            }
        /*vypocet koeficientu determinace + ETV a jejich ulozeni do pole s parametry modelu*/
        suma1 = suma2 = suma3 = suma4 = prumer1 = 0;
        for (e = 200; e < pocet_r_validace; e++) {
            suma1 = suma1 + ((D_tottr_val[e] - D_M_val[e]) * (D_tottr_val[e] - D_M_val[e]));    
            suma2 = suma2 + D_M_val[e];
            suma4 = suma4 + (D_tottr_val[e] - D_M_val[e]);
            }
        prumer1 = suma2 / (pocet_r_validace - 200);
        for (e = 200; e < pocet_r_validace; e++) {
            suma3 = suma3 + ((D_M_val[e] - prumer1)*(D_M_val[e] - prumer1));
            }
        pole_vysledek[c][10] = 1 - (suma1 / suma3);
        pole_vysledek[c][11] = (suma4 / suma2) * 100;
        printf ("validacni CE: %f\n", pole_vysledek[c][10]);
        /*nalezeni mezi pro GNU sobor*/         
        max_prep = max_mer_odtok = max_celk_odtok = max_odtok = 0;
        for (e = 0; e < pocet_r_validace; e++) {    
            if (Pr_val[e] > max_prep) {
                max_prep = Pr_val[e];
                }
            if (D_M_val[e] > max_mer_odtok) {
                max_mer_odtok = D_M_val[e];
                }
            if (D_tottr_val[e] > max_celk_odtok) {
                max_celk_odtok = D_tottr_val[e];
                }                                                                             
            }
        if (max_mer_odtok > max_celk_odtok) {
            max_odtok = max_mer_odtok;
            }
        else {
            max_odtok = max_celk_odtok;
            }
        /*tisk hydrogramu*/
        for (d = 0; d < 7; d++) { 
            hydrogram_val[d + 31] = pole_nazvu_povodi[c][d];
            }
        f = fopen (hydrogram_val, "w");
        for (e = 0; e < pocet_r_validace; e++) {
            fprintf (f, "%.4f\t %.4f\t %.4f\n", Pr_val[e], D_M_val[e], D_tottr_val[e]);
            }
        fclose (f);
        /*vytvoreni davkoveho souboru pro GNU*/
        for (d = 0; d < 3; d++) { 
            graf_val[d + 31] = pole_nazvu_povodi[c][d];
            }
        f = fopen (graf_val, "w");
        fprintf (f, "cd 'C:\\CKSOM1\\output_data\\validace'\n");
        fprintf (f, "set grid\n");
        fprintf (f, "set xlabel 'time step'\n");
        fprintf (f, "set xrange [0:%d]\n", pocet_r_validace);
        fprintf (f, "set xtics %d\n", pocet_r_validace / 10);
        fprintf (f, "set ylabel 'discharge [mm]'\n");
        fprintf (f, "set yrange [0:%.2f]\n", max_odtok / 0.6);
        fprintf (f, "set ytics %.2f\n", (max_odtok / 0.6) / 10);
        fprintf (f, "set y2label 'precipitation [mm]'\n");
        fprintf (f, "set y2range [%.2f:0]\n", max_prep / 0.3);               
        fprintf (f, "set y2tics %.2f\n", (max_prep / 0.3) / 10);
        fprintf (f,"set style fill solid\n");
        fprintf (f,"set key outside below\n");
        fprintf (f, "plot 'C:\\CKSOM1\\output_data\\validace\\hydrogram_%s' u 2 w steps title 'D_{mer}' lt 2\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\validace\\hydrogram_%s' u 3 w steps title 'D_{sim}' lt 1\n", pole_nazvu_povodi[c]);
        fprintf (f, "replot 'C:\\CKSOM1\\output_data\\validace\\hydrogram_%s' u 1 axis x2y2 w boxes title 'Prep' lt 3\n", pole_nazvu_povodi[c]);              
        fprintf (f, "set out 'hydrogram_graf_%s.ps'\n", pole_nazvu_povodi[c]);
        fprintf (f, "set terminal post solid enhanced color\n");
        fprintf (f, "replot\n");
        fprintf (f, "set out\n");
        fprintf (f, "set terminal windows\n");
        fclose(f);        
        }
    f = fopen ("output_data/validace/celkove_vysledky.txt","w");
    for (c = 0; c < pocet_souboru; c++) {
        fprintf (f, "%s\t", pole_nazvu_povodi[c]);
        for (j = 0; j < (pocet_parametru + 4); j++) {
            fprintf (f, "%f\t", pole_vysledek[c][j]);
            }
        fprintf (f, "\n");
        }
    fclose (f);
    f = fopen ("input_data/sens_anl/sens_anl.txt","w");
    for (c = 0; c < pocet_souboru; c++) {
        for (j = 0; j < (pocet_parametru + 2); j++) {
            fprintf (f, "%f\t", pole_vysledek[c][j]);
            }
        fprintf (f, "\n");
        }
    fclose (f);    
    system ("PAUSE");
    return 0;
}
