import numpy
import arcpy
import math
from operator import itemgetter

input_osaSHP = arcpy.GetParameterAsText(0)
output_file = arcpy.GetParameterAsText(1)
path = arcpy.GetParameterAsText(2)
PF_interval = arcpy.GetParameterAsText(3)
PF_delka = arcpy.GetParameterAsText(4)

PF_interval = float(PF_interval)
PF_delka = float(PF_delka)
outSHPlines = "CroSolver_Station_Lines_2D.shp"

#input_osaSHP = "GIS\\SHP\\Osa_Ploucnice_polyline.shp"
#output_file = "PF_2D.txt"
#PF_interval = 50
#PF_delka = 40

def open_osaSHP(inFC):
    List_Osa = []
    # Identify the geometry field
    desc = arcpy.Describe(inFC)
    shapefieldname = desc.ShapeFieldName
    # Create search cursor
    inrows = arcpy.SearchCursor(inFC)

    # Enter for loop for each feature/row
    for row in inrows:
        # Create the geometry object
        feat = row.getValue(desc.shapeFieldName)
        partnum = 0       
        # Step through each part of the feature
        for part in feat:
            # Step through each vertex in the feature
            for pnt in feat.getPart(partnum):
                # Print x,y coordinates of current point
                List_Osa.append((pnt.X,pnt.Y))
            del pnt
            partnum += 1
    return List_Osa

def osa_staniceni(List_Osa):
    List_staniceni = []
    for i in range(len(List_Osa)):
        if i==0:
            staniceni = 0
        else:
            staniceni = staniceni + numpy.sqrt((List_Osa[i][0]-List_Osa[i-1][0])**2+(List_Osa[i][1]-List_Osa[i-1][1])**2)   
        List_staniceni.append(staniceni)    
    return List_staniceni 

def parametry_osy(List_Osa):
    List_parametry_osy = []
    for i in range(len(List_Osa)):
        # y=m.x+b, m=(Yr-Yl)/(Xr-Xl), b=Yr-m.Xr
        if i==0:
            uhel = math.atan2((List_Osa[i][1]-List_Osa[i+1][1]),(List_Osa[i][0]-List_Osa[i+1][0]))
        else:
            uhel = math.atan2((List_Osa[i-1][1]-List_Osa[i][1]),(List_Osa[i-1][0]-List_Osa[i][0]))
        List_parametry_osy.append(uhel)    
    return List_parametry_osy

def station_midPoints(List_staniceni, PF_interval):
    List_staniceni_interval = []
    staniceni_interval = 0
    while staniceni_interval < List_staniceni[len(List_staniceni)-1]:
        List_staniceni_interval.append(staniceni_interval)
        staniceni_interval = staniceni_interval + PF_interval
    return List_staniceni_interval

def midPoints_XYma(List_station_midPoints, List_Osa, List_staniceni, parametry_osy):
    X = map(itemgetter(0),List_Osa)
    Y = map(itemgetter(1),List_Osa)
    uhel = parametry_osy
    midpoint_X = numpy.interp(List_station_midPoints,List_staniceni,X)
    midpoint_Y = numpy.interp(List_station_midPoints,List_staniceni,Y)
    midpoint_uhel = numpy.interp(List_station_midPoints,List_staniceni,uhel)
    List_midPoints_XYuhel = zip(midpoint_X, midpoint_Y, midpoint_uhel)
    return List_midPoints_XYuhel
                            
def PF_XY(List_midPoints_XYma, PF_delka):
    List_PF_XY = []
    for i in range(len(List_midPoints_XYma)):
        midpoint_X = List_midPoints_XYma[i][0]
        midpoint_Y = List_midPoints_XYma[i][1]
        uhel = List_midPoints_XYma[i][2]
        d = PF_delka/2
        Xr = midpoint_X - (math.cos(uhel+math.pi/2))*d
        Yr = midpoint_Y - (math.sin(uhel+math.pi/2))*d
        Xl = midpoint_X + (math.cos(uhel+math.pi/2))*d
        Yl = midpoint_Y + (math.sin(uhel+math.pi/2))*d        
        List_PF_XY.append((Xr, Yr, Xl, Yl))
    return List_PF_XY

def save_output(List_PF_XY, output_file):
    fwrite = open(output_file,"w")
    hlavicka_sloupcu = "Xr\tYr\tXl\tYl"
    fwrite.writelines(hlavicka_sloupcu + "\n")
    for i in range(len(List_PF_XY)):
        fwrite.writelines(str(List_PF_XY[i][0])+"\t"+str(List_PF_XY[i][1])+"\t"+str(List_PF_XY[i][2])+"\t"+
                          str(List_PF_XY[i][3])+"\n")
    #zavreni otevrenych souboru
    fwrite.close()  

def Lines(input_TXT, path, outSHPlines):
    arcpy.CreateFeatureclass_management(path,outSHPlines,"POLYLINE")
    arcpy.env.workspace = path
    arcpy.AddField_management(outSHPlines, "st", "DOUBLE", "", "", "", "", "", "")
    fread = open(input_TXT,"r")
    lines = fread.readlines()[1:]
    cur = arcpy.InsertCursor(path+"\\"+outSHPlines)   
    pnt = arcpy.Point()
    array = arcpy.Array()

    n = 0
    # PF
    for line in lines:
        st = n*PF_interval
        pnt.X = float(line.split()[2])
        pnt.Y = float(line.split()[3])
        array.add(pnt)
        pnt.X = float(line.split()[0])
        pnt.Y = float(line.split()[1])
        array.add(pnt)
      
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Polyline(array))
        feat.setValue("st",st)
        cur.insertRow(feat)
        array.removeAll()
        n += 1

    cur.updateRow
    fread.close()

List_Osa = open_osaSHP(input_osaSHP)
List_staniceni = osa_staniceni(List_Osa)
List_station_midPoints = station_midPoints(List_staniceni, PF_interval)
List_parametry_osy = parametry_osy(List_Osa)
List_midPoints_XYma = midPoints_XYma(List_station_midPoints, List_Osa, List_staniceni, List_parametry_osy)
List_PF_XY = PF_XY(List_midPoints_XYma, PF_delka)

save_output(List_PF_XY, output_file)
Lines(output_file, path, outSHPlines)

print "hotovo"



