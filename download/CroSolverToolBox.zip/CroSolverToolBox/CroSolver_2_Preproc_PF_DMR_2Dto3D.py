import arcpy
import numpy
import os
import string
import fileinput
import arcpy
from arcpy import env

input_TYP_vstupu = arcpy.GetParameterAsText(0)
input_PF = arcpy.GetParameterAsText(1)
input_PF_SHP = arcpy.GetParameterAsText(2)
input_TYP_DMR = arcpy.GetParameterAsText(3)
input_DMR = arcpy.GetParameterAsText(4)
input_DMR_RB = arcpy.GetParameterAsText(5)
input_DMR_LB = arcpy.GetParameterAsText(6)
output_file = arcpy.GetParameterAsText(7)
search_radius = arcpy.GetParameterAsText(8)

search_radius = float(search_radius)


if input_TYP_vstupu == "SHP":
    input_PF = input_PF_SHP[:-4]+".txt"
    
    def open_osaSHP(inFC):
        List_PF = []
        # Identify the geometry field
        desc = arcpy.Describe(inFC)
        shapefieldname = desc.ShapeFieldName
        # Create search cursor
        inrows = arcpy.SearchCursor(inFC)
    
        # Enter for loop for each feature/row
        for row in inrows:
            # Create the geometry object
            feat = row.getValue(desc.shapeFieldName)
            List_PF.append((feat.lastPoint.X,feat.lastPoint.Y, feat.firstPoint.X, feat.firstPoint.Y))
        return List_PF
    
    def save_output(List_PF_XY, outTXT):
        fwrite = open(outTXT,"w")
        hlavicka_sloupcu = "Xr\tYr\tXl\tYl"
        fwrite.writelines(hlavicka_sloupcu + "\n")
        for i in range(len(List_PF_XY)):
            fwrite.writelines(str(List_PF_XY[i][0])+"\t"+str(List_PF_XY[i][1])+"\t"+str(List_PF_XY[i][2])+"\t"+
                              str(List_PF_XY[i][3])+"\n")
        #zavreni otevrenych souboru
        fwrite.close()  
    
    List_PF_XY = open_osaSHP(input_PF_SHP)
    save_output(List_PF_XY, input_PF)
    

def open_input_PF(input_PF):
    fread = open(input_PF,"r")
    lines = fread.readlines()[1:]
    # Listy vstupnich a vystupnich dat
    List_PF = []
    for line_array in lines:
        Xr = float(line_array.split()[0])
        Yr = float(line_array.split()[1]) 
        Xl = float(line_array.split()[2])
        Yl = float(line_array.split()[3])
        List_PF.append((Xr,Yr,Xl,Yl))
    fread.close()
    return List_PF
    
def open_input_DMR(input_DMR):
    fread = open(input_DMR,"r")
    lines = fread.readlines()
    # Listy vstupnich a vystupnich dat
    List_DMR = []
    for line_array in lines:           
        X = float(line_array.split()[0])
        Y = float(line_array.split()[1]) 
        Z = float(line_array.split()[2])
        List_DMR.append((X,Y,Z))
    fread.close()
    return List_DMR

def open_input_DMR_RB(input_DMR):
    fread = open(input_DMR_RB,"r")
    lines = fread.readlines()
    # Listy vstupnich a vystupnich dat
    List_DMR = []
    for line_array in lines:           
        X = float(line_array.split()[0])
        Y = float(line_array.split()[1]) 
        Z = float(line_array.split()[2])
        List_DMR.append((X,Y,Z))
    fread.close()
    return List_DMR

def open_input_DMR_LB(input_DMR):
    fread = open(input_DMR_LB,"r")
    lines = fread.readlines()
    # Listy vstupnich a vystupnich dat
    List_DMR = []
    for line_array in lines:           
        X = float(line_array.split()[0])
        Y = float(line_array.split()[1]) 
        Z = float(line_array.split()[2])
        List_DMR.append((X,Y,Z))
    fread.close()
    return List_DMR
    
def search_points_in_circle_celek(List_PF, List_DMR, search_radius):
    List_minPoint = []
    # Levy breh        
    n = 0
    for n in range(len(List_PF)):
        print str(n) + " from " + str(len(List_PF))
        arcpy.AddMessage(str(n) + " from " + str(len(List_PF)))
        XminR = List_PF[n][0]
        YminR = List_PF[n][1]
        XminL = List_PF[n][2]
        YminL = List_PF[n][3]
        ZminR=ZminL=9999
        for i in List_DMR:            
            DistanceR = numpy.sqrt((i[0]-List_PF[n][0])**2+(i[1]-List_PF[n][1])**2)
            DistanceL = numpy.sqrt((i[0]-List_PF[n][2])**2+(i[1]-List_PF[n][3])**2)
            if DistanceR < search_radius:
                if i[2] < ZminR:
                    XminR = i[0]
                    YminR = i[1]
                    ZminR = i[2]                    
            if DistanceL < search_radius:
                if i[2] < ZminL:
                    XminL = i[0]
                    YminL = i[1]
                    ZminL = i[2]        
        List_minPoint.append((XminR, YminR, ZminR, XminL, YminL, ZminL))
    return List_minPoint

def search_points_in_circle_dle_brehu(List_PF, List_DMR_RB, List_DMR_LB, search_radius):
    List_minPoint = []
    # Levy breh        
    n = 0
    for n in range(len(List_PF)):
        print str(n) + " from " + str(len(List_PF))
        XminR = List_PF[n][0]
        YminR = List_PF[n][1]
        XminL = List_PF[n][2]
        YminL = List_PF[n][3]
        ZminR=ZminL=9999
        for i in List_DMR_RB:            
            DistanceR = numpy.sqrt((i[0]-List_PF[n][0])**2+(i[1]-List_PF[n][1])**2)
            if DistanceR < search_radius:
                if i[2] < ZminR:
                    XminR = i[0]
                    YminR = i[1]
                    ZminR = i[2]
        for i in List_DMR_LB:            
            DistanceL = numpy.sqrt((i[0]-List_PF[n][2])**2+(i[1]-List_PF[n][3])**2)
            if DistanceL < search_radius:
                if i[2] < ZminL:
                    XminL = i[0]
                    YminL = i[1]
                    ZminL = i[2]
        List_minPoint.append((XminR, YminR, ZminR, XminL, YminL, ZminL))
    return List_minPoint
           
def kolme_souradnice(List_PF, List_minPoint):
    List_kolme_souradnice = []
    n = 0
    for n in range(len(List_PF)):
        # y=m.x+b, m=(Yz-Yl)/(Xr-Xl), b=Yr-m.Xr
        # zajisteni deleni nulou
        if (List_PF[n][0]-List_PF[n][2]) == 0:
            m = 0
        else:
            m = (List_PF[n][1]-List_PF[n][3])/(List_PF[n][0]-List_PF[n][2])
        b = List_PF[n][1]-m*List_PF[n][0]
        #X0=(m.y+x-m.b)/(m**2+1), y0=(m**2.y+m.x+b)/(m**2+1)
        Xr0 = (m*List_minPoint[n][1]+List_minPoint[n][0]-m*b)/(m**2+1)
        Yr0 = (m**2*List_minPoint[n][1]+m*List_minPoint[n][0]+b)/(m**2+1)
        Zr0 = List_minPoint[n][2]
        Xl0 = (m*List_minPoint[n][4]+List_minPoint[n][3]-m*b)/(m**2+1)
        Yl0 = (m**2*List_minPoint[n][4]+m*List_minPoint[n][3]+b)/(m**2+1)
        Zl0 = List_minPoint[n][5]
        List_kolme_souradnice.append((Xr0, Yr0, Zr0, Xl0, Yl0, Zl0, m, b))
    return List_kolme_souradnice
    
def save_output(List_PF, List_kolme_souradnice, output_file):
    fwrite = open(output_file,"w")
    hlavicka_sloupcu = "Xr\tYr\tZr\tXl\tYl\tZl"
    fwrite.writelines(hlavicka_sloupcu + "\n")
    n = 0
    for n in range(len(List_PF)):
        fwrite.writelines(str(List_kolme_souradnice[n][0])+"\t"+str(List_kolme_souradnice[n][1])+"\t"+str(List_kolme_souradnice[n][2])+"\t"+
                          str(List_kolme_souradnice[n][3])+"\t"+str(List_kolme_souradnice[n][4])+"\t"+str(List_kolme_souradnice[n][5])+"\n")
    #zavreni otevrenych souboru
    fwrite.close()        
                
List_PF = open_input_PF(input_PF)
if input_TYP_DMR == "DMR_celek":
    List_DMR = open_input_DMR(input_DMR)
    List_minPoint = search_points_in_circle_celek(List_PF, List_DMR, search_radius)
if input_TYP_DMR == "DMR_dle_brehu":
    List_DMR_RB = open_input_DMR_RB(input_DMR_RB)
    List_DMR_LB = open_input_DMR_LB(input_DMR_LB)
    List_minPoint = search_points_in_circle_dle_brehu(List_PF, List_DMR_RB, List_DMR_LB, search_radius)
    

List_kolme_souradnice = kolme_souradnice(List_PF, List_minPoint)

save_output(List_PF, List_kolme_souradnice, output_file)
print "hotovo"
