import numpy
import math

# Input txt file, hlavicka Xr,YrZr,Xl,Yl,Zl
inputTXT = arcpy.GetParameterAsText(0)
output = arcpy.GetParameterAsText(1)
path = arcpy.GetParameterAsText(2)
metoda_vypoctu = arcpy.GetParameterAsText(3)
Q = arcpy.GetParameterAsText(4)
n = arcpy.GetParameterAsText(5)
ss = arcpy.GetParameterAsText(6)
min_distance = arcpy.GetParameterAsText(7)

# prevod vstupnich hodnot na cislo
Q = float(Q)
n = float(n)
ss = float(ss)
min_distance = float(min_distance)
outSHPpoints = "CroSolver_Points_3D.shp"
outSHPlines = "CroSolver_Lines_3D.shp"
outSHPPolygon = "CroSolver_Polygon_3D.shp"

# otevreni vstupniho souboru ke cteni a vytvoreni z obsahu list sparametry
def open_input(inputTXT):
    # body museji jit proti toku
    fread = open(inputTXT,"r")
    # cteni radku mimo prvniho, kde je hlavicka
    lines = fread.readlines()[1:]
    # Predesly radek pro vypocet delky osy a sklonu
    prevLine = ""
    staniceni = 0
    # Vytvoreni praydneho listu vstunich dat
    List_CS = []
    # listovani radku
    for line_array in lines:
        # prevod radku na jednotlive nezname do formatu desetinneho cisla
        Xr = float(line_array.split()[0])
        Yr = float(line_array.split()[1]) 
        Zr = float(line_array.split()[2])
        Xl = float(line_array.split()[3])
        Yl = float(line_array.split()[4])
        Zl = float(line_array.split()[5])
        
        # vypocet sirky profilu
        B = CrossSection_Length(Xr,Yr,Xl,Yl)
        # vypocet bodu v ose profilu
        CrosSection_MidPoint = CrossSection_MidPoint(Xr,Yr,Xl,Yl,Zr,Zl)
        # osova vzdalenost jednotlivych pricnych profilu
        AxisDistance = CrossSection_MidPoint_Dist(CrosSection_MidPoint,prevLine)
        # staniceni profilu proti proudu
        staniceni = staniceni + AxisDistance
        # zapsani do listu vypoctenych hodnot        
        List_CS.append((Xr, Yr, Zr, Xl, Yl, Zl, B, CrosSection_MidPoint[0],CrosSection_MidPoint[1],CrosSection_MidPoint[2], AxisDistance, staniceni,Xr, Yr, Zr, Xl, Yl, Zl))
        # nastavi hodnotu bredchazejiciho bodu osy pro vypocet vzdalnosti profilu a staniceni
        prevLine = CrosSection_MidPoint
    # Vypocet hladiny tak, aby stale klesala 
    List_Altitude = Altitude(List_CS)
    if metoda_vypoctu == "dle_sklonu":
        # Vypocet novych souradnic brehovek dle sklonu
        List_CS = Brehovky_dle_sklonu(List_CS, List_Altitude, ss)            
    # Vypocet sklonu hladiny
    List_Slope = Slope(List_CS, List_Altitude)
    # Vypocet hloubky vody
    List_h = CompDepth(List_CS,Slope(List_CS, List_Altitude),ss,n,Q)
    # Vypocet urovne dna a souradnic pat svahu
    List_BadPoints = BedPoints(List_CS, List_h,List_Altitude)
    # ulozeni vsech dat do txt
    save_output(output, List_CS, List_Slope, List_h, List_BadPoints,List_Altitude)

# definice funkce ulozeni vsech dat do txt
def save_output(output, List_CS, List_Slope, List_h, List_BadPoints,List_Altitude):
    # otevreni vystupniho souboru pro zapisovani
    fwrite = open(output,"w")
    # definice a zapsani hlaviky sloupcu do vystupniho txt, deleni tabelatory
    hlavicka_sloupcu = "Xr\tYr\tZr\tXl\tYl\tZl\tB\tXmp\tYmp\tZmp\tCS_dist\tst\tslope\th\tss\tb\tXrBed\tYrBed\tZrBed\tXlBed\tYlBed\tZlBed\tZaltitude\tXr_input\tYr_input\tZr_input\tXl_input\tYl_input\tZl_input"
    fwrite.writelines(hlavicka_sloupcu + "\n")
    # listovani a zapisovani vsech parametru profilu
    n = 0
    for n in range(len(List_CS)):
        fwrite.writelines(str(List_CS[n][0])+"\t"+str(List_CS[n][1])+"\t"+str(List_Altitude[n])+"\t"+str(List_CS[n][3])+"\t"+str(List_CS[n][4])+
                          "\t"+str(List_Altitude[n])+"\t"+str(List_CS[n][6])+"\t"+str(List_CS[n][7])+"\t"+str(List_CS[n][8])+"\t"+str(List_CS[n][9])+"\t"+
                          str(List_CS[n][10])+"\t"+str(List_CS[n][11])+"\t"+str(List_Slope[n])+"\t"+str(List_h[n][0])+"\t"+str(List_h[n][1])+"\t"+
                          str(List_h[n][2])+"\t"+str(List_BadPoints[n][0])+"\t"+str(List_BadPoints[n][1])+"\t"+str(List_BadPoints[n][4])+
                          "\t"+str(List_BadPoints[n][2])+"\t"+str(List_BadPoints[n][3])+"\t"+str(List_BadPoints[n][4])+"\t"+str(List_Altitude[n])+
                          "\t"+str(List_CS[n][12])+
                          "\t"+str(List_CS[n][13])+"\t"+str(List_CS[n][14])+"\t"+str(List_CS[n][15])+"\t"+str(List_CS[n][16])+"\t"+str(List_CS[n][17])+"\n")
    #zavreni otevrenych souboru
    fwrite.close()

    
# definice funkce vypoctu urevne dna a souradnic pat svahu
def BedPoints(List_CS, List_h, List_Altitude):
    # Vytvoreni prazdneho listu
    List_BadPoints = []
    # listovani profily
    n = 0
    for n in range(len(List_CS)):
        # Vzpocet urovne dna koryta odectenim hladiny a hloubky proudeni
        ZBad = List_Altitude[n]-List_h[n][0]
        B = List_CS[n][6]
        b = List_h[n][2] 
        Xmp = List_CS[n][7]
        Ymp = List_CS[n][8]
        Xr = List_CS[n][0]
        Yr = List_CS[n][1]
        Xl = List_CS[n][3]
        Yl = List_CS[n][4]
        # Vypocet souradnic pat svahu
        XrBed = (Xr-Xmp)/(B/2)*(b/2) + Xmp
        YrBed = (Yr-Ymp)/(B/2)*(b/2) + Ymp
        XlBed = (Xl-Xmp)/(B/2)*(b/2) + Xmp
        YlBed = (Yl-Ymp)/(B/2)*(b/2) + Ymp
        # Pripsani do listu
        List_BadPoints.append((XrBed, YrBed, XlBed, YlBed, ZBad)) 
    return List_BadPoints
    
# definice funkce vypoctu podelneho sklonu    
def Slope(List_CS, List_Altitude):
    ListSlope = []
    n = 0
    # Vypocer sklonu, prvni profil ma stejny sklon, jako druhy
    for n in range(len(List_CS)):
        if n == 0:
            ListSlope.append((List_Altitude[n+1] - List_Altitude[n])/List_CS[n+1][10])
        else:
            ListSlope.append((List_Altitude[n] - List_Altitude[n-1])/List_CS[n][10])
    
    #V pripade nuloveno sklonu se zameni za minimalni sklon
    for n,i in enumerate(ListSlope):
        if i==0:
            ListSlope[n] = min(x for x in ListSlope if  x > 0)
    return ListSlope

# definice funkce pro Vypocet hladiny tak, aby stale klesala  
def Altitude(List_CS):
    # prevraceni listu s profily tak, aby profily sly po proudu
    rev_List_CS = list(List_CS)    
    rev_List_CS.reverse()
    ZmpMin = ""
    # Vytvoreni prazdnych listu
    List_Altitude_H = []
    List_Altitude_st = []
    List_Staniceni = []
    # listy pro filtrovani minimalnich hodnot hladiny dle minimalni vzdalenosti
    List_Altitude_H_minDist = []
    List_Altitude_st_minDist = []
    
    # listovani jednotlivymi profily
    for rev_line_array in rev_List_CS:
        # uroven nizsiho brehu z praveho a leveho
        Zmp = rev_line_array[9]
        staniceni = rev_line_array[11]
        List_Staniceni.append(staniceni)
        # podminka klesani hladiny v nasledujicich profilech
        if Zmp < ZmpMin:
            # zapsani na listy hodnoty klesajici pro hladinu a staniceni
            List_Altitude_H.append(Zmp)
            List_Altitude_st.append(staniceni)
            ZmpMin = Zmp
    #otoceni, aby krivka stoupala proti staniceni pro spusteni funkce interpolace a totoznosti s prifly
    List_Altitude_H.reverse()
    List_Altitude_st.reverse()
    List_Staniceni.reverse()

    # vytvoreni listu, ve kterem se ignoruji hodnoty bliz u sebe, nez povoluje minimalni vzdalenost; prvni a posledni hodnota zustava
    last_st = List_Altitude_st[0]
    for i in range(len(List_Altitude_st)): 

        if i == 0:
            List_Altitude_H_minDist.append(List_Altitude_H[i])
            List_Altitude_st_minDist.append(List_Altitude_st[i])
        elif i == (len(List_Altitude_H)-1):
            List_Altitude_H_minDist.append(List_Altitude_H[i])
            List_Altitude_st_minDist.append(List_Altitude_st[i])
        else: 
            if (List_Altitude_st[i] - last_st) > min_distance:                 
                List_Altitude_H_minDist.append(List_Altitude_H[i])
                List_Altitude_st_minDist.append(List_Altitude_st[i])   
                last_st = List_Altitude_st[i]
            
    # interpolace urovni hladin pro vsechny resene profily
    #List_Altitude = numpy.interp(List_Staniceni,List_Altitude_st,List_Altitude_H) 
    List_Altitude = numpy.interp(List_Staniceni,List_Altitude_st_minDist,List_Altitude_H_minDist)
    return List_Altitude

# Definice funkce pro vypocet delky profilu meyi brehy    
def CrossSection_Length(Xr,Yr,Xl,Yl):
    B = math.sqrt((Xr-Xl)**2+(Yr-Yl)**2)
    return B

# Definice funkce pro Vypocet bodu ve stredu profilu a minimalni urovne brehu
def CrossSection_MidPoint(Xr,Yr,Xl,Yl,Zr,Zl):
    Xmp = (Xr+Xl)/2
    Ymp = (Yr+Yl)/2
    Zmp = min(Zr,Zl)
    return Xmp, Ymp, Zmp

# Definice funkce vypoctu vydalenosti profilu, vzdy ke spodnimu
def CrossSection_MidPoint_Dist(CrosSection_MidPoint,prevLine):
    # Podminka pro prvni profil, ktery ma nulovou vydalenost
    try:
        AxisDistance = math.sqrt((CrosSection_MidPoint[0] - prevLine[0])**2+(CrosSection_MidPoint[1]-prevLine[1])**2)
    except:
        AxisDistance = 0
    return AxisDistance
    
# Definice funkce vypoctu prutoku Chezyho rovnici 
def QCompTrapezoid(B,i,h,ssComp,n_manning):
    # v pripade zaporne sirky ve dne se zdvojnasobi sklon vytvorenim erroru, ktery funkce try identifikuje
    a = h/ssComp
    b = B - 2*a
    if b < 0:
        b=b/0
    O = b + 2*math.sqrt(a**2+h**2)
    S = b*h + a*h
    R = S/O
    C = R**(float(1)/float(6))/n_manning
    Q = S*C*math.sqrt(R*i)
    return Q, ssComp, b

# Vypocet hloubky v profilu pro pozadovany prutok, drsnost a geometrii
def CompDepth(List_CS,List_Slope,ss,n_manning,Q):
    n = 0
    List_h = []
    # listovani profily
    for n in range(len(List_CS)):
        B = List_CS[n][6]
        i = List_Slope[n]
        # definice pocatecnich hodnot, dh-krok vypoctu prutoku, h-hloubka, QComp-vypocitany prutok
        dh = 0.01
        h = 0
        QComp = 0
        ssComp = ss
        #v pripade zaporne sirky se zdvojnasobi sklon svahu a v nejhorsim pripade se sklon da roven 1000:1
        try:
            dh = 0.01
            h = 0
            QComp = 0
            while (QComp<Q):
                h=h+dh
                QComp = QCompTrapezoid(B,i,h,ssComp,n_manning)[0]
                ssComp = QCompTrapezoid(B,i,h,ss,n_manning)[1]
                b = QCompTrapezoid(B,i,h,ssComp,n_manning)[2] 
        except:
            try:
                dh = 0.01
                h = 0
                ssComp = 2*ss
                QComp = 0
                while (QComp<Q):
                    h=h+dh
                    QComp = QCompTrapezoid(B,i,h,ssComp,n_manning)[0]
                    ssComp = QCompTrapezoid(B,i,h,ssComp,n_manning)[1]
                    b = QCompTrapezoid(B,i,h,ssComp,n_manning)[2] 
            except:
                dh = 0.01
                h = 0
                ssComp = 1000
                QComp = 0
                while (QComp<Q):
                    h=h+dh
                    QComp = QCompTrapezoid(B,i,h,ssComp,n_manning)[0]
                    ssComp = QCompTrapezoid(B,i,h,ssComp,n_manning)[1]
                    b = QCompTrapezoid(B,i,h,ssComp,n_manning)[2] 
        List_h.append((h,ssComp,b))
    return List_h

def Brehovky_dle_sklonu(List_CS, List_Altitude, ss):
    List_CS_ss = []
    for n in range(len(List_CS)):
        # Vzpocet urovne dna koryta odectenim hladiny a hloubky proudeni
        ss_nad_hladinou = ss
        Z_alt = List_Altitude[n]
        Zr = List_CS[n][2]
        Zl = List_CS[n][5]       
        B = List_CS[n][6]
        Xr = List_CS[n][0]
        Yr = List_CS[n][1]
        Xl = List_CS[n][3]
        Yl = List_CS[n][4]
        AxisDistance = List_CS[n][10]
        staniceni = List_CS[n][11]

        if (B-((Zr-Z_alt)/ss_nad_hladinou+(Zl-Z_alt)/ss_nad_hladinou))<0:
            if (B-((Zr-Z_alt)/(2*ss_nad_hladinou)+(Zl-Z_alt)/(2*ss_nad_hladinou)))<0:
                ss_nad_hladinou=1000000000
            else:
                ss_nad_hladinou=2*ss_nad_hladinou
            
        # Vypocet souradnic pat svahu
        Xr_ss = (Xr-Xl)/(B)*(B-(Zr-Z_alt)/ss_nad_hladinou) + Xl
        Yr_ss = (Yr-Yl)/(B)*(B-(Zr-Z_alt)/ss_nad_hladinou) + Yl
        Xl_ss = (Xl-Xr)/(B)*(B-(Zl-Z_alt)/ss_nad_hladinou) + Xr
        Yl_ss = (Yl-Yr)/(B)*(B-(Zl-Z_alt)/ss_nad_hladinou) + Yr
        B_ss = math.sqrt((Xr_ss-Xl_ss)**2+(Yr_ss-Yl_ss)**2)
        Xmp_ss = (Xr_ss+Xl_ss)/2
        Ymp_ss = (Yr_ss+Yl_ss)/2
        List_CS_ss.append((Xr_ss, Yr_ss, Z_alt, Xl_ss, Yl_ss, Z_alt, B_ss, Xmp_ss,Ymp_ss, Z_alt, AxisDistance, staniceni, Xr, Yr, Zr, Xl, Yl,Zl))
    return List_CS_ss    

# Spusteni funkce otevreni vstupniho souboru
open_input(inputTXT)




def Lines(input, path, outSHPlines):
    arcpy.CreateFeatureclass_management(path,outSHPlines,"POLYLINE", has_z="ENABLED", has_m="ENABLED")
    arcpy.env.workspace = path
    arcpy.AddField_management(outSHPlines, "st", "DOUBLE", "", "", "", "", "", "")
    arcpy.AddField_management(outSHPlines, "type", "TEXT", "", "", "", "", "", "")
    fread = open(input,"r")
    lines = fread.readlines()[1:]
    cur = arcpy.InsertCursor(path+"\\"+outSHPlines)   
    pnt = arcpy.Point()
    array = arcpy.Array()
    for line in lines:
        pnt.X = float(line.split()[0])
        pnt.Y = float(line.split()[1])
        pnt.Z = float(line.split()[22])
        array.add(pnt)
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polyline(array))
    feat.setValue("type","Breh_pravy")
    cur.insertRow(feat)
    array.removeAll()

    for line in lines:
        pnt.X = float(line.split()[3])
        pnt.Y = float(line.split()[4])
        pnt.Z = float(line.split()[22])
        array.add(pnt)
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polyline(array))
    feat.setValue("type","Breh_levy")
    cur.insertRow(feat)
    array.removeAll()

    for line in lines:
        pnt.X = float(line.split()[16])
        pnt.Y = float(line.split()[17])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polyline(array))
    feat.setValue("type","Pata_prava")
    cur.insertRow(feat)
    array.removeAll()
    
    for line in lines:
        pnt.X = float(line.split()[19])
        pnt.Y = float(line.split()[20])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polyline(array))
    feat.setValue("type","Pata_leva")
    cur.insertRow(feat)
    array.removeAll()
    
    for line in lines:
        pnt.X = float(line.split()[7])
        pnt.Y = float(line.split()[8])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polyline(array))
    feat.setValue("type","Osa")
    cur.insertRow(feat)
    array.removeAll()

    # PF
    for line in lines:
        pnt.X = float(line.split()[0])
        pnt.Y = float(line.split()[1])
        pnt.Z = float(line.split()[22])
        array.add(pnt)
        pnt.X = float(line.split()[16])
        pnt.Y = float(line.split()[17])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
        pnt.X = float(line.split()[7])
        pnt.Y = float(line.split()[8])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
        pnt.X = float(line.split()[19])
        pnt.Y = float(line.split()[20])
        pnt.Z = float(line.split()[21])
        array.add(pnt)
        pnt.X = float(line.split()[3])
        pnt.Y = float(line.split()[4])
        pnt.Z = float(line.split()[22])
        array.add(pnt)
       
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Polyline(array))
        feat.setValue("type","PF")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
        array.removeAll()

    cur.updateRow
    fread.close()
    
def Points(input, path, outSHPpoints):
    arcpy.CreateFeatureclass_management(path,outSHPpoints,"POINT", has_z="ENABLED")
    arcpy.env.workspace = path
    arcpy.AddField_management(outSHPpoints, "st", "DOUBLE", "", "", "", "", "", "")
    arcpy.AddField_management(outSHPpoints, "type", "TEXT", "", "", "", "", "", "")
    fread = open(input,"r")
    lines = fread.readlines()[1:]
    cur = arcpy.InsertCursor(path+"\\"+outSHPpoints) 
    pnt = arcpy.Point()

    for line in lines:
        pnt.X = float(line.split()[0])
        pnt.Y = float(line.split()[1])
        pnt.Z = float(line.split()[9])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","Breh_pravy")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)

    for line in lines:
        pnt.X = float(line.split()[3])
        pnt.Y = float(line.split()[4])
        pnt.Z = float(line.split()[9])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","Breh_levy")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
       
    for line in lines:
        pnt.X = float(line.split()[16])
        pnt.Y = float(line.split()[17])
        pnt.Z = float(line.split()[18])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","Pata_prava")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
        
    for line in lines:
        pnt.X = float(line.split()[19])
        pnt.Y = float(line.split()[20])
        pnt.Z = float(line.split()[21])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","Pata_leva")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
        
    for line in lines:
        pnt.X = float(line.split()[7])
        pnt.Y = float(line.split()[8])
        pnt.Z = float(line.split()[21])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","Osa")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)

    for line in lines:
        pnt.X = float(line.split()[23])
        pnt.Y = float(line.split()[24])
        pnt.Z = float(line.split()[25])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","PB_input")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
        
    for line in lines:
        pnt.X = float(line.split()[26])
        pnt.Y = float(line.split()[27])
        pnt.Z = float(line.split()[28])
        feat = cur.newRow()
        feat.setValue("SHAPE", arcpy.Point(pnt.X, pnt.Y, pnt.Z))
        feat.setValue("type","LB_input")
        feat.setValue("st",line.split()[11])
        cur.insertRow(feat)
        
    cur.updateRow
    fread.close()

def Polygon(input, path, outSHPPolygon):
    arcpy.CreateFeatureclass_management(path,outSHPPolygon,"POLYGON", has_z="ENABLED", has_m="ENABLED")
    fread = open(input,"r")
    lines = fread.readlines()[1:]
    cur = arcpy.InsertCursor(path+"\\"+outSHPPolygon)   
    pnt = arcpy.Point()
    array = arcpy.Array()

    List_PB = []
    List_LB = []

    for line in lines:
        Xr = float(line.split()[0])
        Yr = float(line.split()[1])
        Zr = float(line.split()[2])
        Xl = float(line.split()[3])
        Yl = float(line.split()[4])
        Zl = float(line.split()[5])
        List_PB.append((Xr,Yr,Zr))
        List_LB.append((Xl,Yl,Zl))
    List_LB.reverse()
    List_PB.extend(List_LB)

    # Oblast
    for point in List_PB:
        pnt.X = float(point[0])
        pnt.Y = float(point[1])
        pnt.Z = float(point[2])
        pnt.M = 0
        array.add(pnt)
       
    feat = cur.newRow()
    feat.setValue("SHAPE", arcpy.Polygon(array))
    cur.insertRow(feat)
    array.removeAll()

    cur.updateRow
    fread.close()
        
Points(output, path, outSHPpoints)
Lines(output, path, outSHPlines)
Polygon(output, path, outSHPPolygon)


