#include <iostream>

#include"de.h"

using namespace std;


int main()
{
     //data preparation
//     srand((unsigned)time(0));
//
//     
//      cout <<"\n**** TEST of MINIMUM ****"<< endl;
//      
//      colvec data, data1;
//      data.set_size(100);
//      data.fill(1);          
//      
//      cout << "\nTEST Initialization of  function f1 problem" << endl;
//      test_functions f1(2,1,0);
//      f1.initialize();
//      data1=trans(f1.o.row(0));
//      
//      colvec dataw;
//      dataw.set_size(2);
////      dataw(0) = 49.761;
////      dataw(1) = -66.926;
////      cout << f1.calc_bench_func(dataw) << endl;
//      cout << "Minimum: " << f1.calc_bench_func(data1) << endl;
//
//
//      cout << "\nTEST Initialization of  function f2 problem" << endl;
//      test_functions f2(2,1,1);
//      f2.initialize();
//      data1=trans(f2.o.row(0));
//      cout << "Minimum: " << f2.calc_bench_func(data1) << endl;
//
//
//      cout << "\nTEST Initialization of  function f3 problem" << endl;
//      test_functions f3(2,1,2);
//      f3.initialize();
//      data1=trans(f3.o.row(0));
//      cout << "Minimum: " << f3.calc_bench_func(data1) << endl;
//    
//      cout << "\nTEST Initialization of function f4 problem" << endl;
//      test_functions f4(2,1,3);
//      f4.initialize();
//      data1=trans(f4.o.row(0));
//      cout << "Minimum: " << f4.calc_bench_func(data1) << endl;
//    
//      cout << "\nTEST Initialization of function f5 problem" << endl;  
//      test_functions f5(2,1,4);
//      f5.initialize();
//      data1 = trans(f5.o.row(0));
//      cout << "Minimum: " << f5.calc_bench_func(data1) << endl;
//    
//      cout << "\nTEST Initialization of function f6 problem" << endl;  
//      test_functions f6(2,1,5);
//      f6.initialize();
//      data1 = trans(f6.o.row(0));
//      cout << "Minimum: " << f6.calc_bench_func(data1) << endl;
//      
//      
//      cout << "\nTEST Initialization of function f7 problem" << endl;  
//      test_functions f7(2,1,6);
//      f7.initialize();
//      data1 = trans(f7.o.row(0));
//      cout << "Minimum: " << f7.calc_bench_func(data1) << endl;
//      
//      cout << "\nTEST Initialization of function f8 problem" << endl;  
//      test_functions f8(2,1,7);
//      f8.initialize();
//      data1 = trans(f8.o.row(0));
//      cout << "Minimum: " << f8.calc_bench_func(data1) << endl;
//      
//      cout << "\nTEST Initialization of function f9 problem" << endl;  
//      test_functions f9(2,1,8);
//      f9.initialize();
//      data1 = trans(f9.o.row(0));
//      cout << "Minimum: " << f9.calc_bench_func(data1) << endl;
//      
//      cout << "\nTEST Initialization of function f10 problem" << endl;  
//      test_functions f10(2,1,9);
//      f10.initialize();
//      data1 = trans(f10.o.row(0));
//      cout << "Minimum: " << f10.calc_bench_func(data1) << endl;
//      
//      cout << "\nTEST Initialization of function f11 problem" << endl;  
//      test_functions f11(2,1, 10);
//      f11.initialize();
//      data1 = trans(f11.o.row(0));
//      cout << "Minimum: " << f11.calc_bench_func(data1) << endl;      
      
     // f11.plot_data_3d();
      //precision test
//cout.precision(40);
//double a=9.9998999999999999999999999,b=8.9999999999999999999999999;
//cout << a-b<< endl;
//cout << b-a << endl;
//cout << -a+b << endl;
//      cout << "\n\n**** DE testing ****\n";
      
//      de de("./settings/settings_de");
      
  //    de.initialize_all_POpulation();      

//      de.make_mat_from_Compl();
//      
//      cout <<endl << de.Model_param_Parents;
//      de.sort_model_param_parents_mat();
//      
//      cout << endl << de.best_model(de.Dim);
//de de("./settings/settings_de");
//
//
//    de.run_ensemble();
// //    de.calc_quantiles();





//        colvec data;
//     data << 1<< 2<< 3<< 5<< 5 << 6 << 7 << 10<< 10 << 10;
//
//     cout << de.random_perm<colvec>(10);
//     colvec prst;
//     prst << 0.1<< 0.25<< 0.5 << 0.75 << 1.0;
//cout << de.quantiles_(data,prst);


//for(int i=1;i<10;i++){
//    srand(i);
//    cout << rand()<< endl;
//}
//for (unsigned int i=0; i<2 ;i++ ){
//  de de("./settings/settings_de");
//      //de.SC_DE_best_one_bin( i);  
//      de.SC_DE_rand_one_bin(i);
//  }
//
      
//      cout << endl<< de.best_model << endl << de.best_model(de.Dim);
//      for (unsigned int i=0;i<40 ;i++ ){
//            //
//        cout << de.randu_interval() << endl;
//        }



//      
//      cout << endl <<de.Model_param_Parents;
//      //cout << endl<<  de.Model_Comp;
      
      unsigned int simulation_type = 1;
      
      cout << "****Differential Evolution****" << endl;
      cout << "1 -- single ensemble parameter test of SCDE or vgSDE based on parameters in settings_de." << endl;
      cout << "2 -- multiple ensemble run of SCDE or vgSDE  based on settings in file settings_files." << endl;
      cout << "\nMake your choise: ";
      
      cin >> simulation_type;
      
      switch (simulation_type)
      {
          case 1:{
              cout << "\n\n**** Single DE testing ****\n";
              de de("./settings/settings_de");
              de.run_ensemble();
              break;
          }
          case 2:{
              cout << "\n\n**** Multiple Ensemble DE Testing ****\n";
              string *name_set_files;
              string trash;
              unsigned int n_files = 0;
              
              ifstream de_settings_files("./settings/settings_files");
              if(!de_settings_files) {
                   cout << "\nUnable to open the fiel withnames of settings files: "<< "./settings/settings_files" <<endl;
                    exit(EXIT_FAILURE);
              }
              while (de_settings_files.good())    {
                    getline (de_settings_files,trash);
                    n_files++;
                   }
              n_files--;
       //       n_files--;
              cout << "Algoritms test will be performed from " << n_files << " files" << endl;
              de_settings_files.clear();
              de_settings_files.seekg(0, ios::beg);
              
              name_set_files = new string[n_files];
              for (unsigned int fil=0;fil <n_files ;fil++ ){
                de_settings_files >> name_set_files[fil];
                cout << name_set_files[fil].c_str() << endl;
                }
              
              de_settings_files.close();
              colvec best_models;
              best_models.set_size(n_files);
              
              for (unsigned int i=0; i< n_files ;i++ ){
                    cout << name_set_files[i].c_str() << endl;
                    de de(name_set_files[i]);
                    de.run_ensemble();
                    best_models(i) = (as_scalar(de.best_model_ens(de.Dim)) - de.searched_minimum);
                }
              
              cout <<"BEST MODELS\n";
              for(unsigned int fil=0;fil<n_files;fil++){
                cout << "Settings de: " << name_set_files[fil].c_str() << " \tBEST fitness:  " << best_models(fil) << endl;
              }
              
             ofstream filet_best_stream("./outputs/BEST_MODELS", ios::app);
             if (!filet_best_stream) {
                    cout << "\nIt is impossible to write to file withbest model name an results.s" << endl;
                    exit(EXIT_FAILURE);
                    }
                    
            for(unsigned int fil=0;fil<n_files;fil++){
              filet_best_stream <<  "Settings de: " << name_set_files[fil].c_str() << " \t\t\tBEST fitness:  " << best_models(fil) << endl;
            }
              filet_best_stream.close();
              delete [] name_set_files;
              break;      
          }
          default:
              break;
      }

    return 0;
}
