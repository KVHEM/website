#include "de.h"

de::de(string settings_file)
{
    string trash;
    
    ifstream de_inform(settings_file.c_str());
    if(!de_inform) { // osetreni jestli je soubor mozne otevrit
      cout << "\nUnable to open fil :"<< settings_file.c_str() <<"e with initial settings for computations.";
      exit(EXIT_FAILURE);
    }
    de_inform >> scientific;
    de_inform >> trash >> trash >> N_Complexes >> trash >> n_one_population >> trash >> Dim;
    de_inform >> trash >> lo_limit >> trash >> up_limit;
    de_inform >> trash >> PRoblem_Number;
    if((PRoblem_Number >=0)&&(PRoblem_Number <=10)) Nfunc = 1;
    de_inform >> trash >> Number_of_generations_in_one_complex;
    de_inform >> trash >> max_number_of_shuffles;
    de_inform >> trash >> max_function_eval;
    de_inform >> trash >> F >> CR >> K;
    de_inform >> trash >> converge_limit;
    de_inform >> trash >> ensemble;
    de_inform >> trash >> SCDE_selection;
    de_inform >> trash >> trash;
    de_inform >> trash >> vg_A >> vg_R;
    de_inform >> trash >> quantile_selection;
    de_inform >> trash >> reject_outside_bounds_constrait;
    de_inform >> trash >> directory;
//    de_inform >> trash >> path_out_file;

    de_inform.close();

    all_n_Population = N_Complexes * n_one_population;
    all_n_Param = Dim *all_n_Population;
    
    cout << endl << "**** REVIEW of DE settings ****"<< endl;
    cout << scientific;
    cout << "\nDE initialization with following settings from file: " << settings_file.c_str();
    cout << "\nNumber of complexes: " << N_Complexes << "\nNumber of members in one Population: " << n_one_population << endl;
    cout << "The total population: " << N_Complexes * n_one_population << "\nDimension of the problem: " << Dim  <<endl;
    cout << "Total number of real parameters in population: " << all_n_Param << "\nLower bound for parameter values: " << lo_limit << endl;
    cout << "Upper bound for parameter limit: " << up_limit<< endl;
    cout << "Problem optimization 0 -> sphere etc: " << PRoblem_Number << endl;
    cout << "Funtion evaluations in one complex is " <<    Number_of_generations_in_one_complex << endl;
    cout << "Maximum allowed shuffling  is " <<    max_number_of_shuffles << endl;
    cout << "Converge limit is " << converge_limit << endl;
    cout << "Max_func_eval: " << max_function_eval << endl;
    cout << "Read parameter values F - CR - K: " << F << " "<< CR << " " << K << endl;
    cout << "The ensemble " << ensemble << endl;
    cout << "Algorithm_selection: " << SCDE_selection << endl;
    cout << "SCDE_selection_0-best1bin_1-rand1bin_2-randbest1bin_3-best2bin_4-rand2bin_5-currrand2bin_6-curbest2bin " << endl;
    cout <<  "vg_SCDE_selection_7-best1bin_8-rand1bin_9-randbest1bin_10-best2bin_11-rand2bin_12-currrand2bin_13-curbest2bin" << endl;
    cout << "vg_Parameters_vgA_vgR: " << vg_A << " " << vg_R << endl;
    cout << "Quantile estimates according to Hyndman 0-Inverse of Empirical function: " << quantile_selection << endl;
    cout << "Constrains_O-noconstr_1-inside-bounds: " << reject_outside_bounds_constrait << endl;
    cout << "Directory_for_output: " << directory.c_str() << endl;
    
    int info_constr= 0;
    if(reject_outside_bounds_constrait) info_constr =1;

    Model_Comp.set_size(Dim+1,n_one_population,N_Complexes);
    Model_Comp.fill(99999999);
    
    Model_param_Parents.set_size(Dim +1, all_n_Population);
    Model_param_Parents.fill(99999999);
   
    best_model.set_size(Dim+1);
    best_model_ens.set_size(Dim+1);

    test_functions help_fittness(Dim,Nfunc,PRoblem_Number);
    help_fittness.initialize();
    
    OBj_function = help_fittness;
    
    number_func_evaluation = 0;
    converged = false;
    path_out_file += "INITIAL";
    
    switch (SCDE_selection)
    {
        case best1bin:
            SCDE_NAME = "_BEST1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  << "_Constraint-" << info_constr;
            break;
        case rand1bin:
            SCDE_NAME =  "_RAND1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR << "_Constraint-" << info_constr;
            break;
        case randbest1bin:
            SCDE_NAME =  "_RANDBEST1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr;
            break;            
        case best2bin:
            SCDE_NAME =  "_BEST2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr;
            break;
        case rand2bin:
            SCDE_NAME = "_RAND2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr;
            break;                        
        case currrand2bin:
            SCDE_NAME = "_CURRAND2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr;
            break;
        case curbest2bin:
            SCDE_NAME = "_CURBEST2BIN_";
            EN_INFO  << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_ONE-GEN-" << Number_of_generations_in_one_complex << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr;
            break;
         case vg_best1bin:
            SCDE_NAME = "_vg_BEST1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO <<  "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  << "_Constraint-" << info_constr <<"_vgA-" << vg_A << "_vgR-" << vg_R;
            break;
        case vg_rand1bin:
            SCDE_NAME =  "_vg_RAND1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;
        case vg_randbest1bin:
            SCDE_NAME =  "_vg_RANDBEST1BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;            
        case vg_best2bin:
            SCDE_NAME =  "_vg_BEST2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;
        case vg_rand2bin:
            SCDE_NAME = "_vg_RAND2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;                        
        case vg_currrand2bin:
            SCDE_NAME = "_vg_CURRAND2BIN_";
            EN_INFO << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;
        case vg_curbest2bin:
            SCDE_NAME = "_vg_CURBEST2BIN_";
            EN_INFO  << "_DIM-" << Dim << "_f" << PRoblem_Number+1 <<"_N-COMP-" << N_Complexes << "_SHUF-GEN-" << max_number_of_shuffles;
            EN_INFO << "_POP1COM-" << n_one_population << "_F-" << F << "_CR-" << CR  \
            << "_K-" << K << "_Constraint-" << info_constr<<"_vgA-" << vg_A << "_vgR-" << vg_R;;
            break;
    }
    //Sugnathan values of global minimas
    switch (PRoblem_Number)
    {
        case 0:
            searched_minimum = -450.0;
            break;
         case 1:
            searched_minimum = -450.0;
            break;  
        case 2:
            searched_minimum = -450.0;
            break;
        case 3:
            searched_minimum = -450.0;
            break;
        case 4:
            searched_minimum = -310.0;
            break;            
         case 5:
            searched_minimum = 390.0;
            break;  
        case 6:
            searched_minimum = -180.0;
            break;                                   
        case 7:
            searched_minimum = -140.0;
            break;                       
        case 8:
            searched_minimum = -330.0;
            break; 
        case 9:
            searched_minimum = -330.0;
            break;             
        case 10:
            searched_minimum = 90.0;
            break;                      
        default:
            break;
    }
    

}

de::~de()
{
    //dtor
}

de::de(const de& other)
{
    //copy ctor
        N_Complexes = other.N_Complexes;
        Dim = other.Dim;
        
        lo_limit = other.lo_limit;
        up_limit = other.up_limit;
        
        CR = other.CR;
        F = other.F;
        K = other.K;

        all_n_Population = other.all_n_Population;
        n_one_population = other.n_one_population;
        all_n_Param = other.all_n_Param;
        
        nPop = other.nPop;

        Model_param_Parents = other.Model_param_Parents;

        best_model = other.best_model;
        best_model_ens = other.best_model_ens;
        fitness = other.fitness;
        number_func_evaluation = other.number_func_evaluation;
        Number_of_generations_in_one_complex = other.Number_of_generations_in_one_complex;
        max_number_of_shuffles = other.max_number_of_shuffles;
        
        Model_Comp = other.Model_Comp;
        
        PRoblem_Number = other.PRoblem_Number;
        Nfunc = other.Nfunc;
        
        ensemble = other.ensemble;
        SCDE_selection = other.SCDE_selection;
        
        OBj_function = other.OBj_function;
        converged = other.converged;
        converge_limit = other.converge_limit;
        
        directory = other.directory;
        path_out_file = other.path_out_file;
        
        quantile_selection = other.quantile_selection;
        
        searched_minimum = other.searched_minimum;
        
        vg_A = other.vg_A;
        vg_R = other.vg_R;
}

de& de::operator=(const de& other)
{    //assignment operator
    if (this == &other) {
            return *this; // handle self assignment
    }  else {
        N_Complexes = other.N_Complexes;
        Dim = other.Dim;
        
        lo_limit = other.lo_limit;
        up_limit = other.up_limit;
        
        CR = other.CR;
        F = other.F;
        K = other.K;

        all_n_Population = other.all_n_Population;
        n_one_population = other.n_one_population;
        all_n_Param = other.all_n_Param;
        
        nPop = other.nPop;

        Model_param_Parents = other.Model_param_Parents;

        best_model = other.best_model;
        best_model_ens = other.best_model_ens;
        fitness = other.fitness;
        number_func_evaluation = other.number_func_evaluation;
        Number_of_generations_in_one_complex = other.Number_of_generations_in_one_complex;
        max_number_of_shuffles = other.max_number_of_shuffles;
        
        Model_Comp = other.Model_Comp;
        
        PRoblem_Number = other.PRoblem_Number;
        Nfunc = other.Nfunc;
        
        ensemble = other.ensemble;
        SCDE_selection = other.SCDE_selection;
        
        OBj_function = other.OBj_function;
        converged = other.converged;
        converge_limit = other.converge_limit;
        
        directory = other.directory;
        path_out_file = other.path_out_file;
        
        quantile_selection = other.quantile_selection;
        searched_minimum = other.searched_minimum;
        
        vg_A = other.vg_A;
        vg_R = other.vg_R;
    }
    return *this;
}

/** The initialization of all random Population */
void de::initialize_all_POpulation()
{
    //Latin Hypercube Sampling
    colvec my_init = random_perm<colvec>(all_n_Param);
    colvec help_vec;
    
    help_vec.set_size(all_n_Param);
    help_vec.randu();
    
    my_init -= help_vec;
    my_init = (up_limit - lo_limit) * my_init / all_n_Param + lo_limit;
    
//Initializing the Model param Parents matrix    
    unsigned int help_var =0;
    for (unsigned int i =0; i < all_n_Population ;i++ ){
       for (unsigned int j =0; j<Dim ;j++ ){
         Model_param_Parents(j,i) = my_init(help_var);
         help_var++;
         }
      }
      
    colvec help_col;
    help_col.set_size(Dim);
    for(unsigned int i=0; i< all_n_Population;i++){
        help_col = Model_param_Parents.submat(0,i,Dim-1,i);
        //cout <<endl <<help_col << endl;
        Model_param_Parents(Dim,i) = fittnes(help_col);
    }
    
    make_Compl_from_mat();
}

/**
  * Random permutation according to Richard Durstenfeld in 1964 in Communications of the ACM volume 7, issue 7, as "Algorithm 235: Random permutation"
  */
  template <class my_vec> my_vec de::random_perm(unsigned int n)
{
  unsigned int j=0;
  my_vec shuffled_index, tmp;
  
  shuffled_index.set_size(n);
  for (unsigned int i=0;i<n ;i++ ){
    shuffled_index(i) = i+1;
    }
    
   tmp.set_size(1);
   tmp.fill(1);

  for (unsigned int i = n - 1; i > 0; i--) {
    j = rand_int(i);
    tmp(0) = shuffled_index(j);
    shuffled_index(j) = shuffled_index(i);
    shuffled_index(i) = tmp(0);
  }
  
  return(shuffled_index);
}

/** Random integer number generator */
unsigned int de::rand_int(unsigned int n)
{
  unsigned int limit = RAND_MAX - RAND_MAX % n;
  unsigned int rnd;

//  srand((unsigned)time(0));
  //cout << "\n time "<< time(0)<< endl;

  do {
    rnd = rand();
  } while (rnd >= limit);
  
  return rnd % n;
}

/** After sorting the population according to its fittness -- shuffling the population from Parent matrix to complexes */
void de::make_Compl_from_mat()
{
    unsigned int help_var=0;
    for (unsigned int j=0; j< n_one_population ; j++){
       for (unsigned int i =0; i< N_Complexes ;i++ ){
         Model_Comp.subcube(0,j,i,Dim,j,i) = Model_param_Parents.col(help_var);
         help_var++;
         }  
      }
}

/** Creating the Parent matrix by combining the Complexes of small Populations */
void de::make_mat_from_Compl()
{
    unsigned int left_col=0, right_col;
    right_col = n_one_population -1;
    for (unsigned int j=0; j<N_Complexes ;j++ ){
      Model_param_Parents.submat(0,left_col,Dim,right_col) = Model_Comp.slice(j);
      left_col = right_col+1;
      right_col += n_one_population;
      }
      
//      cout << endl <<"make_mat_from_compl\n" << Model_param_Parents<< endl ;
}

/** Wrapper for test_fuction class */
double de::fittnes(colvec X)
{
    double value =0.0;
    
    value = OBj_function.calc_bench_func(X);    
    
    number_func_evaluation++;
    
    out_fittness(value);
    
    return(value);   
}

/** Sorting columns of Parent matrix according to fittnes */
void de::sort_model_param_parents_mat()
{
    rowvec fit_ness;
    fit_ness = Model_param_Parents.row(Dim);
    
    //cout << fit_ness;
    umat indexes = sort_index(fit_ness);
//    cout <<  "\n sorted indexes\n"  << indexes;
    
    mat Help_Model_param_parents;
    Help_Model_param_parents.set_size(Dim + 1, all_n_Population);
    
    for (unsigned int i = 0; i< all_n_Population ;i++ ){
       Help_Model_param_parents.col(i) = Model_param_Parents.col(indexes(i));
      }
    Model_param_Parents = Help_Model_param_parents;
//     cout << Model_param_Parents;   
    best_model = Model_param_Parents.col(0);
    
//    check_convergence();

}

/** Method for checking the converge of computations */
void de::check_convergence()
{
    if (as_scalar(best_model(Dim)) <= converge_limit) {
            converged = true;
          //  cout << "\nThe problem has converged.\n";
    }
}

/** Shuffled DE best one */
void de::SC_DE_best_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int kk=0;
    while( (kk < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_best_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            kk++;
    }//end while loop

}

/** Shuffled vgSDE best one vg */
void de::vg_SC_DE_best_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/vgSC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
//    vg_A_next = vg_A;
//    vg_A_next +=  vg_A_next * pow(vg_R, coef_multi);
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_best_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
//            if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
//cout << endl << kk << " " << Number_of_generations_in_one_complex << "  vga " << vg_A <<  " vganext  " << vg_A_next << " " << max_function_eval << " n_ feval " << Number_of_generations_in_one_complex * N_Complexes  * n_one_population <<  " " <<  vg_A_next * N_Complexes  * n_one_population - vg_A * N_Complexes  * n_one_population << endl;
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;
}

/** DE/BEST/1/bin */
mat de::DE_best_one_bin(mat Population)
{
    mat offsprings;
    mat POpulation;
    
    POpulation = Population;
    
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                        if (r1 == n_one_population) r1--;
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                        if (r2 == n_one_population) r2--;
                }while((r2 == i)||(r2==r1));
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)|| (s==index_rand)){
                     offsprings(s,i) = best_model(s) + F * (POpulation(s,r1) - POpulation(s,r2));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;
}

/** Random number generator provides double value in interval (0.1) */
double de::randu_interval()
{
    double value = 0.0;
    unsigned int LIM_MAX;
    
    LIM_MAX =   1+ (static_cast<unsigned int>( RAND_MAX ) );
    value = static_cast<double>(rand() ) / (static_cast<double>(LIM_MAX));
   
    return (value);
}

/** Writing the fitness to the out file */
void de::out_fittness(double value)
{
      ofstream out_stream(path_out_file.c_str(), ios::app);
      if (!out_stream) {
       cout << "\nIt is impossible to write to file  " << path_out_file;
       exit(EXIT_FAILURE);
     }
    out_stream << number_func_evaluation << "\t" << (value-searched_minimum) <<"\n";
    out_stream.close();
}

/** Shuffled Drandst one bin */
void de::SC_DE_rand_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();              
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop

}

/** Shuffled vgSDE rand to one bin */
void de::vg_SC_DE_rand_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
//    vg_A_next = vg_A;
//    vg_A_next +=  vg_A_next * pow(vg_R, coef_multi);
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();              
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;     
}

/** DE/RAND/1/bin */
mat de::DE_rand_one_bin(mat POpulation)
{
    mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, r3, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));

                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r3 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r3 == i)||(r3==r1)||(r3==r2));
                
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)||  (s==index_rand)){
                     offsprings(s,i) = POpulation(s,r1) + F * (POpulation(s,r2) - POpulation(s,r3));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;
}

/** DE/rand_to_best/1 */
mat de::DE_rand_to_best_one_bin(mat POpulation)
{
    mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, r3, r4, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));

                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r3 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r3 == i)||(r3==r1)||(r3==r2));
 
                 do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r4 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r4 == i)||(r4==r1)||(r4==r2)||(r4==r3));
                
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)||  (s==index_rand)){
                     offsprings(s,i) = POpulation(s,r1) + K * (best_model(s) - POpulation(s,r4)) + F * (POpulation(s,r2) - POpulation(s,r3));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }                    
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;
}

/** Pure SDE DE/RANDTOBEST/1/BIN */
void de::SC_DE_rand_to_best_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_to_best_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
            
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop
}

/** Pure vgSDE DE/RANDTOBEST/1/BIN */
void de::vg_SC_DE_rand_to_best_one_bin( unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
//    vg_A_next = vg_A;
//    vg_A_next +=  vg_A_next * pow(vg_R, coef_multi);
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_to_best_one_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
            
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;     
}

/** DE/BEST2RAND/2/BIN */
mat de::DE_best_two_bin(mat POpulation)
{
    mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, r3, r4, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));

                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r3 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r3 == i)||(r3==r1)||(r3==r2));
 
                 do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r4 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r4 == i)||(r4==r1)||(r4==r2)||(r4==r3));
                
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)||  (s==index_rand)){
                     offsprings(s,i) = best_model(s) + K * ( POpulation(s,r1) - POpulation(s,r4)) + F * (POpulation(s,r2) - POpulation(s,r3));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;
}

/** Pure SDE DE/BEST2RAND/2/BIN */
void de::SC_DE_best_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_best_two_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop
}

/** Pure vgSDE DE/BEST2RAND/2/BIN */
void de::vg_SC_DE_best_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_best_two_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;
}

/** DE/RAND2/2/BIN */
mat de::DE_rand_two_bin(mat POpulation)
{
    mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, r3, r4, r5, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));

                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r3 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r3 == i)||(r3==r1)||(r3==r2));
 
                 do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r4 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r4 == i)||(r4==r1)||(r4==r2)||(r4==r3));

                 do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r5 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r5 == i)||(r5==r1)||(r5==r2)||(r5==r3)||(r5==r4));
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)||  (s==index_rand)){
                     offsprings(s,i) = POpulation(s,r1) + K * ( POpulation(s,r5) - POpulation(s,r4)) + F * (POpulation(s,r2) - POpulation(s,r3));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }              
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;    
}

/** Pure SDE DE/RAND2/2/BIN */
void de::SC_DE_rand_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_two_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop
}

/** Pure vgSDE DE/RAND2/2/BIN */
void de::vg_SC_DE_rand_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
//    vg_A_next = vg_A;
//    vg_A_next +=  vg_A_next * pow(vg_R, coef_multi);
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_rand_two_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
    //        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;  
}

/** DE/CURRENTTORAND/2/BIN */
mat de::DE_current_to_rand_2_bin(mat POpulation)
{
    mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, r3, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));

                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r3 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r3 == i)||(r3==r1)||(r3==r2));
                
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)|| (s==index_rand)){
                     offsprings(s,i) = POpulation(s,i) + K*(POpulation(s,i) - POpulation(s,r1)) + F * (POpulation(s,r2) - POpulation(s,r3));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }             
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;
}

/** Pure SDE DE/CURRENTTORAND/2/BIN */
void de::SC_DE_current_to_rand_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_current_to_rand_2_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
//        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop    
}

/** Pure vgSDE DE/CURRENTTORAND/2/BIN */
void de::vg_SC_DE_current_to_rand_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;   
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_current_to_rand_2_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
//        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;     
}


/** DE/CURRENTTOBEST/2/BIN */
mat de::DE_current_to_best_2_bin(mat POpulation)
{
     mat offsprings;
    unsigned int number_rows, number_cols;
    unsigned int r1, r2, index_rand;
    double rr = 0.0;
    
    number_cols = POpulation.n_cols;
    number_rows = POpulation.n_rows;
    
    offsprings.set_size(number_rows,number_cols);
    offsprings.fill(44);
//    if(Dim == 2) {
//        cout <<"\nNumber of partial offsprings in one complex is too low: " << n_one_population;
//        exit(EXIT_FAILURE);
//    }
    for (unsigned int j=0;j<Number_of_generations_in_one_complex;j++ ){
            for (unsigned int i=0; i<n_one_population ; i++){
                //generation of neede random indexes
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r1 = static_cast<int>(floor( (rr * n_one_population)));
                }while(r1 == i);
                
                do{
                        rr = static_cast<double>(rand() ) / (static_cast<double>(RAND_MAX));
                        r2 = static_cast<int>(floor( (rr * n_one_population)));
                }while((r2 == i)||(r2==r1));
            //    cout << r1 <<" i " << i << " population member " << r2 <<endl;
                index_rand = rand_int(Dim);
                for (unsigned int s =0;s <Dim ;s++ ){
                   if((randu_interval()<CR)|| (s==index_rand)){
                     offsprings(s,i) = POpulation(s,i) + K * ( best_model(s) - POpulation(s,i)) + F * (POpulation(s,r1) - POpulation(s,r2));
                     if(reject_outside_bounds_constrait){
                        if((as_scalar(offsprings(s,i))< lo_limit) || (as_scalar(offsprings(s,i))>up_limit))
                           offsprings(s,i) = POpulation(s,i);
                     }
                    } else {
                      offsprings(s,i) = POpulation(s,i);
                    }//end if of statement
                  }//end Dim loop
                    colvec help_col;
                    help_col.set_size(Dim);
                    help_col = offsprings.submat(0,i,Dim-1,i);
                    offsprings(Dim,i) = fittnes(help_col);
                  if(as_scalar(offsprings(Dim,i)) < as_scalar(POpulation(Dim,i))){
                    POpulation.col(i) = offsprings.col(i);
                     if(as_scalar(offsprings(Dim,i))<=best_model(Dim)) best_model = offsprings.col(i);
                  }//end of evaluation of fittnes condition
              }//end of offspring population loop
      }//end of max number of function evaluation loop 
    return POpulation;   
}

/** Pure SDE DE/CURRENTTOBEST/2/BIN */
void de::SC_DE_current_to_best_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_current_to_best_2_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
//        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            k++;
    }//end while loop    
}

/** Pure vgSDE DE/CURRENTTOBEST/2/BIN */
void de::vg_SC_DE_current_to_best_two_bin(unsigned int ensemble_number)
{
    stringstream EN_INFO1;
    EN_INFO1 << "_ens_" << ensemble_number;

    path_out_file +=  "/SC";
    path_out_file += SCDE_NAME.c_str() +  EN_INFO.str() + EN_INFO1.str();
    
    initialize_all_POpulation();
//    cout << endl << path_out_file;
    unsigned int k=0;
    unsigned int help_vg_A, help_vg_R,coef_multi=0;// vg_A_next;
    help_vg_A = vg_A;
    help_vg_R = vg_R;
    while( (k < max_number_of_shuffles)){
            sort_model_param_parents_mat();
            make_Compl_from_mat();
            vg_A = vg_A + vg_R*coef_multi;
//            vg_A_next = vg_A + vg_R*(coef_multi+1);
            Number_of_generations_in_one_complex = vg_A;            
            for (unsigned int i =0;i<N_Complexes ; i++){
              Model_Comp.slice(i) = DE_current_to_best_2_bin(Model_Comp.slice(i));
            }
            make_mat_from_Compl();  
//            cout << boolalpha << "\nSC DE/best/1 -- " << k <<" iteration of the main loop. \nConvergence Status --> "<< converged;
//        if(k==4) converged = true;
//            if(converged) {
//                cout <<"\n\nThe computation reached the convergence with number of function eval: " << number_func_evaluation << "."<< endl;
//                cout << Model_Comp << endl << Model_param_Parents;
//                break;
//            }//end for loop
            coef_multi++;
            k++;
    }//end while loop
    vg_A = help_vg_A;
    vg_R = help_vg_R;   
}

/** The general interface to the problem testings 
 SCDE_selection_0-best1bin_1-rand1bin_2-randbest1bin_3-best2bin_4-rand2bin_5-currrand2bin_6-curbest2bin*/
void de::run_ensemble()
{
    cout << "\n\n**** ENSEMBLE RUN ****\n";
    string filet_names;//file with names of ensemble outcomes
      
    filet_names +=directory + "/File_names" + SCDE_NAME.c_str() + EN_INFO.str();
    
    ofstream filet_name_stream(filet_names.c_str(), ios::app);
      if (!filet_name_stream) {
       cout << "\nIt is impossible to write to file with nams " << filet_name_stream<< endl;
       exit(EXIT_FAILURE);
     }
     
     best_model_ens.fill(9999999);

    for(unsigned int i=0; i<ensemble;i++){   
            srand(i+1);
            if (!path_out_file.empty()) path_out_file.clear(); 
            path_out_file += directory;
            cout << "\nEnsemble simulation: " << i+1;
            number_func_evaluation = 0;
            switch (SCDE_selection)
            {
                case best1bin:
                    SC_DE_best_one_bin(i);
                    break;
                case rand1bin:
                    SC_DE_rand_one_bin(i);
                    break;
                case randbest1bin:
                    SC_DE_rand_to_best_one_bin(i);
                    break;
                case best2bin:
                    SC_DE_best_two_bin(i);
                    break;
                case rand2bin:
                    SC_DE_rand_two_bin(i);
                    break;
                case currrand2bin:
                    SC_DE_current_to_rand_two_bin(i);
                    break;
                case curbest2bin:
                    SC_DE_current_to_best_two_bin(i);
                    break;
                case vg_best1bin:
                    vg_SC_DE_best_one_bin(i);
                    break;
                case vg_rand1bin:
                    vg_SC_DE_rand_one_bin(i);
                    break;
                case vg_randbest1bin:
                    vg_SC_DE_rand_to_best_one_bin(i);
                    break;
                case vg_best2bin:
                    vg_SC_DE_best_two_bin(i);
                    break;
                case vg_rand2bin:
                    vg_SC_DE_rand_two_bin(i);
                    break;
                case vg_currrand2bin:
                    vg_SC_DE_current_to_rand_two_bin(i);
                    break;
                case vg_curbest2bin:
                    vg_SC_DE_current_to_best_two_bin(i);
                    break;                
                 default:
                    break;
            }
            filet_name_stream << path_out_file.c_str() << endl;
            cout << endl <<"Best model: " << (as_scalar(best_model(Dim)) - searched_minimum) << endl;
            if(as_scalar(best_model(Dim))  < as_scalar(best_model_ens(Dim)) ) best_model_ens = best_model;
            best_model.fill(9999999);
        }
        filet_name_stream.close();
        
       cout << endl << "\n***The ensemble run has been finished.***" << endl;
       
       calc_quantiles_fast_small(); 
       
       cout << endl << "***The quantiles has been computed.***\n" << endl;
  
}

/** Removes the duplicated elements in my_vec 
 the implementation for type 7 of estimation of quantiles
TODO implementa rest quantile estimators
*/
template<class my_vec>  my_vec de::unique_(my_vec data)
{
   data = sort(data);
   
   my_vec return_vec;
   return_vec.set_size(data.n_elem);
   return_vec.fill(999999);
   
   unsigned int number_d =0, help_ind =0, help_var =0;
   number_d = data.n_elem;
   
    for (unsigned int i=0;i< number_d;i++ ){
           while (as_scalar(data(help_ind)) == as_scalar(data(help_var)) ){
               help_var++; 
           }
           help_ind += (help_var - help_ind) + 1;
           help_var = help_ind;
           return_vec(help_ind) = data(help_ind);
      }
   
   return_vec.reshape(help_ind);
   
   return(return_vec);
}

/** Returns vector of quantiles for given data 
IMPLEMENTED
  Discontinuous:
       INV_emp_dist - inverse of the empirical distribution function
 
 NOT IMPLEMENTED      
  //   INV_emp_dist_av - like type 1, but with averaging at discontinuities (g=0)
  //   SAS_near_int - SAS definition: nearest even order statistic
   //  Piecwise linear continuous:
   //    In this case, sample quantiles can be obtained by linear interpolation
   //    between the k-th order statistic and p(k).
   //    type=4 - linear interpolation of empirical cdf, p(k)=k/n;
   //    type=5 - hydrolgical a very popular definition, p(k) = (k-0.5)/n;
   //    type=6 - used by Minitab and SPSS, p(k) = k/(n+1);
   //    type=7 - used by S-Plus and R, p(k) = (k-1)/(n-1);
   //    type=8 - resulting sample quantiles are approximately median unbiased
   //             regardless of the distribution of x. p(k) = (k-1/3)/(n+1/3);
   //    type=9 - resulting sample quantiles are approximately unbiased, when
   //             the sample comes from Normal distribution. p(k)=(k-3/8)/(n+1/4);
   //
   //    default type = 7
   //
    References:
    1) Hyndman, R.J and Fan, Y, (1996) "Sample quantiles in statistical packages"
                                        American Statistician, 50, 361-365

*/
template<class my_vec> my_vec  de::quantiles_(my_vec data, my_vec probs)
{
    my_vec sorted_data;
    my_vec quantile;
    
    sorted_data = sort(data);
    quantile.set_size(probs.n_elem);
       
    uvec index;
    index.set_size(probs.n_elem);

    switch (quantile_selection)
    {
        case INV_emp_dist:
            for (unsigned int i=0; i<probs.n_elem  ;i++ ){
                    if(as_scalar(probs(i)) == 0.0) index(i) = 0;
                        else index(i) = static_cast<unsigned int> (ceil((as_scalar(probs(i) * sorted_data.n_elem)))) -1;
                   }
            for (unsigned int i=0; i<probs.n_elem  ;i++ ){
                      quantile(i) = sorted_data(index(i));
                  }            
            break;
        
//        case INV_emp_dist_av:
//                    
//            break;  
//        default:
//            break;
    }
    
 //   cout << index;
    return(quantile);
}

/** Slow Quantile estimation for large problems*/
void de::calc_quantiles()
{  
/*     working example */
//     colvec data;
//     data << 1<< 2<< 3<< 4<< 5 << 6 << 7 << 8<< 9 << 10 <<11 << 12 << 13 << 14 << 15 << 16 << 17 << 18 << 19 << 20 << 21 << 22 << 23 << 24 << 25;
     rowvec prst;
     prst << 0.<< 0.25<< 0.5 << 0.75 << 1.0;

//     cout << data;
//     cout << endl << quantiles_(data, prst);
   string filet_names;//file with names of ensemble outcomes
    
    filet_names +=directory + "/File_names" + SCDE_NAME.c_str() + EN_INFO.str();
    //filet_names += directory + "/File_names" + "_SC" + SCDE_NAME.c_str() + EN_INFO.str();
    
 //   cout << filet_names;
  
    string *file_en, trash;
    unsigned int number_of_files = 0;
    
    ifstream de_file_ens_names(filet_names.c_str());
    while(de_file_ens_names.good()){
    de_file_ens_names >> trash;
    number_of_files++;
    
    }
    number_of_files--;
    cout << endl << "Opening the "<< number_of_files << endl;
    file_en = new string[number_of_files];
    
    de_file_ens_names.clear();
    de_file_ens_names.seekg (0, ios::beg);
    
    for (unsigned int i =0; i< number_of_files ;i++ ){
      de_file_ens_names >> file_en[i] ;
    //  cout << file_en[i] << endl;
      }
    de_file_ens_names.close();
    
    ifstream first_filet(file_en[0].c_str());
    unsigned int num_rows =0;
    while(first_filet.good()){
        getline(first_filet,trash);    
        num_rows++;
        }
    first_filet.close();
    num_rows --;
    
    rowvec Quantiles_ens;
    Quantiles_ens.set_size(prst.n_elem+2);

    rowvec help_vec1;    
    mat  data_one_file;
    
    string filet_quantiles;
    filet_quantiles +=directory + "/Ensemble_quantiles_SC_" +SCDE_NAME.c_str() + EN_INFO.str();
    
    ofstream out_quantile_stream(filet_quantiles.c_str(), ios::app);
      if (!out_quantile_stream) {
       cout << "\nIt is impossible to write to file  " << filet_quantiles;
       exit(EXIT_FAILURE);
      }

    cout << "\nComputing the Quantiles\n";
    for (unsigned int j=0; j<num_rows ; j++){
      help_vec1.set_size(number_of_files);
      for (unsigned int i =0; i<number_of_files; i++){
             data_one_file.load(file_en[i].c_str());
             help_vec1(i) = data_one_file(j,1);
             if(j==0) cout <<  i;
             data_one_file.reset();
             }      
             cout << endl<< help_vec1;
      Quantiles_ens.subvec(0,prst.n_elem-1) = quantiles_<rowvec>(help_vec1, prst);
      Quantiles_ens(prst.n_elem) = mean(help_vec1);
      Quantiles_ens(prst.n_elem+1) = stddev(help_vec1);
      for(unsigned int qu =0; qu < (prst.n_elem+2); qu++){
        out_quantile_stream << Quantiles_ens(qu) << "\t";
      }
      out_quantile_stream << "\n";
      help_vec1.reset();
     }
      
    delete [] file_en;      
    out_quantile_stream.close();
}

/** Fast Quantile estimation for middle problems*/
void de::calc_quantiles_fast_small()
{  
/*     working example */
//     colvec data;
//     data << 1<< 2<< 3<< 4<< 5 << 6 << 7 << 8<< 9 << 10 <<11 << 12 << 13 << 14 << 15 << 16 << 17 << 18 << 19 << 20 << 21 << 22 << 23 << 24 << 25;
     rowvec prst;
     prst << 0.0 << 0.25<< 0.5 << 0.75 << 1.0;

//     cout << data;
//     cout << endl << quantiles_(data, prst);
   string filet_names;//file with names of ensemble outcomes
    
    filet_names +=directory + "/File_names" + SCDE_NAME.c_str() + EN_INFO.str();
    //filet_names += directory + "/File_names" + "_SC" + SCDE_NAME.c_str() + EN_INFO.str();
    
 //   cout << filet_names;
  
    string *file_en, trash;
    unsigned int number_of_files = 0;
    
    ifstream de_file_ens_names(filet_names.c_str());
    while(de_file_ens_names.good()){
       de_file_ens_names >> trash;
       number_of_files++;
      }
    number_of_files--;
//    cout << endl << "Opening the "<< number_of_files << endl;
    file_en = new string[number_of_files];
    
    de_file_ens_names.clear();
    de_file_ens_names.seekg (0, ios::beg);
    
    for (unsigned int i =0; i< number_of_files ;i++ ){
      de_file_ens_names >> file_en[i] ;
    //  cout << file_en[i] << endl;
      }
    de_file_ens_names.close();
    
    ifstream first_filet(file_en[0].c_str());
    unsigned int num_rows =0;
    while(first_filet.good()){
        getline(first_filet,trash);    
        num_rows++;
        }
    first_filet.close();
    num_rows --;
   // cout << num_rows << endl;
    
    mat Quantiles_ens;
    Quantiles_ens.set_size(num_rows, prst.n_elem+2);


    
    mat  data_all_file;
    data_all_file.set_size(num_rows,number_of_files);

      for (unsigned int i =0; i<number_of_files; i++){
             mat data_one_file;
             data_one_file.load(file_en[i].c_str());
             data_all_file.submat(0,i,num_rows-1,i) = data_one_file.col(1);
             }      
             
      //       cout <<"\nAll mat finallize.d\n";
    string filet_quantiles;
    filet_quantiles +=directory + "/Ensemble_quantiles_SC_" +SCDE_NAME.c_str() + EN_INFO.str();
    
//    ofstream out_quantile_stream(filet_quantiles.c_str(), ios::app);
//      if (!out_quantile_stream) {
//       cout << "\nIt is impossible to write to file  " << filet_quantiles;
//       exit(EXIT_FAILURE);
//      }

    cout << "\nComputing the Quantiles\n";
    for (unsigned int j=0; j<num_rows ; j++){
      rowvec help_vec1;    
      help_vec1.set_size(number_of_files);
      help_vec1 = data_all_file.row(j);
      Quantiles_ens.submat(j,0,j,prst.n_elem-1) = quantiles_<rowvec>(help_vec1, prst);
      Quantiles_ens(j,prst.n_elem) = mean(help_vec1);
      Quantiles_ens(j,prst.n_elem+1) = stddev(help_vec1);
     }

    Quantiles_ens.save(filet_quantiles.c_str(),raw_ascii);
    delete [] file_en;      
//    out_quantile_stream.close();
}
