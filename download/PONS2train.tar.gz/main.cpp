#include "vzory.h"
#include "neural_net.h"

int main()
{

//Jednoduche rozhrani programu PONS2train pro testovani architektury MLP
   cout << "\nPONS2train: program pro testovani architektury MLP:\n";


   neural_net nn("./settings/settings_MOPEX_14359000_half.txt");//TIME series working
   nn.inicializuj(); //meni sit, parametr je bias
   nn.test_treninku();


return 0;
}
