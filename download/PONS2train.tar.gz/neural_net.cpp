#include "neural_net.h"

neural_net::neural_net()
{
        pocet_vstupu = 0; //pocet vstupu do site
        typ_trenovani = 0; //pouzivame jen BP (v souboru oznacen jako 1)
        typ_init = 0;
        pocet_epoch = 0; // vyjadruje pocet epoch (modelova hodnota)
        pocet_vzorovych_dat = 0; // vyjadruje pocet casovych rad treninkovych vzoru
        pocet_data_test =0;// vyjadruje pocet casovych rad testovacich vzoru

        pocet_vrstev = 0; // pocet vrstev v siti
        pocet_neuronu = 0; // celkovy pocet neuronu v siti, vcetne vstupu
        pocet_vah = 0; // pocet vah v siti
        pocet_vystupu = 0;
        LAG = 0;

        momentum = 0.0; // zohledneni predchadzejici zmeny vah, nabyva hodnoty (0,1)
        learning_rate = 0.0;
        regul_alpha = 0.0;
        regul_beta = 0.0;

        e1 = 0.0;
        e2 = 0.0;
        tau = 0.0;
        maxiter = 0;

        eps = 0;
        c1 = 0;
        c2 = 0;
        CCmaxiter = 0;
        CC_restart_out = false;
        CC_restart_period = 99999999;
        CC_restart_boundary = 0.0;
        CC_POWEL = false;
        
        BBmaxiter = 0;
        BB_eps = 0.0;
        BB_restart_boundary =0.0;
        BB_restart_out = false;

        delta_init = 0.0;
        eta_plus = 0.0;
        eta_minus = 0.0;
        deltamax = 0.0;
        deltamin = 0.0;
        BP_Rprop_pocet_epoch = 0;

        SS_vah = 0.0;
        SS_er = 0.0;

        low_init = 0.0;
        up_init = 0.0;

        vahy.reset();
        dE_vahy.reset();
        dF_vahy.reset();
        saturations.reset();

        soubor_s_nastavenim_vzoru = "";
        cesta_pro_vypis_kriterii ="";
        cesta_pro_vypis_best_net_vah = "";
        cesta_pro_vypis_best_net_simulaci = "";
        nazev_souboru_s_vypisem_site = "";
        path_OLS_benchmark = "";
        bench_OLS = false;

        bias_ano_ne = false;
        bias_const = 1;

        file_nas_vzoru = new string[1];
        file_nas_vzoru[0] = "";

        pocet_vzoru = 0;

        pocet_data_test = 0;
        pocet_radku_test_dat = 0;

        VSTUPY.reset();
        VSTUPY_TEST.reset();
        VYSTUPY.reset();
        VYSTUPY_TEST.reset();
        SIM_VYSTUPY.reset();
        SIM_VYSTUPY_TEST.reset();
        REZIDUI.reset();
        
        beta_OLS.reset();

        J.reset();
        Hessian.reset();
        Ensemble = 0;

        control_delta_par = 0.0;
        control_SS_error = 0;
        controls_out = false;

        control_saturation = false;
        saturation_sigma = 0.0;

        vystupy.reset();

        best_net = false;
        vypis_best_nets = false;
        index_bestnet_kriteria = 0;
        prah_kriteria = 0.0;
        bestnet_vahy.reset();
        bestnet_vahy_initial.reset();
        real_pocet_bestnet = 0;

        trenuj_ens_s_init_vahami = false;
}

// konstruktor vytvarejici sit prostrednictvim udaju ze souboru "settings.txt"
neural_net::neural_net(string nazev_souboru_s_nastavenim)
{
    ifstream proud_soubor(nazev_souboru_s_nastavenim.c_str()); //c_str() meni string na const char; otvirame soubor

    string odpad; // do tohoto stringu sa nacitaji ze settings.txt retezce ne cisla

    if(!proud_soubor) { // osetreni jestli je soubor mozne otevrit
      cout << "\n Chyba v otevreni souboru s nastavenim site."<<endl;
      exit(EXIT_FAILURE);
    }

    //zacina nacitani jednotlivych polozek ze souboru settings.txt
    proud_soubor >> odpad >> odpad; // Architektura_site: >> Pocet_vstupu: (string) je odpad
    proud_soubor >> pocet_vstupu; // cislo u poctu vstupu = Pocet_vstupu

    if (pocet_vstupu <= 0) { // kontrola poctu vstupu
       cout << "\n Sit nema zadny vstup. "<<endl;
       exit(EXIT_FAILURE);
    }

    proud_soubor >> odpad >> pocet_vrstev; // string je odpad, cislo je Pocet_vrstev

    if(pocet_vrstev <= 0) { // kontrola poctu vrstev
       cout << "\n Sit nema zadnou vrstvu. "<<endl;
       exit(EXIT_FAILURE);
    }

    pocet_neuronu_ve_vrtsve = new unsigned int[pocet_vrstev]; // alokujeme pamet, neurony ve vrstve se vytvareji dynamicky (jde o pole)
    typ_akt_fci = new unsigned int[pocet_vrstev]; // alokace pameti pro typ aktivacni fce (jde o pole)

    proud_soubor >> odpad; // Pocet_neuronu_ve_vrstve (string)

    /* nacitani poctu neuronu ve vrstve (cislo): pocet cisel zavisi na poctu vrstev,
    pocet neuronov se ulozi do pole a pocet poli predstavuje pocet vrstev v neuronove siti*/
    for (unsigned int i=0;i< pocet_vrstev ; i++ ) {
    	proud_soubor >> pocet_neuronu_ve_vrtsve[i];
    }

    proud_soubor >> odpad; //Typ_akt_fce (string)

    //viz. Pocet_neuronu ve vrstve, typ aktivacni fce je stejny pro vsechny neurony v jedne vrstve
    for (unsigned int i=0;i< pocet_vrstev ; i++ ) {
    	proud_soubor >> typ_akt_fci[i];
    }

    proud_soubor >> odpad >> pocet_vystupu; // string, cislo = Pocet_vystupu

    if ((pocet_vystupu <= 0) ||(pocet_vystupu !=pocet_neuronu_ve_vrtsve[pocet_vrstev-1])){ //kontrola nacitani vstupu
       cout << "\n Sit nema zadny vstup nebo ma spatne zadane vystupy a pocet neuronu v posledni vrstve. "<<endl;
       exit(EXIT_FAILURE);
    }

    proud_soubor >> odpad >> bias_ano_ne >> bias_const; // string, cislo = Bias_ano_ne

    if (bias_ano_ne){ //podminka kdyz je bias
        for (unsigned int i = 0; i < pocet_vrstev-1; i++) {
            pocet_neuronu_ve_vrtsve[i] = pocet_neuronu_ve_vrtsve[i]+1; //prida neuron do vrstvy
        }
    }

    //naplneni dvojrozmerneho pole "**neuron_ve_vrstve"
    neuron_ve_vrstve = new neuron*[pocet_vrstev]; // pro kazdy "neuron_ve_vrstve" inicializuje tridu neuron[]
    for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
         neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrtsve[vrs] ];
          }

    vystupy.set_size(pocet_vystupu);
    vystupy.fill(999999);

    proud_soubor >> odpad >> typ_trenovani; //string, cislo = typ_trenovani

//    if (typ_trenovani <0 ) // kontrola nacteni typu trenovani
//    {
//        cout << "\n V teto verzi programu je podporovan pouze typ BP trenovani (volba 1). \n Opravte v souboru settings.txt."<<endl;
//        exit (EXIT_FAILURE);
//    }

    proud_soubor >> odpad >> learning_rate >> momentum  >> regul_alpha >> regul_beta >> pocet_epoch; //string, cislo = learning_rate

    if ((learning_rate <= 0)&&(learning_rate >1)) // kontrola nacteni learning rate
    {
        cout << "\n Zadana hodnota pro Learning rate neni programem podporovana. \n Opravte v souboru settings.txt."<<endl;
        exit (EXIT_FAILURE);
    }

    if ((momentum <= 0)&&(momentum>1)) // kontrola nacteni momentum
    {
        cout << "\n Zadana hodnota pro Momentum neni programem podporovana. \n Opravte v souboru settings.txt."<<endl;
        exit (EXIT_FAILURE);
    }
    proud_soubor >> odpad >> e1 >> e2 >> tau >> maxiter;

//    if ((e1<0)||(e2<0)||(tau<0)||(maxiter<0))  {
//        cout << "\nSpatne zadane parametry LevMar optimalizace\n."<<endl;
//        proud_soubor.close();
//        exit (EXIT_FAILURE);
//    }
    proud_soubor >>odpad >> delta_init >> eta_minus >> eta_plus >> deltamin >> deltamax >> BP_Rprop_pocet_epoch;

    //cout <<endl << eta_minus <<"\t" << eta_plus;

    if ((eta_minus <0) || (eta_plus < 0)|| (deltamin < 0)|| (deltamax < 0)){
        cout << "\nSpatne zadane parametry BPbatch Rprop optimalizace:  jsou mensi nebo rovny nule.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
    }

    if(eta_minus >1){
        cout << "\nSpatne zadane parametry BPbatch Rprop optimalizace:  eta_minus je vetsi nez 1.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    if(deltamax < deltamin){
        cout << "\nSpatne zadane parametry BPbatch Rprop optimalizace:  deltamin je vetsi nez deltamax.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    if(eta_minus > eta_plus){
        cout << "\nSpatne zadane parametry BPbatch Rprop optimalizace:  eta_minus je vetsi nez eta_plus.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    proud_soubor >> odpad >> eps >> c1 >> c2 >> CCmaxiter >> CC_restart_out >> CC_restart_period >> CC_restart_boundary >> CC_POWEL;

    if (eps < 0) {
        cout << "\nSpatne zadana hodnota parametru eps ConGrad optimalizace.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    if ((c1 < 0) ||(c1>1)){
        cout << "\nSpatne zadana hodnota parametru c1 ConGrad optimalizace.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    if ((c2 < 0) ||(c1>1)) {
        cout << "\nSpatne zadana hodnota parametru c2 ConGrad optimalizace.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    if (CCmaxiter <= 0) {
        cout << "\nSpatne zadana hodnota parametru CCmaxiter ConGrad optimalizace.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }
    
    proud_soubor >> odpad >> BBmaxiter >> BB_restart_out >> BB_restart_boundary >> BB_eps;

    if (BBmaxiter <= 0) {
        cout << "\nSpatne zadana hodnota parametru BBmaxiter SD_BB optimalizace.\n"<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
        }

    proud_soubor >> odpad >> Ensemble;

    if (pocet_epoch <= 0) // kontrola nacteni pocet epoch
    {
        cout << "\n Pocet epoch je mensi nebo roven 0. \n Opravte v souboru settings.txt. "<<endl;
        exit (EXIT_FAILURE);
    }

    proud_soubor >> odpad >> pocet_vzorovych_dat; //string, cislo = pocet_vzoru

    proud_soubor >> odpad >> pocet_data_test;

    proud_soubor >> odpad >> typ_init;

//    if (typ_init <0){
//            cout << "\nZadany typ initializace je mensi nez 0.";
//            proud_soubor.close();
//            exit (EXIT_FAILURE);
//    }

    proud_soubor >> odpad >> low_init >> up_init;

    if(up_init <= low_init){
        cout << "\nZadane hodnoty nahone inicilizace vah jsou nespravne."<<endl;
        proud_soubor.close();
        exit (EXIT_FAILURE);
    }


    proud_soubor >> odpad >> controls_out >> control_SS_error >> control_delta_par;

    if (control_SS_error <=0){
      cout << "\nPozor na zadani kontorlni sumy cvercu pro vypis vysledku.\n" ;
      proud_soubor.close();
        exit (EXIT_FAILURE);
    }

    proud_soubor >> odpad >> control_saturation >> saturation_sigma;


    unsigned int ppr =0;
    proud_soubor >> odpad >> ppr;

    if(ppr == 1) best_net = true;
        else best_net =false;

    ppr =0;
    proud_soubor >> ppr;

    if(ppr == 1) vypis_best_nets = true;
        else vypis_best_nets =false;

     proud_soubor >> index_bestnet_kriteria >> prah_kriteria;

    proud_soubor >> odpad;
    proud_soubor >> soubor_s_nastavenim_vzoru;

     if (pocet_vzorovych_dat == 0) // kontrola nacteni pocet vzoru
    {
        cout << "\n Zadany pocet vzorovych dat neni programem podporovan. \n Opravte v souboru settings.txt. "<<endl;
      proud_soubor.close();
        exit (EXIT_FAILURE);
    }

    proud_soubor >> odpad;
    proud_soubor >> cesta_pro_vypis_kriterii;

    proud_soubor >> odpad;
    proud_soubor >> soubor_s_nastavenim_test_vzoru;
    proud_soubor >> odpad;
    proud_soubor >> nazev_souboru_s_vypisem_site;
    proud_soubor >> odpad;
    proud_soubor >> cesta_pro_vypis_best_net_vah;
    proud_soubor >> odpad;
    proud_soubor >> cesta_pro_vypis_best_net_simulaci;
    proud_soubor >> odpad >> trenuj_ens_s_init_vahami >> soubor_s_init_vahami;
    proud_soubor >> odpad >> bench_OLS >> path_OLS_benchmark;

    proud_soubor.close(); // zavreni souboru settings.txt, nacitani dat je hotove

    pocet_vah = 0;

   pocet_neuronu = 0;
    //pocet neuronu v siti vcetne biasovskych neuronu
    for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
        pocet_neuronu = pocet_neuronu + pocet_neuronu_ve_vrtsve[vrs];
    }

   spocti_pocet_vah();

   vahy.set_size(pocet_vah);
   vahy.fill(9999);
   dE_vahy.set_size(pocet_vah);
   dE_vahy.fill(0.0);

   dF_vahy.set_size(pocet_vah);
   dF_vahy.fill(0.0);

   saturations.set_size(pocet_vah);
   saturations.fill(0.0);
   
   beta_OLS.set_size(pocet_vstupu + 1, pocet_vystupu);
   beta_OLS.fill(0.0);
   
   data_kal = new vzory[pocet_vzorovych_dat];
   file_nas_vzoru = new string[pocet_vzorovych_dat];
   file_nas_test_dat = new string[pocet_data_test];

   ifstream proud_naz_vzory(soubor_s_nastavenim_vzoru.c_str());

   if(!proud_naz_vzory){
           cout << "\nNemohu otevrit soubor s nastaveni vzoru: " << soubor_s_nastavenim_vzoru;
           exit(EXIT_FAILURE);
         }
   unsigned int   pom_pocet_soub=0;

         while (proud_naz_vzory.good()){
            getline (proud_naz_vzory,odpad);
            pom_pocet_soub++;
           }

           pom_pocet_soub--;
           pom_pocet_soub--;

           if(pom_pocet_soub != pocet_vzorovych_dat) {
                cout << "\nPocet nastaveni vzoru v souboru: " << soubor_s_nastavenim_vzoru << ": " << pom_pocet_soub << " neodpovida zadanemu nastaveni vzoru " << pocet_vzorovych_dat;
           proud_naz_vzory.close();
           exit(EXIT_FAILURE);

           }

       proud_naz_vzory.clear();
       proud_naz_vzory.seekg(0, ios::beg);
   for (unsigned int fi=0; fi <pocet_vzorovych_dat ;fi++ ){
      proud_naz_vzory >> file_nas_vzoru[fi];
      }
   proud_naz_vzory.close();

   data_kal = new vzory[pocet_vzorovych_dat];
   for (unsigned int vz = 0; vz < pocet_vzorovych_dat ; vz++ ){
     vzory  data_kons(file_nas_vzoru[vz].c_str());
     data_kal[vz] = data_kons;
     }


   ifstream proud_naz_test_vzory(soubor_s_nastavenim_test_vzoru.c_str());

   if(!proud_naz_test_vzory){
           cout << "\nNemohu otevrit soubor s nastaveni test vzoru: " << soubor_s_nastavenim_test_vzoru;
           exit(EXIT_FAILURE);
         }
   unsigned int   pom_test_pocet_soub=0;

         while (proud_naz_test_vzory.good()){
            getline (proud_naz_test_vzory,odpad);
            pom_test_pocet_soub++;
           }

           pom_test_pocet_soub--;
           pom_test_pocet_soub--;

           if(pom_test_pocet_soub != pocet_data_test) {
                cout << "\nPocet nastaveni test vzoru v souboru: " << soubor_s_nastavenim_test_vzoru << ": " << pom_test_pocet_soub << " neodpovida zadanemu nastaveni test vzoru " << pocet_vzorovych_dat;
           proud_naz_test_vzory.close();
           exit(EXIT_FAILURE);

           }

       proud_naz_test_vzory.clear();
       proud_naz_test_vzory.seekg(0, ios::beg);
   for (unsigned int fi=0; fi <pocet_data_test ;fi++ ){
      proud_naz_test_vzory >> file_nas_test_dat[fi];
      }
   proud_naz_test_vzory.close();


   data_test = new vzory[pocet_data_test];
   for (unsigned int vz = 0; vz < pocet_vzorovych_dat ; vz++ ){
     vzory  data_test_kons(file_nas_test_dat[vz].c_str());
     data_test[vz] = data_test_kons;
     }

    pocet_vzoru = 0;
    pocet_radku_test_dat = 0;

    VSTUPY.reset();
    VSTUPY_TEST.reset();
    VYSTUPY.reset();
    VYSTUPY_TEST.reset();
    SIM_VYSTUPY.reset();
    SIM_VYSTUPY_TEST.reset();
    REZIDUI.reset();
    J.reset();
    Hessian.reset();
    bestnet_vahy.reset();
    bestnet_vahy_initial.reset();
    real_pocet_bestnet = 0;
    SS_vah = 0.0;
    SS_er = 0.0;
    LAG = 0;
}

neural_net::~neural_net() //destruktor, zbavujeme se inicializovanych poli
{
    // odstraneni neuronu ve skrytych vrstvach
   for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
    delete[] neuron_ve_vrstve[vrs];
}

  delete[] neuron_ve_vrstve; // odstraneni vrstvy

    //nejdriv odstranujeme neurony ve vrstvach, potom jejich pocty a typy aktivacnich fci
    if (pocet_vrstev != 0) {
      delete[] pocet_neuronu_ve_vrtsve;
      delete[] typ_akt_fci;
    }

    if(pocet_vzorovych_dat!=0){
      delete[] file_nas_vzoru;
      delete[] data_kal;
    }


    if(pocet_data_test !=0){
        delete[] file_nas_test_dat;
        delete[] data_test;
    }
}


/**
  * Pretizeny konstruktor
  */
neural_net::neural_net(const neural_net& other) // kopirovaci konstruktor
{
        pocet_vstupu = other.pocet_vstupu;
        typ_trenovani = other.typ_trenovani;
        typ_init = other.typ_init;
        pocet_epoch = other.pocet_epoch;
        pocet_radku_test_dat = other.pocet_radku_test_dat;

        soubor_s_nastavenim_test_vzoru = other.soubor_s_nastavenim_test_vzoru;
        soubor_s_nastavenim_vzoru = other.soubor_s_nastavenim_vzoru;

        if((pocet_vzorovych_dat != other.pocet_vzorovych_dat)&&(pocet_vzorovych_dat > 0)){
            delete[] file_nas_vzoru;
            delete[] data_kal;
        }

        pocet_vzorovych_dat = other.pocet_vzorovych_dat;
        file_nas_vzoru = new string[pocet_vzorovych_dat];
        data_kal = new vzory[pocet_vzorovych_dat];

        for (unsigned int fi=0; fi<pocet_vzorovych_dat ;fi++ ){
          file_nas_vzoru[fi] = other.file_nas_vzoru[fi];
          }

        for (unsigned int vz = 0; vz < pocet_vzorovych_dat ; vz++ ){
           data_kal[vz] = other.data_kal[vz];
        }

        if((pocet_data_test != other.pocet_data_test)&&(pocet_data_test >0)){
            delete[] file_nas_test_dat;
            delete[] data_test;
        }

        pocet_data_test = other.pocet_data_test;
        file_nas_test_dat = new string[pocet_data_test];
        data_test = new vzory[pocet_data_test];
        for (unsigned int fi=0; fi<pocet_data_test ;fi++ ){
          file_nas_test_dat[fi] = other.file_nas_test_dat[fi];
          }

        for (unsigned int vz = 0; vz < pocet_vzorovych_dat ; vz++ ){
          data_test[vz] = other.data_test[vz];
          }

        pocet_neuronu = other.pocet_neuronu;
        pocet_vah = other.pocet_vah;
        pocet_vystupu = other.pocet_vystupu;
        vystupy = other.vystupy;
        vahy =other.vahy;
        dE_vahy = other.dE_vahy;
        dF_vahy = other.dF_vahy;
        saturations = other.saturations;
        LAG = other.LAG;

        SS_vah = other.SS_vah;
        SS_er = other.SS_er;
        Ensemble = other.Ensemble;

        controls_out = other.controls_out;
        control_delta_par = other.control_delta_par;
        control_SS_error = other. control_SS_error;

        control_saturation = other.control_saturation;
        saturation_sigma = other.saturation_sigma;

        if( pocet_vrstev  != other.pocet_vrstev) {
         if (pocet_vrstev >0) {
            delete[] pocet_neuronu_ve_vrtsve;
            delete[] typ_akt_fci;
         }
        pocet_neuronu_ve_vrtsve = new unsigned int[other.pocet_vrstev];
        typ_akt_fci =  new unsigned int[other.pocet_vrstev];
        }

        momentum = other.momentum;
        regul_alpha = other.regul_alpha;
        regul_beta = other.regul_beta;
        learning_rate = other.learning_rate;

        bias_ano_ne = other.bias_ano_ne;
        bias_const = other.bias_const;

        e1 = other.e1;
        e2 = other.e2;
        tau = other.tau;
        maxiter = other.maxiter;

        eps = other.eps;
        c1 = other.c1;
        c2 = other.c2;
        CCmaxiter = other.CCmaxiter;
        CC_restart_out = other.CC_restart_out;
        CC_restart_period = other.CC_restart_period;
        CC_restart_boundary = other.CC_restart_boundary;
        CC_POWEL = other.CC_POWEL;
        
        BBmaxiter = other.BBmaxiter;
        BB_eps = other.BB_eps;
        BB_restart_boundary = other.BB_restart_boundary;
        BB_restart_out = other.BB_restart_out;

        delta_init = other. delta_init;
        eta_minus = other.eta_minus;
        eta_plus = other.eta_plus;
        deltamax = other.deltamax;
        deltamin = other. deltamin;
        BP_Rprop_pocet_epoch = other.BP_Rprop_pocet_epoch;

        if( pocet_vrstev != other.pocet_vrstev) {
         if (pocet_vrstev >0) {
            delete[] neuron_ve_vrstve;
         }
        neuron_ve_vrstve = new neuron*[other.pocet_vrstev];
        }

        pocet_vrstev = other.pocet_vrstev;

        for (unsigned int vrs = 0; vrs <other.pocet_vrstev ;vrs++ ) {
         	pocet_neuronu_ve_vrtsve[vrs] = other.pocet_neuronu_ve_vrtsve[vrs];
         	typ_akt_fci[vrs] = other.typ_akt_fci[vrs];
         }


        for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
           neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrtsve[vrs] ];
          }

          for (unsigned int vrs = 0; vrs <pocet_vrstev ;vrs++ ) {
              for(unsigned int neur = 0;neur <pocet_neuronu_ve_vrtsve[vrs];neur++)
                 neuron_ve_vrstve[vrs][neur] = other.neuron_ve_vrstve[vrs][neur];
          }
          
          path_OLS_benchmark = other.path_OLS_benchmark;
          beta_OLS = other.beta_OLS;
          bench_OLS = other.bench_OLS;
          
          pocet_vzoru = other.pocet_vzoru;
          VSTUPY = other.VSTUPY;
          VSTUPY_TEST = other.VSTUPY_TEST;
          VYSTUPY = other.VYSTUPY;
          VYSTUPY_TEST = other. VYSTUPY_TEST;
          SIM_VYSTUPY = other.SIM_VYSTUPY;
          SIM_VYSTUPY_TEST = other.SIM_VYSTUPY_TEST;
          REZIDUI = other.REZIDUI;

          cesta_pro_vypis_kriterii = other.cesta_pro_vypis_kriterii;
          cesta_pro_vypis_best_net_vah = other.cesta_pro_vypis_best_net_vah;
          cesta_pro_vypis_best_net_simulaci = other.cesta_pro_vypis_best_net_simulaci;
          nazev_souboru_s_vypisem_site = other.nazev_souboru_s_vypisem_site;

          J = other.J;
          Hessian = other.Hessian;

          low_init = other.low_init;
          up_init = other.up_init;

          best_net = other.best_net;
          vypis_best_nets = other.vypis_best_nets;
          index_bestnet_kriteria = other.index_bestnet_kriteria;
          prah_kriteria = other.prah_kriteria;
          bestnet_vahy = other.bestnet_vahy;
          bestnet_vahy_initial = other.bestnet_vahy_initial;
          trenuj_ens_s_init_vahami = other.trenuj_ens_s_init_vahami;
          soubor_s_init_vahami = other.soubor_s_init_vahami;
}

/**
  * Prirazovaci operator
  */
neural_net& neural_net::operator=(const neural_net& other)
{
    if (this == &other) return *this; // handle self assignment
        else {

        pocet_vstupu = other.pocet_vstupu;
        typ_trenovani = other.typ_trenovani;
        typ_init = other.typ_init;
        pocet_epoch = other.pocet_epoch;
        
        LAG = other.LAG;

        pocet_neuronu = other.pocet_neuronu;
        pocet_vah = other.pocet_vah;
        pocet_vystupu = other.pocet_vystupu;
        vystupy = other.vystupy;
        pocet_radku_test_dat = other.pocet_radku_test_dat;

         if(pocet_vrstev >0){
            for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
                    delete[] neuron_ve_vrstve[vrs];
                    }
            delete[] neuron_ve_vrstve;
            delete[] pocet_neuronu_ve_vrtsve;
            delete[] typ_akt_fci;

            pocet_vrstev = other.pocet_vrstev;

            typ_akt_fci = new unsigned int[pocet_vrstev];
            pocet_neuronu_ve_vrtsve = new unsigned int[pocet_vrstev];

            for (unsigned int vrs = 0; vrs <other.pocet_vrstev ;vrs++ ) {
         	   pocet_neuronu_ve_vrtsve[vrs] = other.pocet_neuronu_ve_vrtsve[vrs];
         	   typ_akt_fci[vrs] = other.typ_akt_fci[vrs];
              }

            neuron_ve_vrstve = new neuron*[pocet_vrstev]; // pro kazdy "neuron_ve_vrstve" inicializuje tridu neuron[]
            for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++) {
                     neuron_ve_vrstve[vrs] = new neuron[pocet_neuronu_ve_vrtsve[vrs]];
                }

           for (unsigned int vrs = 0; vrs <pocet_vrstev ;vrs++ ) {
              for(unsigned int neur = 0;neur <pocet_neuronu_ve_vrtsve[vrs];neur++)
                 neuron_ve_vrstve[vrs][neur] = other.neuron_ve_vrstve[vrs][neur];
                }

          }

        vahy = other.vahy;
        dE_vahy = other.dE_vahy;
        dF_vahy = other.dF_vahy;
        saturations = other.saturations;

        momentum = other.momentum;
        learning_rate = other.learning_rate;
        regul_alpha = other.regul_alpha;
        regul_beta = other.regul_beta;

        bias_ano_ne = other.bias_ano_ne;
        bias_const =other.bias_const;

        soubor_s_nastavenim_vzoru = other.soubor_s_nastavenim_vzoru;

        e1 = other.e1;
        e2 = other.e2;
        tau = other.tau;
        maxiter = other.maxiter;

        eps = other.eps;
        c1 = other.c1;
        c2 = other.c2;
        CCmaxiter = other.CCmaxiter;
        CC_restart_out = other.CC_restart_out;
        CC_restart_period = other.CC_restart_period;
        CC_restart_boundary = other.CC_restart_boundary;
        CC_POWEL = other.CC_POWEL;
        
        BBmaxiter = other.BBmaxiter;
        BB_eps = other.BB_eps;
        BB_restart_boundary = other.BB_restart_boundary;
        BB_restart_out = other.BB_restart_out;        

        controls_out = other.controls_out;
        control_delta_par = other.control_delta_par;
        control_SS_error = other. control_SS_error;

        control_saturation = other.control_saturation;
        saturation_sigma = other.saturation_sigma;

        Ensemble = other.Ensemble;

        SS_vah = other.SS_vah;
        SS_er = other.SS_er;

        delta_init = other. delta_init;
        eta_minus = other.eta_minus;
        eta_plus = other.eta_plus;
        deltamax = other.deltamax;
        deltamin = other. deltamin;
        BP_Rprop_pocet_epoch = other.BP_Rprop_pocet_epoch;

      if(pocet_vzorovych_dat >0) {
        delete[] data_kal;
        delete[] file_nas_vzoru;
      }

        pocet_vzorovych_dat = other.pocet_vzorovych_dat;
        file_nas_vzoru = new string[pocet_vzorovych_dat];

        for (unsigned int fi=0; fi<pocet_vzorovych_dat ;fi++ ){
          file_nas_vzoru[fi] = other.file_nas_vzoru[fi];
          }

       data_kal = new vzory[pocet_vzorovych_dat];
       for (unsigned int vz = 0; vz < pocet_vzorovych_dat ; vz++ ){
         data_kal[vz] = other.data_kal[vz];
       }

       if(pocet_data_test >0){
          delete[] data_test;
          delete[] file_nas_test_dat;
       }

       pocet_data_test = other.pocet_data_test;
       file_nas_test_dat = new string[pocet_data_test];


      for (unsigned int fi=0; fi<pocet_data_test ;fi++ ){
          file_nas_test_dat[fi] = other.file_nas_test_dat[fi];
          }

       data_test = new vzory[pocet_data_test];
       for (unsigned int vz = 0; vz < pocet_data_test; vz++ ){
         data_test[vz] = other.data_test[vz];
       }

      pocet_vzoru = other.pocet_vzoru;
      VSTUPY = other.VSTUPY;
      VSTUPY_TEST = other.VSTUPY_TEST;
      VYSTUPY = other.VYSTUPY;
      VYSTUPY_TEST = other.VYSTUPY_TEST;
      SIM_VYSTUPY = other.SIM_VYSTUPY;
      SIM_VYSTUPY_TEST = other.SIM_VYSTUPY_TEST;
      REZIDUI = other.REZIDUI;
      cesta_pro_vypis_kriterii = other.cesta_pro_vypis_kriterii;
      cesta_pro_vypis_best_net_vah = other.cesta_pro_vypis_best_net_vah;
      cesta_pro_vypis_best_net_simulaci = other.cesta_pro_vypis_best_net_simulaci;
      nazev_souboru_s_vypisem_site = other.nazev_souboru_s_vypisem_site;

      J = other.J;
      Hessian = other.Hessian;

      low_init = other.low_init;
      up_init = other.up_init;

      best_net = other.best_net;
      vypis_best_nets = other.vypis_best_nets;
      index_bestnet_kriteria = other.index_bestnet_kriteria;
      prah_kriteria = other.prah_kriteria;
      bestnet_vahy = other.bestnet_vahy;
      bestnet_vahy_initial =other.bestnet_vahy_initial;
      trenuj_ens_s_init_vahami = other.trenuj_ens_s_init_vahami;
      soubor_s_init_vahami = other.soubor_s_init_vahami;
      
      path_OLS_benchmark = other.path_OLS_benchmark;
      beta_OLS = other.beta_OLS;
      bench_OLS = other.bench_OLS;

    }//assignment operator
    return *this;
}

/**
 * Vypise neuronovou sit do souboru
  * @param nazev souboru pro vypis site
 */
void neural_net::vypis_neural_net(string nazev_souboru)
{
    ofstream proud_soubor(nazev_souboru.c_str());

    if(!proud_soubor) { // osetreni jestli je soubor mozne otevrit
      cout << "\n Chyba v otevreni souboru s nastavenim site."<<endl;
      exit(EXIT_FAILURE);
    }

    proud_soubor << "Architektura_neuronove_site:" << endl;
    proud_soubor << "Pocet_vstupu: " << pocet_vstupu << endl;
    proud_soubor << "Pocet_vrstev: " << pocet_vrstev << endl;
    proud_soubor  << "Pocet_neuronu_ve_vrstvach:  ";
    for (unsigned int vrs=0; vrs < pocet_vrstev; vrs++ ){
        if((bias_ano_ne) &&(vrs !=pocet_vrstev -1) ){
      	proud_soubor << pocet_neuronu_ve_vrtsve[vrs] -1 <<"\t";
        } else {
        proud_soubor << pocet_neuronu_ve_vrtsve[vrs]  <<"\t";
        }
    }
    proud_soubor << endl;
    proud_soubor << "Typ_akt_fce_sigmoida_0_linearni_1_htangenta_2_gauss_3_inv_abs_4_loglog_5_cloglog_6_cloglogm_7_ROOTSIG_8_LOGSIG_9_SECH_10_WAVE_11: " ;
    for (unsigned int vrs=0; vrs < pocet_vrstev; vrs++ ){
      	proud_soubor << typ_akt_fci[vrs] <<"\t";
    }
    proud_soubor << endl;
    proud_soubor << "Pocet_vystupu: " << pocet_vystupu << endl;
    proud_soubor << "Bias_ANO_NE: " << bias_ano_ne << endl;
    proud_soubor << "Trenovani_BPonline_0_BPonlineregul_1_BPbatch_2_BPbatchregul_3_LMbatch_4_LMbatchregul_5_BPRpropPLUS_6_BPRpropMINUS_7_ScConGrad_Perry_8_ScConGrad_HEST_9_ScConGrad_FLETCHER_10_ScConGrad_POLAK_11:  " << typ_trenovani << endl;

    proud_soubor << "BP_Learning_rate_Momentum_Regul_Alpha_Regul_Beta_Pocet_Epoch: " << learning_rate << "\t" <<  momentum<< "\t"  << regul_alpha<< "\t"  << regul_beta<< "\t"  << pocet_epoch << endl;

    proud_soubor << "LevMar_parametery_e1_e2_tau_maxiter: " << e1<< "\t"  << e2<< "\t"  << tau<< "\t"  << maxiter << endl;
    proud_soubor << "BP_Rprop_deltainit_etaminus_etaplus_deltamin_deltamax_pocet_epoch: " << delta_init << "\t" << eta_minus<< "\t"  << eta_plus<< "\t"  << deltamin<< "\t"  << deltamax<< "\t"  << BP_Rprop_pocet_epoch <<endl;
    proud_soubor << "ConGrad_eps_c1linesearch_c2braketing_maxiter: " << eps<< "\t"   << c1<< "\t"   << c2<< "\t"   << CCmaxiter<< "\t" << CC_restart_out  << "\t" << CC_restart_period << "\t" << CC_restart_boundary << endl;
    proud_soubor <<  "SD_BB_BB_maxiiter_BB_restart_out_BB_restart_boundary_BB_eps: " << BBmaxiter << "\t" << BB_restart_out << "\t" << BB_restart_boundary << "\t" << BB_eps << endl;
    proud_soubor << "Ensemble_simulace: " << Ensemble << endl;
    proud_soubor << "Pocet_kal_vzoru: " << pocet_data_test << endl;
    proud_soubor << "Pocet_test_vzoru: " << pocet_data_test << endl;
    proud_soubor << "RAND_INIT_TYPE_unit_interval_0_Widrow_Nguyen_1: " << typ_init << endl;
    proud_soubor << "Interval_of_unif_rand_init_low_init_up_init: " << low_init << "\t" << up_init << endl;
    proud_soubor << "Vypis_controls_out_control_SS_error_control_delta_par: " << controls_out << "\t" << control_SS_error << "\t" << control_delta_par << endl;
    proud_soubor << "Saturace_neuronu_control_saturation_saturation_sigma: " << control_saturation << "\t" << saturation_sigma << endl;
    proud_soubor << "Selection_of_best_nets_Zda_best_net_Zda_vypis_Best_net_kriterium_Prahova_hodnota_kriteria: " << best_net << "\t" << vypis_best_nets << "\t" << index_bestnet_kriteria << "\t" << prah_kriteria << endl;

    proud_soubor << "Soubor_s_nastavenim_kal_vzoru: " << soubor_s_nastavenim_vzoru.c_str() << endl;
    proud_soubor << "Cesta_pro_vypis_kal_kriterii: " << cesta_pro_vypis_kriterii.c_str() << endl;
    proud_soubor << "Soubor_s_nastavenim_test_vzoru: " << soubor_s_nastavenim_test_vzoru.c_str()  << endl;
    proud_soubor << "Vypis_souboru_s_nastavenim_site: "    << nazev_souboru_s_vypisem_site.c_str() << endl;
    proud_soubor << "Cesta_pro_vypis_ensemblu_vah_bestnets: "    << cesta_pro_vypis_best_net_vah.c_str() << endl;
    proud_soubor << "Cesta_pro_vypis_ensemblu_simulaci_bestnets: "  << cesta_pro_vypis_best_net_simulaci.c_str() << endl;
    proud_soubor << "Vypis_init_vah_bestnetu_Soubor_s_pocatecnimi_vahami_pro_ensemble_kalibraci: " << trenuj_ens_s_init_vahami << "\t"<< soubor_s_init_vahami.c_str() << endl;
    proud_soubor << "Benchmark_Linear_Model_YES_OLS_Benchmark_Path_pro_vypis:  " << bench_OLS << "\t" << path_OLS_benchmark;
    proud_soubor << endl;
    proud_soubor.close();
}


/**
  * Provede inicilaizaci NN site pred vypoctem
  */
void neural_net::inicializuj() //fce je volana z main.cpp a meni puvodni stav nn site
{
    colvec pom_vstupy; // pomocny sloupcovy vektor vstupu
    rowvec pom_vahy; // pomocny radkovy vektor vah
    int Bias = 0;   // vychozi hodnota biasu
    if (bias_ano_ne){ // kdyz je bias 1 v souboru settings.txt
 //      for (int i = 0; i < pocet_vrstev-1; i++) {
 //           pocet_neuronu_ve_vrtsve[i] = pocet_neuronu_ve_vrtsve[i]+1;
 //      }
        Bias = 1;
    }

    unsigned int pom_pr=0;

    for (unsigned int vrs=0; vrs < pocet_vrstev; vrs++ ) { // pro jednotlive vrstvy
    	for (unsigned int neur=0; neur < pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) {
        if (vrs == 0 ) { // pro prvni vrstvu vyplni vektor vah a vstupu pro kazdy neuron
            pom_vstupy.set_size(pocet_vstupu);
            pom_vstupy.fill(0.0);
            pom_vahy.set_size(pocet_vstupu);
            pom_vahy.fill(0.0);
         //   pom_vahy=pom_vahy*0.10;// nahodne generovane
         } else { //pro dalsi vrstvy rozsiri vektor vstupu a vah
           pom_vstupy.reshape(pocet_neuronu_ve_vrtsve[vrs-1] - Bias,1);
         // pom_vstupy(pocet_neuronu_ve_vrtsve[vrs-1]) = rand();
           pom_vstupy.fill(0.0);
           pom_vahy.reshape(1,pocet_neuronu_ve_vrtsve[vrs-1] - Bias);
           pom_vahy.fill(0.0);
     //      pom_vahy=pom_vahy*0.10;
         }
    	    pom_pr++;
    	    if(bias_ano_ne){
               if((vrs ==0) && (neur!=pocet_neuronu_ve_vrtsve[vrs]-1)) neuron_ve_vrstve[vrs][neur].premen(pocet_vstupu, pom_vstupy, pom_vahy, bias_ano_ne, typ_akt_fci[vrs]);
               if((vrs != 0) && (neur!=pocet_neuronu_ve_vrtsve[vrs]-1)) neuron_ve_vrstve[vrs][neur].premen(pocet_neuronu_ve_vrtsve[vrs-1] - Bias, pom_vstupy, pom_vahy, bias_ano_ne, typ_akt_fci[vrs]);
               if((vrs < pocet_vrstev -1) && (neur == pocet_neuronu_ve_vrtsve[vrs]-1))  {
                               pom_vstupy.set_size(1,1);
                               pom_vstupy.fill(1);
                               pom_vahy.set_size(1,1);
                               pom_vahy.fill(1);
                             //  cout << "UPSSS" << pom_vstupy <<pom_vahy << "\n";
                               neuron_ve_vrstve[vrs][neur].premen(1, pom_vstupy, pom_vahy, false, 1);
                               neuron_ve_vrstve[vrs][neur].vypocti();
                            //   neuron_ve_vrstve[vrs][neur].vypis_neuron();
               }
               if ((vrs == pocet_vrstev -1) &&(neur == pocet_neuronu_ve_vrtsve[vrs]-1)){
                    neuron_ve_vrstve[vrs][neur].premen(pocet_neuronu_ve_vrtsve[vrs-1] - Bias, pom_vstupy, pom_vahy, bias_ano_ne, typ_akt_fci[vrs]);
                 //   neuron_ve_vrstve[vrs][neur].vypis_neuron();
                    }
         	}
            else {
                if(vrs == 0)  neuron_ve_vrstve[vrs][neur].premen(pocet_vstupu, pom_vstupy, pom_vahy, bias_ano_ne, typ_akt_fci[vrs]);
                  else neuron_ve_vrstve[vrs][neur].premen(pocet_neuronu_ve_vrtsve[vrs-1]-Bias , pom_vstupy, pom_vahy, bias_ano_ne, typ_akt_fci[vrs]);
               }
               pom_pr++;
         	}

    }

 //   cout << endl<< pocet_vah << endl;
    prirad_do_vahy();
    rand_vahy();
    prirad_z_vahy();
}

/**
  * Stanovi pocet vah v NN siti
  */
void neural_net::spocti_pocet_vah() // fce na vypocet poctu vah v siti, potrebuje pocet neuronu, ten je inicializovany uz pri nacitani site ze settings.txt
{
    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }
    // pocet vah stanovenych bez biasovske vahy
    for (unsigned int vrs = 0; vrs < pocet_vrstev; vrs++)
    {
        if(vrs == 0) pocet_vah = (pocet_vstupu +Bias) * (pocet_neuronu_ve_vrtsve[vrs]-Bias);
          else if (vrs <(pocet_vrstev -1) )  pocet_vah += (pocet_neuronu_ve_vrtsve[vrs-1])*(pocet_neuronu_ve_vrtsve[vrs] -Bias);
             else if (vrs == (pocet_vrstev -1) )  pocet_vah += (pocet_neuronu_ve_vrtsve[vrs-1])*(pocet_neuronu_ve_vrtsve[vrs] );
    }

}

/**
 * Provede sireni signalu MLP, stanovi vystup
 * @param vstupy bez biasovske nuly
 */
void neural_net::vypocti_1vzor(colvec pom_vstupy)
{
    if (pom_vstupy.n_elem !=  pocet_vstupu){
       cout << "\n Pocet vstupu predavanych polem do NN site neodpovida nastaveni NN site. \n";\
       exit(EXIT_FAILURE);
    }
   int  Bias=0;
   if (bias_ano_ne) { // fce kontroluje bias pri zadavani, jestli je sit pri inicializacii s biasem
       pom_vstupy.reshape(pom_vstupy.n_elem +1,1);
       pom_vstupy(pom_vstupy.n_elem-1) = 1;
       Bias = 1;
   }
//cout << endl << "ups" << endl << endl;
    for (unsigned int vrs=0;vrs<pocet_vrstev ; vrs++) // pro kazdou vrstvu
    {
    	if(vrs ==0){ // v prvni vrstve
    	  for (unsigned int neur = 0;neur < pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ )	{ // pro sit s biasem, pro kazdy neuron v prvni vrtsve
             neuron_ve_vrstve[vrs][neur].vstupy = pom_vstupy; // vypocita vstupy
    		 neuron_ve_vrstve[vrs][neur].vypocti(); //vypocita neuron pomoci jeho fce "vypocti()"
  //           neuron_ve_vrstve[vrs][neur].vypis_neuron();
    		 }
    	} else if(vrs!=pocet_vrstev-1) { // v dalsich vrstvach
    	     for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] - Bias ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
    	        {
    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
    	        }
    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
  //  	     neuron_ve_vrstve[vrs][neur].vypis_neuron();
    	     }
    	} else { // jinak pro sit bez biasu
    	    for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
    	        {
    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
    	        }
    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
//    	     neuron_ve_vrstve[vrs][neur].vypis_neuron();
    	     }
    	   }
    }
    for(unsigned int vys=0;vys<pocet_vystupu;vys++){
              vystupy(vys) = neuron_ve_vrstve[pocet_vrstev-1][vys].vystup;
    }
}

/**
 * Rozhrani pro volbu ruznych trenovani
 */
void neural_net::trenuj(){
    vzory *zaloha_kal, * zaloha_test;

    zaloha_kal = new vzory[pocet_vzorovych_dat];
    zaloha_test = new vzory[pocet_data_test];

    for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      zaloha_kal[vzk] = data_kal[vzk];
      }
    for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      zaloha_test[vzt] = data_test[vzt];
      }


    priprav_data_k_trenovani();
    priprav_testovaci_data();
    LAG_control();
    prirad_do_vahy();
    
    if (bench_OLS) benchmark_OLS();

   // cout <<endl << 0. << " \t " << norm(dE_vahy,2) << " \t " << norm(vahy,2) << " \t " << (norm(REZIDUI,2)) << "\n";
    switch (typ_trenovani) // na zaklade typu trenovani vyberu metodu trenovani site
    {
    	case BPonline:
       	    bp_online();
    		break;
    	case BPonline_regul:
       	    bp_online_regul();
    		break;
        case BPbatch:
       	    bp_batch();
    		break;
        case BPbatch_regul:
       	    bp_batch_regul();
    		break;
        case LMbatch:
           LevM_batch();
           break;
         case LMbatch_regul:
           LevM_batch_regul();
           break;
         case BPbatch_RpropPLUS:
           bp_RpropPLUS();
           break;
         case BPbatch_RpropMINUS:
           bp_RpropMINUS();
           break;
         case ScCoCr_PERRY:
           ScConGrad_Perry();
           break;
          case ScCoCr_HESTENES:
           ScConGrad_Hestenes();
           break;
          case ScCoCr_FLETCHER:
           ScConGrad_Fletcher();
           break;
          case ScCoCr_POLAK:
           ScConGrad_Polak();
           break;
          case StepD_BaBo:
           StepD_BB();
           break;
          default:
            break;
    }

   for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
                if(data_kal[vz].shuffle_indexy) {
                    data_kal[vz].prehazej_vzory_zpet(true,true,false);
                }
            }
   vypocti_allvzory();
   vypocti_allvzory_test();
   
    stringstream lag_slovo;
    lag_slovo << LAG << "_LAG_";

   string slovo_mer_kal, slovo_sim_kal;
   slovo_mer_kal = "/OUT_OBS_KAL_" + lag_slovo.str();
   slovo_sim_kal = "/OUT_SIM_KAL_" + lag_slovo.str();

   string slovo_mer_test, slovo_sim_test;
   slovo_mer_test += "/OUT_OBS_TEST_" + lag_slovo.str();
   slovo_sim_test += "/OUT_SIM_TEST_" + lag_slovo.str();

  //  cout << data[0].sim_vystupy<< endl;
  for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
     data_kal[vz].transformuj_zpetne(true,true,true);
     data_kal[vz].vypis_vystupy(slovo_mer_kal);
     data_kal[vz].vypis_sim_vystupy(slovo_sim_kal);
    }

  for (unsigned int vz = 0; vz < pocet_data_test ;vz++ ){
     data_test[vz].transformuj_zpetne(true,true,true);
     data_test[vz].vypis_vystupy(slovo_mer_test);
     data_test[vz].vypis_sim_vystupy(slovo_sim_test);
    }

     for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      data_kal [vzk] = zaloha_kal[vzk];
      }
    for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      data_test[vzt] = zaloha_test[vzt];
      }

   delete[] zaloha_kal;
   delete[] zaloha_test;
}


/**
  * Online BP
  */
void neural_net::bp_online()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    for (unsigned int epocha= 0; epocha < pocet_epoch; epocha++ ){
     for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
         backpropagation_ONLINE_basic_step(trans(data_kal[vz].data_vstupu.row(vzor)), trans(data_kal[vz].data_vystupu.row(vzor)));
                  }
      }
    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPonline_");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPonline_");
      prirad_do_vahy();
      vypocti_allvzory();
      cout <<endl << epocha+1 << "\t" << norm(dE_vahy,2) << "\t" << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) break;
     if(control_delta_par >= delta_normy_zmeny_vahy) break;
   }
}

/**
  * Online BP s regularizaci
  */
void neural_net::bp_online_regul()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;

    for (unsigned int epocha= 0; epocha < pocet_epoch; epocha++ ){
     for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
         backpropagation_ONLINE_basic_step_regul(trans(data_kal[vz].data_vstupu.row(vzor)), trans(data_kal[vz].data_vystupu.row(vzor)));
                  }
      }
    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPonlineregul_");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPonlineregul_");
      prirad_do_vahy();
      vypocti_allvzory();
      cout <<endl << epocha+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }
   }
}

/**
  * Zakladni krok BP algoritmu  pro jeden vzor
  */
void neural_net::backpropagation_ONLINE_basic_step(colvec vzor_vstupy, colvec vzor_vystup)
{
      vypocti_1vzor(vzor_vstupy); // nejprve vypocita chybu na vystupu ze site
      zmen_vahy_1vzor(vzor_vstupy, vzor_vystup); // nasledne zmeni vahy podla teto chyby
}

/**
  * Zakladni krok BP algoritmu  s regularizaci pro jeden vzor
  */
void neural_net::backpropagation_ONLINE_basic_step_regul(colvec vzor_vstupy, colvec vzor_vystup)
{
      vypocti_1vzor(vzor_vstupy); // nejprve vypocita chybu na vystupu ze site
      zmen_vahy_1vzor_regul(vzor_vstupy, vzor_vystup); // nasledne zmeni vahy podla teto chyby
}

/**
  * Stanovi pro jeden vzor zmenu vah v siti, potom co sit vypocitala chybui, vynuluje delty
  */
void neural_net::zmen_vahy_1vzor(colvec vzor_vstupy, colvec vzor_vystup)
{
   colvec pom_delta; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti
   pom_delta.set_size(pocet_vystupu); // inicializace premenne tak, aby mela velikost jako je pocet vystupu ze site
  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu -1) =1;
  }

   pom_delta = vzor_vystup - vystupy; // vypocet rozdilu
  // cout << pom_delta;
 //  cout << pocet_vrstev <<"\n";
   unsigned int vrs = 0;
  // for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index;
       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                   double pom_dw =0.0;
                   pom_dw = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1) );
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta(neur) * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dE_dw(neur1) =  neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup;
                   // vypocitej zmenu vah bp_online a zmen danou vahu tak, ze se na vypocet pouziji hodnoty z predchazejicich neuronu
               	   neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
               	   neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) =  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                }
             }
//cout << "ups" << neuron_ve_vrstve[vrs][0].delta_vahy <<"\n";
          }
        else {
//            double pom_dw =0.0;
                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) = neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup;
                        neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                        neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) = learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                         }
                   }
                }

                else  if(vrs == 0){
                // vstupy do prvni skryte vrstvy
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) = neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1);
                        neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                        neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) = learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                         }
                   }
                   break;
                }
        }
    }//vrstvy
    nulovani_delt();
}

/**
  * Stanovi pro jeden vzor zmenu vah v siti, potom co sit vypocitala chybu vyuzije regularizaci, vynuluje delty
  */
void neural_net::zmen_vahy_1vzor_regul(colvec vzor_vstupy, colvec vzor_vystup)
{
   colvec pom_delta; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti
   pom_delta.set_size(pocet_vystupu); // inicializace premenne tak, aby mela velikost jako je pocet vystupu ze site
  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu -1) =1;
  }

   pom_delta = vzor_vystup - vystupy; // vypocet rozdilu
  // cout << pom_delta;
 //  cout << pocet_vrstev <<"\n";
 unsigned int vrs = 0;
 //  for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index;
       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                   double pom_dw =0.0;
                   pom_dw = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1) );
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta(neur) * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dE_dw(neur1) =  regul_beta * neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup +regul_alpha *neuron_ve_vrstve[vrs][neur].vahy(neur1);
                   // vypocitej zmenu vah bp_online a zmen danou vahu tak, ze se na vypocet pouziji hodnoty z predchazejicich neuronu
               	   neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
               	   neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) =  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                }
             }
//cout << "ups" << neuron_ve_vrstve[vrs][0].delta_vahy <<"\n";
          }
        else {
//            double pom_dw =0.0;
                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) = regul_beta * neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup+regul_alpha *neuron_ve_vrstve[vrs][neur].vahy(neur1);
                        neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                        neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) = learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                         }
                   }
                }

                else  if(vrs == 0){
                // vstupy do prvni skryte vrstvy
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) = regul_beta * neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1)+regul_alpha *neuron_ve_vrstve[vrs][neur].vahy(neur1);
                        neuron_ve_vrstve[vrs][neur].vahy(neur1) +=  learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                        neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1) = learning_rate*neuron_ve_vrstve[vrs][neur].dE_dw(neur1) + momentum * neuron_ve_vrstve[vrs][neur].iter_delta_vah(neur1);
                         }
                   }
                   break;
                }
        }
    }//vrstvy
    nulovani_delt();
}

/**
  * Priradi do vektoru vah a vektrou derivaci aktualni hodnoty vah a derivaci v neuronove siti
  */
void neural_net::prirad_do_vahy()
{
    unsigned int pom_pocet = 0, pom_pocet1 = 0;
    unsigned int pom_index = 0;

    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }

    for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){
        if(vrs == 0) {
            pom_pocet1 = pocet_vstupu + Bias;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] - Bias;
           }
           else if((vrs < (pocet_vrstev-1))&&(vrs>0)) {
            pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] -Bias;
             } else if(vrs == (pocet_vrstev-1)){
                     pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
                     pom_pocet = pocet_neuronu_ve_vrtsve[vrs] ;
             }

        for (unsigned int neur = 0; neur < pom_pocet; neur++ ){
          for (unsigned int neur1 = 0; neur1 < pom_pocet1; neur1++ ){
           vahy(pom_index) = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1));
           dE_vahy(pom_index) = as_scalar(neuron_ve_vrstve[vrs][neur].dE_dw(neur1));
           dF_vahy(pom_index) = as_scalar(neuron_ve_vrstve[vrs][neur].dF_dw(neur1));
      //     cout <<  endl << "vrs_ " << vrs << " neuron_ " << neur << " vaha_ " << neur1;
           pom_index++;
            }
          }
        }
       // cout << endl;
}

/**
  * Priradi do vah neuronu hodnoty zadane parametrem
  * @param prirazovany vektor hodnot
  */
void neural_net::prirad_z_vahy(double *vahy)
{
    unsigned int pom_pocet;
    unsigned int pom_index = 0;

    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }

    for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){
        if(vrs == 0) pom_pocet = pocet_vstupu + Bias;
           else pom_pocet = pocet_neuronu_ve_vrtsve[vrs-1] ;
        for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs]-Bias ; neur++ ){
          for (unsigned int neur1 = 0; neur1 < pom_pocet ; neur1++ ){
            neuron_ve_vrstve[vrs][neur].vahy(neur1) = vahy[pom_index];
            pom_index++;
            }
          }
        }
}

/**
  * Priradi do vah neuronu hodnoty zadane parametrem
  * @param prirazovany vektor hodnot
  */
void neural_net::prirad_z_vahy(colvec vahy)
{
    unsigned int pom_pocet;
    unsigned int pom_index = 0;

    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }

    for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){
        if(vrs == 0) pom_pocet = pocet_vstupu + Bias;
           else pom_pocet = pocet_neuronu_ve_vrtsve[vrs-1] ;
        for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs]-Bias ; neur++ ){
          for (unsigned int neur1 = 0; neur1 < pom_pocet ; neur1++ ){
            neuron_ve_vrstve[vrs][neur].vahy(neur1) = as_scalar(vahy(pom_index));
            pom_index++;
            }
          }
        }
}

/**
  * Priradi z vektoru vahy hodnoty vah do vektoru vah jednotlivym neuronum
  * vynuluje pole dE_dw dF_dw a delta vahy u neuronu
  */
void neural_net::prirad_z_vahy()
{
    unsigned int pom_pocet = 0, pom_pocet1 = 0;
    unsigned int pom_index = 0;

    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }

    for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){
        if(vrs == 0) {
            pom_pocet1 = pocet_vstupu + Bias;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] -Bias;
           }
           else if(vrs < (pocet_vrstev -1)&&(vrs > 0)) {
            pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] -Bias;
             } else if(vrs == (pocet_vrstev-1)){
                     pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
                     pom_pocet = pocet_neuronu_ve_vrtsve[vrs] ;
             }

        for (unsigned int neur = 0; neur < pom_pocet; neur++ ){
          for (unsigned int neur1 = 0; neur1 < pom_pocet1; neur1++ ){
            neuron_ve_vrstve[vrs][neur].vahy(neur1) = as_scalar(vahy(pom_index));
            neuron_ve_vrstve[vrs][neur].dE_dw(neur1) = 0.0;
            neuron_ve_vrstve[vrs][neur].dF_dw(neur1) = 0.0;
            neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = 0.0;
            pom_index++;
           // cout <<  endl << "vrs " << vrs << " neuron " << neur << " vaha " << neur1;
            }
          }
        }
       // cout << endl;
}

/**
  * Vypocte pro vsechny vstupni vzory jejich vystupy
  */
void neural_net::vypocti_allvzory()
{
   unsigned int pom_pocet =0;
    for (unsigned int vz=0; vz <pocet_vzorovych_dat ; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //vypocti_1vzor(trans(VSTUPY.row(pom_pocet)));
            vypocti_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            data_kal[vz].sim_vystupy.row(vzor) = trans(vystupy);
            SIM_VYSTUPY.row(pom_pocet) = trans(vystupy);
            pom_pocet++;
            }
      }
      REZIDUI = SIM_VYSTUPY - VYSTUPY;
}
/**
  * Pripravy dat pro trenovani
  * vytvori vstupni matice pro vzory data
  * naplni celkove matice vstupnich vystupnich a simulovanych dat
  */
void neural_net::priprav_data_k_trenovani()
{
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
       data_kal[vz].vytvor_vstupni_matici();
       data_kal[vz].vytvor_vystupni_matici();
       pocet_vzoru += data_kal[vz].pocet_vzoru;
    }

//    ofstream proud_soubor_datvs("./vzory/vystupy/best_nets/data_kal_vs.txt", ios::app);
//    proud_soubor_datvs << data_kal[0].data_vstupu;
//    proud_soubor_datvs.close();
//
//    ofstream proud_soubor_datvy("./vzory/vystupy/best_nets/data_kal_vy.txt", ios::app);
//    proud_soubor_datvy << data_kal[0].data_vystupu;
//    proud_soubor_datvy.close();

     VSTUPY.set_size(pocet_vzoru,pocet_vstupu);
     VYSTUPY.set_size(pocet_vzoru,pocet_vystupu);
     SIM_VYSTUPY.set_size(pocet_vzoru,pocet_vystupu);
     SIM_VYSTUPY.fill(9999);
 //    cout << "\n POcet vzoru " << pocet_vzoru << endl;
    unsigned int prvni_row =0, last_row=0;
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
        last_row += data_kal[vz].pocet_vzoru;
 //       cout << endl<< last_row <<"\t" << prvni_row;
        data_kal[vz].transformuj(true,true);

        VSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vstupu-1)) =data_kal[vz].data_vstupu;
        VYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_kal[vz].data_vystupu;
        if(data_kal[vz].shuffle_indexy) {
            data_kal[vz].shuffle();
            data_kal[vz].prehazej_vzory(true,true);
        }
       prvni_row = last_row;
    }

}

/**
  * Vypocte kriteria pro tranformovane a netransformovane data a vypise je do souboru
  * @param casovy posum pro pi index
  * @param nazev cesty souboru pro vypis
  * @param identfikator pro vypis kriterii
  */
void neural_net::stanov_kriteria( unsigned int cislo1, string nazev_filetu, string slovo)
{

  vzory *data_trans;

  data_trans = new vzory[pocet_vzorovych_dat];

  for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
    data_trans[vz] = data_kal[vz];
    if(data_kal[vz].shuffle_indexy) {
        data_kal[vz].prehazej_vzory_zpet(true,true,false);
       }
    }

  vypocti_allvzory();


  colvec mean_krit_trans;
  mean_krit_trans.set_size(17);
  mean_krit_trans.fill(0);
  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se11;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);    
    se11 << "_kriteria_trans_" << LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ se11.str();
    colvec Qobs, Qsim;
    Qobs = VYSTUPY.col(kr);
    Qsim = SIM_VYSTUPY.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    Qobs.reset();
    Qsim.reset();
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_trans(mr) += krit.krit[mr] / pocet_vystupu;
      }
    }
    string nazev_fileto1;
    stringstream se1, se12;
    nazev_fileto1 += nazev_filetu;
    se1 << "MEAN";
    se12 <<  LAG << "_LAG" << ".txt";
    nazev_fileto1 += slovo + se1.str()+ "_kriteria_trans_" + se12.str();
    
    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto1, mean_krit_trans);

  for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
    data_kal[vz].transformuj_zpetne(true,true,true);
    }

  mat trans_VYSTUPY, trans_SIMVYSTUPY;

  trans_SIMVYSTUPY.set_size(pocet_vzoru,pocet_vystupu);
  trans_VYSTUPY.set_size(pocet_vzoru,pocet_vystupu);

  unsigned int prvni_row =0, last_row=0;
  for (unsigned int vz =0; vz <pocet_vzorovych_dat ;vz++ ){
    last_row += data_kal[vz].pocet_vzoru;
    trans_VYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_kal[vz].data_vystupu;
    trans_SIMVYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_kal[vz].sim_vystupy;
    prvni_row = last_row;
    }

  colvec mean_krit_orig;
  mean_krit_orig.set_size(17);
  mean_krit_orig.fill(0);

  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se14;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);
    se14 <<  LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ "_kriteria_orig_" + se14.str();
    colvec Qobs, Qsim;
    Qobs = trans_VYSTUPY.col(kr);
    Qsim = trans_SIMVYSTUPY.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_orig(mr) += krit.krit[mr] / pocet_vystupu;
      }
    Qobs.reset();
    Qsim.reset();
    }

    string nazev_fileto12;
    stringstream se122, se13;
    nazev_fileto12 += nazev_filetu;
    se122 << "MEAN";
    se13 <<  "_" << LAG << "_LAG" << ".txt";
    nazev_fileto12 += slovo + se122.str()+ "_kriteria_orig" + se13.str();

    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto12 , mean_krit_orig);

  for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
    data_kal[vz] = data_trans[vz];
    }

   delete []  data_trans;
}

/**
  * Vypocte pro dany vstup a vystup hodnotu derivace \f[ \frac{\partial E}{\partial w_i}\f] a pricte ji do stanajici hodnoty derivace
  * @param vstupy
  * @param vystupy
  */
void neural_net::vypocti_derivace_BP_1vzor(colvec vzor_vstupy, colvec vzor_vystup)
{
   colvec pom_delta; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti
   pom_delta.set_size(pocet_vystupu); // inicializace premenne tak, aby mela velikost jako je pocet vystupu ze site
  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu) =1;
  }

   pom_delta = vzor_vystup - vystupy; // vypocet rozdilu

  // cout << pom_delta;
   //cout << pocet_vrstev <<"\n";
    unsigned int vrs = 0;
 //  for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index;
   //for (unsigned int vrs = (pocet_vrstev-1);vrs  >= 0;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
       // cout <<"uops" <<vrs << endl;
       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                   double pom_dw =0.0;
                   pom_dw = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1) );
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta(neur) * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dE_dw(neur1) +=  neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup;
                   }
             }

          }   else {
//            double pom_dw =0.0;

                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup;
                        }
                   }
                } else if(vrs == 0){
                // vstupy do prvni skryte vrstvy
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       // cout  << "pocet vstupu +bias " << pocet_vstupu + Bias << endl;
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1);
                        //cout  << "jsem tady " << neuron_ve_vrstve[vrs][neur].dE_dw(neur1) << endl;
                        }
                   }
                   break;
                }
        }
    }//vrstvy
   nulovani_delt(); //vynulovat delty
   //cout  << " normice " << norm(dE_vahy,2);
}

/**
  * Vypocte pro dany vstup a vystup hodnotu derivace \f[ \frac{\partial E}{\partial w_i}\f] a pricte ji do stanajici hodnoty derivace
  * @param vstupy
  * @param vystupy
  */
void neural_net::vypocti_derivace_BP_1vzor_regul(colvec vzor_vstupy, colvec vzor_vystup)
{
   colvec pom_delta; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti
   pom_delta.set_size(pocet_vystupu); // inicializace premenne tak, aby mela velikost jako je pocet vystupu ze site
  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu ) =1;
  }

   pom_delta = vzor_vystup - vystupy; // vypocet rozdilu
  // cout << pom_delta;
 //  cout << pocet_vrstev <<"\n";
 unsigned int vrs = 0;
 //  for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index; 
   //for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                   double pom_dw =0.0;
                   pom_dw = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1) );
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta(neur) * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dE_dw(neur1) +=  regul_beta * neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup + regul_alpha * neuron_ve_vrstve[vrs][neur].vahy(neur1);
                  }
             }

          }
        else {
//            double pom_dw =0.0;
                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += regul_beta * neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup + regul_alpha * neuron_ve_vrstve[vrs][neur].vahy(neur1);
                        }
                   }
                }

                else  if(vrs == 0){
                // vstupy do prvni skryte vrstvy
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1) + regul_alpha * neuron_ve_vrstve[vrs][neur].vahy(neur1);
                        }
                   }
                   break;
                }
        }
    }//vrstvy
   nulovani_delt(); //vynulovat delty
}

/**
  *  Vypocet sumu derivaci pro vsechny vzory a priradi vysledne vahy do vektoru vahy
  */
void neural_net::vypocti_gradient_batch()
{

     for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
            vypocti_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            vypocti_derivace_BP_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)),trans(data_kal[vz].data_vystupu.row(vzor)));
            }
      }
      prirad_do_vahy();

}

/**
  * Trenovani NN site BP batch
  */
void neural_net::bp_batch()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec pom_delta_vahy;
    pom_delta_vahy.set_size(pocet_vah);
    pom_delta_vahy.fill(0.0);


    for (unsigned int epocha= 0; epocha < pocet_epoch; epocha++ ){
      vypocti_gradient_batch();
      vahy = vahy + learning_rate * dE_vahy + momentum * pom_delta_vahy;
      pom_delta_vahy = learning_rate * dE_vahy + momentum * pom_delta_vahy;
     if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPbatch_");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPbatch_");
      vypocti_allvzory();
      cout <<endl << epocha+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
      if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }
     prirad_z_vahy();
     if (control_saturation) net_saturation();
   }

}

/**
  * Vynulovani vsech delta clenu u neuronu
  */
void neural_net::nulovani_delt()
{

for (unsigned int vrs =0; vrs <pocet_vrstev ; vrs++ ){
        for (unsigned int neur=0; neur <pocet_neuronu_ve_vrtsve[vrs] ; neur++ ){
          neuron_ve_vrstve[vrs][neur].delta_vahy.fill(0);
          }
    }
}

/**
  * Vynulovani vsech derivace vystupu dle vahy
  */
void neural_net::nulovani_dF_dw()
{

for (unsigned int vrs =0; vrs <pocet_vrstev ; vrs++ ){
        for (unsigned int neur=0; neur <pocet_neuronu_ve_vrtsve[vrs] ; neur++ ){
          neuron_ve_vrstve[vrs][neur].dF_dw.fill(0);
          }
    }
    dF_vahy.fill(0);
}

/**
  * Vynulovani vsech derivace chybove fce dle vahy
  */
void neural_net::nulovani_dE_dw()
{

for (unsigned int vrs =0; vrs <pocet_vrstev ; vrs++ ){
        for (unsigned int neur=0; neur <pocet_neuronu_ve_vrtsve[vrs] ; neur++ ){
          neuron_ve_vrstve[vrs][neur].dE_dw.fill(0);
          }
    }
    dE_vahy.fill(0);
}

/**
  * Vypocet derivaci pro batch SD a prirazeni vah do vektoru vahy
  */
void neural_net::vypocti_gradient_batch_regul()
{
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
            vypocti_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            vypocti_derivace_BP_1vzor_regul(trans(data_kal[vz].data_vstupu.row(vzor)),trans(data_kal[vz].data_vystupu.row(vzor)));
            }
      }
      prirad_do_vahy();

}

/**
  * Trenovani NN site BP batch s regularizacnim clenem
  */
void neural_net::bp_batch_regul()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec pom_delta_vahy;
    pom_delta_vahy.set_size(pocet_vah);
    pom_delta_vahy.fill(0.0);

    for (unsigned int epocha= 0; epocha < pocet_epoch; epocha++ ){
      vypocti_gradient_batch_regul();
      vahy = vahy + learning_rate * dE_vahy + momentum * pom_delta_vahy;
      pom_delta_vahy = learning_rate * dE_vahy + momentum * pom_delta_vahy;
     if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPbatch_regul_");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPbatch_regul_");
      vypocti_allvzory();
      cout <<endl << epocha+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) /(pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }
     prirad_z_vahy();
     if (control_saturation) net_saturation();
   }
}

/**
  * Levenberg Marquardt
  */
void neural_net::LevM_batch()
{
   unsigned int stop_code, numiter;
   double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
   double v=2, mu =0, rho = 0.0;
   mat POM_REZIDUI;
   numiter = maxiter;

   mat Iden = eye<mat>(pocet_vah,pocet_vah);
   colvec delta_vahy;
   colvec pom_vahy;

   vypocti_allvzory();
   POM_REZIDUI = REZIDUI;
   delta_vahy.set_size(pocet_vah);
   pom_vahy.set_size(pocet_vah);

   vypocti_derivace_J_batch();
   mu = tau * max(Hessian.diag());
   vypocti_gradient_batch();

   bool found = (norm(dE_vahy,"inf") < e1);
   cout << endl << "LEVMAR" << endl;
   while((found==false)&&(--numiter>0)){

    solve(delta_vahy, Hessian + mu*Iden, dE_vahy);
    //cout << maxiter - numiter << "  \t  "<< norm(REZIDUI, 2) << "   \t   " << norm(delta_vahy,2) << endl;

    if(norm(delta_vahy,2) < e2*norm(vahy,2))    {
      cout << endl << "Velikost zmeny vah je " << norm(delta_vahy,2) << " oproti minimalni velikosti vah e2*norm(vahy,2) " << e2*norm(vahy,2) << endl;
      found = true;
      stop_code = 1;
    } else {
      pom_vahy = vahy;
      vahy = vahy + delta_vahy;
      prirad_z_vahy();
      vypocti_allvzory();

      rho = as_scalar((norm(POM_REZIDUI,2) - norm(REZIDUI,2)) / (trans(delta_vahy)*(mu * delta_vahy + dE_vahy)));

      if(rho > 0){
        POM_REZIDUI = REZIDUI;
        vypocti_derivace_J_batch();
        vypocti_gradient_batch();
        v= 2;

     if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(maxiter - numiter,pom_nazev,"KAL_LevMar_batch_");
      stanov_kriteria_test(maxiter - numiter,pom_nazev,"TEST_LevMar_batch_");
      cout <<endl << maxiter - numiter << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if((maxiter - numiter)==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
       if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }



       } else{
        vahy = pom_vahy;
        mu = mu * v;
        v = 2 * v;

      }

    }
    if (control_saturation) net_saturation();
   }
}

/**
  * Vypocet derivace vystupu dle parametru
  */
void neural_net::vypocti_derivace_J_batch()
{
  for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
            vypocti_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            vypocti_derivace_dy_dw_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            }
      }

   prirad_do_vahy();

   Hessian =  dF_vahy * trans(dF_vahy);
}

/**
  * Vypocet derivace vystupu dle vahy a pricte ji ke stavajici hodnote derivace dF_dw
  */
void neural_net::vypocti_derivace_dy_dw_1vzor(colvec vzor_vstupy)
{
   double pom_delta = 1; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti

  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu -1) =1;
  }


  // cout << pom_delta;
 //  cout << pocet_vrstev <<"\n";
 unsigned int vrs = 0;
 //  for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index; 
 
   //for (unsigned int vrs = (pocet_vrstev-1);vrs>=0 ;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni

       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dF_dw(neur1) +=  neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup;
                   //cout << pocet_neuronu_ve_vrtsve[vrs] << neuron_ve_vrstve[vrs][neur].dF_dw.n_elem<< endl;
                  }
             }

          }
        else {
//            double pom_dw =0.0;
                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dF_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup;
                        }
                   }
                }

                else  if(vrs == 0){
                // vstupy do prvni skryte vrstvy
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dF_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1);
                        }
                   }
                   break;
                }
        }
    }//vrstvy
   nulovani_delt(); //vynulovat delty
}

/**
  * Levenberg Marquardt s regularizaci
  */
void neural_net::LevM_batch_regul()
{
   unsigned int stop_code, numiter;
   double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
   double v=2, mu =0, rho = 0.0, gamma = 0.0;
   mat POM_REZIDUI;
   numiter = maxiter;

   mat Iden = eye<mat>(pocet_vah,pocet_vah);
   colvec delta_vahy;
   colvec pom_vahy;

   vypocti_allvzory();
   POM_REZIDUI = REZIDUI;
   delta_vahy.set_size(pocet_vah);
   pom_vahy.set_size(pocet_vah);

   regul_beta = 1;
   regul_alpha = 0;

   vypocti_derivace_J_batch();
   vypocti_gradient_batch_regul();

   mu = tau * max(Hessian.diag());

//    solve(delta_vahy, Hessian + ( mu)*Iden, dE_vahy);
//    vahy = vahy + delta_vahy;
//    prirad_z_vahy();
//
//   vypocti_allvzory();
//
//   stanov_SS_vah();
//   stanov_SS_er();
//
//   gamma = pocet_vah - 2 * regul_alpha * as_scalar(trace(inv(Hessian+ ( mu + regul_alpha)*Iden)));
//   regul_alpha = gamma / (2 * SS_vah);
//   regul_beta = (pocet_vzoru * pocet_vystupu - gamma )/ (2 * SS_er);
//
//   cout << endl << gamma << " \t "<< regul_beta  << " \t "<< regul_alpha;

   bool found = (norm(dE_vahy,"inf") < e1);
   cout << endl << "LEVMAR regul" << endl;
   while((found==false)&&(--numiter>0)){

    vypocti_allvzory();

    stanov_SS_vah();
    stanov_SS_er();

    gamma = pocet_vah - 2 * regul_alpha * as_scalar(trace(inv(2*regul_beta * Hessian + ( 2*regul_alpha +mu)*Iden)));
    //gamma = pocet_vah - 2 * regul_alpha / as_scalar(trace((2*regul_beta * Hessian + ( 2*regul_alpha +mu)*Iden)));
    regul_alpha = gamma / (2 *SS_vah);
    regul_beta = (pocet_vzoru * pocet_vystupu - gamma )/ (2 * SS_er);

    solve(delta_vahy, 2 * regul_beta * Hessian + ( mu +2* regul_alpha)*Iden, dE_vahy);

    if(norm(delta_vahy,2) < e2*norm(vahy,2))    {
      cout << endl << "Velikost zmeny vah je " << norm(delta_vahy,2) << " oproti minimalni velikosti vah e2*norm(vahy,2) " << e2*norm(vahy,2) << endl;
      found = true;
      stop_code = 1;
    } else {
      pom_vahy = vahy;
      vahy = vahy + delta_vahy;
      prirad_z_vahy();
      vypocti_allvzory();

      rho = as_scalar((norm(POM_REZIDUI,2) - norm(REZIDUI,2)) / (trans(delta_vahy)*(mu* delta_vahy + dE_vahy)));
      //cout << endl << gamma << " \tbeta  "<< regul_beta  << " \talpha "<< regul_alpha<< " \trho " << rho << endl;
      if(rho > 0){
        POM_REZIDUI = REZIDUI;
        vypocti_derivace_J_batch();
        vypocti_gradient_batch();
        v= 2;

     if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(maxiter - numiter,pom_nazev,"KAL_LevMar_REGUL_batch_");
      stanov_kriteria_test(maxiter - numiter,pom_nazev,"TEST_LevMar_REGUL_batch_");
      vypocti_allvzory();
      cout <<endl << maxiter - numiter << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy << "\t" << gamma << "\t" << regul_alpha << "\t" << regul_beta;
     }
     if((maxiter - numiter)==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

       // cout << endl << gamma << " \tbeta  "<< regul_beta  << " \talpha "<< regul_alpha<< endl;
       } else{
        vahy = pom_vahy;
        mu = mu * v;
        v = 2 * v;

      }

   }
    if (control_saturation) net_saturation();
   }
}

/**
  *  RPROP PLUS varianta batch backpropagation algoritmu
  */
void neural_net::bp_RpropPLUS()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec pom_delta_vahy, prev_dE_dw, pom_krok_vahy, prev_pom_krok_vahy;
    pom_delta_vahy.set_size(pocet_vah);
    pom_delta_vahy.fill(0.0);
    prev_dE_dw.set_size(pocet_vah);
    prev_dE_dw.fill(0.0);
    pom_krok_vahy.set_size(pocet_vah);
    pom_krok_vahy.fill(0.0);
    prev_pom_krok_vahy.set_size(pocet_vah);
    prev_pom_krok_vahy.fill(delta_init);
    mat pom_REZID;


    string pom_nazev;
    pom_nazev +=cesta_pro_vypis_kriterii +"/";
    stanov_kriteria(0,pom_nazev,"KAL_BPbatch_RpropPLUS");
    stanov_kriteria_test(0,pom_nazev,"TEST_BPbatch_RpropPLUS");
    pom_REZID.fill(0.0);


    for (unsigned int epocha= 0; epocha < BP_Rprop_pocet_epoch; epocha++ ){

      vypocti_gradient_batch();

      //heuristika pro Delta vahy
      for (unsigned int vh = 0; vh < pocet_vah ; vh++ ){
        if(dE_vahy(vh) * prev_dE_dw(vh) < 0){
            pom_krok_vahy(vh) = mini(as_scalar(prev_pom_krok_vahy(vh)) * eta_plus, deltamax);
            pom_delta_vahy(vh) = pom_krok_vahy(vh) * ( -sign(as_scalar(-dE_vahy(vh))));
            vahy(vh) = vahy(vh) + pom_delta_vahy(vh);
        } else if(dE_vahy(vh) * prev_dE_dw(vh) > 0){
           pom_krok_vahy(vh) = maxi(as_scalar(prev_pom_krok_vahy(vh)) * eta_minus,  deltamin);
          if(norm(REZIDUI,2) >= norm(pom_REZID,2)) {
             vahy(vh) = vahy(vh) - pom_delta_vahy(vh);
             }
           dE_vahy(vh) = 0.0;
        } else if(dE_vahy(vh) * prev_dE_dw(vh) == 0){
             pom_delta_vahy(vh) = pom_krok_vahy(vh) * ( -sign(as_scalar(-dE_vahy(vh))));
             vahy(vh) = vahy(vh) + pom_delta_vahy(vh);
        }
    }

      // cout << vahy << dE_vahy;
      prev_dE_dw = dE_vahy;
      pom_REZID = REZIDUI;
      prev_pom_krok_vahy = pom_krok_vahy;
      prirad_z_vahy();
      vypocti_allvzory();

      if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
      } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
      }

      if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPbatch_RpropPLUS");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPbatch_RpropPLUS");
      //vypocti_allvzory();
      cout <<endl << epocha+1 << " \t  " << norm(dE_vahy,2) << "  \t   " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)<< "  \t " << delta_normy_zmeny_vahy;
     }

      if (control_SS_error > norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
//     if(control_delta_par > delta_normy_zmeny_vahy){
//         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
//         break;
//      }

          if (control_saturation) net_saturation();

    }
}

/**
  * POmocna fce pro BP Rprop
  */
double neural_net::sign( double num)
{
    double ups= 0.0;
    if (num> 0) ups = 1;
    if (num < 0) ups = -1;
    if (num ==0.0) ups =0.0;

    return ups;
}

/**
  * POmocna fce pro BP Rprop
  */
double neural_net::mini(double c_1, double c_2)
{
   double num=0.0;
    if( c_1 < c_2) num = c_1;
    else num = c_2;

   return num;
}


/**
  * POmocna fce pro BP Rprop
  */
double neural_net::maxi(double c_1, double c_2)
{
   double num=0.0;
    if( c_1 >=c_2) num = c_1;
    else num = c_2;

   return num;
}

/**
  * Nahodne inicializuje vektor vahy zvolenou metodou
  */
void neural_net::rand_vahy()
{

    switch (typ_init)
    {
        case UNIT_INTERVAL:{
              srand ( time(NULL) );
              unsigned int LIM_MAX;
              LIM_MAX =   1+ (static_cast<unsigned int>( RAND_MAX ) );
              for (unsigned int vh = 0; vh < pocet_vah; vh++){
    	                 vahy(vh) = static_cast<double>(rand() / (static_cast<double>(LIM_MAX))* (up_init - low_init) + low_init) ;
    	             }
        }
            break;
        case NGUYEN_WIDROW:{
            srand ( time(NULL) );
            vahy.randn();
            double normalisation =0.0;
            normalisation = as_scalar(norm(vahy,2));
            //cout <<endl << normalisation << endl;
            if(normalisation !=0) {
//            for (unsigned int vh=0; vh<pocet_vah; vh++){
//               vahy(vh) = vahy(vh) / normalisation * 3.84;
//              }
                vahy = vahy / normalisation * 3.84;
            }
                
            prirad_z_vahy();

            if(bias_ano_ne){
               unsigned int Bias = 1;
               unsigned int index_bias_neuronu = 0;
               rowvec pom_vahy;
              double norm_vec;

           for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){

              if(vrs ==0 ) index_bias_neuronu = pocet_vstupu;
                else index_bias_neuronu = index_bias_neuronu + pocet_neuronu_ve_vrtsve[vrs-1];

              for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ){
                    pom_vahy = neuron_ve_vrstve[vrs][neur].vahy.subvec(0, neuron_ve_vrstve[vrs][neur].pocet_vstupu - Bias - 1 );
                    norm_vec = norm(pom_vahy, 2);
//                      norm_vec = 1;
           //   cout << endl << index_bias_neuronu << "  neur " <<  neur << " vrs "<< vrs;
                   vahy[index_bias_neuronu] = bias_const * vahy[index_bias_neuronu] * norm_vec * normalisation / 3.84;
                   if(vrs ==0) index_bias_neuronu = index_bias_neuronu + pocet_vstupu+1;
                      else index_bias_neuronu = index_bias_neuronu + pocet_neuronu_ve_vrtsve[vrs-1];

                   if(neur == pocet_neuronu_ve_vrtsve[vrs] - Bias -1 )  {
                      if(vrs ==0 ) index_bias_neuronu = index_bias_neuronu - (pocet_vstupu+1);
                      else index_bias_neuronu = index_bias_neuronu - pocet_neuronu_ve_vrtsve[vrs-1];
                   }
                   norm_vec = 0.0;
               }
             }    
             pom_vahy = neuron_ve_vrstve[pocet_vrstev - 1][pocet_neuronu_ve_vrtsve[pocet_vrstev - 1] -1].vahy.subvec(0, pocet_neuronu_ve_vrtsve[pocet_vrstev - 2] - Bias - 2);
             norm_vec = norm(pom_vahy, 2);
             vahy(pocet_vah - 1) = bias_const * vahy(pocet_vah - 1) * norm_vec  * normalisation / 3.84;
            
              }
            }
            break;
        default:
            break;
    

       }

    //   cout << endl<< " last vaha index " << index_bias_neuronu << " new last " << index_bias_neuronu + pocet_neuronu_ve_vrtsve[pocet_vrstev-2];
     prirad_z_vahy();

//       cout << endl;

}

/**
  * Nahodne inicializuje vektor vahy zvolenou metodou
  */
void neural_net::rand_vahy(unsigned int Seed)
{

    switch (typ_init)
    {
        case UNIT_INTERVAL:{
              srand ( Seed );
              unsigned int LIM_MAX;
              LIM_MAX =   1+ (static_cast<unsigned int>( RAND_MAX ) );
              for (unsigned int vh = 0; vh < pocet_vah; vh++){
    	                 vahy(vh) = static_cast<double>(rand() / (static_cast<double>(LIM_MAX))* (up_init - low_init) + low_init) ;
    	             }
        }
            break;
        case NGUYEN_WIDROW:{
            srand (Seed );
            vahy.randn();
            double normalisation =0.0;
            normalisation = as_scalar(norm(vahy,2));
            //cout <<endl << normalisation << endl;
            if(normalisation !=0) {
//            for (unsigned int vh=0; vh<pocet_vah; vh++){
//               vahy(vh) = vahy(vh) / normalisation * 3.84;
//              }
                vahy = vahy / normalisation * 3.84;
            }
                
            prirad_z_vahy();

            if(bias_ano_ne){
               unsigned int Bias = 1;
               unsigned int index_bias_neuronu = 0;
               rowvec pom_vahy;
              double norm_vec;

           for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){

              if(vrs ==0 ) index_bias_neuronu = pocet_vstupu;
                else index_bias_neuronu = index_bias_neuronu + pocet_neuronu_ve_vrtsve[vrs-1];

              for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ){
                    pom_vahy = neuron_ve_vrstve[vrs][neur].vahy.subvec(0, neuron_ve_vrstve[vrs][neur].pocet_vstupu - Bias - 1 );
                    norm_vec = norm(pom_vahy, 2);
//                      norm_vec = 1;
           //   cout << endl << index_bias_neuronu << "  neur " <<  neur << " vrs "<< vrs;
                   vahy[index_bias_neuronu] = bias_const * vahy[index_bias_neuronu] * norm_vec * normalisation / 3.84;
                   if(vrs ==0) index_bias_neuronu = index_bias_neuronu + pocet_vstupu+1;
                      else index_bias_neuronu = index_bias_neuronu + pocet_neuronu_ve_vrtsve[vrs-1];

                   if(neur == pocet_neuronu_ve_vrtsve[vrs] - Bias -1 )  {
                      if(vrs ==0 ) index_bias_neuronu = index_bias_neuronu - (pocet_vstupu+1);
                      else index_bias_neuronu = index_bias_neuronu - pocet_neuronu_ve_vrtsve[vrs-1];
                   }
                   norm_vec = 0.0;
               }
             }    
             pom_vahy = neuron_ve_vrstve[pocet_vrstev - 1][pocet_neuronu_ve_vrtsve[pocet_vrstev - 1] -1].vahy.subvec(0, pocet_neuronu_ve_vrtsve[pocet_vrstev - 2] - Bias - 2);
             norm_vec = norm(pom_vahy, 2);
             vahy(pocet_vah - 1) = bias_const * vahy(pocet_vah - 1) * norm_vec  * normalisation / 3.84;
            
              }
            }
            break;
        default:
            break;
    }

  

}

/**
  * Stanovi matici nahodne inicializovanych vah NN site
  *@return matice vah nahodne inicializovana
  */
mat neural_net::mat_rand_vahy()
{
    mat vah_rand;
    vah_rand.set_size(pocet_vah,Ensemble);
    switch (typ_init)
    {
        case UNIT_INTERVAL:{


               srand ( time(NULL) );
               unsigned int LIM_MAX;
               LIM_MAX =   1+ (static_cast<unsigned int>( RAND_MAX ) );

               for (unsigned int vh = 0; vh < pocet_vah; vh++){
                      for (unsigned int en = 0;en <Ensemble ; en++ ){
                             vah_rand(vh,en)= static_cast<double>( rand() / (static_cast<double>(LIM_MAX))) *( up_init - low_init ) + low_init;
                             }
                      }

                 }


            break;
        case NGUYEN_WIDROW:{

            srand ( time(NULL) );
            vah_rand.randn();

            double normalisation =0.0;
            normalisation = as_scalar(norm(vah_rand,2));
            //cout <<endl << normalisation << endl;
            if(normalisation !=0) {
//            for (unsigned int vh=0; vh<pocet_vah; vh++){
//                    for (unsigned int en = 0;en <Ensemble ; en++ ){
//                             vah_rand(vh,en) = vah_rand(vh,en) / normalisation * 3.84;
//                    }
//              }
               vah_rand = 3.84 * vah_rand / normalisation;
            }

            }
            break;
        default:
            break;
    }
  return vah_rand;
}

/**
  * RPROP MINUS varinat batch backpropagation algoritmu
  */
void neural_net::bp_RpropMINUS()
{
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec pom_delta_vahy, prev_dE_dw, pom_krok_vahy, prev_pom_krok_vahy;
    pom_delta_vahy.set_size(pocet_vah);
    pom_delta_vahy.fill(0.0);
    pom_krok_vahy.set_size(pocet_vah);
    pom_krok_vahy.fill(0.0);
    prev_pom_krok_vahy.set_size(pocet_vah);
    prev_pom_krok_vahy.fill(delta_init);
    mat pom_REZID;
    prev_dE_dw.set_size(pocet_vah);
    prev_dE_dw.fill(0.0);


    string pom_nazev;
    pom_nazev +=cesta_pro_vypis_kriterii +"/";
    stanov_kriteria(0,pom_nazev,"KAL_BPbatch_RpropMINUS");
    stanov_kriteria_test(0,pom_nazev,"TEST_BPbatch_RpropMINUS_");
    pom_REZID.fill(0.0);


    for (unsigned int epocha= 0; epocha < BP_Rprop_pocet_epoch; epocha++ ){

      vypocti_gradient_batch();

      //heuristika pro Delta vahy
      for (unsigned int vh = 0; vh < pocet_vah ; vh++ ){
        if(dE_vahy(vh) * prev_dE_dw(vh) > 0){
            pom_krok_vahy(vh) = mini(as_scalar(prev_pom_krok_vahy(vh)) * eta_plus, deltamax);
            } else if(dE_vahy(vh) * prev_dE_dw(vh) < 0){
           pom_krok_vahy(vh) = maxi(as_scalar(prev_pom_krok_vahy(vh)) * eta_minus,  deltamin);
           dE_vahy(vh) = 0.0;
            }
//             else if(dE_vahy(vh) * prev_dE_dw(vh) > 0){
//                pom_krok_vahy(vh) = 0;
//            }
        vahy(vh) = vahy(vh) - sign(as_scalar(-dE_vahy(vh))) * pom_krok_vahy(vh);
      }

   if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epocha,pom_nazev,"KAL_BPbatch_RpropMINUS_");
      stanov_kriteria_test(epocha,pom_nazev,"TEST_BPbatch_RpropMINUS_");
      vypocti_allvzory();
      cout <<endl << epocha+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epocha==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }

     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

      prev_dE_dw = -dE_vahy;
      prirad_z_vahy();
      vypocti_allvzory();
      pom_REZID = REZIDUI;
      prev_pom_krok_vahy = pom_krok_vahy;
      // cout << vahy << dE_vahy;
      prirad_z_vahy();

    if (control_saturation) net_saturation();
    }
}

/**
  * Stanovi sumu ctvercu vah
  */
void neural_net::stanov_SS_vah()
{
    SS_vah = as_scalar(trans(vahy) * vahy);
}

/**
  * Stanovy sumu ctvercu rezidui
  */
void neural_net::stanov_SS_er()
{
    SS_er = as_scalar(sum(sum(REZIDUI % REZIDUI)));
}

/**
  * Vypocte opakovany trenink zvolenou metodou a vypise do souboru
  */
void neural_net::test_treninku()
{
    vzory *zaloha_kal, * zaloha_test;

    zaloha_kal = new vzory[pocet_vzorovych_dat];
    zaloha_test = new vzory[pocet_data_test];

    for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      zaloha_kal[vzk] = data_kal[vzk];
      }
    for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      zaloha_test[vzt] = data_test[vzt];
      }


 //mat vah_rand;
 //vah_rand.set_size(pocet_vah,Ensemble);
 //vah_rand = mat_rand_vahy();
 colvec pom_init_vahy;
 pom_init_vahy.set_size(pocet_vah);
 priprav_data_k_trenovani();
 priprav_testovaci_data();
 LAG_control();
 
 if (bench_OLS) benchmark_OLS();
 
 
 bestnet_vahy.set_size(pocet_vah, 1);
 bestnet_vahy.fill(0);
 bestnet_vahy_initial.set_size(pocet_vah,1);
 bestnet_vahy_initial.fill(0);
// prirad_do_vahy();
 cout << endl << "Ensemble run";
// cout << endl << 0. << " \t " << norm(dE_vahy,2) << " \t " << norm(vahy,2) << " \t " << (norm(REZIDUI,2));

 string slovo_best_net = "";

  for (unsigned int en = 0; en<Ensemble ;en++ ){

    rand_vahy(en + 1);
    pom_init_vahy = vahy;
//    cout  << norm(pom_init_vahy,2) << endl;
    prirad_z_vahy();
    prirad_do_vahy();
    nulovani_dF_dw();
    nulovani_dE_dw();
    REZIDUI.fill(0);
    string pom_nazev, slovo, slovo1;
    pom_nazev +=cesta_pro_vypis_kriterii +"/";
    switch (typ_trenovani) // na zaklade typu trenovani vyberu metodu trenovani site
    {
    	case BPonline:
       	    bp_online();
    		break;
    	case BPonline_regul:
       	    bp_online_regul();
       	    slovo += "KAL_Ensemble_BPonline_";
       	    slovo1 += "TEST_Ensemble_BPonline_";
    		break;
        case BPbatch:
       	    bp_batch();
       	    slovo += "KAL_Ensemble_BPbatch_";
       	    slovo1 += "TEST_Ensemble_BPbatch_";
    		break;
        case BPbatch_regul:
       	    bp_batch_regul();
       	    slovo += "KAL_Ensemble_BPbatch_regul_";
       	    slovo1 += "TEST_Ensemble_BPbatch_regul_";
    		break;
        case LMbatch:
           LevM_batch();
           slovo += "KAL_Ensemble_LEV_MAR_";
           slovo1 += "TEST_Ensemble_LEV_MAR_";
           break;
         case LMbatch_regul:
           LevM_batch_regul();
           slovo += "KAL_Ensemble_LEV_MAR_regul_";
           slovo1 += "TEST_Ensemble_LEV_MAR_regul_";
           break;
         case BPbatch_RpropPLUS:
           bp_RpropPLUS();
           slovo += "KAL_Ensemble_RpropPLUS_";
           slovo1 += "TEST_Ensemble_RpropPLUS_";
           break;
         case BPbatch_RpropMINUS:
           bp_RpropMINUS();
           slovo += "KAL_Ensemble_RpropMINUS_";
           slovo1 += "TEST_Ensemble_RpropMINUS_";
           break;
        case ScCoCr_PERRY:
           ScConGrad_Perry();
           slovo += "KAL_Ensemble_ScCoGr_Perry_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_Perry_batch";
           break;
        case ScCoCr_HESTENES:
           ScConGrad_Hestenes();
           slovo += "KAL_Ensemble_ScCoGr_HESTENES_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_HESTENES_batch";
           break;
         case ScCoCr_FLETCHER:
           ScConGrad_Fletcher();
           slovo += "KAL_Ensemble_ScCoGr_FLETCHER_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_FLETCHER_batch";
           break;
          case ScCoCr_POLAK:
           ScConGrad_Polak();
           break;           
          case StepD_BaBo:
           StepD_BB();
           slovo += "KAL_Ensemble_SDBB_batch";
           slovo1 += "TEST_Ensemble_SDBB_batch";
           break;
          default:
            break;
    }

 cout <<  endl << en+1 << " \t " << norm(dE_vahy,2) << " \t " << norm(vahy,2) << " \t " << (norm(REZIDUI,2))/(pocet_vzoru*pocet_vystupu);
// cout  << " pom_init " << norm(pom_init_vahy,2) << endl;
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
                if(data_kal[vz].shuffle_indexy) {
                    data_kal[vz].prehazej_vzory_zpet(true,true,false);
                }
            }

  // prirad_do_vahy();
   vypocti_allvzory();
   vypocti_allvzory_test();
   stanov_kriteria(en,pom_nazev,slovo);
   stanov_kriteria_test_selectbestnet(en,pom_nazev,slovo1, pom_init_vahy);
   if(en == 0) slovo_best_net += slovo1;
   for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
           if(data_kal[vz].shuffle_indexy) {
   //         data_kal[vz].shuffle();
            data_kal[vz].prehazej_vzory(true,true);
        }
    }
   }

   if(vypis_best_nets) {
     vypis_best_vahy(slovo_best_net, true);
   }

   if(best_net){
     if(real_pocet_bestnet >0){
      ensemble_simulation();
     }
   }

   for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      data_kal [vzk] = zaloha_kal[vzk];
      }
   for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      data_test[vzt] = zaloha_test[vzt];
      }

   delete[] zaloha_kal;
   delete[] zaloha_test;
}

/**
  * Sdruzene gradienty Perry skalovane
  */
void neural_net::ScConGrad_Perry()
{
    double alp=0.0, ny=0.0, bbeta = 0.0, pom_SS_er = 0.0;
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec d, s, y, d_old, vahy_old, g_old;

    d.set_size(pocet_vah);
    d.fill(0);

    s.set_size(pocet_vah);
    s.fill(0);

    y.set_size(pocet_vah);
    y.fill(0);

    d_old.set_size(pocet_vah);
    d_old.fill(0);

    g_old.set_size(pocet_vah);
    g_old.fill(0);

    vahy_old.set_size(pocet_vah);
    vahy_old.fill(0);

    s = vahy;

    for (unsigned int epch = 0; epch < CCmaxiter; epch++){

         vypocti_allvzory();
         stanov_SS_er();
         vypocti_gradient_batch_CC();
         pom_SS_er = SS_er;
         

        //cout << endl << " normiceperry " << norm(dE_vahy,2) << endl;
       // cout << vahy << endl << dE_vahy;
         if(pom_SS_er < eps){
             cout << endl <<   "CG converges Sum of Squares of Reziduals: " << SS_er << endl;
            break ;
         }
         if( (epch == 0) ){
            alp =  1/ norm(dE_vahy,2);
            d = -dE_vahy;
            vahy_old = vahy;

         } else{
             y= dE_vahy - g_old;
             if (CC_POWEL){
                  if((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))){
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       if (((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 ))) cout << endl << "Powel restarting procedure.";
                    }
                  }
               }
             if ( (norm(y,2) < CC_restart_boundary) || ( ((epch +1 ) % CC_restart_period ) == 0) || (norm(d_old ,2) < CC_restart_boundary) || (norm(s ,2) < CC_restart_boundary)||(norm(d_old ,2) < CC_restart_boundary)){//
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       cout << "\n\nRestarting condition fullfilled -> restarting CC.";
                    //+cout << "y " << norm(y,2) << " s " << norm(s,2) << " ny " << ny_old << " g_old " << norm(g_old, 2) << " d_old " << norm(d_old, 2) <<" ep " << ((epch +1 ) % 5000 ) << endl;
                       if ((norm(y, 2) < CC_restart_boundary)) cout << endl << "y == 0";
                       if ((norm(g_old, 2) < CC_restart_boundary)) cout << endl << "g_old == 0";
                       if ((norm(s, 2) < CC_restart_boundary)) cout << endl << "s == 0";
                       if ((norm(d_old, 2) < CC_restart_boundary)) cout << endl << "d_old == 0";
                       if (( ((epch +1 ) % CC_restart_period ) == 0)) cout << endl << "epochy";
                }


             } else {
             ny=as_scalar((trans(s) * s) / (trans(y)*s));
             bbeta = as_scalar((trans((ny*y - s)) * (dE_vahy)) / (trans(y) * d_old)); //Perrysova samoskalovaci formule pro ccbetu
             d = -ny * dE_vahy + bbeta * d_old;
       //      cout  << endl << "normd "<< norm(d,2) << "\tny " << ny << "\tbbeta " << bbeta << endl;
             if ((as_scalar(trans(d) * dE_vahy)) <= (-10e-3 * norm(d,2) * norm(dE_vahy,2))){}
             else{
                 d = -ny *dE_vahy;
                 alp =  1/ norm(dE_vahy,2);
                 //d = dE_vahy;
               if (CC_restart_out)  cout << "\nSpectral gradient: "<< as_scalar(trans(d) * dE_vahy)<< " <= " << -10e-3*(norm(d,2) * norm(dE_vahy,2)) <<" restarting CC.";
                 //if(ny * dE_vahy <=){as_scalar
                 //    d = dE_vahy;
  //      cout << endl << "0_alp " << alp << " d_old " << norm(d_old,2)  << " d " << norm(d,2) <<  " y " << norm(y,2) ;
  //      cout <<endl << "0_ny " << ny << " bbeta " << bbeta  << " v_old " << norm(vahy_old,2) << " s " << norm(s,2);
                 //}
                }

             alp = alp * norm(d,2) / norm(d_old,2);
            }//if (epch ==0)
    //        cout << endl << "0_alp " << alp << " d_old " << norm(d_old,2)  << " d " << norm(d,2);
    //        cout <<endl << "0_ny " << ny << " bbeta " << bbeta  << " v_old " << norm(vahy_old,2);
        }
         alp = line_search(alp, vahy_old, d, pom_SS_er);


        // alp = line_search(2.5, vahy_old, d, pom_SS_er);
//         cout <<endl <<"alp " << alp << "\t norm vahy " << norm(vahy,2) << "\t d " << norm(d,2);
         vahy = vahy_old + alp * d;
//         cout << "\t vahy " << norm(vahy,2) <<endl;
         s = vahy - vahy_old;
         d_old = d;
         g_old = dE_vahy;
         vahy_old = vahy;
         //if(epch == 1){
//            cout << endl << "1_alp " << alp << " d_old " << norm(d_old,2)  << " d " << norm(d,2);
//            cout <<endl << "1_ny " << ny << " bbeta " << bbeta << " s " << norm(s,2) << " v " << norm(vahy,2)  << " g_old " << norm(g_old,2) << endl;
         //}

    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epch,pom_nazev,"KAL_ScCoGr_Perry_batch_");
      stanov_kriteria_test(epch,pom_nazev,"TEST_ScCoGr_Perry_batch_");
      cout <<endl << epch+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }


     if(epch==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
      if((control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu))) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

         prirad_z_vahy();


         if (control_saturation) net_saturation();

      }
}

/**
  * Line search pro nelinearni srdruzene gradienty
  */
double neural_net::line_search(double alp, colvec old_Vahy, colvec direction, double zero_error)
{
    double r=0.61803399, c= 1.0 - r;
    double f1  = 0.0, f2 = 0.0, x0 = 0.0, x1 = 0.0, x2 = 0.0, x3 = 0.0, tol =0.0;
    unsigned int pom_prom = 0.0;
    bool maxi_ter = false;
    double alphi;

    mat tri_cisla;
    tri_cisla.set_size(2,3);

    tol = c1;

 //   cout << endl  <<"CC alp: " << alp << endl;
    //osetrit alp dobre je dat 2.5 kdyz je divna
    tri_cisla = bracketing(alp,old_Vahy,direction,zero_error);

    x0 = as_scalar(tri_cisla(0,0));
    x3 = as_scalar(tri_cisla(0,2));


    if ( fabs(as_scalar(tri_cisla(0,2) - tri_cisla(0,1))) > fabs(as_scalar(tri_cisla(0,1) - tri_cisla(0,0)))) {
        x1 =as_scalar(tri_cisla(0,1));
        x2 = as_scalar(tri_cisla(0,1) + c * (tri_cisla(0,2) - tri_cisla(0,1)));
    } else {
        x2 =as_scalar(tri_cisla(0,1));
        x1 = as_scalar(tri_cisla(0,1) - c * (tri_cisla(0,1) - tri_cisla(0,0)));
    }

    f1 = vypocti_allvzory_a_error(old_Vahy + x1 * direction);
    f2 = vypocti_allvzory_a_error(old_Vahy + x2 * direction);

    while( fabs(x3 - x0) > tol*(fabs(x1) + fabs(x2))){
        if (f2 < f1) {
            x0 = x1;
            x1 = x2;
            x2 =  r * x2 + c * x3;
            f1 = f2;
            f2 = vypocti_allvzory_a_error(old_Vahy + x2 * direction);
          } else {
             x3 = x2;
             x2 = x1;
             x1 = r * x1 +c * x0;
             f2 = f1;
             f1 = vypocti_allvzory_a_error(old_Vahy + x1 * direction);
          }
          pom_prom++;
          if(pom_prom > 1000) {
 //               cout <<"\nLine search reached max iterations. Using Learnig rate and making step forward.";
           //     alphi = learning_rate;
                maxi_ter= true;
                break;
          }
    }
   if((f1 <= f2) &&(maxi_ter = false) ){
        alphi = x1;
   } else {
       alphi = x2;
   }
  if(maxi_ter) {
       if(alphi >= 0) alphi = learning_rate;
          else alphi = - learning_rate;
          cout << endl << "Line search reached max iterations." << endl;
      }
    return alphi;
}

/**
  * Funkce pro line search - nalezne tri cisla mezi kterymi je minimum
  */
mat neural_net::bracketing(double alp, colvec old_Vahy, colvec direction, double zero_error)
{
    double pom_error=0.0, t1 = 0.0, t2 = 0.0, denom = 0.0, ep_s = 0.0, step = 0.0, max_step =0.0;
    unsigned int pom_prom = 0;
    mat tri_cisla;
    tri_cisla.set_size(2,3);
    tri_cisla.fill(0);

    colvec pom_vahy;
    pom_vahy.set_size(pocet_vah);
    pom_vahy.fill(0);

    ep_s = c2;

    //cout << endl <<"alpha: " << alp << endl;
   // cout << endl << tri_cisla << endl;
  //  if(alp < 0.0) alp =learning_rate;
   // if(alp  > 1.0) alp =learning_rate;

    pom_vahy = old_Vahy + alp*direction;
   // cout << endl << "NORM 0,2 " << norm(pom_vahy,2) << endl;
    pom_error = vypocti_allvzory_a_error(pom_vahy);

    if (zero_error < pom_error) {
        tri_cisla(0,0) = -alp;
        tri_cisla(0,1) = 0.0;
        tri_cisla(1,0) = pom_error;
        tri_cisla(1,1) = zero_error;
    } else {
        tri_cisla(0,0) = 0.0;
        tri_cisla(0,1) = alp;
        tri_cisla(1,0) = zero_error;
        tri_cisla(1,1) = pom_error;
    }
   // cout << endl << tri_cisla << endl;

    tri_cisla(0,2) = tri_cisla(0,1) +1.618034 * (tri_cisla(0,1) - tri_cisla(0,0));
    pom_vahy = old_Vahy + tri_cisla(0,2)*direction;
  //  cout << endl << "NORM " << norm(pom_vahy,2) << endl;
    tri_cisla(1,2) = vypocti_allvzory_a_error(pom_vahy);

 //   cout << endl << tri_cisla << endl << "ups"<< endl<<tri_cisla(1,2) - tri_cisla(1,1) << endl;

    while ((tri_cisla(0,1) > tri_cisla(0,2))){
        t1 = as_scalar((tri_cisla(0,1) - tri_cisla(0,0)) * (tri_cisla(1,1) - tri_cisla(1,2)));
        t2 = as_scalar((tri_cisla(0,1) - tri_cisla(0,2)) * (tri_cisla(1,1) - tri_cisla(1,0)));
    //    cout <<endl << "AUOIHDJHJKHEJKHE";
        denom = 2 * (t2 - t1);
        if(std::fabs(denom) < eps){
            if (denom >= 0)
                denom = ep_s;
              else
                denom = - ep_s;
        }

        step = as_scalar( tri_cisla(0,1) + ((tri_cisla(0,1)- tri_cisla(0,0)) * t1 - (tri_cisla(0,1) - tri_cisla(0,2)) * t2));
        max_step = as_scalar(tri_cisla(0,1) + 200 * (tri_cisla(0,1) - tri_cisla(0,2)));

        if (as_scalar((tri_cisla(0,1) - step) * (step - tri_cisla(0,2)))  > 0) {
            pom_error = vypocti_allvzory_a_error(old_Vahy + step*direction);
            if (pom_error  < as_scalar(tri_cisla(1,2))){
                tri_cisla(0,0) = tri_cisla(0,1);
                tri_cisla(0,1) = step;
                tri_cisla(1,0) = tri_cisla(1,1);
                tri_cisla(1,1) = pom_error;
                return tri_cisla;
            } else if (pom_error  > as_scalar(tri_cisla(1,1))){
                tri_cisla(0,2) = step;
                tri_cisla(1,2) = pom_error;
                return tri_cisla;
            } else {
            step  = as_scalar( tri_cisla(0,2) + 1.618034 * (tri_cisla(0,2) - tri_cisla(0,1)));
            pom_error = vypocti_allvzory_a_error(old_Vahy + step*direction);
            }
        } else if (as_scalar((tri_cisla(0,2) - step) * (step - max_step)) > 0.0) {
            step = max_step;
            pom_error  = vypocti_allvzory_a_error(old_Vahy + step*direction);
        } else {
            step = as_scalar(tri_cisla(0,2) + 1.618034 * (tri_cisla(0,2) - tri_cisla(0,1)));
            pom_error  = vypocti_allvzory_a_error(old_Vahy + step*direction);
        }
        tri_cisla(0,0) = tri_cisla(0,1);
        tri_cisla(1,0) = tri_cisla(1,1);
        tri_cisla(0,1) = tri_cisla(0,2);
        tri_cisla(1,1) = tri_cisla(1,2);
        tri_cisla(0,2) = step;
        tri_cisla(1,2) = pom_error;
        pom_prom++;
        if(pom_prom > 2000) {
                cout <<"\nBraketing reached max iterations.\n";
                break;
        }
    }

 // cout << endl << tri_cisla << endl;
    return tri_cisla;
}

/**
  *  Vypocte propagaci NN siti vsech vzoru a stanovi pro ne SC error
  */
double neural_net::vypocti_allvzory_a_error(colvec Vahy)
{
    unsigned int pom_pocet =0;

    vahy = Vahy;
    prirad_z_vahy();

    for (unsigned int vz=0; vz <pocet_vzorovych_dat ; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            vypocti_1vzor(trans(VSTUPY.row(pom_pocet)));
            data_kal[vz].sim_vystupy.row(vzor) = trans(vystupy);
            SIM_VYSTUPY.row(pom_pocet) = trans(vystupy);
            pom_pocet++;
            }
      }
      REZIDUI = SIM_VYSTUPY - VYSTUPY;

      //return as_scalar(sum(sum(REZIDUI)));
       return as_scalar(norm(REZIDUI,2));
}

/**
  * Sdruzene gradienty Hestenes skalovane
  */
void neural_net::ScConGrad_Hestenes()
{
    double alp=0.0, ny=0.0, bbeta = 0.0, pom_SS_er;
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec d, s, y, d_old, vahy_old, g_old;

    d.set_size(pocet_vah);
    d.fill(0);

    s.set_size(pocet_vah);
    s.fill(0);

    y.set_size(pocet_vah);
    y.fill(0);

    d_old.set_size(pocet_vah);
    d_old.fill(0);

    g_old.set_size(pocet_vah);
    g_old.fill(0);

    vahy_old.set_size(pocet_vah);
    vahy_old.fill(0);

    s = vahy;

    for (unsigned int epch = 0; epch < CCmaxiter; epch++){
         vypocti_allvzory();
         stanov_SS_er();
         vypocti_gradient_batch_CC();
         pom_SS_er = SS_er;

         if(pom_SS_er < eps){
             cout << endl <<   "CG zkonvergoval SS: " << SS_er << endl;
            break ;
         }
         if(epch == 0){
            alp =  1/ norm(dE_vahy,2);
            d = -dE_vahy;
            vahy_old = vahy;
         } else{
             y= dE_vahy - g_old;
             if (CC_POWEL){
                  if((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))){
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       if (((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 ))) cout << endl << "Powel restarting procedure.";
                    }
                  }
               }
              if ( (norm(y,2) < CC_restart_boundary) || ( ((epch +1 ) % CC_restart_period ) == 0) ||(norm(d_old ,2) < CC_restart_boundary)  || (norm(s ,2) < CC_restart_boundary) ){//
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       cout << "\n\nRestarting condition fullfilled -> restarting CC.";
                    //+cout << "y " << norm(y,2) << " s " << norm(s,2) << " ny " << ny_old << " g_old " << norm(g_old, 2) << " d_old " << norm(d_old, 2) <<" ep " << ((epch +1 ) % 5000 ) << endl;
                       if ((norm(y, 2) < CC_restart_boundary)) cout << endl << "y == 0";
                       if ((norm(s, 2) < CC_restart_boundary)) cout << endl << "s == 0";
                       if ((norm(d_old, 2) < CC_restart_boundary)) cout << endl << "d_old == 0";
                       if (( ((epch +1 ) % CC_restart_period ) == 0)) cout << endl << "epochy";
               }
             }  else {
             ny=as_scalar((trans(s) * s) / (trans(y)*s));
             bbeta = as_scalar((trans((ny*dE_vahy)) * y) / (trans(d_old) * y)); //Hestenes samoskalovaci formule pro ccbetu
             d = -ny * dE_vahy + bbeta * d_old;
       //      cout  << endl << "normd "<< norm(d,2) << "\tny " << ny << "\tbbeta " << bbeta << endl;
             if (as_scalar(trans(d) * dE_vahy) <= (-10e-3 * norm(d,2) * norm(dE_vahy,2))){}else{
                 d = -ny *dE_vahy;
             }
             alp = alp * norm(d,2) / norm(d_old,2);
             }
         }//if (epch ==0)
         alp = line_search(alp, vahy_old, d, pom_SS_er);
         //alp = line_search(2.5, vahy_old, d, pom_SS_er);
    //     cout <<endl <<"alp " << alp << "\t norm vahy " << norm(vahy,2) << "\t d " << norm(d,2);
         vahy = vahy_old + alp * d;
   //      cout << "\t vahy old" << norm(vahy_old,2) <<endl;
         s = vahy - vahy_old;
         d_old = d;
         g_old =dE_vahy;
         vahy_old = vahy;
         prirad_z_vahy();
      //   cout  << endl << "norms "<< norm(s,2) << "\ty " << norm(y,2) << endl;


    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epch,pom_nazev,"KAL_ScCoGr_Hestenes_batch_");
      stanov_kriteria_test(epch,pom_nazev,"TEST_ScCoGr_Hestenes_batch_");
      cout <<endl << epch+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epch==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

         if (control_saturation) net_saturation();

      }
}

/**
  * Sdruzene gradienty Fletcher skalovane
  */
void neural_net::ScConGrad_Fletcher()
{
    double alp=0.0, ny=0.0, bbeta = 0.0, pom_SS_er, ny_old =0.0;
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec d, s, y, d_old, vahy_old, g_old;

    d.set_size(pocet_vah);
    d.fill(0);

    s.set_size(pocet_vah);
    s.fill(0);

    y.set_size(pocet_vah);
    y.fill(0);

    d_old.set_size(pocet_vah);
    d_old.fill(0);

    g_old.set_size(pocet_vah);
    g_old.fill(0);

    vahy_old.set_size(pocet_vah);
    vahy_old.fill(0);

    s = vahy;

//    ofstream proud_soubor_vahy("/home/pavel/Programs/perceptron/vzory/vystupy/best_nets/vahy_bias.txt");
//proud_soubor_vahy << neuron_ve_vrstve[0][3].vahy;
    for (unsigned int epch = 0; epch < CCmaxiter; epch++){
         vypocti_allvzory();
         stanov_SS_er();
         vypocti_gradient_batch_CC();
         pom_SS_er = SS_er;

         if(pom_SS_er < eps){
             cout << endl <<   "CG zkonvergoval SS: " << SS_er << endl;
            break ;
         }
         if(epch == 0){
            alp =  1/ norm(dE_vahy,2);
            d = -dE_vahy;
            vahy_old = vahy;
        //    ny = alp;
         } else{
             y= dE_vahy - g_old;
             if (CC_POWEL){
                  if((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))){
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       if (((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 ))) cout << endl << "Powel restarting procedure.";
                    }
                  }
               }
             if ( (((norm(y, 2) < CC_restart_boundary) || ( ((epch +1 ) % CC_restart_period ) == 0)) || ((norm(g_old, 2) < CC_restart_boundary) || (norm(s, 2) < 10e-18))) || ((norm(d_old, 2) < CC_restart_boundary)  || ( (ny_old < CC_restart_boundary)   && ( epch > 1)  )   )   || ((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.5 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 )) ){//  || ((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 ))
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
               if (CC_restart_out) {
                    cout << "\n\nRestarting condition fullfilled -> restarting CC.";
                    //+cout << "y " << norm(y,2) << " s " << norm(s,2) << " ny " << ny_old << " g_old " << norm(g_old, 2) << " d_old " << norm(d_old, 2) <<" ep " << ((epch +1 ) % 5000 ) << endl;
                    if ((norm(y, 2) < 10e-18)) cout << endl << "y == 0";
                    if ((norm(g_old, 2) < 10e-18)) cout << endl << "g_old == 0";
                    if ((norm(s, 2) < 10e-18)) cout << endl << "s == 0";
                    if ((ny_old) < 10e-18) cout << endl << "ny_old == 0";
                    if ((norm(d_old, 2) < 10e-18)) cout << endl << "d_old == 0";
                    if (( ((epch +1 ) % CC_restart_period ) == 0)) cout << endl << "epochy";
               }
             }  else{
             ny=as_scalar((trans(s) * s) / (trans(y)*s));
             bbeta = as_scalar((trans((ny*dE_vahy)) * dE_vahy) / (ny_old * trans(g_old) * g_old)); //Hestenes samoskalovaci formule pro ccbetu
             d = -ny * dE_vahy + bbeta * d_old;
       //      cout  << endl << "normd "<< norm(d,2) << "\tny " << ny << "\tbbeta " << bbeta << endl;
             if (as_scalar(trans(d) * dE_vahy) <= (-10e-3 * norm(d,2) * norm(dE_vahy,2))){}else{
                 d = -ny *dE_vahy;
             }
             alp = alp * norm(d,2) / norm(d_old,2);
             }
         }//if (epch ==0)
         alp = line_search(alp, vahy_old, d, pom_SS_er);
         //alp = line_search(2.5, vahy_old, d, pom_SS_er);
    //     cout <<endl <<"alp " << alp << "\t norm vahy " << norm(vahy,2) << "\t d " << norm(d,2);
         vahy = vahy_old + alp * d;

//         proud_soubor_vahy << neuron_ve_vrstve[0][3].vahy;
   //      cout << "\t vahy old" << norm(vahy_old,2) <<endl;
         s = vahy - vahy_old;
         d_old = d;
         g_old =dE_vahy;
         vahy_old = vahy;
         prirad_z_vahy();
         ny_old = ny;
    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epch,pom_nazev,"KAL_ScCoGr_Fletcher_batch_");
      stanov_kriteria_test(epch,pom_nazev,"TEST_ScCoGr_Fletcher_batch_");
      cout <<endl << epch+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy << " \t " << norm(dE_vahy, "inf");
     }
     if(epch==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

    if (control_saturation) net_saturation();

      }
//      proud_soubor_vahy.close();
}

/**
  * Sdruzene gradienty Polak skalovane
  */
void neural_net::ScConGrad_Polak()
{
    double alp=0.0, ny=0.0, bbeta = 0.0, pom_SS_er, ny_old =0.0;
    double  delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;
    colvec d, s, y, d_old, vahy_old, g_old;

    d.set_size(pocet_vah);
    d.fill(0);

    s.set_size(pocet_vah);
    s.fill(0);

    y.set_size(pocet_vah);
    y.fill(0);

    d_old.set_size(pocet_vah);
    d_old.fill(0);

    g_old.set_size(pocet_vah);
    g_old.fill(0);

    vahy_old.set_size(pocet_vah);
    vahy_old.fill(0);

    s = vahy;

    for (unsigned int epch = 0; epch < CCmaxiter; epch++){
         vypocti_allvzory();
         stanov_SS_er();
         vypocti_gradient_batch_CC();
         pom_SS_er = SS_er;

         if(pom_SS_er < eps){
             cout << endl <<   "CG zkonvergoval SS: " << SS_er << endl;
            break ;
         }
         if(epch == 0){
            alp =  1/ norm(dE_vahy,2);
            d = -dE_vahy;
            vahy_old = vahy;
         } else{
             y= dE_vahy - g_old;
             if (CC_POWEL){
                  if((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))){
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                    if (CC_restart_out) {
                       if (((fabs( as_scalar(trans(g_old) * dE_vahy)) >= 0.2 * norm(dE_vahy,2) * norm(dE_vahy,2))  && (epch >1 ))) cout << endl << "Powel restarting procedure.";
                    }
                  }
               }
             if ( (norm(y,2) < CC_restart_boundary) || ( ((epch +1 ) % CC_restart_period ) == 0) || (norm(g_old ,2) < CC_restart_boundary) || (norm(s ,2) < CC_restart_boundary)||(norm(d_old ,2) < CC_restart_boundary) || ((ny_old < CC_restart_boundary)  && (epch > 1))){//
                    alp =  1/ norm(dE_vahy,2);
                    d = -dE_vahy;
                 if (CC_restart_out) {
                    cout << "\n\nRestarting condition fullfilled -> restarting CC.";
                    //+cout << "y " << norm(y,2) << " s " << norm(s,2) << " ny " << ny_old << " g_old " << norm(g_old, 2) << " d_old " << norm(d_old, 2) <<" ep " << ((epch +1 ) % 5000 ) << endl;
                    if ((norm(y, 2) < 10e-18)) cout << endl << "y == 0";
                    if ((norm(g_old, 2) < 10e-18)) cout << endl << "g_old == 0";
                    if ((norm(s, 2) < 10e-18)) cout << endl << "s == 0";
                    if ((ny_old) < 10e-18) cout << endl << "ny_old == 0";
                    if ((norm(d_old, 2) < 10e-18)) cout << endl << "d_old == 0";
                    if (( ((epch +1 ) % CC_restart_period ) == 0)) cout << endl << "epochy";
               }
             }  else{
             ny=as_scalar((trans(s) * s) / (trans(y)*s));
             bbeta = as_scalar((trans((ny*dE_vahy)) * y) / (ny_old * trans(g_old) * g_old)); //Hestenes samoskalovaci formule pro ccbetu
             d = -ny * dE_vahy + bbeta * d_old;
       //      cout  << endl << "normd "<< norm(d,2) << "\tny " << ny << "\tbbeta " << bbeta << endl;
             if (as_scalar(trans(d) * dE_vahy) <= (-10e-3 * norm(d,2) * norm(dE_vahy,2))){}else{
                 d = -ny *dE_vahy;
               }
             alp = alp * norm(d,2) / norm(d_old,2);
             }
         }//if (epch ==0)
         alp = line_search(alp, vahy_old, d, pom_SS_er);
         //alp = line_search(2.5, vahy_old, d, pom_SS_er);
    //     cout <<endl <<"alp " << alp << "\t norm vahy " << norm(vahy,2) << "\t d " << norm(d,2);
         vahy = vahy_old + alp * d;
   //      cout << "\t vahy old" << norm(vahy_old,2) <<endl;
         s = vahy - vahy_old;
         d_old = d;
         g_old =dE_vahy;
         vahy_old = vahy;
         prirad_z_vahy();
         ny_old = ny;
      //   cout  << endl << "norms "<< norm(s,2) << "\ty " << norm(y,2) << endl;
    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epch,pom_nazev,"KAL_ScCoGr_Polak_batch_");
      stanov_kriteria_test(epch,pom_nazev,"TEST_ScCoGr_Polak_batch_");
      cout <<endl << epch+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }
     if(epch==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
     if(control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu)) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }

    if (control_saturation) net_saturation();
   }
}

/**
  * Stanovi pro dany vzor saturaci neuronu
  */
void neural_net::neurons_saturation_1vzor(colvec pom_vstupy)
{
  if (pom_vstupy.n_elem !=  pocet_vstupu){
       cout << "\n Pocet vstupu predavanych polem do NN site neodpovida nastaveni NN site. \n";\
       exit(EXIT_FAILURE);
    }
   int  Bias=0;
   if (bias_ano_ne) { // fce kontroluje bias pri zadavani, jestli je sit pri inicializacii s biasem
       pom_vstupy.reshape(pom_vstupy.n_elem +1,1);
       pom_vstupy(pom_vstupy.n_elem-1) = 1;
       Bias = 1;
   }

    for (unsigned int vrs=0;vrs<pocet_vrstev ; vrs++) // pro kazdou vrstvu
    {
    	if(vrs ==0){ // v prvni vrstve
    	  for (unsigned int neur = 0;neur < pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ )	{ // pro sit s biasem, pro kazdy neuron v prvni vrtsve
             neuron_ve_vrstve[vrs][neur].vstupy = pom_vstupy; // vypocita vstupy
    		 neuron_ve_vrstve[vrs][neur].vypocti(); //vypocita neuron pomoci jeho fce "vypocti()"
    		 neuron_ve_vrstve[vrs][neur].saturation += neuron_ve_vrstve[vrs][neur].vystup / (pocet_vzoru * pocet_vystupu);
    		 }
    	} else if(vrs!=pocet_vrstev-1) { // v dalsich vrstvach
    	     for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] - Bias ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
    	        {
    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
    	        }
    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
    	     neuron_ve_vrstve[vrs][neur].saturation += neuron_ve_vrstve[vrs][neur].vystup / pocet_vzoru;
    	     }
    	} else { // jinak pro sit bez biasu
    	    for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
    	        {
    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
    	        }
    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
    	     neuron_ve_vrstve[vrs][neur].saturation += neuron_ve_vrstve[vrs][neur].vystup / pocet_vzoru;
    	     }
    	   }
    }
}

/**
  * Nuluje saturaci neuronu
  */
void neural_net::nulovani_saturation()
{
    for (unsigned int vrs =0; vrs <pocet_vrstev ; vrs++ ){
        for (unsigned int neur=0; neur <pocet_neuronu_ve_vrtsve[vrs] ; neur++ ){
          neuron_ve_vrstve[vrs][neur].saturation = 0.0;
          }
    }
}

/**
  * Funkce pro kotrolu saturace neuronu
  */
void neural_net::net_saturation()
{
    unsigned int pom_pocet =0;

   // cout  << endl << "Probiha odstaneni saturace.";

    for (unsigned int vz=0; vz <pocet_vzorovych_dat ; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
            neurons_saturation_1vzor(trans(VSTUPY.row(pom_pocet)));
            pom_pocet++;
            }
      }
//  std::srand ( time(NULL) );
//   colvec nah_pom_vahy;
//   nah_pom_vahy.set_size(pocet_vah);
//   nah_pom_vahy.randn();
//   colvec pom_vahy;
//   pom_vahy.set_size(pocet_vah);
//   prirad_do_vahy();
//   pom_vahy = vahy;
//
   change_sat_weights();

   prirad_z_vahy();

   nulovani_saturation();

}

/**
  * Zmeny vahy u saturovanych neuronu
  */
void neural_net::change_sat_weights()
{
   int  Bias=0, pom_prom = 0.0;
   if (bias_ano_ne) { // fce kontroluje bias pri zadavani, jestli je sit pri inicializacii s biasem
            Bias = 1;
   }
    std::srand(time(NULL));

for (unsigned int vrs=0;vrs<pocet_vrstev ; vrs++) // pro kazdou vrstvu
    {
    	if(vrs ==0){ // v prvni vrstve
    	  for (unsigned int neur = 0;neur < pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ )	{ // pro sit s biasem, pro kazdy neuron v prvni vrtsve
            if ( fabs(neuron_ve_vrstve[vrs][neur].saturation) > saturation_sigma ) {
                    neuron_ve_vrstve[vrs][neur].vahy.randn();
                    pom_prom++;
            }
    		 }
    	} else if(vrs!=pocet_vrstev-1) { // v dalsich vrstvach
    	     for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] - Bias ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
//    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
//    	        {
//    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
//    	        }
//    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
             if ( fabs(neuron_ve_vrstve[vrs][neur].saturation) > saturation_sigma ) {
                    neuron_ve_vrstve[vrs][neur].vahy.randn();
                    pom_prom++;
            }
    	     }
    	} else { // jinak pro sit bez biasu
    	    for (unsigned int neur = 0; neur < pocet_neuronu_ve_vrtsve[vrs] ; neur++) { // pro kazdy neuron v dane vrstve, zacina od vrs = 1
//    	        for (unsigned int neur1 = 0;neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ) // pro kazdy neuron predchazejici vrstvy [vrs-1]
//    	        {
//    	        	neuron_ve_vrstve[vrs][neur].vstupy(neur1) = neuron_ve_vrstve[vrs-1][neur1].vystup; // vystup z predchazejiciho neuronu je vstupem do dalsiho neuronu
//    	        }
//    	     neuron_ve_vrstve[vrs][neur].vypocti(); // probehne vypocet neuronu se zadanym vstupem
               if ( fabs(neuron_ve_vrstve[vrs][neur].saturation) > saturation_sigma ) {
                    neuron_ve_vrstve[vrs][neur].vahy.randn();
                    pom_prom++;
                       }
    	     }
    	   }
    }
    if(pom_prom >0) cout  << endl <<"Saturace byla nalezena u " << pom_prom << " vah.";
}

/**
  * Pripravi testovaci data
  */
void neural_net::priprav_testovaci_data()
{
    for (unsigned int vz = 0; vz < pocet_data_test;vz++ ){
       data_test[vz].vytvor_vstupni_matici();
       data_test[vz].vytvor_vystupni_matici();
       pocet_radku_test_dat += data_test[vz].pocet_vzoru;
    }

     VYSTUPY_TEST.set_size(pocet_radku_test_dat,pocet_vystupu);
     VSTUPY_TEST.set_size(pocet_radku_test_dat,pocet_vstupu);
     SIM_VYSTUPY_TEST.set_size(pocet_radku_test_dat,pocet_vystupu);
     SIM_VYSTUPY_TEST.fill(9999);

     unsigned int prvni_row =0, last_row=0;
     for (unsigned int vz = 0; vz < pocet_data_test ;vz++ ){
        last_row += data_test[vz].pocet_vzoru;
 //       cout << endl<< last_row <<"\t" << prvni_row;
        data_test[vz].transformuj(true,true);
        VSTUPY_TEST.submat(prvni_row,0,(last_row-1),(pocet_vstupu-1)) =data_test[vz].data_vstupu;
        VYSTUPY_TEST.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_test[vz].data_vystupu;
        prvni_row = last_row;
    }
}

/**
  * Vypocte pro vsechny testovaci data testovaci vystupy
  */
void neural_net::vypocti_allvzory_test()
{
    unsigned int pom_pocet = 0;
    for (unsigned int vz = 0; vz <pocet_data_test; vz++ ){
      for (unsigned int vzor = 0; vzor < data_test[vz].pocet_vzoru ;vzor++ ){
            vypocti_1vzor(trans(data_test[vz].data_vstupu.row(vzor)));
            data_test[vz].sim_vystupy.row(vzor) = trans(vystupy);
            SIM_VYSTUPY_TEST.row(pom_pocet) = trans(vystupy);
            pom_pocet++;
            }
      }
}

/**
  * Stanovi kriteria pro data testovacich souboru
  */
void neural_net::stanov_kriteria_test(unsigned int cislo1, string nazev_filetu, string slovo)
{
  vzory *data_trans;

  data_trans = new vzory[pocet_data_test];

  for (unsigned int vz=0;vz < pocet_data_test ;vz++ ){
    data_trans[vz] = data_test[vz];
    }

  vypocti_allvzory_test();

  colvec mean_krit_trans;
  mean_krit_trans.set_size(17);
  mean_krit_trans.fill(0);
  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se11;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);
    se11 << "_kriteria_" << LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ se11.str();
    colvec Qobs, Qsim;
    Qobs = VYSTUPY_TEST.col(kr);
    Qsim = SIM_VYSTUPY_TEST.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_trans(mr) += krit.krit[mr] / pocet_vystupu;
      }
    Qobs.reset();
    Qsim.reset();
    }

    string nazev_fileto1;
    stringstream se1, se14;
    nazev_fileto1 += nazev_filetu;
    se1 << "MEAN";
    se14 <<  LAG << "_LAG" << ".txt";
    nazev_fileto1 += slovo + se1.str()+ "_kriteria_trans" + se14.str();

    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto1, mean_krit_trans);


  mat trans_VYSTUPY, trans_SIMVYSTUPY;


  for (unsigned int vz=0;vz < pocet_data_test;vz++ ){
    data_test[vz].transformuj_zpetne(true,true,true);
    }

  trans_SIMVYSTUPY.set_size(pocet_radku_test_dat,pocet_vystupu);
  trans_VYSTUPY.set_size(pocet_radku_test_dat,pocet_vystupu);

  unsigned int prvni_row =0, last_row=0;
  for (unsigned int vz =0; vz <pocet_data_test ;vz++ ){
    last_row += data_test[vz].pocet_vzoru;
    trans_VYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_test[vz].data_vystupu;
    trans_SIMVYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_test[vz].sim_vystupy;
    prvni_row = last_row;
    }

  colvec mean_krit_orig;
  mean_krit_orig.set_size(17);
  mean_krit_orig.fill(0);


  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se15;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);
    se15 <<  LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ "_kriteria_orig_ " +se15.str();
    colvec Qobs, Qsim;
    Qobs = trans_VYSTUPY.col(kr);
    Qsim = trans_SIMVYSTUPY.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_orig(mr) += krit.krit[mr] / pocet_vystupu;
      }
    Qobs.reset();
    Qsim.reset();
    }

    string nazev_fileto12;
    stringstream se12, se154;
    nazev_fileto12 += nazev_filetu;
    se12 << "MEAN";
    se154 <<  LAG << "_LAG" << ".txt";
    nazev_fileto12 += slovo + se12.str()+ "_kriteria_orig_ " + se154.str();

    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto12 , mean_krit_orig);

  for (unsigned int vz=0;vz < pocet_data_test ;vz++ ){
    data_test[vz] = data_trans[vz];
    }

   delete []  data_trans;
}

/**
  * Vypise prumerna data kriterii do soubor
  * @param jmeno souboru pro vypis
  * @param pr hodnoty kriterii vypsane do souboru
  */
void neural_net::vypis_MEAN(unsigned int cislo, string file, colvec MEAN_data)
{
  ofstream proud(file.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis vyhodnocovacich kriterii - " << file;
    exit(0);
  }

 proud << cislo << "\t" << trans(MEAN_data) ;

proud.close();

}

/**
  * Stanovi kriteria vypise do souboru a vybrete nejlepsi sit splnujici pozadavky na best net
  * @param poradi simulaci daneho vypoctu
  * @param cesta pro vypis souboru
  * @param identifikatorzvolenoho algoritmu trenovani testovaneho  vypoctu
  * @param vektor pocatecni initializace vah
  */
void neural_net::stanov_kriteria_test_selectbestnet(unsigned int cislo1, string nazev_filetu, string slovo, colvec initial_vahy)
{
  vzory *data_trans;

  data_trans = new vzory[pocet_data_test];

  for (unsigned int vz=0;vz < pocet_data_test ;vz++ ){
    data_trans[vz] = data_test[vz];
    }

  vypocti_allvzory_test();

  colvec mean_krit_trans;
  mean_krit_trans.set_size(17);
  mean_krit_trans.fill(0);
  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se18;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);
    se18 <<  LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ "_kriteria_trans_" + se18.str() ;
    colvec Qobs, Qsim;
    Qobs = VYSTUPY_TEST.col(kr);
    Qsim = SIM_VYSTUPY_TEST.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_trans(mr) += krit.krit[mr] / pocet_vystupu;
      }
    Qobs.reset();
    Qsim.reset();
    }

    string nazev_fileto1;
    stringstream se1, se8;
    nazev_fileto1 += nazev_filetu;
    se1 << "MEAN";
    se8 <<  LAG << "_LAG" << ".txt";
    nazev_fileto1 += slovo + se1.str()+ "_kriteria_trans_" + se8.str();

    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto1, mean_krit_trans);

  mat trans_VYSTUPY, trans_SIMVYSTUPY;

  for (unsigned int vz=0;vz < pocet_data_test;vz++ ){
    data_test[vz].transformuj_zpetne(true,true,true);
    }

  trans_SIMVYSTUPY.set_size(pocet_radku_test_dat,pocet_vystupu);
  trans_VYSTUPY.set_size(pocet_radku_test_dat,pocet_vystupu);

  unsigned int prvni_row =0, last_row=0;
  for (unsigned int vz =0; vz <pocet_data_test ;vz++ ){
    last_row += data_test[vz].pocet_vzoru;
    trans_VYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_test[vz].data_vystupu;
    trans_SIMVYSTUPY.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_test[vz].sim_vystupy;
    prvni_row = last_row;
    }

  colvec mean_krit_orig;
  mean_krit_orig.set_size(17);
  mean_krit_orig.fill(0);

  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se9;
    nazev_filet1 += nazev_filetu;
    se << (kr+1);
    se9 <<  LAG << "_LAG" << ".txt";
    nazev_filet1 += slovo + se.str()+ "_kriteria_orig_" + se9.str();
    colvec Qobs, Qsim;
    Qobs = trans_VYSTUPY.col(kr);
    Qsim = trans_SIMVYSTUPY.col(kr);
    kriteria krit(Qobs,Qsim);
    krit.vypocti_vsechna(pocet_vah, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit.vypis((nazev_filet1),(cislo1+1));
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_orig(mr) += krit.krit[mr] / pocet_vystupu;
      }
    Qobs.reset();
    Qsim.reset();
    }

     if(best_net){
        if(as_scalar(mean_krit_orig[index_bestnet_kriteria -1] ) >=  prah_kriteria) {
            cout << endl  <<   "Neural net fullfills the bestnet condition. Number of bestnets: " << real_pocet_bestnet +1;
            real_pocet_bestnet++;
            if((bestnet_vahy.n_cols == (real_pocet_bestnet -1)) &&(real_pocet_bestnet == 1)){
                bestnet_vahy.col(real_pocet_bestnet-1) = vahy;
                bestnet_vahy_initial.col(real_pocet_bestnet - 1) = initial_vahy;
                if(vypis_best_nets) {
                    vypis_kriteria_best_nets(real_pocet_bestnet , slovo,mean_krit_orig);
                }
            } else {
                bestnet_vahy.reshape(pocet_vah, real_pocet_bestnet);
                bestnet_vahy.col(real_pocet_bestnet - 1) = vahy;
                bestnet_vahy_initial.reshape(pocet_vah,real_pocet_bestnet);
                bestnet_vahy_initial.col(real_pocet_bestnet - 1) = initial_vahy;
                if(vypis_best_nets) {
                    vypis_kriteria_best_nets(real_pocet_bestnet, slovo,mean_krit_orig);
                }
            }
        }
    }

    string nazev_fileto12;
    stringstream se12, se6;
    nazev_fileto12 += nazev_filetu;
    se12 << "MEAN";
    se6 <<  LAG << "_LAG" << ".txt";
    nazev_fileto12 += slovo + se12.str()+ "_kriteria_orig_" + se6.str() ;

    if(pocet_vystupu > 1) vypis_MEAN(cislo1 +1 , nazev_fileto12 , mean_krit_orig);

  for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
    data_test[vz] = data_trans[vz];
    }

   delete []  data_trans;
}

/**
  * Vypise vahy vsech siti splnujici podminku pro best_net do souboru
  * jedna se o vahy na zacatku a na konci uceni
  * @param retezec znaku oznacujici nejlepsi sit
  */
void neural_net::vypis_best_vahy(string slovo, bool vypsat_init_NN)
{
    string pom_nazev;
    pom_nazev += cesta_pro_vypis_best_net_vah +"/";
    stringstream se12;
    se12 << "_best_nets_weights" <<  LAG << "_LAG" << ".txt";
    pom_nazev += slovo + se12.str();

    ofstream proud_soubor(pom_nazev.c_str());

    if(!proud_soubor){
        cout << "\nNeni mozne otevrit soubor " << pom_nazev;
        exit(EXIT_FAILURE);
    }
    proud_soubor.precision(22);
    proud_soubor.width(30);
    proud_soubor.setf(ios::left);
    for (unsigned int rad =0; rad < bestnet_vahy.n_rows ;rad ++ ){
      for (unsigned int sl =0; sl < bestnet_vahy.n_cols ;sl ++ ){
         proud_soubor << as_scalar(bestnet_vahy(rad,sl)) ;//<< "  \t\t  ";
         proud_soubor.width(30);
        }
        proud_soubor << endl;
      }
    proud_soubor.close();

    if(vypsat_init_NN){
    string pom_nazev1;
    pom_nazev1 += cesta_pro_vypis_best_net_vah +"/";
    stringstream se121;
    se121 << "_best_nets_weights_initial_" << LAG << "_LAG" << ".txt";
    pom_nazev1 += slovo + se121.str();

    ofstream proud_soubor1(pom_nazev1.c_str());

    if(!proud_soubor1){
        cout << "\nNeni mozne otevrit soubor " << pom_nazev1;
        exit(EXIT_FAILURE);
    }
    proud_soubor1.precision(22);
    proud_soubor1.width(30);
    proud_soubor1.setf(ios::left);
    for (unsigned int rad =0; rad < bestnet_vahy.n_rows ;rad ++ ){
      for (unsigned int sl =0; sl < bestnet_vahy.n_cols ;sl ++ ){
         proud_soubor1 << as_scalar(bestnet_vahy_initial(rad,sl)) ;//<< "  \t\t  ";
         proud_soubor1.width(30);
        }
        proud_soubor1 << endl;
      }
    proud_soubor1.close();
    }

}

/**
  * Vypise kriteria vybranych best nets
  * @param infromace o souboru provypis
  */
void neural_net::vypis_kriteria_best_nets(unsigned int cislo , string slovo, colvec MEAN_kriteria)
{
    string pom_nazev;
    pom_nazev += cesta_pro_vypis_best_net_vah +"/";
    stringstream se12;
    se12 << "_best_nets_kriteria_" << LAG << "_LAG" << ".txt";
    pom_nazev += slovo + se12.str();

    ofstream proud_soubor(pom_nazev.c_str(), ios::app);

    if(!proud_soubor){
        cout << "\nNeni mozne otevrit soubor " << pom_nazev;
        exit(EXIT_FAILURE);
    }

    proud_soubor << cislo << "\t" << trans(MEAN_kriteria);

    proud_soubor.close();

}

/**
  * Ensemble simulation s vyuzitim vysledku bestnet
  */
void neural_net::ensemble_simulation()
{
    nahrad_cestu();

    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
                if(data_kal[vz].shuffle_indexy) {
                    data_kal[vz].prehazej_vzory_zpet(true,true,false);
                }
            }

    vzory *data_kal_ens, *data_test_ens;

    data_kal_ens = new vzory[pocet_vzorovych_dat];
    data_test_ens = new vzory[pocet_data_test];

    for (unsigned int ka = 0; ka < pocet_vzorovych_dat ; ka++ ){
      data_kal_ens[ka] = data_kal[ka];
      }
    for (unsigned int te = 0; te < pocet_data_test ; te++ ){
      data_test_ens[te] = data_test[te];
      }

    stringstream lag_slovo;
    lag_slovo << LAG << "_LAG_";
    for (unsigned int ens = 0; ens < real_pocet_bestnet ; ens++){
       stringstream cislo;
       cislo << ens +1;

       string slovo_mer_kal, slovo_sim_kal;
       slovo_mer_kal = "/OUT_OBS_KAL_" + cislo.str() + "_ens_"+ lag_slovo.str();
       slovo_sim_kal = "/OUT_SIM_KAL_"+ cislo.str() + "_ens_"+ lag_slovo.str();

       string slovo_mer_test, slovo_sim_test;
       slovo_mer_test += "/OUT_OBS_TEST_" + cislo.str() + "_ens_"+ lag_slovo.str();
       slovo_sim_test += "/OUT_SIM_TEST_"+ cislo.str() + "_ens"+"_"+ lag_slovo.str();

       vahy = bestnet_vahy.col(ens);

       prirad_z_vahy();

       vypocti_allvzory();
       vypocti_allvzory_test();

       for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
           data_kal[vz].transformuj_zpetne(true,true,true);
           data_kal[vz].vypis_vystupy(slovo_mer_kal);
           data_kal[vz].vypis_sim_vystupy(slovo_sim_kal);
          }

       for (unsigned int vz = 0; vz < pocet_data_test ;vz++ ){
          data_test[vz].transformuj_zpetne(true,true,true);
          data_test[vz].vypis_vystupy(slovo_mer_test);
          data_test[vz].vypis_sim_vystupy(slovo_sim_test);
         }

    for (unsigned int ka = 0; ka < pocet_vzorovych_dat ; ka++ ){
      data_kal[ka] = data_kal_ens[ka];
      }

    for (unsigned int te = 0; te < pocet_data_test ; te++ ){
      data_test[te] = data_test_ens[te];
      }
    }

    delete[] data_kal_ens;
    delete[] data_test_ens;
}

/**
  * Nahrazuje cestu ve vzorech pro vypis k ensemblu
  */
void neural_net::nahrad_cestu()
{
    for (unsigned int fi =0; fi < pocet_data_test ; fi++ ){
      data_test[fi].out_cesta = cesta_pro_vypis_best_net_simulaci;
      }

    for (unsigned int fi =0; fi < pocet_vzorovych_dat; fi++ ){
      data_kal[fi].out_cesta = cesta_pro_vypis_best_net_simulaci;
      }
}

/**
  * Test treninku a genaralizace s nactenymi vahami ze souboru best int vahy
  */
void neural_net::test_treninku_s_read_vahami()
{
    vzory *zaloha_kal, * zaloha_test;

    zaloha_kal = new vzory[pocet_vzorovych_dat];
    zaloha_test = new vzory[pocet_data_test];

    for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      zaloha_kal[vzk] = data_kal[vzk];
      }
    for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      zaloha_test[vzt] = data_test[vzt];
      }


 mat vah_rand;
 //vah_rand.set_size(pocet_vah,Ensemble);
 vah_rand.load(soubor_s_init_vahami.c_str());
// cout << endl<< vah_rand << endl;
 unsigned int ensemble_read_init_vah = 0;
 ensemble_read_init_vah = vah_rand.n_cols;
 if(ensemble_read_init_vah == 0 ){
    cout << "\nPocet sloupcu v souboru " << soubor_s_init_vahami.c_str() << " je roven nule." << endl;
    exit(EXIT_FAILURE );
 }

 priprav_data_k_trenovani();
 priprav_testovaci_data();
 LAG_control();
 
 if (bench_OLS) benchmark_OLS();

 bestnet_vahy.set_size(pocet_vah, 1);
 bestnet_vahy.fill(0);
 bestnet_vahy_initial.set_size(pocet_vah,1);
 bestnet_vahy_initial.fill(0);

 cout << endl << "Ensemble run";

 string slovo_best_net = "";

  for (unsigned int en = 0; en<ensemble_read_init_vah ;en++ ){
    vahy = vah_rand.col(en);
    prirad_z_vahy();
    nulovani_dF_dw();
    nulovani_dE_dw();
    REZIDUI.fill(0.0);
    string pom_nazev, slovo, slovo1;
    pom_nazev +=cesta_pro_vypis_kriterii +"/";
    switch (typ_trenovani) // na zaklade typu trenovani vyberu metodu trenovani site
    {
    	case BPonline:
       	    bp_online();
    		break;
    	case BPonline_regul:
       	    bp_online_regul();
       	    slovo += "KAL_Ensemble_BPonline_";
       	    slovo1 += "TEST_Ensemble_BPonline_";
    		break;
        case BPbatch:
       	    bp_batch();
       	    slovo += "KAL_Ensemble_BPbatch_";
       	    slovo1 += "TEST_Ensemble_BPbatch_";
    		break;
        case BPbatch_regul:
       	    bp_batch_regul();
       	    slovo += "KAL_Ensemble_BPbatch_regul_";
       	    slovo1 += "TEST_Ensemble_BPbatch_regul_";
    		break;
        case LMbatch:
           LevM_batch();
           slovo += "KAL_Ensemble_LEV_MAR_";
           slovo1 += "TEST_Ensemble_LEV_MAR_";
           break;
         case LMbatch_regul:
           LevM_batch_regul();
           slovo += "KAL_Ensemble_LEV_MAR_regul_";
           slovo1 += "TEST_Ensemble_LEV_MAR_regul_";
           break;
         case BPbatch_RpropPLUS:
           bp_RpropPLUS();
           slovo += "KAL_Ensemble_RpropPLUS_";
           slovo1 += "TEST_Ensemble_RpropPLUS_";
           break;
         case BPbatch_RpropMINUS:
           bp_RpropMINUS();
           slovo += "KAL_Ensemble_RpropMINUS_";
           slovo1 += "TEST_Ensemble_RpropMINUS_";
           break;
        case ScCoCr_PERRY:
           ScConGrad_Perry();
           slovo += "KAL_Ensemble_ScCoGr_Perry_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_Perry_batch";
           break;
        case ScCoCr_HESTENES:
           ScConGrad_Hestenes();
           slovo += "KAL_Ensemble_ScCoGr_HESTENES_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_HESTENES_batch";
           break;
         case ScCoCr_FLETCHER:
           ScConGrad_Fletcher();
           slovo += "KAL_Ensemble_ScCoGr_FLETCHER_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_FLETCHER_batch";
           break;
          case ScCoCr_POLAK:
           ScConGrad_Polak();
           slovo += "KAL_Ensemble_ScCoGr_POLAK_batch";
           slovo1 += "TEST_Ensemble_ScCoGr_POLAK_batch";
           break;
          case StepD_BaBo:
           StepD_BB();
           slovo += "KAL_Ensemble_SDBB_batch";
           slovo1 += "TEST_Ensemble_SDBB_batch";
           break;           
           default:
            break;
    }

 cout <<endl << en+1 << " \t " << norm(dE_vahy,2) << " \t " << norm(vahy,2) << " \t " << (norm(REZIDUI,2))/(pocet_vzoru*pocet_vystupu);
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
                if(data_kal[vz].shuffle_indexy) {
                    data_kal[vz].prehazej_vzory_zpet(true,true,false);
                }
            }


   vypocti_allvzory();
   vypocti_allvzory_test();
   stanov_kriteria(en,pom_nazev,slovo);
   stanov_kriteria_test_selectbestnet(en,pom_nazev,slovo1,vah_rand.col(en));
   if(en == 0) slovo_best_net += slovo1;

   for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
           if(data_kal[vz].shuffle_indexy) {
   //         data_kal[vz].shuffle();
            data_kal[vz].prehazej_vzory(true,true);
        }
    }
   }

   for (unsigned int vzk = 0; vzk < pocet_vzorovych_dat ; vzk++){
      data_kal [vzk] = zaloha_kal[vzk];
   //   cout  << endl << data_kal[vzk].data_vstupu;
      }
   for (unsigned int vzt = 0; vzt < pocet_data_test; vzt++){
      data_test[vzt] = zaloha_test[vzt];
      }

   if(vypis_best_nets) {
     vypis_best_vahy(slovo_best_net,false);
   }

   if(best_net){
     if(real_pocet_bestnet > 0){
      ensemble_simulation();
     }
   }

   delete[] zaloha_kal;
   delete[] zaloha_test;
}

void neural_net::prirad_do_dE_dw()
{
    unsigned int pom_pocet = 0, pom_pocet1 = 0;
    unsigned int pom_index = 0;

    unsigned int Bias = 0;
    if (bias_ano_ne) { // pokud je sit s biasem
      Bias =1;
    }

    for (unsigned int vrs = 0;vrs < pocet_vrstev ; vrs++ ){
        if(vrs == 0) {
            pom_pocet1 = pocet_vstupu + Bias;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] -Bias;
           }
           else if(vrs < (pocet_vrstev -1)&&(vrs > 0)) {
            pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
            pom_pocet = pocet_neuronu_ve_vrtsve[vrs] -Bias;
             } else if(vrs == (pocet_vrstev-1)){
                     pom_pocet1 = pocet_neuronu_ve_vrtsve[vrs-1] ;
                     pom_pocet = pocet_neuronu_ve_vrtsve[vrs] ;
             }

        for (unsigned int neur = 0; neur < pom_pocet; neur++ ){
          for (unsigned int neur1 = 0; neur1 < pom_pocet1; neur1++ ){
            //neuron_ve_vrstve[vrs][neur].vahy(neur1) = as_scalar(vahy(pom_index));
            dE_vahy(pom_index) =  neuron_ve_vrstve[vrs][neur].dE_dw(neur1);
            //neuron_ve_vrstve[vrs][neur].dF_dw(neur1) = 0.0;
            //neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = 0.0;
            pom_index++;
            }
          }
        }
}


void neural_net::vypocti_gradient_batch_CC()
{

     for (unsigned int vz = 0; vz < pocet_vzorovych_dat; vz++ ){
      for (unsigned int vzor = 0; vzor < data_kal[vz].pocet_vzoru ;vzor++ ){
//     for (unsigned int vz = 0; vz < 1; vz++ ){
//      for (unsigned int vzor = 0; vzor < 1 ;vzor++ ){
            //cout << vzor << "\t" <<data[0].data_vstupu.row(vzor) << endl << pom_vzor_vstupy << endl;
            vypocti_1vzor(trans(data_kal[vz].data_vstupu.row(vzor)));
            vypocti_derivace_BP_1vzor_CC(trans(data_kal[vz].data_vstupu.row(vzor)),trans(data_kal[vz].data_vystupu.row(vzor)));
            }
      }
//    ofstream proud_soubor_vahy("/home/pavel/Programs/perceptron/vzory/vystupy/best_nets/vahy_bias_CC.txt", ios::app);
//    proud_soubor_vahy << neuron_ve_vrstve[0][3].dE_dw;
//    proud_soubor_vahy.close();

    prirad_do_vahy();
}


/**
  * Vypocte pro dany vstup a vystup hodnotu derivace \f[ \frac{\partial E}{\partial w_i}\f] a pricte ji do stanajici hodnoty derivace
  * @param vstupy
  * @param vystupy
  */
void neural_net::vypocti_derivace_BP_1vzor_CC(colvec vzor_vstupy, colvec vzor_vystup)
{
   colvec pom_delta; //vytvoreni pomocne premenne, udavajici rozdil pozadovanych a simulovanych udaju v siti
   pom_delta.set_size(pocet_vystupu); // inicializace premenne tak, aby mela velikost jako je pocet vystupu ze site

  // cout << " prv " << vzor_vstupy << endl << endl;
  unsigned int Bias = 0;
  if (bias_ano_ne) { // pokud je sit s biasem
      Bias = 1;
      vzor_vstupy.reshape(pocet_vstupu+1,1); // je nutne poslat jako vstup 1 do prvni skryte vrstvy
      vzor_vstupy(pocet_vstupu) =1;
  }
   //cout << vzor_vstupy << endl;
  // cout << endl << vzor_vstupy.n_elem << endl;
   //pom_delta = vzor_vystup - vystupy; // vypocet rozdilu
   pom_delta = vystupy - vzor_vystup; // vypocet rozdilu
  // cout << pom_delta;
   //cout << pocet_vrstev <<"\n";
   unsigned int vrs =0;
  // for (unsigned int vrs = (pocet_vrstev-1);vrs  >= 0;vrs--)  { // pro kazdou vrstvu v siti, zaciname posledni
   for (unsigned int vrs_index = 0;vrs_index  < pocet_vrstev;vrs_index++)  {
       vrs = pocet_vrstev - 1 - vrs_index;
   
       // cout <<"uops " <<vrs << endl;
       if (vrs == (pocet_vrstev-1) ){ // kdyz jde o vystupni vrstvu
          for (unsigned int neur=0; neur<pocet_neuronu_ve_vrtsve[vrs] ; neur++ ) { // pro kazdy neuron v dane vrstve
               for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1] ;neur1++ ){ // pro vsechny neurony predchadzejici vrstvy[vrs-1]
                //   double pom_dw =0.0;
                 //  pom_dw = as_scalar(neuron_ve_vrstve[vrs][neur].vahy(neur1) );
                   neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) = pom_delta(neur) * neuron_ve_vrstve[vrs][neur].der_afce;
                   neuron_ve_vrstve[vrs][neur].dE_dw(neur1) +=  neuron_ve_vrstve[vrs][neur].delta_vahy(neur1)* neuron_ve_vrstve[vrs-1][neur1].vystup;
                   }
             }

          }   else {
//            double pom_dw =0.0;
                if(vrs>0){//prostredek nn
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_neuronu_ve_vrtsve[vrs-1];neur1++ ){
                          for (unsigned int neur2 = 0; neur2 < pocet_neuronu_ve_vrtsve[vrs+1] - Bias ;neur2++){
                        	neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * neuron_ve_vrstve[vrs-1][neur1].vystup;
                        }
                   }
                } else { if(vrs ==0){
                // vstupy do prvni skryte vrstvyif(vrs == 0)
                   for (unsigned int neur=0; neur< pocet_neuronu_ve_vrtsve[vrs] - Bias; neur++ ) {//cout <<"vrs "<< vrs <<"neur "<< neur <<"\n";
                       for (unsigned int  neur1 = 0; neur1 < pocet_vstupu + Bias;neur1++ ){
                          unsigned int pom_pocet;
                          if (pocet_neuronu_ve_vrtsve[vrs+1] == (pocet_vrstev -1)) {pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1];}
                          else pom_pocet  = pocet_neuronu_ve_vrtsve[vrs+1] - Bias;
                          for (unsigned int neur2 = 0; neur2 < pom_pocet ;neur2++){
                         //   cout <<"vrs "<< vrs <<"neur2 "<< neur2 <<"\n";
                            neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) += neuron_ve_vrstve[vrs+1][neur2].delta_vahy(neur) * neuron_ve_vrstve[vrs+1][neur2].vahy(neur);
                            }
                           // if( neur1 == pocet_vstupu) cout  << vrs << " " << neuron_ve_vrstve[0][neur].delta_vahy(neur1) << endl;
                        neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) *= neuron_ve_vrstve[vrs][neur].der_afce;
                           // if( neur1 == pocet_vstupu) cout << neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) << endl;
                        neuron_ve_vrstve[vrs][neur].dE_dw(neur1) += neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) * vzor_vstupy(neur1);
                         //if( neur1 == pocet_vstupu) cout << neuron_ve_vrstve[vrs][neur].delta_vahy(neur1) <<  " vs " << vzor_vstupy(neur1) << endl;
                         //if( neur1 == pocet_vstupu) cout << neuron_ve_vrstve[vrs][neur].dE_dw(neur1) << endl << endl;
                       // cout  << "jsem tady " << neuron_ve_vrstve[vrs][neur].dE_dw(neur1) << endl;
                        }

                   }
                   break;
                }
                }
                
        }
    }//vrstvy

//    ofstream proud_soubor_vahy("/home/pavel/Programs/perceptron/vzory/vystupy/best_nets/vahy_bias_CC_deriv.txt", ios::app);
//    proud_soubor_vahy << neuron_ve_vrstve[0][3].dE_dw;
//    proud_soubor_vahy.close();

   nulovani_delt(); //vynulovat delty
   //cout  << " normice " << norm(dE_vahy,2);

}

/**
  *  Zkoroluje zda je zadany LAG u vsech dat stejne
  */
void neural_net::LAG_control()
{
    unsigned int LAG_kal = 9999999, LAG_test = 99999999;
    for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
       if (vz==0) LAG_kal = data_kal[vz].lag;
       else{
         if (LAG_kal != data_kal[vz].lag) {
            cout << endl << "Spatne zadany interval predikce u kalibracnich dat " << data_kal[vz].soubor_s_nazvy_vstupu;
            exit(EXIT_FAILURE);
         }
       }
      }
      
    for (unsigned int vz = 0; vz < pocet_data_test ;vz++ ){
       if (vz==0) LAG_test = data_test[vz].lag;
       else{
         if (LAG_test != data_test[vz].lag) {
            cout << endl << "Spatne zadany interval predikce u testovacich  dat " << data_test[vz].soubor_s_nazvy_vstupu;
            exit(EXIT_FAILURE);
         }
       }
      }
      
      if (LAG_kal != LAG_test){
          cout << endl << "Spatne zadany interval predikce u dat " << LAG_kal << " u kalibrace a u " << LAG_test << " testovacich dat";   
          exit(EXIT_FAILURE);
      }
      
      LAG = LAG_kal + 1;
}


void neural_net::StepD_BB()
{
    double ny = 0.0, pom_SS_er =0.0, delta_normy_zmeny_vahy = 0.0, prev_norm_zmeny_vahy = 0.0;//, alp = 0.0;
    colvec d, s, y, d_old, vahy_old, g_old;
    
    s.set_size(pocet_vrstev);
    y.set_size(pocet_vrstev);
    vahy_old.set_size(pocet_vrstev);
    g_old.set_size(pocet_vah);
    d_old.set_size(pocet_vah);
    d.set_size(pocet_vah);
    
    vahy.fill(0.0);
    s = vahy;
    
    
    for (unsigned int epch = 0; epch < BBmaxiter; epch++){
         vypocti_allvzory();
         stanov_SS_er();
         vypocti_gradient_batch_CC();
         pom_SS_er = SS_er;
    
    
         if(pom_SS_er < BB_eps){
             cout << endl <<   "SD BB converges Sum of Squares of Reziduals: " << SS_er << endl;
            break ;
         }
         if( (epch == 0) ){
            ny =  1/ norm(dE_vahy,2);
            d = - ny * dE_vahy;
            vahy_old = vahy;
         } else {
             y= dE_vahy - g_old;
             if((norm(s,2) <= BB_restart_boundary) || (norm(y, 2) <= BB_restart_boundary) || (as_scalar(trans(dE_vahy) * dE_vahy)) <= (-10e-3 * norm(dE_vahy,2) * norm(dE_vahy,2)) ) {
                ny =  1/ norm(dE_vahy,2);
                d = - ny * dE_vahy;
                if(BB_restart_out){
                    if(norm(s,2) <= BB_restart_boundary ) cout << endl << "Restarting the SD-BB because s = BB_boundary";
                    if(norm(y,2) <= BB_restart_boundary ) cout << endl << "Restarting the SD-BB because y = BB_boundary";
                }
             } else{
                 //ny=as_scalar((trans(s) * s) / (trans(y)*s));              
                 ny=as_scalar((trans(s) * y) / (trans(y)*y)); 
                 d = -ny * dE_vahy;
                 if ((as_scalar(trans(d) * dE_vahy)) <= (-10e-3 * norm(d,2) * norm(dE_vahy,2))){}
                     else{
                      ny =  1/ norm(dE_vahy,2);
                      d = -ny *dE_vahy;
                 //d = dE_vahy;
                    if (BB_restart_out)  cout << "\nSpectral gradient: "<< as_scalar(trans(d) * dE_vahy)<< " <= " << -10e-3*(norm(d,2) * norm(dE_vahy,2)) <<" restarting SDBB.";
                 //if(ny * dE_vahy <=){as_scalar
                 //    d = dE_vahy;
  //      cout << endl << "0_alp " << alp << " d_old " << norm(d_old,2)  << " d " << norm(d,2) <<  " y " << norm(y,2) ;
  //      cout <<endl << "0_ny " << ny << " bbeta " << bbeta  << " v_old " << norm(vahy_old,2) << " s " << norm(s,2);
                 //}
                }
    //             alp = alp * norm(d,2) / norm(d_old,2);
                 }
                 
             //alp = line_search(alp, vahy_old, d, pom_SS_er);    
             //vahy = vahy_old + alp * d;
             vahy = vahy_old + d;
             s = vahy - vahy_old;
             g_old = dE_vahy;
             d_old = d;
             vahy_old = vahy;
         }
         
    if (controls_out){
      string pom_nazev;
      pom_nazev +=cesta_pro_vypis_kriterii +"/";
      stanov_kriteria(epch,pom_nazev,"KAL_SDBB_batch_");
      stanov_kriteria_test(epch,pom_nazev,"TEST_SDBB_batch_");
      cout <<endl << epch+1 << "  \t  " << norm(dE_vahy,2) << "  \t  " << norm(vahy,2) << "   \t   " << norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu) << " \t " << delta_normy_zmeny_vahy;
     }


     if(epch==0) {
        delta_normy_zmeny_vahy = as_scalar(norm(dE_vahy,2));
        prev_norm_zmeny_vahy = 0.0;
     } else{
        delta_normy_zmeny_vahy = fabs(prev_norm_zmeny_vahy - as_scalar(norm(dE_vahy,2)));
        prev_norm_zmeny_vahy = as_scalar(norm(dE_vahy,2));
     }
      if((control_SS_error >= norm(REZIDUI,2) / (pocet_vzoru * pocet_vystupu))) {
            cout << endl << "Dosazena  dobra hodnota SC.";
            break;
     }
     if(control_delta_par >= delta_normy_zmeny_vahy) {
         cout << endl << "Dosazena  nizka hodnota zmeny vah.";
         break;
      }
         
         if (control_saturation) net_saturation();
         
    }
}

/**
  * Reseni problemu OLS
  */
void neural_net::benchmark_OLS()
{
  vzory *data_trans_TEST, *data_trans_KAL;

  data_trans_TEST = new vzory[pocet_data_test];
  data_trans_KAL = new vzory[pocet_vzorovych_dat];

  for (unsigned int vz=0;vz < pocet_data_test ;vz++ ){
    data_trans_TEST[vz] = data_test[vz];
    }

   for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
    data_trans_KAL[vz] = data_kal[vz];
    if(data_kal[vz].shuffle_indexy) {
        data_kal[vz].prehazej_vzory_zpet(true,true,false);
       }
    }
       
    for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
     data_kal[vz].transformuj_zpetne(true,true,false);
    }
//    cout << endl << "helo1";
    for (unsigned int vz=0;vz < pocet_data_test;vz++ ){
     data_test[vz].transformuj_zpetne(true,true,false);
    }
//  cout << endl << "helo2";  
  mat VYSTUPY_KAL_OLS, SIMVYSTUPY_KAL_OLS, VSTUPY_KAL_OLS;
  
//  cout << endl << "helo3";

  SIMVYSTUPY_KAL_OLS.set_size(pocet_vzoru,pocet_vystupu);
  SIMVYSTUPY_KAL_OLS.fill(0.0);
  VYSTUPY_KAL_OLS.set_size(pocet_vzoru,pocet_vystupu);
  VSTUPY_KAL_OLS.set_size(pocet_vzoru,pocet_vstupu+1);
  VSTUPY_KAL_OLS.fill(1);
  
//  cout << endl << "helo4" << " nvys" << VYSTUPY_KAL_OLS.n_rows << " nrows " << VSTUPY_KAL_OLS.n_rows;

  unsigned int prvni_row =0, last_row=0;
  for (unsigned int vz =0; vz <pocet_vzorovych_dat ;vz++ ){
    last_row += data_kal[vz].pocet_vzoru;
    VYSTUPY_KAL_OLS.submat(prvni_row,0,(last_row-1),(pocet_vystupu-1)) =data_kal[vz].data_vystupu;
    VSTUPY_KAL_OLS.submat(prvni_row,0,(last_row-1),(pocet_vstupu-1)) =data_kal[vz].data_vstupu;
    prvni_row = last_row;
  }
//  cout << endl << "helo5";

  mat VYSTUPY_TEST_OLS, SIMVYSTUPY_TEST_OLS, VSTUPY_TEST_OLS;
  
  VYSTUPY_TEST_OLS.set_size(pocet_radku_test_dat, pocet_vystupu);
  SIMVYSTUPY_TEST_OLS.set_size(pocet_radku_test_dat, pocet_vystupu);
  SIMVYSTUPY_TEST_OLS.fill(0.0);
  VSTUPY_TEST_OLS.set_size(pocet_radku_test_dat,pocet_vstupu+1);
  VSTUPY_TEST_OLS.fill(1);

  
  unsigned int prvni_row_test =0, last_row_test=0;
  for (unsigned int vz =0; vz <pocet_data_test ;vz++ ){
    last_row_test += data_test[vz].pocet_vzoru;
    VYSTUPY_TEST_OLS.submat(prvni_row_test,0,(last_row_test-1),(pocet_vystupu-1)) =data_test[vz].data_vystupu;
    VSTUPY_TEST_OLS.submat(prvni_row_test,0,(last_row_test-1),(pocet_vstupu-1)) =data_test[vz].data_vstupu;
    prvni_row_test = last_row_test;
  }  
  
//  cout << endl << "helo6";
 
   for(unsigned int vys = 0; vys < pocet_vystupu; vys++){
            colvec beta, OBS_vec;
            beta.set_size(pocet_vstupu + 1);    
            OBS_vec = VYSTUPY_KAL_OLS.col(vys);
            solve(beta, VSTUPY_KAL_OLS, OBS_vec);
            beta_OLS.col(vys) = beta;    
       }

//  cout << endl << "helo7";
       
    SIMVYSTUPY_KAL_OLS = VSTUPY_KAL_OLS * beta_OLS;
    SIMVYSTUPY_TEST_OLS = VSTUPY_TEST_OLS * beta_OLS;
    
    
  colvec mean_krit_kal_bench;
  mean_krit_kal_bench.set_size(17);
  mean_krit_kal_bench.fill(0);
  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se11;
    nazev_filet1 += path_OLS_benchmark;
    se << (kr+1);    
    se11 << "_kriteria_bench_OLS_" << LAG << "_LAG" << ".txt";
    nazev_filet1 +=  "/KAL_" + se.str() + se11.str();
    colvec Qobs, Qsim;
    Qobs = VYSTUPY_KAL_OLS.col(kr);
    Qsim = SIMVYSTUPY_KAL_OLS.col(kr);
    kriteria krit_kal_bench(Qobs,Qsim);
    krit_kal_bench.vypocti_vsechna(pocet_vstupu + 1, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit_kal_bench.vypis((nazev_filet1),1);
    Qobs.reset();
    Qsim.reset();
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_kal_bench(mr) += krit_kal_bench.krit[mr] / pocet_vystupu;
      }
    }
    string nazev_fileto1;
    stringstream se1, se12;
    nazev_fileto1 += path_OLS_benchmark+ "/" ;
    se1 << "MEAN_KAL_";
    se12 <<  LAG << "_LAG" << ".txt";
    nazev_fileto1 += se1.str()+ "_kriteria_bench_OLS_" + se12.str();
    
    if(pocet_vystupu > 1) vypis_MEAN(1 , nazev_fileto1, mean_krit_kal_bench);

    
  colvec mean_krit_test_bench;
  mean_krit_test_bench.set_size(17);
  mean_krit_test_bench.fill(0);
  for (unsigned int kr = 0;kr<pocet_vystupu ;kr++ ){
    string nazev_filet1;
    stringstream se, se11;
    nazev_filet1 += path_OLS_benchmark;
    se << (kr+1);    
    se11 << "_kriteria_bench_OLS_" << LAG << "_LAG" << ".txt";
    nazev_filet1 +=  "/TEST_" + se.str() + se11.str();
    colvec Qobs, Qsim;
    Qobs = VYSTUPY_TEST_OLS.col(kr);
    Qsim = SIMVYSTUPY_TEST_OLS.col(kr);
    kriteria krit_test_bench(Qobs,Qsim);
    krit_test_bench.vypocti_vsechna(pocet_vstupu + 1, kr+1, 0.25, 0.75);
    //cout << nazev_filet1 << endl;
    krit_test_bench.vypis((nazev_filet1),1);
    Qobs.reset();
    Qsim.reset();
    for (unsigned int mr = 0;mr < 17 ;mr++ ){
      mean_krit_test_bench(mr) += krit_test_bench.krit[mr] / pocet_vystupu;
      }
    }
    
    string nazev_fileto1_t;
    stringstream se1_t, se12_t;
    nazev_fileto1_t += path_OLS_benchmark+ "/" ;
    se1_t << "MEAN_TEST_";
    se12_t <<  LAG << "_LAG" << ".txt";
    nazev_fileto1 += se1_t.str()+ "_kriteria_bench_OLS_" + se12_t.str();
    
    if(pocet_vystupu > 1) vypis_MEAN(1 , nazev_fileto1_t, mean_krit_test_bench);
       
    mat REZ_KAL , REZ_TEST;
    REZ_KAL.set_size(pocet_vzoru,pocet_vystupu);
    REZ_TEST.set_size(pocet_radku_test_dat, pocet_vystupu);
    
    REZ_KAL = VYSTUPY_KAL_OLS - SIMVYSTUPY_KAL_OLS;
    REZ_TEST = VYSTUPY_TEST_OLS - SIMVYSTUPY_TEST_OLS;
       
    cout << endl << "Benchmark OLS solution: \n" << "Norm(REZ) " << norm(REZ_KAL,2) / (pocet_vzoru * pocet_vystupu) << " for calibration, " << norm(REZ_TEST,2) / (pocet_radku_test_dat * pocet_vystupu) << " for testing data sets." << endl;
    
   unsigned int prvni_row_testb =0, last_row_testb=0;
   for (unsigned int vz =0; vz <pocet_data_test ;vz++ ){
    last_row_testb += data_test[vz].pocet_vzoru;
    data_test[vz].data_vystupu = VYSTUPY_TEST_OLS.submat(prvni_row_testb,0,(last_row_testb-1),(pocet_vystupu-1));
    data_test[vz].sim_vystupy = SIMVYSTUPY_TEST_OLS.submat(prvni_row_testb,0,(last_row_testb-1),(pocet_vystupu-1));
    prvni_row_testb = last_row_testb;
   }
    
   unsigned int prvni_rowb =0, last_rowb=0;
   for (unsigned int vz =0; vz <pocet_vzorovych_dat ;vz++ ){
    last_rowb += data_kal[vz].pocet_vzoru;
    data_kal[vz].data_vystupu = VYSTUPY_KAL_OLS.submat(prvni_rowb,0,(last_rowb-1),(pocet_vystupu-1));
    data_kal[vz].sim_vystupy = SIMVYSTUPY_KAL_OLS.submat(prvni_rowb,0,(last_rowb-1),(pocet_vystupu-1));
    prvni_rowb = last_rowb;
   } 
    
   stringstream lag_slovo;
   lag_slovo << LAG << "_LAG_"; 
    
   string slovo_mer_kal, slovo_sim_kal;
   slovo_mer_kal = "/OUT_OBS_KAL_OLS_" + lag_slovo.str();
   slovo_sim_kal =  "/OUT_SIM_KAL_OLS_" + lag_slovo.str();

   string slovo_mer_test, slovo_sim_test;
   slovo_mer_test += "/OUT_OBS_TEST_OLS_" + lag_slovo.str();
   slovo_sim_test +=  "/OUT_SIM_TEST_OLS_" + lag_slovo.str();

  for (unsigned int vz = 0; vz < pocet_vzorovych_dat ;vz++ ){
     data_kal[vz].vypis_vystupy(slovo_mer_kal);
     data_kal[vz].vypis_sim_vystupy(slovo_sim_kal);
    }

  for (unsigned int vz = 0; vz < pocet_data_test ;vz++ ){
     data_test[vz].vypis_vystupy(slovo_mer_test);
     data_test[vz].vypis_sim_vystupy(slovo_sim_test);
    }

    
    for (unsigned int vz=0;vz < pocet_data_test ;vz++ ){
      data_test[vz] = data_trans_TEST[vz];
    }  
    
    for (unsigned int vz=0;vz < pocet_vzorovych_dat ;vz++ ){
      data_kal[vz] = data_trans_KAL[vz];
    }  
    
    delete[] data_trans_TEST;   
    delete[] data_trans_KAL;
}

void neural_net::premen_architekturu()
{


}
