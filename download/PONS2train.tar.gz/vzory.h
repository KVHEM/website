#ifndef VZORY_H
#define VZORY_H

#include <iostream>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <string>
#include <fstream>
#include <ios>
#include <time.h>
#include "armadillo"

using namespace std;
using namespace arma;



class vzory
{
    public:
        enum {Nelinearni, Linearni} typ_transformace;
        vzory();
        vzory(string jmeno_souboru_s_nastavenim);
        ~vzory();
        vzory(const vzory& other);
        vzory& operator=(const vzory& other);

        unsigned int pocet_casovych_vzoru;//!< Počet casovych vzorů MLP
        unsigned int pocet_maticovych_vzoru;//!< Počet maticovych vzorů MLP
        unsigned int pocet_vzoru;//!< Celkovy počet vzorů MLP

        unsigned int pocet_IN;//!< Počet vstupů MLP
        unsigned int pocet_OUT;//!< Počet výstupů MLP

        unsigned int pocet_druhu_vstupu;//!< Počet druhů casovych vstupů MLP
        unsigned int pocet_maticovych_vstupu;//!< Pocet maticovych vstupu

        unsigned int *historie_vstupu;//!< Pole s historii casovych vstupů MLP
        unsigned int *sloupec;//!< Sloupec dat nacitanych pro tvorbu casovych vstupu

        unsigned int pocet_druhu_casovych_vystupu;//!< Pocet predpovidanych velicin NN siti
        unsigned int sloupec_predik_dat;//!< Sloupec v casovym souboru predpovidanych dat
        unsigned int lag;//!< Posun v casovych vzorech znazornujici posun predikcniho intervalu

        unsigned int pocet_maticovych_vystupu;//!< Pocet souboru s maticovymi vystupy

        unsigned int pocet_vstupnich_souboru;//!< Celkovy pocet vstupnich souboru
        unsigned int pocet_vystupnich_souboru;//!< Celkovy pocet vystupnich souboru

        unsigned int transformace_dat;//!< typ transformace
        double alpha;//!< parametr nelinearni transformace
        double min_lin_tran, max_lin_tran;//!< Interval pro zobrazeni dat
        double kacko, qecko ;//!< Parametry linearni transformace
        bool shuffle_indexy;//!< zda se vzory nahodne prehodi vzory
        unsigned int *indexy_prehazeni_vzoru;


        string soubor_s_nazvy_vstupu;//!< Soubor s nazvy souboru vstupnich dat ve forme casovych rad
        string soubor_s_nazvy_mat_vstupu;//!< Soubor s nazvy souboru vstupnich dat ve forme matic

        string out_cesta;//!< Adresar pro vypsani vzoru

        string *soubory_se_vstupy;//!< Pole s nazvy datovych souboru casovych rad
        string *soubory_s_maticovymi_vstupy;//!< Pole s nazvy datovych souboru matic vstupu

        string soubor_s_cas_vystupy;//!< Pole s nazvy datovych souboru casovych rad vystupu
        string *soubory_s_maticovymi_vystupy;//!< Pole s nazvy datovych souboru matic vystupu

        string soubor_s_nazvem_cas_vystupu;//!< Pole s nazvy casovych dat vystupu
        string soubor_s_nazvem_mat_vystupu;//!< Pole s nazvy maticovych vystupu

        string *out_soubory;//!< Jmena vsech vystupnich souboru
        string *in_soubory;//!<Jmena vsech vstupnich souboru

        mat data_vstupu;//!< matice vstupů do MLP
        mat data_vystupu;//!< matice měřených výstupů  MLP
        mat sim_vystupy;//!< matice vypočtených výstupů z MLP

        mat vytvor_kusy_casove_vst_matice(string soubor_s_daty, unsigned int pocet_sloupcu, unsigned int posun, unsigned int pocet_OUT_NN, unsigned int sloupec_v_souboru);//!< Vytvoreni casti vstupni matice kontrolovane urcitym druhem vstupu
        mat vytvor_kusy_casove_vys_matice(string soubor_s_daty, unsigned int sloupec_v_souboru);//!< Vytvoreni casti vstupni matice kontrolovane urcitym druhem vstupu

        mat vytvor_kusy_necasove_vst_matice(string soubor_s_daty);//!< Nacte soubor matici a vrati kus matice
        mat vytvor_kusy_necasove_vys_matice(string soubor_s_daty);//!< Nacte soubor matici a vrati kus matice

        mat vytvor_casovou_vstupni_matici();
        mat vytvor_necasovou_vstupni_matici();

        mat vytvor_casovou_vystupni_matici();
        mat vytvor_necasovou_vystupni_matici();

        void vytvor_vstupni_matici();
        void vytvor_vystupni_matici();

        void stanov_pocet_casovych_vzoru();//! Stanovi pocet casovych vzoru
        void stanov_pocet_maticovych_vzoru();//! Stanovi pocet maticovych vzoru

        mat transformuj_nonlin(mat A);
        mat transformuj_nonlin_zpetne(mat A);

        void stanov_parametry_lintrans();
        mat transformuj_lin(mat A);
        mat transformuj_lin_zpetne(mat A);

        void transformuj(bool VSTUPY, bool VYSTUPY);
        void transformuj_zpetne(bool VSTUPY, bool VYSTUPY, bool SIMVYSTUPY);

        void prehazej_vzory(bool VSTUPY, bool VYSTUPY);
        void prehazej_vzory_zpet(bool VSTUPY, bool VYSTUPY, bool SIMVYSTUPY);

        unsigned int rand_int(unsigned int n);
        void shuffle();

        void vypis_vstupy();
        void vypis_vystupy(string slovo);
        void vypis_sim_vystupy(string slovo);

    protected:
    private:
};

#endif // VZORY_H
