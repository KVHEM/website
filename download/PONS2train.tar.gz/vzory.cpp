#include "vzory.h"
//
vzory::vzory(){
   pocet_vystupnich_souboru = 0;
   pocet_casovych_vzoru = 0;
   pocet_druhu_vstupu = 0;
   pocet_maticovych_vzoru = 0;
   pocet_IN = 0;
   pocet_OUT = 0;
   pocet_vzoru = 0;
   pocet_maticovych_vystupu = 0;
   pocet_maticovych_vstupu = 0;
   pocet_vstupnich_souboru = 0;
   transformace_dat = 0;
   lag = 0;
   alpha =0;
   min_lin_tran = 0;
   max_lin_tran = 1;
   kacko= 1;
   qecko = 0;
   shuffle_indexy = false;

   data_vstupu.reset();
   data_vystupu.reset();
   sim_vystupy.reset();
}


vzory::vzory(string jmeno_souboru_s_nastavenim)
{
  ifstream proud_soubor(jmeno_souboru_s_nastavenim.c_str()); //c_str() meni string na const char; otvirame soubor

    if(!proud_soubor){
      cout << "\nNemohu otevrit soubor s nastavenim vzoru: " << jmeno_souboru_s_nastavenim;
      exit(EXIT_FAILURE);
    }

    string odpad; // do tohoto stringu sa nacitaji ze settings.txt retezce ne cisla

   proud_soubor >> odpad;
   proud_soubor >> pocet_IN;

  if(pocet_IN < 1)  { // osetreni velikosti matic
      cout << "\nPocet vstupu je mensi nez 1."<<endl;
      proud_soubor.close(); // zavreni souboru settings.txt, nacitani dat je hotove
      exit(EXIT_FAILURE);
    }

    proud_soubor >> odpad;
    proud_soubor >> pocet_OUT;

    if(pocet_OUT < 1)  { // osetreni velikosti matic
      cout << "\nPocet vystupu je mensi nez 1."<<endl;
      proud_soubor.close(); // zavreni souboru settings.txt, nacitani dat je hotove
      exit(EXIT_FAILURE);
    }

    proud_soubor >> odpad;
    proud_soubor >> lag;

    proud_soubor >> odpad;
    proud_soubor >> pocet_druhu_vstupu;

//    if(pocet_druhu_vstupu < 0)  { // osetreni velikosti matic
//      cout << "\n Pocet druhu vstupu je mensi nez 0."<<endl;
//      proud_soubor.close(); // zavreni souboru settings.txt, nacitani dat je hotove
//      exit(EXIT_FAILURE);
//    }

    if(pocet_druhu_vstupu > 0){
        historie_vstupu = new unsigned int[pocet_druhu_vstupu];
        sloupec = new unsigned int[pocet_druhu_vstupu];

        proud_soubor >> odpad;


        unsigned int pom_prom=0;

        for (unsigned int dr=0; dr< pocet_druhu_vstupu; dr++ ){
            proud_soubor >> historie_vstupu[dr];
            pom_prom = pom_prom + historie_vstupu[dr];
          }

        if (pom_prom != pocet_IN) {
            cout << "\nCelkovy pocet  zadanych druhu vstupu je ruzny od poctu vstupu MLP."<<endl;
            proud_soubor.close(); // zavreni souboru settings.txt, nacitani dat je hotove
            exit(EXIT_FAILURE);
        }


     proud_soubor >> odpad;

     for (unsigned int sl=0; sl<pocet_druhu_vstupu ; sl++ ){
       proud_soubor >> sloupec[sl];
       }

     proud_soubor >> odpad;
     proud_soubor >> soubor_s_nazvy_vstupu;

     soubory_se_vstupy = new string[pocet_druhu_vstupu];

     ifstream proud_soubor_vstupnich_dat(soubor_s_nazvy_vstupu.c_str());

      if(!proud_soubor_vstupnich_dat){
         cout << "Nemohu otevrit soubor s nazvy souboru pro casove vzory: " << soubor_s_nazvy_vstupu;
         exit(EXIT_FAILURE);
       }

      unsigned int pom_pocet_radku =0;
      while (proud_soubor_vstupnich_dat.good()){
            getline (proud_soubor_vstupnich_dat,odpad);
            pom_pocet_radku++;
 //           cout << "\nooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
          }
//   cout << "\nOOOOOOOOOOOOOOOOOOOOooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
       pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
  //     pom_pocet_radku--;

       if(pom_pocet_radku != pocet_druhu_vstupu){
           cout << "\nV souboru s nazvy vstupnich casovych souboru " << soubor_s_nazvy_vstupu.c_str() << " je jiny pocet souboru " << pom_pocet_radku<<" nez je pocet druhu casovych vstupu: " << pocet_druhu_vstupu << ".\n ";
           proud_soubor_vstupnich_dat.close();
           exit(EXIT_FAILURE);
        }
   // cout << pom_pocet_radku<<endl ;
   //Navrat na zacatek souboru.
       proud_soubor_vstupnich_dat.clear();
       proud_soubor_vstupnich_dat.seekg(0, ios::beg);

       for (unsigned int fil =0;fil < pocet_druhu_vstupu ; fil++ ){
            proud_soubor_vstupnich_dat >> soubory_se_vstupy[fil];
        }

        proud_soubor_vstupnich_dat.close();
    } else {

    if(pocet_druhu_vstupu == 0){
 //   cout <<"\n" << pocet_druhu_vstupu << endl;
       for (unsigned int rad=0; rad<4; rad++){
          getline(proud_soubor, odpad);
     //     cout << "\n" <<odpad << endl;
         }
        } else {
                cout << "\nJe zadan zaporny pocet druhu vstupu v souboru s nastaveni vstupu :" << jmeno_souboru_s_nastavenim << "\n ";
                proud_soubor.close();
                exit(EXIT_FAILURE);
        }
}
    proud_soubor >> odpad;
    //cout <<"\n" << odpad << endl;
    proud_soubor >> pocet_maticovych_vstupu;
  //  cout << "\nMMMMAA " << pocet_maticovych_vstupu << endl;

    if(pocet_maticovych_vstupu ==0){

    for (unsigned int rad =0; rad < 2 ; rad++){
                getline(proud_soubor, odpad);
           //     cout <<"\n uouiosaufioa s "<< odpad << endl;
      }

    } else{
    //cout <<"\n" << odpad<< pocet_maticovych_vstupu << endl;
    proud_soubor >> odpad;
    proud_soubor >> soubor_s_nazvy_mat_vstupu;

    soubory_s_maticovymi_vstupy = new string[pocet_maticovych_vstupu];

    ifstream proud_s_nazvy_maticovych_souboru(soubor_s_nazvy_mat_vstupu.c_str());
    unsigned int pom_pocet_mat_radku = 0;

       while (proud_s_nazvy_maticovych_souboru.good()){
            getline (proud_s_nazvy_maticovych_souboru,odpad);
            pom_pocet_mat_radku++;
    }

    pom_pocet_mat_radku--;
    pom_pocet_mat_radku--;

    if(pom_pocet_mat_radku != pocet_maticovych_vstupu){
      cout << "\nV souboru s nazvy souboru maticovych vstupu je jiny pocet souboru nez je pocet druhu maticovych vstupu.\n";
      proud_s_nazvy_maticovych_souboru.close();
      exit(EXIT_FAILURE);
    }

    proud_s_nazvy_maticovych_souboru.clear();
    proud_s_nazvy_maticovych_souboru.seekg(0, ios::beg);

    for (unsigned int fil=0; fil< pocet_maticovych_vstupu ; fil++ ){
      proud_s_nazvy_maticovych_souboru >> soubory_s_maticovymi_vstupy[fil];
      }

    proud_s_nazvy_maticovych_souboru.close();
    }
     // zavreni souboru settings.txt, nacitani dat je hotove


    if(pocet_druhu_vstupu >0) {
       stanov_pocet_casovych_vzoru();
       } else pocet_casovych_vzoru = 0;

    pocet_maticovych_vzoru = 0;

    if(pocet_maticovych_vstupu >0) {
       stanov_pocet_maticovych_vzoru();
       } else pocet_maticovych_vzoru = 0;


//    cout << "\nOOOOOOOOOOOOOOOOOOOOO Pocet maticovych vzoru: " << pocet_maticovych_vzoru << endl;

    pocet_vzoru = pocet_casovych_vzoru + pocet_maticovych_vzoru;

    cout << "\nPocet vzoru vstupnich dat je  " << pocet_vzoru << "\n" << endl;

    if (pocet_vzoru == 0) {
      cout << "\nPocet vzoru je roven 0, PROTO NEPROBEHNE ZAADNY VYPOCET.\n";
      proud_soubor.close();
      exit(EXIT_FAILURE);
    }

    if(pocet_vzoru >0){
       indexy_prehazeni_vzoru = new unsigned int[pocet_vzoru];
       for (unsigned int ind =0; ind < pocet_vzoru; ind++ ){
         indexy_prehazeni_vzoru[ind] = ind;
         }
    }

    proud_soubor >> odpad;
   // cout << endl << odpad << endl;
    proud_soubor >> pocet_druhu_casovych_vystupu;

    if ((pocet_druhu_vstupu == 0) && (pocet_druhu_casovych_vystupu > 0)) {
        cout << "\nPocet druhu casovych vstupu je roven: " << pocet_druhu_vstupu << " a pocet druhu casovych vystupu  je roven: "<< pocet_druhu_casovych_vystupu <<".\n";
        cout << "\nProblem je v souboru: " << jmeno_souboru_s_nastavenim << endl;
        proud_soubor.close();
        exit(EXIT_FAILURE);
    }

    if ((pocet_druhu_vstupu > 0) && (pocet_druhu_casovych_vystupu == 0)) {
        cout << "\nPocet druhu casovych vstupu je roven: " << pocet_druhu_vstupu << " a pocet druhu casovych vystupu  je roven: "<< pocet_druhu_casovych_vystupu <<".\n";
        cout << "\nProblem je v souboru: " << jmeno_souboru_s_nastavenim << endl;
        proud_soubor.close();
        exit(EXIT_FAILURE);
    }

    if(pocet_druhu_casovych_vystupu ==0) {
       for (unsigned int rad =0; rad < 3 ;rad ++ ){
          getline(proud_soubor, odpad);
         }

    } else if (pocet_druhu_casovych_vystupu >0){


    proud_soubor >> odpad;
    proud_soubor >> sloupec_predik_dat;


    if (sloupec_predik_dat <1) {
      cout << "\nZadany sloupec pro vystupy je meni nez 1 neprobehne vypocet.\n";
      proud_soubor.close();
      exit(EXIT_FAILURE);
    }


    proud_soubor >> odpad;
    proud_soubor >> soubor_s_nazvem_cas_vystupu;

    ifstream proud_s_nazvy_cas_vys_souboru(soubor_s_nazvem_cas_vystupu.c_str());

          if(!proud_s_nazvy_cas_vys_souboru){
         cout << "Nemohu otevrit soubor s nazvy souboru pro casove vystupni vzory: " << soubor_s_nazvy_vstupu;
         exit(EXIT_FAILURE);
       }

      unsigned int pom_pocet_radku =0;
      while (proud_s_nazvy_cas_vys_souboru.good()){
            getline (proud_s_nazvy_cas_vys_souboru,odpad);
            pom_pocet_radku++;
 //           cout << "\nooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
          }
//     cout << "\nOOOOOOOOOOOOOOOOOOOOooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
       pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
       pom_pocet_radku--;

    if(pom_pocet_radku != pocet_druhu_casovych_vystupu){
      cout << "\nV souboru s nazvy souboru casovych vystupu je jiny pocet souboru.\n ";
      proud_s_nazvy_cas_vys_souboru.close();
      exit(EXIT_FAILURE);
    }

    proud_s_nazvy_cas_vys_souboru.clear();
    proud_s_nazvy_cas_vys_souboru.seekg(0, ios::beg);

    proud_s_nazvy_cas_vys_souboru >> soubor_s_cas_vystupy;

    proud_s_nazvy_cas_vys_souboru.close();

    } else {

     if (pocet_druhu_casovych_vystupu <1) {
      cout << "\nPocet druhu vystupu je mensi nez 1, neprobehne vypocet.\n";
      proud_soubor.close();
      exit(EXIT_FAILURE);
      }

    }

    proud_soubor >> odpad;
    proud_soubor >> pocet_maticovych_vystupu;

    if(pocet_maticovych_vystupu == 0) {
           for (unsigned int rad =0; rad < 2 ;rad ++ ){
          getline(proud_soubor, odpad);
         }

    } else if(pocet_maticovych_vystupu >0) {
        proud_soubor >> odpad;
        proud_soubor >> soubor_s_nazvem_mat_vystupu;

            ifstream proud_s_nazvy_mat_vys_souboru(soubor_s_nazvem_mat_vystupu.c_str());

          if(!proud_s_nazvy_mat_vys_souboru){
         cout << "Nemohu otevrit soubor s nazvy souboru pro casove vystupni vzory: " << soubor_s_nazvy_vstupu;
         exit(EXIT_FAILURE);
       }

      unsigned int pom_pocet_radku =0;
      while (proud_s_nazvy_mat_vys_souboru.good()){
            getline (proud_s_nazvy_mat_vys_souboru,odpad);
            pom_pocet_radku++;
 //           cout << "\nooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
          }
//     cout << "\nOOOOOOOOOOOOOOOOOOOOooooooUUUUUUUUUUUUUUUUUUUUU:  " << pom_pocet_radku<<endl;
       pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
       pom_pocet_radku--;

    if(pom_pocet_radku != pocet_maticovych_vystupu){
      cout << "\nV souboru s nazvy souboru maticovych vystupu je jiny pocet souboru.\n ";
      proud_s_nazvy_mat_vys_souboru.close();
      exit(EXIT_FAILURE);
    }

    proud_s_nazvy_mat_vys_souboru.clear();
    proud_s_nazvy_mat_vys_souboru.seekg(0, ios::beg);

    soubory_s_maticovymi_vystupy = new string[pocet_maticovych_vystupu];

    for (unsigned int fil=0; fil < pocet_maticovych_vystupu; fil++ ){
      proud_s_nazvy_mat_vys_souboru >> soubory_s_maticovymi_vystupy[fil];
   //   cout << endl<< soubory_s_maticovymi_vystupy[fil] << endl;
      }
    proud_s_nazvy_mat_vys_souboru >> soubor_s_cas_vystupy;

    proud_s_nazvy_mat_vys_souboru.close();


    } else {
          cout << "\nSpatne zadany maticovy vystup, neprobehne vypocet.\n";
          proud_soubor.close();
          exit(EXIT_FAILURE);
    }

    if(pocet_maticovych_vstupu != pocet_maticovych_vystupu) {
          cout << "\nPocet souboru s maticovymi vstupy: " << pocet_maticovych_vstupu << "neni roven poctu souboru s maticovymi vystupy :" << pocet_maticovych_vystupu << ".\n";
          proud_soubor.close();
          exit(EXIT_FAILURE);

    }
   //cout << "\nuuuuuu " << pocet_druhu_casovych_vystupu<< "\t"<< soubor_s_nazvem_vystupu <<endl;
   //natvrdo nastvena velikost matic, ktera bude zmenena
  proud_soubor >> odpad;
  proud_soubor >> shuffle_indexy;

  proud_soubor >> odpad;
  proud_soubor >> transformace_dat;


   if((transformace_dat != Nelinearni)&&(transformace_dat != Linearni)) {
          cout << "\nTyp tranformace je spatne zadan: " << transformace_dat << " mel by byt 0 nelinearni nebo 1 linearni, je zadano : " << transformace_dat << ".\n";
          proud_soubor.close();
          exit(EXIT_FAILURE);
   }

   if(transformace_dat == Nelinearni) {
      proud_soubor >> odpad;
      proud_soubor >> alpha;
      proud_soubor >> odpad >> odpad >> odpad;
      proud_soubor >> odpad >> out_cesta;
      min_lin_tran = 1;
      max_lin_tran = 1;
   } else {
      proud_soubor >> odpad;
      proud_soubor >> odpad;
      alpha = 0.5;
      proud_soubor >> odpad;
      proud_soubor >> min_lin_tran;
      proud_soubor >> max_lin_tran;

      proud_soubor >> odpad >> out_cesta;

      if(min_lin_tran >= max_lin_tran){
           cout << "\nMinimum nebo maximum Linearni tranformace je spatne zadano: " << min_lin_tran << " by mel byt mensi nez maximm : " << max_lin_tran<< ".\n";
          proud_soubor.close();
          exit(EXIT_FAILURE);
         }

      if((min_lin_tran <0)||(min_lin_tran>1)) {
         cout << "\nMinimum linearni transfromace dat: " << min_lin_tran << " je mimo povodleny interval transfromace.\n";
         proud_soubor.close();
         exit(EXIT_FAILURE);
      }

      if((max_lin_tran <0)||(max_lin_tran>1)) {
         cout << "\nMaximum linearni transfromace dat: " << max_lin_tran << " je mimo povodleny interval transfromace.\n";
         proud_soubor.close();
         exit(EXIT_FAILURE);
      }
   }

    proud_soubor.close();

    pocet_vstupnich_souboru = 0;
    pocet_vystupnich_souboru = 0;

    if(pocet_casovych_vzoru >0) {
        pocet_vstupnich_souboru = pocet_vstupnich_souboru + pocet_druhu_vstupu;
        pocet_vystupnich_souboru = pocet_vystupnich_souboru + 1;
      }

    if (pocet_maticovych_vzoru > 0) {
                        pocet_vstupnich_souboru = pocet_vstupnich_souboru + pocet_maticovych_vstupu;
                        pocet_vystupnich_souboru = pocet_vystupnich_souboru + pocet_maticovych_vystupu;
                  }

    if(pocet_vstupnich_souboru > 0) {
        in_soubory = new string[pocet_vstupnich_souboru];
    }

    if (pocet_vystupnich_souboru > 0){
        out_soubory = new string[pocet_vystupnich_souboru];
    }

    if((pocet_casovych_vzoru > 0)&&(pocet_maticovych_vstupu) > 0){
      for (unsigned int vs = 0; vs < pocet_druhu_vstupu; vs++ ){
        in_soubory[vs] = soubory_se_vstupy[vs];
       // cout << endl << in_soubory[vs];
        }
      for (unsigned int vs = pocet_druhu_vstupu; vs < pocet_vstupnich_souboru; vs++ ){
        in_soubory[vs] = soubory_s_maticovymi_vstupy[vs-pocet_druhu_vstupu];
     //   cout << endl << in_soubory[vs];
        }
     } else if(pocet_druhu_vstupu > 0) {
            for (unsigned int vs = 0; vs < pocet_vstupnich_souboru; vs++ ){
                    in_soubory[vs] = soubory_se_vstupy[vs];
          //         cout << endl << in_soubory[vs];
                    }
                }
                    else if(pocet_maticovych_vstupu >0 )   {
                             for (unsigned int vs = 0; vs < pocet_vstupnich_souboru; vs++ ){
                                in_soubory[vs] = soubory_s_maticovymi_vstupy[vs];
                              //  cout << endl << in_soubory[vs];
                                }
                    }

    if((pocet_casovych_vzoru > 0)&&(pocet_maticovych_vstupu) > 0){
              out_soubory[0] = soubor_s_cas_vystupy;
          //    cout << endl << out_soubory[0];

              for (unsigned int vs = 1; vs < pocet_vystupnich_souboru; vs++ ){
                            out_soubory[vs] = soubory_s_maticovymi_vystupy[vs-1];
          //                 cout << endl << out_soubory[vs];
            }
     } else if(pocet_druhu_vstupu > 0) {
                   out_soubory[0] = soubor_s_cas_vystupy;
         //          cout << endl << out_soubory[0];
     }
                    else if(pocet_maticovych_vstupu >0 )   {
                             for (unsigned int vs = 0; vs < pocet_vystupnich_souboru; vs++ ){
                                out_soubory[vs] = soubory_s_maticovymi_vystupy[vs];
         //                       cout << endl << out_soubory[vs];
                                }
                    }
    kacko = 1;
    qecko = 0;

    cout << endl<< "Pocet vzoru pred vytvorenim matice s daty: " << pocet_vzoru << endl;

    data_vstupu.set_size(pocet_vzoru,pocet_IN);
    data_vystupu.set_size(pocet_vzoru,pocet_OUT);
    sim_vystupy.set_size(pocet_vzoru,pocet_OUT);

    data_vstupu.fill(9999999);
    data_vystupu.fill(9999999);
    sim_vystupy.fill(9999999);
}

vzory::~vzory()
{
    data_vstupu.reset();
    data_vystupu.reset();
    sim_vystupy.reset();

    if(pocet_druhu_vstupu > 0) {
      delete[] historie_vstupu;
      delete[] sloupec;
      delete[] soubory_se_vstupy;
    }

    if(pocet_maticovych_vstupu > 0){
      delete[] soubory_s_maticovymi_vstupy;
    }

    if(pocet_maticovych_vystupu > 0){
      delete[] soubory_s_maticovymi_vystupy;
    }

    if(pocet_vstupnich_souboru > 0) {
        delete[] in_soubory;
    }

    if (pocet_vystupnich_souboru > 0){
        delete[] out_soubory;
    }

    if(pocet_vzoru != 0){
        delete[] indexy_prehazeni_vzoru;
    }
}

vzory::vzory(const vzory& other)
{
        pocet_maticovych_vzoru = other.pocet_maticovych_vzoru;
        pocet_IN = other.pocet_IN;
        pocet_OUT = other.pocet_OUT;



        if( pocet_druhu_vstupu != other.pocet_druhu_vstupu) {
         if (pocet_druhu_vstupu >0) {
            delete[] historie_vstupu;
            delete[] sloupec;
            delete[] soubory_se_vstupy;
         }
         historie_vstupu = new unsigned int[other.pocet_druhu_vstupu];
         sloupec = new unsigned int[other.pocet_druhu_vstupu];
         soubory_se_vstupy = new string[other.pocet_druhu_vstupu];
         }
         pocet_druhu_vstupu = other.pocet_druhu_vstupu;
         for (unsigned int vs=0; vs < other.pocet_druhu_vstupu ;vs++ ){
            historie_vstupu[vs] = other.historie_vstupu[vs];
            sloupec[vs] = other. sloupec[vs];
            soubory_se_vstupy[vs] = other.soubory_se_vstupy[vs];
           }

        pocet_druhu_casovych_vystupu = other.pocet_druhu_casovych_vystupu;
        sloupec_predik_dat = other.sloupec_predik_dat;


        transformace_dat =other.transformace_dat;
        alpha = other.alpha;
        min_lin_tran = other.min_lin_tran;
        max_lin_tran = other.max_lin_tran;
        kacko = other.kacko;
        qecko =other.qecko;
        shuffle_indexy = other.shuffle_indexy;
        out_cesta = other.out_cesta;
        lag = other.lag;

        if((pocet_vzoru != other.pocet_vzoru)||(other.pocet_vzoru>0)){
            if(pocet_vzoru >0) delete[] indexy_prehazeni_vzoru;
         indexy_prehazeni_vzoru =  new unsigned int[other.pocet_vzoru];
        }


        pocet_vzoru = other.pocet_vzoru;
        pocet_casovych_vzoru = other.pocet_casovych_vzoru;

        for(unsigned int vz=0; vz < other.pocet_vzoru;vz++){
          indexy_prehazeni_vzoru[vz] = other.indexy_prehazeni_vzoru[vz];
        }

        soubor_s_nazvy_vstupu = other.soubor_s_nazvy_vstupu;
        soubor_s_nazvy_mat_vstupu = other.soubor_s_nazvy_mat_vstupu;

       if(pocet_maticovych_vstupu != other.pocet_maticovych_vstupu){
            if(pocet_maticovych_vstupu > 0 ) delete[] soubory_s_maticovymi_vstupy;
            soubory_s_maticovymi_vstupy = new string[other.pocet_maticovych_vstupu];
        }
        pocet_maticovych_vstupu = other.pocet_maticovych_vstupu;
        for(unsigned int vz=0; vz < other.pocet_maticovych_vstupu;vz++){
            soubory_s_maticovymi_vstupy[vz] =other.soubory_s_maticovymi_vstupy[vz];
        }

       soubor_s_cas_vystupy = other.soubor_s_cas_vystupy;//je zatim pro jednu instanci vzory jeden

       if(pocet_maticovych_vystupu != other.pocet_maticovych_vystupu){
              if(pocet_maticovych_vystupu > 0 ) delete[] soubory_s_maticovymi_vystupy;
              soubory_s_maticovymi_vystupy = new string[other.pocet_maticovych_vystupu];
         }
         pocet_maticovych_vystupu = other.pocet_maticovych_vystupu;
         for(unsigned int vz=0; vz < other.pocet_maticovych_vystupu;vz++){
             soubory_s_maticovymi_vystupy[vz] = other.soubory_s_maticovymi_vystupy[vz];
         }

        soubor_s_nazvem_cas_vystupu = other.soubor_s_nazvem_cas_vystupu;
        soubor_s_nazvem_mat_vystupu = other.soubor_s_nazvem_mat_vystupu;


        if(pocet_vstupnich_souboru != other.pocet_vstupnich_souboru) {
            if(pocet_vstupnich_souboru >0) delete[] in_soubory;
            in_soubory =new string[other.pocet_vstupnich_souboru];
        }

        pocet_vstupnich_souboru = other.pocet_vstupnich_souboru;

         for(unsigned int vz=0; vz < other.pocet_vstupnich_souboru;vz++){
             in_soubory[vz] = other.in_soubory[vz];
         }


         if(pocet_vystupnich_souboru != other.pocet_vystupnich_souboru) {
            if(pocet_vystupnich_souboru > 0) delete[] out_soubory;
            out_soubory =new string[other.pocet_vystupnich_souboru];
        }
        pocet_vystupnich_souboru = other.pocet_vystupnich_souboru;

         for(unsigned int vz=0; vz < other.pocet_vystupnich_souboru;vz++){
             out_soubory[vz] = other.out_soubory[vz];
         }

        data_vstupu = other.data_vstupu;
        data_vystupu = other.data_vystupu;
        sim_vystupy = other.sim_vystupy;


}

vzory& vzory::operator=(const vzory& other)
{
    if (this == &other) return *this; // handle self assignment
     else {

        pocet_casovych_vzoru = other.pocet_casovych_vzoru;
        pocet_maticovych_vzoru = other.pocet_maticovych_vzoru;
        pocet_IN = other.pocet_IN;
        pocet_OUT = other.pocet_OUT;

        if( pocet_druhu_vstupu != other.pocet_druhu_vstupu) {
         if (pocet_druhu_vstupu >0) {
            delete[] historie_vstupu;
            delete[] sloupec;
            delete[] soubory_se_vstupy;
         }
         pocet_druhu_vstupu = other.pocet_druhu_vstupu;
         historie_vstupu = new unsigned int[pocet_druhu_vstupu];
         sloupec = new unsigned int[pocet_druhu_vstupu];
         soubory_se_vstupy = new string[pocet_druhu_vstupu];
         }

         for (unsigned int vs=0; vs < other.pocet_druhu_vstupu ;vs++ ){
            historie_vstupu[vs] = other.historie_vstupu[vs];
            sloupec[vs] = other. sloupec[vs];
            soubory_se_vstupy[vs] = other.soubory_se_vstupy[vs];
           }

        pocet_druhu_casovych_vystupu = other.pocet_druhu_casovych_vystupu;
        sloupec_predik_dat = other.sloupec_predik_dat;


        if((pocet_vzoru != other.pocet_vzoru)||(other.pocet_vzoru>0)){
            if(pocet_vzoru >0) delete[] indexy_prehazeni_vzoru;
         indexy_prehazeni_vzoru =  new unsigned int[other.pocet_vzoru];
        }

        pocet_vzoru = other.pocet_vzoru;

        for(unsigned int vz=0; vz < other.pocet_vzoru;vz++){
          indexy_prehazeni_vzoru[vz] = other.indexy_prehazeni_vzoru[vz];
        }

        soubor_s_nazvy_vstupu = other.soubor_s_nazvy_vstupu;
        soubor_s_nazvy_mat_vstupu = other.soubor_s_nazvy_mat_vstupu;

       if(pocet_maticovych_vstupu != other.pocet_maticovych_vstupu){
            if(pocet_maticovych_vstupu > 0 ) delete[] soubory_s_maticovymi_vstupy;
            soubory_s_maticovymi_vstupy = new string[other.pocet_maticovych_vstupu];
        }
        pocet_maticovych_vstupu = other.pocet_maticovych_vstupu;
        for(unsigned int vz=0; vz < other.pocet_maticovych_vstupu;vz++){
            soubory_s_maticovymi_vstupy[vz] =other.soubory_s_maticovymi_vstupy[vz];
        }

       soubor_s_cas_vystupy = other.soubor_s_cas_vystupy;//je zatim pro jednu instanci vzory jeden

       if(pocet_maticovych_vystupu != other.pocet_maticovych_vystupu){
              if(pocet_maticovych_vystupu > 0 ) delete[] soubory_s_maticovymi_vystupy;
              soubory_s_maticovymi_vystupy = new string[other.pocet_maticovych_vystupu];
         }
         pocet_maticovych_vystupu = other.pocet_maticovych_vystupu;
         for(unsigned int vz=0; vz < other.pocet_maticovych_vystupu;vz++){
             soubory_s_maticovymi_vystupy[vz] = other.soubory_s_maticovymi_vystupy[vz];
         }

        soubor_s_nazvem_cas_vystupu = other.soubor_s_nazvem_cas_vystupu;
        soubor_s_nazvem_mat_vystupu = other.soubor_s_nazvem_mat_vystupu;


        if(pocet_vstupnich_souboru != other.pocet_vstupnich_souboru) {
            if(pocet_vstupnich_souboru >0) delete[] in_soubory;
            in_soubory =new string[other.pocet_vstupnich_souboru];
        }

        pocet_vstupnich_souboru = other.pocet_vstupnich_souboru;

         for(unsigned int vz=0; vz < other.pocet_vstupnich_souboru;vz++){
             in_soubory[vz] = other.in_soubory[vz];
         }


         if(pocet_vystupnich_souboru != other.pocet_vystupnich_souboru) {
            if(pocet_vystupnich_souboru > 0) delete[] out_soubory;
            out_soubory =new string[other.pocet_vystupnich_souboru];
        }
        pocet_vystupnich_souboru = other.pocet_vystupnich_souboru;

         for(unsigned int vz=0; vz < other.pocet_vystupnich_souboru;vz++){
             out_soubory[vz] = other.out_soubory[vz];
         }

        lag = other.lag;
        transformace_dat = other.transformace_dat;
        alpha = other.alpha;
        min_lin_tran = other.min_lin_tran;
        max_lin_tran = other.max_lin_tran;
        kacko = other.kacko;
        qecko = other.qecko;
        shuffle_indexy = other.shuffle_indexy;
        out_cesta = other.out_cesta;

        data_vstupu = other.data_vstupu;
        data_vystupu = other.data_vystupu;
        sim_vystupy = other.sim_vystupy;

     }
    return *this;
}

/**
  * Spocet pocet casovych vzoru
  */
void vzory::stanov_pocet_casovych_vzoru()
{
    string odpad;

    unsigned int *pom_pocet_radku;

    pom_pocet_radku = new unsigned int[pocet_druhu_vstupu];

    //cout << pocet_druhu_vstupu << endl;

    for (unsigned int filet=0; filet < pocet_druhu_vstupu ; filet++ ){
      ifstream proud_vstup(soubory_se_vstupy[filet].c_str());
      pom_pocet_radku[filet] = 0;
      if(!proud_vstup.good()){
         cout << "\nPri stanoveneni poctu vzoru je chyba v otevreni souboru se vstupnimi daty:" << soubory_se_vstupy[filet];
         exit(EXIT_FAILURE);
      }

       while (proud_vstup.good())    {
            getline (proud_vstup,odpad);
            pom_pocet_radku[filet]++;
            //cout << pom_pocet_radku[filet]<<endl;
        }

       pom_pocet_radku[filet]--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
       pom_pocet_radku[filet]--;

       proud_vstup.close();
      }

      // kontrola poctu radku v souborech
      for (unsigned int vs=0; vs<(pocet_druhu_vstupu-1) ; vs++ ){
        if( pom_pocet_radku[vs] != pom_pocet_radku[vs+1]){
          cout <<"\nPri stanoveni poctu vzoru v souboru: "   << soubory_se_vstupy[vs] << " je jiny pocet radku nez v souboru " << soubory_se_vstupy[vs+1] ;
          exit(EXIT_FAILURE);
         }
    }

    unsigned int max_vs_history = 0;

    max_vs_history = *max_element(historie_vstupu, historie_vstupu+pocet_druhu_vstupu);
    //cout << max_vs_history;

    pocet_casovych_vzoru = pom_pocet_radku[0] - pocet_OUT - max_vs_history + 1 - lag;

    cout << pocet_casovych_vzoru << " out " << pocet_OUT << " max " << max_vs_history << " lag "<< lag << " rd "<< pom_pocet_radku[0] << endl;

    if(pocet_druhu_vstupu >0)  delete[] pom_pocet_radku;
   // cout <<"\nPocet vzoru z casovych rad: " << pocet_casovych_vzoru;
}

/**
  * Vytvori  cast matice vstupu
  * @param soubor s daty
  * @param delka historie
  * @param posun historie zleva
  */
mat vzory::vytvor_kusy_casove_vst_matice(string soubor_s_daty, unsigned int pocet_sloupcu, unsigned int posun, unsigned int pocet_OUT_NN, unsigned int sloupec_v_souboru)
{
    mat dilci_matice;
    dilci_matice.set_size(pocet_casovych_vzoru,pocet_sloupcu);

  //    cout << "\nPocet radku> "<< dilci_matice.n_rows;

    string odpad;
    string pom_radek;

   // double radek = 0.0;
    unsigned int pom_pocet_radku = 0;
    colvec pom_vstupy;

    ifstream proud(soubor_s_daty.c_str());

    if(!proud) {
      cout << "\n Chyba v otevreni souboru se vstupy pri vytvareni dilci casove matice: "<< soubor_s_daty <<endl;
      cout << "bum,";
      exit(EXIT_FAILURE);
    }
//cout << "\n";
    while (proud.good()){
            getline (proud,pom_radek);
            pom_pocet_radku++;
        //    cout << pom_pocet_radku<<endl;
    }
    pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
    pom_pocet_radku--;
    //cout << pom_pocet_radku<<endl ;
    proud.clear();
    proud.seekg(0, ios::beg);

    //Stanoveni poctu sloupcu v souboru
    string radek_pro_sl;
    getline(proud,radek_pro_sl);
    stringstream is(radek_pro_sl.c_str());
    //cout  <<"\n"<< radek_pro_sl <<"\n";
    unsigned   int pom_pocet_sl=0;
    while (is >> odpad)    {
      pom_pocet_sl++;
    }
    //cout << "\nPocet sloupcu je " << pom_pocet_sl << std::endl;
    //navrat v proudu na zacatek souboru
    proud.clear();
    proud.seekg(0, ios::beg);
    pom_vstupy.set_size(pom_pocet_radku);

    if(pom_pocet_sl < sloupec_v_souboru){
     cout << "\nPocet sloupcu v souboru: " << soubor_s_daty << " je mensi nez zadany sloupec v nastaveni nacitani dat.\n";
     proud.close();
     exit(EXIT_FAILURE);
    }

    for (unsigned int rd=0; rd<pom_pocet_radku; rd++ ){
      for (unsigned int sl =0; sl < pom_pocet_sl; sl++ ){
        if(sl == (sloupec_v_souboru-1)) proud >> pom_vstupy(rd);
         else proud >> odpad;
        }
      }
   // cout << "vstupy" <<endl;
   // cout << pom_vstupy;
    proud.close();

 //   unsigned int pom_prom = 0;

    colvec posunuty_pom_vstupy;
    posunuty_pom_vstupy.set_size(pom_vstupy.n_elem - posun - pocet_OUT_NN - lag);
 //   cout <<"\nPocet radku " << posunuty_pom_vstupy.n_rows << "\n";

    posunuty_pom_vstupy= pom_vstupy.submat(posun,0,(pom_vstupy.n_elem-pocet_OUT_NN - lag),0);

       for (unsigned int i = 0; i< pocet_casovych_vzoru; i++ ){
         for (unsigned int j = 0; j < pocet_sloupcu; j++ ){
            dilci_matice(i,j) = posunuty_pom_vstupy(i + j );
            }
        }
   return dilci_matice;
  }

mat vzory::vytvor_casovou_vstupni_matici()
{
    mat  kus_dat;
    mat data_cas_vstupu;
    data_cas_vstupu.set_size(pocet_casovych_vzoru,pocet_IN);

    unsigned int max_vs_history = 0;
    max_vs_history = *max_element(historie_vstupu, historie_vstupu+pocet_druhu_vstupu);

    unsigned int left_col = 0, right_col = historie_vstupu[0]-1;

    for (unsigned int vs=0; vs< pocet_druhu_vstupu; vs++ ){
       kus_dat.set_size(pocet_casovych_vzoru, historie_vstupu[vs]);
       kus_dat = vytvor_kusy_casove_vst_matice(soubory_se_vstupy[vs].c_str(), historie_vstupu[vs], max_vs_history - historie_vstupu[vs] , pocet_OUT, sloupec[vs]);
 //      cout <<"\nkus dat \n" << kus_dat;
       data_cas_vstupu.submat(0, left_col, pocet_casovych_vzoru-1, right_col)  = kus_dat;
   //    cout <<"\n ups "<< left_col <<"\t"<< pocet_casovych_vzoru -1 << "\t" << right_col<<endl;
       left_col = left_col + historie_vstupu[vs];
       if (vs<(pocet_druhu_vstupu-1)) right_col =right_col + historie_vstupu[vs+1];
       kus_dat.reset();
      }

    //cout <<"\nDATA\n " << data_cas_vstupu;
    return data_cas_vstupu;
}

/**
  * Nacte kus matice a priradi do vraticiho vstupu
  * @param soubor s matic vzorovych vstupnich dat
  */
mat vzory::vytvor_kusy_necasove_vst_matice(string soubor_s_daty)
{
    mat  kus_dat;
    string odpad;

    unsigned int pom_pocet_radku = 0;

    ifstream proud(soubor_s_daty.c_str());

    if(!proud) {
      cout << "\n Chyba v otevreni souboru se vstupy pri vytvareni dilci proste matice: "<< soubor_s_daty <<endl;
      exit(EXIT_FAILURE);
    }

        while (proud.good()){
            getline (proud,odpad);
            pom_pocet_radku++;
        //    cout << pom_pocet_radku<<endl;
    }
    pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
    pom_pocet_radku--;
    //cout << pom_pocet_radku<<endl ;//
    proud.clear();
    proud.seekg(0, ios::beg);
    //Stanoveni poctu sloupcu v souboru
    string radek_pro_sl;
    getline(proud,radek_pro_sl);
    stringstream is(radek_pro_sl.c_str());
    //cout  <<"\n"<< radek_pro_sl <<"\n";
    unsigned   int pom_pocet_sl=0;
    while (is >> odpad)    {
      pom_pocet_sl++;
    }

    if(pom_pocet_sl != pocet_IN){
     cout << "\nPocet sloupcu v souboru: " << soubor_s_daty << " je " << pom_pocet_sl << " a neni roven zadanemu poctu vstupu neuronove site " << pocet_IN<<".\n";
     proud.close();
     exit(EXIT_FAILURE);
    }

    kus_dat.set_size(pom_pocet_radku, pocet_IN);

    proud.clear();
    proud.seekg(0, ios::beg);

    for (unsigned int rad=0; rad < pom_pocet_radku ; rad++ ){
      for (unsigned int sl=0;sl< pom_pocet_sl ; sl++ ){
        proud >> kus_dat(rad,sl);
        }
      }

    proud.close();

    return kus_dat;
}

/**
  * Vypocte pocet maticovych vstupnich vzoru
  */
void vzory::stanov_pocet_maticovych_vzoru()
{
   mat pom_matice;

   for (unsigned int fil = 0; fil < pocet_maticovych_vstupu; fil++){
     pom_matice = vytvor_kusy_necasove_vst_matice(soubory_s_maticovymi_vstupy[fil]);
     pocet_maticovych_vzoru = pocet_maticovych_vzoru + pom_matice.n_rows;
     }

}

/**
  * Otevre soubory s maticovymi daty a vytvori z nich matici
  */
mat vzory::vytvor_necasovou_vstupni_matici()
{
    mat matice_dat;
    matice_dat.set_size(pocet_maticovych_vzoru, pocet_IN);
    unsigned int up_row = 0, down_row= 0;

    for (unsigned int fil=0; fil < pocet_maticovych_vstupu; fil++){
      mat pom_matice;
      pom_matice = vytvor_kusy_necasove_vst_matice(soubory_s_maticovymi_vstupy[fil]);
      down_row = down_row + pom_matice.n_rows;
      matice_dat.submat(up_row,0, down_row-1,pocet_IN-1)=pom_matice;
 //     cout << "pus " << up_row << "rrrr " << down_row << endl;
      up_row = down_row;
      pom_matice.reset();
      }

    return matice_dat;
}

void vzory::vytvor_vstupni_matici()
{
    mat pom_cas, pom_mat;
    if((pocet_druhu_vstupu ==0) && (pocet_maticovych_vstupu > 0) ){
      pom_mat = vytvor_necasovou_vstupni_matici();
      data_vstupu.submat(0,0,pom_mat.n_rows -1, pocet_IN-1) = pom_mat;
    }

    if((pocet_druhu_vstupu >0) &&(pocet_maticovych_vstupu == 0) ){
          pom_cas = vytvor_casovou_vstupni_matici();
          data_vstupu.submat(0,0,pom_cas.n_rows -1, pocet_IN-1) = pom_cas;
        }

    if((pocet_druhu_vstupu > 0) &&(pocet_maticovych_vstupu > 0) ){
        pom_cas = vytvor_casovou_vstupni_matici();
        pom_mat = vytvor_necasovou_vstupni_matici();
        data_vstupu.submat(0,0,pom_cas.n_rows -1, pocet_IN-1) = pom_cas;
        data_vstupu.submat(pom_cas.n_rows,0,pocet_vzoru -1, pocet_IN-1) = pom_mat;
    }

    if(Linearni) {
       stanov_parametry_lintrans();
    } else{
        kacko = 1;
        qecko =0;
    }


}


mat vzory::vytvor_kusy_casove_vys_matice(string soubor_s_daty, unsigned int sloupec_v_souboru)
{
    mat dilci_matice;
    dilci_matice.set_size(pocet_casovych_vzoru,pocet_OUT);

  //    cout << "\nPocet radku> "<< dilci_matice.n_rows;

    string odpad;
    string pom_radek;

   //////////// double radek = 0.0;
    unsigned int pom_pocet_radku = 0;
    colvec pom_vstupy;

    ifstream proud(soubor_s_daty.c_str());

    if(!proud) {
      cout << "\n Chyba v otevreni souboru se vstupy pri vytvareni dilci casove matice: "<< soubor_s_daty <<endl;
      exit(EXIT_FAILURE);
    }
//cout << "\n";
    while (proud.good()){
            getline (proud,pom_radek);
            pom_pocet_radku++;
        //    cout << pom_pocet_radku<<endl;
    }
    pom_pocet_radku--;//soubor musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
    pom_pocet_radku--;
    //cout << pom_pocet_radku<<endl ;
    proud.clear();
    proud.seekg(0, ios::beg);

    //Stanoveni poctu sloupcu v souboru
    string radek_pro_sl;
    getline(proud,radek_pro_sl);
    stringstream is(radek_pro_sl.c_str());
    //cout  <<"\n"<< radek_pro_sl <<"\n";
    unsigned   int pom_pocet_sl=0;
    while (is >> odpad)    {
      pom_pocet_sl++;
    }
    //cout << "\nPocet sloupcu je " << pom_pocet_sl << std::endl;
    //navrat v proudu na zacatek souboru
    proud.clear();
    proud.seekg(0, ios::beg);
    pom_vstupy.set_size(pom_pocet_radku);

    if(pom_pocet_sl < sloupec_v_souboru){
     cout << "\nPri vytvareni vystupnich vzoru pocet sloupcu v souboru: " << soubor_s_daty << " je mensi nez zadany sloupec v nastaveni nacitani dat.\n";
     proud.close();
     exit(EXIT_FAILURE);
    }

    for (unsigned int rd=0; rd<pom_pocet_radku; rd++ ){
      for (unsigned int sl =0; sl < pom_pocet_sl; sl++ ){
        if(sl == (sloupec_v_souboru-1)) proud >> pom_vstupy(rd);
         else proud >> odpad;
        }
      }
   // cout << "vstupy" <<endl;
   //cout << pom_vstupy;
    proud.close();

 ////  unsigned int pom_prom = 0;

   unsigned int max_vs_history = 0;
   max_vs_history = *max_element(historie_vstupu, historie_vstupu+pocet_druhu_vstupu);
     // cout <<"\n Max hist " << max_vs_history<< " max " << pom_vstupy.n_elem - max_vs_history <<endl;

    colvec posunuty_pom_vstupy;
    posunuty_pom_vstupy.set_size(pom_vstupy.n_elem - max_vs_history - lag);
 //   cout <<"\nPocet radku " << posunuty_pom_vstupy.n_rows << "\n";

    posunuty_pom_vstupy= pom_vstupy.submat(max_vs_history+lag,0,(pom_vstupy.n_elem-1),0);


    //cout << endl << posunuty_pom_vstupy << endl;

       for (unsigned int i = 0; i< pocet_casovych_vzoru; i++ ){
         for (unsigned int j = 0; j <pocet_OUT; j++ ){
            dilci_matice(i,j) = posunuty_pom_vstupy(i + j );
            }
        }
   return dilci_matice;
}

mat vzory::vytvor_casovou_vystupni_matici()
{
   mat dilci_matice;
   dilci_matice.set_size(pocet_casovych_vzoru, pocet_OUT);

   dilci_matice = vytvor_kusy_casove_vys_matice(soubor_s_cas_vystupy, sloupec_predik_dat);

   return dilci_matice;
}

/**
  * Nacte kus matice a priradi do vraticiho vstupu
  * @param soubor s matic vzorovych vstupnich dat
  */
mat vzory::vytvor_kusy_necasove_vys_matice(string soubor_s_daty)
{
    mat  kus_dat;
    string odpad;

    unsigned int pom_pocet_radku = 0;

    ifstream proud(soubor_s_daty.c_str());

    if(!proud) {
      cout << "\n Chyba v otevreni souboru se vstupy pri vytvareni dilci proste matice: "<< soubor_s_daty <<endl;
      exit(EXIT_FAILURE);
    }

        while (proud.good()){
            getline (proud,odpad);
            pom_pocet_radku++;
        //    cout << pom_pocet_radku<<endl;
    }
    pom_pocet_radku--;//soubopr musi mit prazdny radek oznaceny entrem !!!!!!!!!!!!!!!!
    pom_pocet_radku--;
    //cout << pom_pocet_radku<<endl ;
    proud.clear();
    proud.seekg(0, ios::beg);
    //Stanoveni poctu sloupcu v souboru
    string radek_pro_sl;
    getline(proud,radek_pro_sl);
    stringstream is(radek_pro_sl.c_str());
    //cout  <<"\n"<< radek_pro_sl <<"\n";
    unsigned   int pom_pocet_sl=0;
    while (is >> odpad)    {
      pom_pocet_sl++;
    }

    if(pom_pocet_sl != pocet_OUT){
     cout << "\nPocet sloupcu v souboru: " << soubor_s_daty << " je " << pom_pocet_sl << " a neni roven zadanemu poctu vystupu neuronove site " << pocet_OUT<<".\n";
     proud.close();
     exit(EXIT_FAILURE);
    }

    kus_dat.set_size(pom_pocet_radku, pocet_OUT);

    proud.clear();
    proud.seekg(0, ios::beg);

    for (unsigned int rad=0; rad < pom_pocet_radku ; rad++ ){
      for (unsigned int sl=0;sl< pom_pocet_sl ; sl++ ){
        proud >> kus_dat(rad,sl);
        }
      }

    proud.close();

    return kus_dat;
}


mat vzory::vytvor_necasovou_vystupni_matici()
{
    mat matice_dat;
    matice_dat.set_size(pocet_maticovych_vzoru, pocet_OUT);
    unsigned int up_row = 0, down_row= 0;

    for (unsigned int fil=0; fil < pocet_maticovych_vystupu; fil++){
      mat pom_matice;
      pom_matice = vytvor_kusy_necasove_vys_matice(soubory_s_maticovymi_vystupy[fil]);
  //    cout << pom_matice << "eee" << endl;
      down_row = down_row + pom_matice.n_rows;
      matice_dat.submat(up_row,0, down_row-1, pocet_OUT-1)=pom_matice;
  //    cout << "pus " << up_row << "rrrr " << down_row << endl;
      up_row = down_row;
    //  cout << matice_dat;
      pom_matice.reset();
      }

    return matice_dat;
}


void vzory::vytvor_vystupni_matici()
{
    mat pom_cas, pom_mat;
    if((pocet_druhu_casovych_vystupu ==0) && (pocet_maticovych_vstupu > 0) ){
      pom_mat = vytvor_necasovou_vystupni_matici();
      data_vystupu.submat(0,0,pom_mat.n_rows -1, pocet_OUT-1) = pom_mat;
    }

    if((pocet_druhu_casovych_vystupu >0) &&(pocet_maticovych_vystupu == 0) ){
          pom_cas = vytvor_casovou_vystupni_matici();
          data_vystupu.submat(0,0,pom_cas.n_rows -1, pocet_OUT-1) = pom_cas;
        }

    if((pocet_druhu_casovych_vystupu > 0) &&(pocet_maticovych_vystupu > 0) ){
        pom_cas = vytvor_casovou_vystupni_matici();
        pom_mat = vytvor_necasovou_vystupni_matici();
        data_vystupu.submat(0,0,pom_cas.n_rows -1, pocet_OUT-1) = pom_cas;
        data_vystupu.submat(pom_cas.n_rows,0,pocet_vzoru -1, pocet_OUT-1) = pom_mat;
    }
}



mat vzory::transformuj_nonlin(mat A)
{
    mat B;
    B.set_size(A.n_rows,A.n_cols);
    B.fill(999999);

    for (unsigned int rad = 0; rad < A.n_rows ; rad ++ ){
       for (unsigned int sl = 0; sl < A.n_cols ; sl++){
          B(rad, sl) = 1 -  exp(-alpha *(as_scalar(A(rad, sl))));
         }
      }

      return B;
}

mat vzory::transformuj_nonlin_zpetne(mat A)
{
    mat B;
    B.set_size(A.n_rows,A.n_cols);
    B.fill(999999);

    for (unsigned int rad = 0; rad < A.n_rows ; rad ++ ){
       for (unsigned int sl = 0; sl < A.n_cols ; sl++){
          if (   (1-as_scalar(A(rad,sl))) == 0){
            B(rad, sl) = 1/alpha *  log( 1/10E-30);
          } else B(rad, sl) = 1/alpha *  log( (1 /(1-as_scalar(A(rad,sl)))));
         }
      }

      return B;
}

void vzory::stanov_parametry_lintrans()
{

    double xmin =0.0, xmax =0.0;

    xmin = min(min(data_vstupu));
    xmax = max(max(data_vstupu));

    kacko = (max_lin_tran - min_lin_tran)/(xmax - xmin);
    qecko = max_lin_tran - kacko *xmax;

}

mat vzory::transformuj_lin(mat A)
{
    mat B;
    B.set_size(A.n_rows, A.n_cols);


    for (unsigned int rad = 0; rad < A.n_rows ; rad ++ ){
       for (unsigned int sl = 0; sl < A.n_cols ; sl++){
          B(rad, sl) = kacko* as_scalar(A(rad,sl)) + qecko;
         }
      }


    return B;
}

mat vzory::transformuj_lin_zpetne(mat A)
{
    mat B;
    B.set_size(A.n_rows, A.n_cols);


    for (unsigned int rad = 0; rad < A.n_rows ; rad ++ ){
       for (unsigned int sl = 0; sl < A.n_cols ; sl++){
          B(rad, sl) = as_scalar(A(rad,sl))/kacko - qecko/kacko;
         }
      }

    return B;
}

/**
  * Provede transfromaci vzoru
  * @param tranformace vstupnich vzoru
  * @param transformace vystupnich vzoru
  */
void vzory::transformuj(bool VSTUPY, bool VYSTUPY)
{
  switch (transformace_dat)
  {
      case Nelinearni:
          if(VSTUPY){
           data_vstupu = transformuj_nonlin(data_vstupu);
          }
           if(VYSTUPY){
           data_vystupu = transformuj_nonlin(data_vystupu);
          }
          break;

      case Linearni:
          if(VSTUPY){
           data_vstupu = transformuj_lin(data_vstupu);
          }
           if(VYSTUPY){
            data_vystupu = transformuj_lin(data_vystupu);
          }
          break;
      default:
          break;
  }
}

void vzory::transformuj_zpetne(bool VSTUPY, bool VYSTUPY, bool SIMVYSTUPY)
{

  switch (transformace_dat)
  {
      case Nelinearni:
          if(VSTUPY){
           data_vstupu = transformuj_nonlin_zpetne(data_vstupu);
          }
          if(VYSTUPY){
           data_vystupu = transformuj_nonlin_zpetne(data_vystupu);
          }
          if(SIMVYSTUPY){
            sim_vystupy =  transformuj_nonlin_zpetne(sim_vystupy);
           }
          break;

      case Linearni:
          if(VSTUPY){
            data_vstupu = transformuj_lin_zpetne(data_vstupu);
          }
           if(VYSTUPY){
            data_vystupu = transformuj_lin_zpetne(data_vystupu);
          }
          break;
          if(SIMVYSTUPY){
            sim_vystupy =  transformuj_lin_zpetne(sim_vystupy);
           }
      default:
          break;
  }
}

unsigned int vzory::rand_int(unsigned int n)
{
  unsigned int limit = RAND_MAX - RAND_MAX % n;
  unsigned int rnd;

  srand((unsigned)time(0));

  do {
    rnd = rand();
  } while (rnd >= limit);
  return rnd % n;
}


/**
  * Fisher–Yates shuffle varinat dle Richard Durstenfeld in 1964 in Communications of the ACM volume 7, issue 7, as "Algorithm 235: Random permutation"
  */
void vzory::shuffle()
{
  unsigned int j, tmp;

  for (unsigned int i = pocet_vzoru - 1; i > 0; i--) {
    j = rand_int(i + 1);
    tmp = indexy_prehazeni_vzoru[j];
    indexy_prehazeni_vzoru[j] = indexy_prehazeni_vzoru[i];
    indexy_prehazeni_vzoru[i] = tmp;
  }

}

void vzory::prehazej_vzory(bool VSTUPY, bool VYSTUPY)
{
    mat vstupy_B, vystupy_B;
    vstupy_B.set_size(data_vstupu.n_rows, data_vstupu.n_cols);
    vystupy_B.set_size(data_vystupu.n_rows, data_vystupu.n_cols);

    vstupy_B.fill(999999);
    vystupy_B.fill(999999);

    if(VSTUPY){
      for (unsigned int rad=0; rad <pocet_vzoru ; rad++ ){
         //vstupy_B.insert_rows(rad, data_vstupu.row(indexy_prehazeni_vzoru[rad]));
         vstupy_B.row(rad) = data_vstupu.row(indexy_prehazeni_vzoru[rad]);
      }
      data_vstupu = vstupy_B;
    }
    if(VYSTUPY){
      for (unsigned int rad=0; rad <pocet_vzoru ; rad++ ){
         vystupy_B.row(rad) = data_vystupu.row(indexy_prehazeni_vzoru[rad]);
      }
      data_vystupu =vystupy_B;
    }

}

void vzory::prehazej_vzory_zpet(bool VSTUPY, bool VYSTUPY, bool SIMVYSTUPY)
{
    mat vstupy_B, vystupy_B, simvystupy_B;
    vstupy_B.set_size(data_vstupu.n_rows, data_vstupu.n_cols);
    vystupy_B.set_size(data_vystupu.n_rows, data_vystupu.n_cols);

    vstupy_B.fill(999999);
    vystupy_B.fill(999999);

    if(VSTUPY){
      for (unsigned int rad=0; rad <pocet_vzoru ; rad++ ){
         //vstupy_B.insert_rows(rad, data_vstupu.row(indexy_prehazeni_vzoru[rad]));
         vstupy_B.row(indexy_prehazeni_vzoru[rad]) = data_vstupu.row(rad);
      }
      data_vstupu = vstupy_B;
    }
    if(VYSTUPY){
      for (unsigned int rad=0; rad <pocet_vzoru ; rad++ ){
         vystupy_B.row(indexy_prehazeni_vzoru[rad]) = data_vystupu.row(rad);
      }
      data_vystupu = vystupy_B;
    }
    if(SIMVYSTUPY){
      for (unsigned int rad=0; rad <pocet_vzoru ; rad++ ){
         simvystupy_B.row(indexy_prehazeni_vzoru[rad]) = sim_vystupy.row(rad);
      }
      sim_vystupy = simvystupy_B;
    }
}

void vzory::vypis_vystupy(string slovo)
{
   string *nazev_filetu, adresar, soubor;

   if(pocet_vystupnich_souboru ==0){
     cout <<"\nPocet vystupnich souboru ve vzorech je roven 0 " << endl;
     exit(EXIT_FAILURE);
   }

   nazev_filetu = new string[pocet_vystupnich_souboru];

  size_t found;


   for (unsigned int fil=0; fil<pocet_vystupnich_souboru ; fil++){
     found=out_soubory[fil].find_last_of("/\\");
     //nazev_filetu[fil] += out_soubory[fil].substr(0,found);
     nazev_filetu[fil] += out_cesta;
     soubor = out_soubory[fil].substr(found+1);
     nazev_filetu[fil] += slovo + soubor;
  //   cout << nazev_filetu[fil] << endl;
     }

   for (unsigned int fil=0; fil < pocet_vystupnich_souboru; fil++ ){
       ofstream filetka(nazev_filetu[fil].c_str(),ios::out);
       if(!filetka){
         cout <<"\nNelze otevrit soubor: " << nazev_filetu[fil] << endl;
         exit(EXIT_FAILURE);
       }
       filetka << data_vystupu;
       filetka.close();
     }

   delete[] nazev_filetu;
}


void vzory::vypis_sim_vystupy(string slovo)
{
   string *nazev_filetu, adresar, soubor;

   if(pocet_vystupnich_souboru ==0){
     cout <<"\nPocet vystupnich souboru ve vzorech je roven 0 " << endl;
     exit(EXIT_FAILURE);
   }

   nazev_filetu = new string[pocet_vystupnich_souboru];

  size_t found;

   for (unsigned int fil=0; fil<pocet_vystupnich_souboru ; fil++){
     found=out_soubory[fil].find_last_of("/\\");
     //nazev_filetu[fil] += out_soubory[fil].substr(0,found);
     nazev_filetu[fil] += out_cesta;
     soubor = out_soubory[fil].substr(found+1);
     nazev_filetu[fil] += slovo + soubor;
  //   cout << nazev_filetu[fil] << endl;
     }

   for (unsigned int fil=0; fil < pocet_vystupnich_souboru; fil++ ){
       ofstream filetka(nazev_filetu[fil].c_str(),ios::out);
       if(!filetka){
         cout <<"\nNelze otevrit soubor: " << nazev_filetu[fil] << endl;
         exit(EXIT_FAILURE);
       }
       filetka << sim_vystupy;
       filetka.close();
     }

   delete[] nazev_filetu;
}
//        void vypis_vystupy();
//        void vypis_sim_vystupy();

