#include "neuron.h"

// v konstruktoru je treba inicializovat vsechny promenne ktere pouzivame
neuron::neuron()
{
        bias_ANO = false;
        typ_akt_fce = SIGMOIDA;
        pocet_vstupu = 0;
        aktivace = 0;
        vystup = 0;
        der_afce = 0;
        saturation = 0.0;
        
        vstupy.reset();
        vahy.reset();
        delta_vahy.reset();
        dE_dw.reset();
        dF_dw.reset();
        iter_delta_vah.reset();

}

neuron::~neuron()
{
    //dtor
}

/* kopirovaci konstruktor umoznuje prenest vlastnosti puvodniho neuronu do dalsiho,
    aby se vytvorila rada stejnych neuronu se stejnymi vlastnostmi*/
neuron::neuron(const neuron& other)
{
     pocet_vstupu = other.pocet_vstupu;
     vstupy = other.vstupy;
     vahy = other.vahy;
     delta_vahy = other.delta_vahy;
     saturation = other.saturation;

     bias_ANO = other.bias_ANO;
     typ_akt_fce = other.typ_akt_fce;
     aktivace = other.aktivace;
     vystup = other.vystup;
     der_afce = other.der_afce;
     dE_dw = other.dE_dw;
     dF_dw = other.dF_dw;
     iter_delta_vah = other.iter_delta_vah;

}

/* operator prirazeni slouzi k tomu, aby se dalo napsat:
    neuron a; neuron b;
    a = b;*/
neuron& neuron::operator=(const neuron& other)
{
    if (this == &other) return *this; // handle self assignment
    else {
         pocet_vstupu = other.pocet_vstupu;
         vstupy = other.vstupy;
         vahy = other.vahy;
         delta_vahy = other.delta_vahy;
         saturation = other.saturation;

         bias_ANO = other.bias_ANO;
         typ_akt_fce = other.typ_akt_fce;
         aktivace = other.aktivace;
         vystup = other.vystup;
         der_afce = other.der_afce;
         dE_dw = other.dE_dw;
         dF_dw = other.dF_dw;
         iter_delta_vah = other.iter_delta_vah;
         srand((unsigned)time(NULL));

    }
    return *this;
}

// pretazeny konstruktor umoznuje zavolat parametry, t.j. neuron a priradime mu zaroven vlastnosti, pocet vstupu, vstupy apod.
neuron::neuron(unsigned int pom_pocet_vstupu, colvec pom_vstupy, rowvec pom_vahy, bool pom_bias, int pom_typ_akt_fce)
{
    if (pom_pocet_vstupu <=0){
    	 cout << "\n Pocet vstupu do neuronu je mensi nebo roven 0.\n";
    	 exit(EXIT_FAILURE);
        }
      pocet_vstupu = pom_pocet_vstupu;

    if (pocet_vstupu != pom_vahy.n_elem){
         cout << "\n Pocet vstupu do neuronu je odlisny od poctu prvku predavaneho vektoru vah.\n";
    	 exit(EXIT_FAILURE);
        }

    if (pocet_vstupu != pom_vstupy.n_elem){
         cout << "\n Pocet vstupu do neuronu je odlisny od poctu prvku predavaneho vektoru vstupu.\n";
    	 exit(EXIT_FAILURE);
        }

    if ((pom_typ_akt_fce < 0)|| (pom_typ_akt_fce > 11)){
         cout << "\n U neuronu je spatne zadan typ aktivacni fce.\n";
    	 exit(EXIT_FAILURE);
        }

    typ_akt_fce = pom_typ_akt_fce; //inicializace promennych podle parametru predavanych ve funkci
    bias_ANO = pom_bias;
    vstupy.set_size(pocet_vstupu); //inicializace vstupu
    vstupy = pom_vstupy;
    vahy.set_size(pocet_vstupu); //inicialiazace vahy
    vahy = pom_vahy;
    delta_vahy.set_size(pocet_vstupu); //inicialiazace delta_vahy
    delta_vahy.fill(0);
    dE_dw.set_size(pocet_vstupu); //inicializace dE_dW
    dE_dw.fill(0);
    dF_dw.set_size(pocet_vstupu);
    dF_dw.fill(0);
    iter_delta_vah.set_size(pocet_vstupu); //inicializace iter_delta_vah
    iter_delta_vah.fill(0.0);
    saturation = 0.0;

    if (bias_ANO){ //kdyz je bias
    	vahy.reshape(1,pocet_vstupu+1); //rozsirujeme radek o jeden prvek
    	vahy(pocet_vstupu) = rand(); //rozsireny prvek ma hodnotu random (vahy jsou dany nahodne)
    	vstupy.reshape(pocet_vstupu+1,1); //rozsirujeme sloupec o jeden prvek
    	vstupy(pocet_vstupu) = 1.0; //rozsireny prvek ma hodnotu jedna (je to bias)
    	delta_vahy.reshape(1, pocet_vstupu+1);
    	delta_vahy(pocet_vstupu) = 0;
        dE_dw.set_size(pocet_vstupu+1);
        dE_dw.fill(0);
        dF_dw.set_size(pocet_vstupu+1);
        dF_dw.fill(0);
        iter_delta_vah.set_size(pocet_vstupu+1);
        iter_delta_vah.fill(0);
    }

}

/* aktivace neuronu provede skalarni soucin (rowvec vahy* colvec vstupy)
    za pomoci arma fce as_scalar!*/
void neuron::stanov_aktivaci()
{
    aktivace = as_scalar(vahy*vstupy);
}

/* vypocet jednotlivych typu fci na zaklade zvoleneho typu aktivacni fce definovane v "neuron.h" pomoci pole "enum"
    a volane jako posledni hodnota v konstruktoru "neuron::neuron()",
    tato hodnota se definuje uz pri vytvoreni neuronu v tomto konstruktoru*/
void neuron::stanov_vystup()
{
    switch (typ_akt_fce) {
    /* promenna "vystup", uchovava vypocitanou hodnotu a dale postupuje do stanoveni derivace aktivacni fce
    (jednotlive fce jsou definovane v knihovne armadillo)*/
    case SIGMOIDA:
      vystup =1 / (1 + exp(-1*aktivace)) ;
      break;

    case LINEARNI:
      vystup = aktivace;
      break;

    case HTANGENTA:
      vystup = tanh(aktivace);
      break;

    case GAUSS:
      vystup = exp(-(aktivace * aktivace));
      break;
      
    case INVERSE_ABS:
      vystup = aktivace / (1 +fabs(aktivace));
      break;  
      
    case LOGLOG:
      vystup = exp(-exp(-1*aktivace)) ;
      break; 
      
    case CLOGLOG:
      vystup = 1- exp(-exp(aktivace)) ;
      break;          
      
    case CLOGLOGM:
      vystup = 1 - 2* exp(-0.7 * exp(aktivace)) ;
      break;       
      
    case ROOTSIG:
      vystup = aktivace / (1 + sqrt(1 + aktivace * aktivace) );
      
    case LOGSIG:  
      vystup = (1 / (1 + exp(-aktivace)) ) * (1 / (1 + exp(-aktivace)) );
      
    case SECH:
       vystup = 2 / (exp(aktivace) + exp(-aktivace)) ;
       
    case WAVE:
        vystup = (1-aktivace * aktivace) * exp(-(aktivace * aktivace));

    default:
      break;
    }
}

/* vypocet derivaci jednotlivych aktivacnich fci,
    posledni cast vypoctu neuronu, ziskame derivaci danych fci podla typu aktivacni fce*/
void neuron::stanov_der_afce()
{
  switch (typ_akt_fce) {
// k derivaci jsou potrebne hodnoty vystup z neuronu a aktivace neuronu
    case SIGMOIDA:
      der_afce = 1*( 1* vystup * (1 - vystup));
      break;

    case LINEARNI:
      der_afce = 1;
      break;

    case GAUSS:
      der_afce = - 0.5* vystup * aktivace;
      break;

    case HTANGENTA:
      der_afce = (1 - vystup * vystup);
      break;

    case INVERSE_ABS:
      der_afce = 1 / ((1 +fabs(aktivace)) * (1 +fabs(aktivace)));
      break;

    case LOGLOG:
      der_afce = exp(-1*aktivace) * vystup*1;
      break;         

    case CLOGLOG:
      der_afce = exp(aktivace) * ( 1 - vystup) ;
      break;
      
    case CLOGLOGM:
      der_afce = 1.4 * exp(aktivace) * exp( -0.7 * exp(aktivace));
      break;
      
    case  ROOTSIG:
       der_afce = 1 / ((1 + sqrt(1 + aktivace *aktivace))*(sqrt(1 +aktivace *aktivace))); 
       
    case LOGSIG:
       der_afce =  (2*exp(-aktivace) ) / (( 1 + exp(-aktivace)) * ( 1 + exp(-aktivace)) *( 1 + exp(-aktivace)));
       
    case SECH:
        der_afce =  -vystup* tanh(aktivace);
        
    case WAVE:
        der_afce = 2 * aktivace * exp(-(aktivace*aktivace)) * (-2 + aktivace *aktivace);

    default:
      break;
  }
}

//vyvola vsechny 3 predchazejici fce potrebne k vypoctu neuronu: aktivace, vypocet vystupu a derivace aktivacni fce
void neuron::vypocti()
{
    stanov_aktivaci();// udela sumu vstupy * vahy + bias (kdyz je)
    stanov_vystup(); // vypocet vystupu z neuronu
    stanov_der_afce(); // derivace vystupu aktivacni fce
}
/**
 * Zmeni neuron predanymi parametry
 * @param pom_pocet_vstupu novy pocet vstupu
 * @param pom_vstupy novy vstupy vektor o velikosti prvku pom_pocet_vstupu
 */
//je stejny jako neuron::neuron() a ma stejnou fci, meni stav neuronu, pri jeho opetovnem volani, nebo inicializaci
void neuron::premen(unsigned int pom_pocet_vstupu, colvec pom_vstupy, rowvec pom_vahy, bool pom_bias, int pom_typ_akt_fce)
{
   if (pom_pocet_vstupu <=0){
    	 cout << "\n Pocet vstupu do neuronu je mensi nebo roven 0.\n";
    	 exit(EXIT_FAILURE);
        }
      pocet_vstupu = pom_pocet_vstupu;
// skutecna hodnota pocet_vstupu je rovna pomocne z fce, je potrebna kvuli tomu ze uz s ni pracujeme

    if (pocet_vstupu != pom_vahy.n_elem){
         cout << "\n Pocet vstupu do neuronu je odlisny od poctu prvku predavaneho vektoru vah.\n";
    	 exit(EXIT_FAILURE);
        }

    if (pocet_vstupu != pom_vstupy.n_elem){
         cout << "\n Pocet vstupu do neuronu je odlisny od poctu prvku predavaneho vektoru vstupu.\n";
    	 exit(EXIT_FAILURE);
        }

    if ((pom_typ_akt_fce < 0)|| (pom_typ_akt_fce > 11)){
         cout << "\n U neuronu je spatne zadan typ aktivacni fce.\n";
    	 exit(EXIT_FAILURE);
        }

    typ_akt_fce = pom_typ_akt_fce; // inicializace promennych podle parametru predavanych ve fci
    bias_ANO = pom_bias;
    vstupy.set_size(pocet_vstupu); // inicializace vstupy
    vstupy = pom_vstupy;
    vahy.set_size(pocet_vstupu); // inicializace vahy
    vahy = pom_vahy;
    delta_vahy.set_size(pocet_vstupu); // iniicializace delta_vahy
    delta_vahy.fill(0);
    dE_dw.set_size(pocet_vstupu); // inicializace dE_dw
    dE_dw.fill(0);
    dF_dw.set_size(pocet_vstupu);
    dF_dw.fill(0);
    iter_delta_vah.set_size(pocet_vstupu); // inicializace iter_delta_vah
    iter_delta_vah.fill(0);

    if (bias_ANO){ // kdyz je bias rozsiri vektor vstupu o jeden prvek s hodnotou 1 a vektor vah o jeden prvek s nahodnou hodnotou
    	vahy.reshape(1,pocet_vstupu+1);
    	vahy(pocet_vstupu) = randu();
    	vstupy.reshape(pocet_vstupu+1,1);
    	vstupy(pocet_vstupu) = 1.0;
    	delta_vahy.reshape(1,pocet_vstupu+1);
    	delta_vahy(pocet_vstupu) =0;
        dE_dw.set_size(pocet_vstupu+1);
        dE_dw.fill(0);
        dF_dw.set_size(pocet_vstupu+1);
        dF_dw.fill(0);
        iter_delta_vah.set_size(pocet_vstupu+1);
        iter_delta_vah.fill(0);
    }
}

// vypise udaje o neuronu
void neuron::vypis_neuron()
{
   cout << "\nNeuron:\n" << "\nPocet vstupu: " << pocet_vstupu;
   cout << "\nVahy: " << vahy << "\nVstupy:\n"  << vstupy;
   cout << "\nDelta vah: " << delta_vahy;
   cout << "\nDerivace chybove fce dle vahy: " << dE_dw;
   cout << "\nIteracni zmena pro momentum: " << iter_delta_vah;
   cout << "\nBIAS: " << bias_ANO <<"\ntyp afce: " << typ_akt_fce << "\nderivace afce: " << der_afce ;
   cout << "\n\nAktivace: " << aktivace << "\t vystup: " << vystup << "\n";
}

rowvec neuron::rand_u(rowvec A, unsigned int Seed)
{
    rowvec B;
    B.set_size(A.n_elem);
    B.fill(999);

    srand(Seed);

    for (unsigned int vh = 0; vh < A.n_elem; vh++){
//    	B(vh) = (double) rand() / (RAND_MAX+1)) ;
    }

    return B;
}
