#ifndef NEURON_H
#define NEURON_H

#include <armadillo>
#include <time.h>

using namespace arma;



/**
 * Trida neuron
 */
class neuron
{
    public:
        
        enum {SIGMOIDA, LINEARNI, HTANGENTA, GAUSS, INVERSE_ABS, LOGLOG, CLOGLOG, CLOGLOGM, ROOTSIG,LOGSIG, SECH, WAVE} prehled_typ_akt_fce;

        neuron(); // konstruktor
        neuron(unsigned int pom_pocet_vstupu, colvec pom_vstupy, rowvec pom_vahy, bool pom_bias, int pom_typ_akt_fce);//! konstruktor

        ~neuron(); // destruktor
        neuron(const neuron& other); // kopirovaci konstruktor
        neuron& operator=(const neuron& other); // operator prirazeni

        unsigned int pocet_vstupu;//! pocet vstupu neuronu
        colvec vstupy;//! sloupcovy vektor vstupu do neuronu
        rowvec vahy;//! radkovy vektor vah
        rowvec delta_vahy;//! radkovy vektor zmen vahy
        rowvec dE_dw;//! radkovy vektor celkove derivace vahy
        rowvec dF_dw;//! radkovy vektor celkove derivace vahy
        rowvec iter_delta_vah;//! zmena vah pro momentum
        bool bias_ANO;//! volba biasovskeho neuronu
        int typ_akt_fce;//! typ aktivacni funkce

        /**
        *Aktivace neuronu s logistickou sigmoidou \f[ f(a) =\frac{1}{1+e^{-a}} \f]
        */
        double aktivace;
        double vystup;
        double der_afce;
        double saturation;

        rowvec rand_u(rowvec A, unsigned int Seed);//lepsi nahodna incializace
        void stanov_vystup(); // vypocet vystupu z neuronu
        void stanov_aktivaci(); // udela sumu vstupy * vahy + bias (kdyz je)
        void stanov_der_afce(); //derivace vystupu aktivacni fce
        void vypocti(); // fce ktera obsahuje aktivaci vystupu a derivaci v jednom, tedy slouci vsechny tri fce do sebe

        void premen(unsigned int pom_pocet_vstupu, colvec pom_vstupy, rowvec pom_vahy, bool pom_bias, int pom_typ_akt_fce);
        /*obchazejici konstruktor, je stejny jako pretazeny konstruktor se stejnou fci,
        jeho ucelem je menit stav neuronu pri opetovne zmene vstupu*/
        void vypis_neuron(); // vypise udaje o neuronu

    protected:
    private:
};

#endif // NEURON_H
