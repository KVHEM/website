#ifndef NEURAL_NET_H
#define NEURAL_NET_H

#include <iostream>
#include <cmath>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "neuron.h"
#include "vzory.h"
#include "kriteria.h"

using namespace std;

/** Trida neuronove site
 *
 */
class neural_net
{
    public:
        enum {BPonline, BPonline_regul,BPbatch,BPbatch_regul,LMbatch, LMbatch_regul, BPbatch_RpropPLUS, BPbatch_RpropMINUS,  \
             ScCoCr_PERRY, ScCoCr_HESTENES,  ScCoCr_FLETCHER,  ScCoCr_POLAK, StepD_BaBo} prehled_typu_trenovani;

         enum {UNIT_INTERVAL, NGUYEN_WIDROW} typ_initial;

        neural_net();
        neural_net(string nazev_souboru_s_nastavenim); // pretizeny konstruktor bere soubor settings.txt ktery obsahuje nastaveni site
        ~neural_net(); //destruktor
        neural_net(const neural_net& other); // kopirovaci konstruktor
        neural_net& operator=(const neural_net& other); // operator prirazeni

        string cesta_pro_vypis_kriterii;
        string nazev_souboru_s_vypisem_site;

        double control_delta_par;
        double control_SS_error;
        bool controls_out;

        bool control_saturation;
        double saturation_sigma;

        //tyto promenne se nacitaji ze souboru "settings.txt", podle ktereho nastavujeme architekturu site
        unsigned int pocet_vstupu; //pocet vstupu do site
        unsigned int typ_trenovani; //pouzivame jen BP (v souboru oznacen jako 0)
        unsigned int typ_init;
        unsigned int pocet_epoch; // vyjadruje pocet epoch (modelova hodnota)

        //Informace pro kalibracni data
        string *file_nas_vzoru;
        unsigned int pocet_vzorovych_dat; // vyjadruje pocet treninkovych vzoru reprezentovane poctem objektu *data, urcuje se na zaklade vstupu!
        unsigned int pocet_vzoru;// pocet radku v matici VSTUPY, VYSTUPY ziskane ze vzoru *data
        unsigned int LAG;//!< Posun prvni sloupce simulovanych dat

        //Infromace pro testovaci data
        string *file_nas_test_dat;
        unsigned int pocet_data_test;
        unsigned int pocet_radku_test_dat;

        unsigned int pocet_vrstev; // pocet vrstev v siti
        unsigned int pocet_neuronu; // celkovy pocet neuronu v siti, vcetne vstupu
        unsigned int pocet_vah; // pocet vah v siti
        unsigned int pocet_vystupu; // celkovy pocet vystupu ze site
        unsigned int *pocet_neuronu_ve_vrtsve; // dynamicky alokovane pole, naplnime vrstvu poctem neuronu
        unsigned int *typ_akt_fci; // dynamicky alokovane pole, nacitame typy aktivacnich fci do jednotlivych neuronu ve vrstve

        double momentum; // zohledneni predchadzejici zmeny vah, nabyva hodnoty (0,1)
        double learning_rate; // rychlost uceni, udava se v rozmezi (0,1)
        double regul_alpha;//Hyperparametr pro regularizaci uceni
        double regul_beta;//Hyperparametr pro regularizaci uceni

        double e1;
        double e2;
        double tau;
        unsigned int maxiter;

        double eps;
        double c1;
        double c2;
        unsigned int  CCmaxiter;
        bool CC_restart_out;
        unsigned int CC_restart_period;
        double CC_restart_boundary;
        bool CC_POWEL;
        
        unsigned int BBmaxiter;
        bool BB_restart_out;        
        double BB_restart_boundary;
        double BB_eps;
        
        double SS_vah;
        double SS_er;

        colvec vahy;
        colvec dE_vahy;
        colvec dF_vahy;
        colvec saturations;

        double delta_init;
        double eta_plus;// kladna velikost kroku pro Rprop
        double eta_minus;// zaporna delka krokku pro Rprop
        double deltamax;
        double deltamin;
        unsigned int BP_Rprop_pocet_epoch;

        double low_init;
        double up_init;

        vzory *data_kal;//Kalibracni data
        vzory *data_test;//Testovaci data
        vzory *data_val;//Validacni data

        string soubor_s_nastavenim_vzoru;
        string soubor_s_nastavenim_test_vzoru;

        bool bias_ano_ne; // bias nacteny ze souboru settings.txt
        double bias_const;

        neuron **neuron_ve_vrstve; // dvojrozmerne pole usporada neurony tak, ze naplni kazdou vrstvu poctem neuronu
        colvec vystupy; // vektor vystupu je pouzity pri vypoctu pom_delty, ktera pocita rozdil mezi pozadovanymi a simulovanymi daty ze site

        mat VSTUPY;
        mat VSTUPY_TEST;
        mat VYSTUPY;
        mat VYSTUPY_TEST;
        mat SIM_VYSTUPY;
        mat SIM_VYSTUPY_TEST;
        mat REZIDUI;

        mat J;// jakobiho matice J = DF_w, kde dF_dw je sloupcovy vektor derivace vystupu dle vahy
        mat Hessian;//Hesian = J * trans(J)
        
        mat beta_OLS;
        bool bench_OLS;
        string path_OLS_benchmark;

        unsigned int Ensemble;

        bool best_net;
        bool vypis_best_nets;
        unsigned int index_bestnet_kriteria;
        unsigned int real_pocet_bestnet;
        double prah_kriteria;
        mat bestnet_vahy;
        mat bestnet_vahy_initial;
        string cesta_pro_vypis_best_net_vah;
        string cesta_pro_vypis_best_net_simulaci;
        bool trenuj_ens_s_init_vahami;
        string soubor_s_init_vahami;

        void inicializuj();
        void rand_vahy();
        void rand_vahy(unsigned int Seed);
        mat  mat_rand_vahy();

        void spocti_pocet_vah();
        void priprav_data_k_trenovani();
        void priprav_testovaci_data();
        void LAG_control();

        void vypocti_1vzor(colvec pom_vstupy);

        void nulovani_delt();
        void nulovani_dF_dw();
        void nulovani_dE_dw();
        void vypocti_derivace_dy_dw_1vzor(colvec vzor_vstupy);
        void vypocti_gradient_batch();
        void vypocti_gradient_batch_CC();
        void vypocti_gradient_batch_regul();
        void vypocti_derivace_J_batch();

        void net_saturation();
        void neurons_saturation_1vzor(colvec pom_vstupy);
        void nulovani_saturation();
        void change_sat_weights();

        void stanov_kriteria(unsigned int cislo1, string nazev_filetu, string slovo);
        void stanov_kriteria_test(unsigned int cislo1, string nazev_filetu, string slovo);
        void stanov_kriteria_test_selectbestnet(unsigned int cislo1, string nazev_filetu, string slovo, colvec initial_vahy);
        void vypis_MEAN(unsigned int cislo, string file, colvec MEAN_data);

        void vypocti_allvzory();
        void vypocti_allvzory_test();
        double vypocti_allvzory_a_error(colvec Vahy);

        void bp_RpropPLUS();
        void bp_RpropMINUS();
        double maxi(double c1, double c2);
        double mini(double c1, double c2);
        double sign( double num);

        void bp_online_regul(); // trenovani typu online, update vah okamzite po vypocitani chyby
        void bp_batch_regul();
        void backpropagation_ONLINE_basic_step(colvec vzor_vstupy, colvec vzor_vystup);
        void backpropagation_ONLINE_basic_step_regul(colvec vzor_vstupy, colvec vzor_vystup);
        void zmen_vahy_1vzor(colvec vzor_vstupy, colvec vzor_vystup);
        void prirad_do_dE_dw();
        void zmen_vahy_1vzor_regul(colvec vzor_vstupy, colvec vzor_vystup);

        void bp_online();//BP trenovani typu online, update vah okamzite po vypocitani chyby
        void bp_batch();//BP trenovani typu batch
        void vypocti_derivace_BP_1vzor(colvec vzor_vstupy, colvec vzor_vystup);
        void vypocti_derivace_BP_1vzor_regul(colvec vzor_vstupy, colvec vzor_vystup);
        void vypocti_derivace_BP_1vzor_CC(colvec vzor_vstupy, colvec vzor_vystup);

        void LevM_batch();
        void LevM_batch_regul();

        void ScConGrad_Perry();
        void ScConGrad_Hestenes();
        void ScConGrad_Fletcher();
        void ScConGrad_Polak();
        double line_search(double alp, colvec old_Vahy, colvec direction, double zero_error);
        mat bracketing(double alp, colvec old_Vahy, colvec direction, double zero_error);
        
        void StepD_BB();
        
        void benchmark_OLS();

        void stanov_SS_vah();
        void stanov_SS_er();

        void prirad_do_vahy();
        void prirad_z_vahy();

        void prirad_z_vahy(double *vahy);
        void prirad_z_vahy(colvec vahy);

        void trenuj(); // fce na trenovani site
        void test_treninku();
        void test_treninku_s_read_vahami();

        void vypis_neural_net(string nazev_souboru);
        void premen_architekturu();

        void vypis_best_vahy(string slovo, bool vypsat_init_NN);
        void vypis_kriteria_best_nets(unsigned int cislo , string slovo, colvec MEAN_kriteria);

        void ensemble_simulation();
        void nahrad_cestu();

    protected:
    private:

};

#endif // NEURAL_NET_H
