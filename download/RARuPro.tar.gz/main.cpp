//#include "hydrogram.h"
//#include "hyetogram.h"
//#include "charakteristiky_1d.h"
//using namespace std;

#include "so_udalost.h"

int main()
{
//Priklad inicializace SO udalosti
  so_udalost flood;

  double qq[10]={1,20,40,50,50,50,40,30,20,1};

  int w=10;

  hydrogram pv1(2,qq,w,true,2,7,1,true); // pri teto inicializaci v promene pv1.pocatek je zanesen index prvni hodnoty hydrogramu
  hyetogram pv11(2,qq,w,true,2,7,1,true);
      
  flood.hydrogram_so = pv1;
  flood.hyetogram_so = pv11;
  flood.hydrogram_so.vypocti_charakteristiky();
  flood.hydrogram_so.vypis_charakteristiky("soubor11");
  flood.hydrogram_so.vypocti_timecharakteristiky();
  flood.vypocti_SO_timing_charakteristiky();


  so_udalost flo(pv11,pv1,1,1,0);
  flo.hydrogram_so.vypocti_charakteristiky();
  flo.hydrogram_so.vypis_charakteristiky("soubor1_1");
  flo.vypocti_SO_timing_charakteristiky();
//Konec prikladu inicializace SO udalosti
 
  pv1.vypocti_charakteristiky(pv1.data_1D);
  pv1.vypis_charakteristiky("soubor");
  pv1.vypis_hydrogram("soubor1");

  hydrogram pv2;

  pv2.nacti_data_hydrogramu("soubor1",1,1,true);
  pv2.vypocti_charakteristiky(pv2.data_1D);
  pv2.vypis_charakteristiky("soubor_2");
  pv2.vypis_hydrogram("soubor_22");

  double qqw[13]={1,2,1,1,1,1,1,1,1,1,1,1,1};

  pv2.prirad_hydrogram_data(qqw,13,true);
  pv2.vypis_hydrogram("soubor_223");
  pv2.vypocti_charakteristiky(pv2.data_1D);
  pv2.vypis_charakteristiky("soubor_23");

  pv2.prevede_jednotky(1.5,true);
  
  hydrogram pv3;

  pv3 = pv1;

  pv3.vypis_charakteristiky("soubor_3");
  pv3.vypis_hydrogram("soubor_31");
  pv3.prirad_hydrogram_data(qq,10,true);
  pv3.vypocti_charakteristiky();
  pv3.vypis_charakteristiky("soubor_3");

  charakteristiky_1D pv4(qqw,13,true,1,13,1,true);

  pv4.vypocti_charakteristiky();
  pv4.vypis_data_1D("soubor_4");
  pv4.vypis_charakteristiky("soubor41");

  charakteristiky_1D pv5;
  pv5.prirad_1Ddata(qq,10,true);
  pv5.vypocti_charakteristiky();
  pv5.vypis_data_1D("soubor_5");
  pv5.vypis_charakteristiky("soubor51");

  charakteristiky_1D pv6(qq,w,true,2,7,1,true);

  pv6.vypocti_charakteristiky(pv6.data_1D);
  pv6.vypis_charakteristiky("soubor6");
  
  flood.hydrogram_so = pv1;
  flood.hyetogram_so = pv11;
  flood.hydrogram_so.vypocti_charakteristiky();
  flood.hydrogram_so.vypis_charakteristiky("soubor11");

  return 0;
}
