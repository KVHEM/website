#include "charakteristiky_1d.h"

charakteristiky_1D::charakteristiky_1D()
{
    pocet_charakteristik = 20;
    charakteristiky.set_size(pocet_charakteristik);
    charakteristiky.fill(999999999.99);
    velikost = 0;
    prevod_jednotek = 1;
    pocatek_konec = false;
    pocatek = 0;
    konec = 0;
    data_1D.set_size(velikost);
    data_1D.fill(999999.9);
    suma_je_objem_vyska = false;
    pocet_time_char = 22;
    time_charakteristics.set_size(pocet_time_char);
    time_charakteristics.fill(999999.9);
    pocet_vol_char = 30;
    vol_charakteristics.set_size(pocet_vol_char);
    vol_charakteristics.fill(999999.9);
    pocet_comchar = 28;
    com_charakteristics.set_size(pocet_comchar);
    com_charakteristics.fill(999999.99);
}

charakteristiky_1D::charakteristiky_1D(double *data_1D_d, unsigned int data_size, bool poc_kon, unsigned int poc, unsigned int kon, double pre_jed, bool sum_je_vyska_obj)
{
    pocet_charakteristik = 20;
    charakteristiky.set_size(pocet_charakteristik);
    charakteristiky.fill(999999999.99);
    pocet_time_char = 22;
    time_charakteristics.set_size(pocet_time_char);
    time_charakteristics.fill(999999.9);
    pocet_vol_char = 30;
    vol_charakteristics.set_size(pocet_vol_char);
    vol_charakteristics.fill(999999.9);
    pocet_comchar = 28;
    com_charakteristics.set_size(pocet_comchar);
    com_charakteristics.fill(999999.99);
    prevod_jednotek = pre_jed;
    pocatek_konec = poc_kon;

  if (pocatek_konec) {
      if (poc < 1) {
             cout << "Spatne zadany pocatek predavanych 1D dat: musi byt vetsi nez 0." << "\n";
             exit(EXIT_FAILURE);
           }
           pocatek = poc;
      if (kon < poc) {
             cout << "Spatne zadany konec predavanych 1D dat: musi byt vetsi nez pocatek." << "\n";
             exit(EXIT_FAILURE);
           }
           konec = kon;
           velikost = konec - pocatek + 1;
      if (data_size < velikost) {
             cout << "Spatne zadana data pro pripravu charakteristik 1D dat: velikost originalnich dat musi byt vetsi nez rozsah zadaneho pocatku a konce." << "\n";
             exit(EXIT_FAILURE);
           }
        } else {
           konec = data_size;
           pocatek = 1;
           velikost = data_size;
        }

    data_1D.set_size(velikost);

    unsigned long i = 0;
    for (unsigned long dat = pocatek-1; dat < konec; dat++ ) {
    	   data_1D(i) = prevod_jednotek * data_1D_d[dat];
    	   i++;
       }
       
        suma_je_objem_vyska = sum_je_vyska_obj;
}

charakteristiky_1D::~charakteristiky_1D()
{
    charakteristiky.reset();
    time_charakteristics.reset();
    vol_charakteristics.reset();
    com_charakteristics.reset();
    data_1D.reset();
}

charakteristiky_1D::charakteristiky_1D(const charakteristiky_1D& other)
{
  pocatek = other.pocatek;
  konec = other.konec;
  pocatek_konec = other.pocatek_konec;

  prevod_jednotek = other.prevod_jednotek;

  pocet_charakteristik = other.pocet_charakteristik;
  charakteristiky = other.charakteristiky;
  
  velikost = other.velikost;
  data_1D = other.data_1D;
 
  pocet_time_char = other.pocet_charakteristik;
  pocet_vol_char = other.pocet_vol_char;
  time_charakteristics = other.time_charakteristics;
  vol_charakteristics = other.vol_charakteristics;
  suma_je_objem_vyska = other.suma_je_objem_vyska;
  pocet_comchar = other.pocet_comchar;
  com_charakteristics = other.com_charakteristics;
}

charakteristiky_1D& charakteristiky_1D::operator=(const charakteristiky_1D& rhs)
{
    if(this != &rhs){
             pocatek = rhs.pocatek;
             konec = rhs.konec;
             pocatek_konec = rhs.pocatek_konec;

             prevod_jednotek = rhs.prevod_jednotek;

             pocet_charakteristik = rhs.pocet_charakteristik;
             velikost = rhs.velikost;
             
             pocet_time_char = rhs.pocet_time_char;
             pocet_vol_char = rhs.pocet_vol_char;
             pocet_comchar = rhs.pocet_comchar;
             
             time_charakteristics = rhs.time_charakteristics;
             vol_charakteristics = rhs.vol_charakteristics;
             com_charakteristics = rhs.com_charakteristics;
             
             charakteristiky.set_size(pocet_charakteristik);
             data_1D.set_size(velikost);
             
             charakteristiky = rhs.charakteristiky;
             data_1D = rhs.data_1D;
             suma_je_objem_vyska = rhs.suma_je_objem_vyska;
    }
    return *this;
}

/**
  * Přiřadí data do 1D datového pole, kontroluje zda velikost dat je větší než 0, nastaví proměnné pocatek, konec a pocatek_konec
  * @param přiřazovaná data
  * @param velikost přiřazovaných dat
  */
void charakteristiky_1D::prirad_1Ddata(double *data, unsigned int data_size, bool suma_je_vyska_obj)
{
    if (data_size <1) {
      cout << "\n Velikost 1D dat musi byt vetsi nez 0" ;
      exit(EXIT_FAILURE);
      } else {
      
      velikost = data_size;
      data_1D.set_size(velikost);
      
      for (unsigned int dat = 0; dat < velikost; dat++ ){
        data_1D(dat) = data[dat];
        }
        
     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska =suma_je_vyska_obj;
     }
}

/**
  * Přiřadí data do 1D datového pole, kontroluje zda velikost dat je větší než 0, nastaví proměnné pocatek, konec a pocatek_konec
  * @param přiřazovaná data
  * @param velikost přiřazovaných dat
  */
void charakteristiky_1D::prirad_1Ddata(colvec data, unsigned int data_size, bool suma_je_vyska_obj)
{
    if (data_size <1) {
     cout << "\n Velikost 1D dat musi byt vetsi nez 0" ;
     exit(EXIT_FAILURE);
     } else {
// TODO (pavel#1#): Pridat kontrolu velikosti vektoru a pole      
     velikost = data_size;
     data_1D.set_size(velikost);
    
     data_1D = data;
      
     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska =suma_je_vyska_obj;
     }
}

void charakteristiky_1D::nacti_data_1D(string nazev_souboru,  unsigned int sloupec, unsigned int pocet_sloupcu)
{
    string odpad;

     unsigned int pocet_radku = 0, velikost_filetu = 0;

     ifstream myfile (nazev_souboru.c_str());

  if (myfile.is_open()) {
    while (! myfile.eof() ) {
      getline (myfile,odpad);
      pocet_radku++;
    }
      velikost = pocet_radku-1;
      data_1D.set_size(velikost);
      velikost_filetu = myfile.tellg();
   //   cout << velikost_filetu << "\n";
      myfile.clear();
      myfile.seekg(0, ios::beg);
      for (unsigned int rad = 0; rad < velikost; rad++ ) {
             for (unsigned int sl = 0; sl < pocet_sloupcu; sl++ ) {
          	     if (sl == sloupec-1)  myfile >> data_1D(rad);
          	        else myfile >> odpad;
              }
      }
    myfile.close();
    }  else { cout << "Chyba v otevreni souboru pro nacteni dat: " << nazev_souboru.c_str() << "\n";
    exit(EXIT_FAILURE);
    }

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
}

/**
  * Vypíše data_1D do souboru
  * @param názav souboru pro výpis dat
  */
void charakteristiky_1D::vypis_data_1D(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis dat_1D - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int dat = 0; dat < velikost; dat++)
  	proud << data_1D(dat) << "\n";
  proud.close();
}

/**
  * Vypíše charakteristiky 1D pole do souboru
  * @param název souboru
  */
void charakteristiky_1D::vypis_charakteristiky(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis charakteristik hydrogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int ch = 0; ch < pocet_charakteristik; ch++)
  	proud << charakteristiky(ch) << "\t";
  proud << "\n";
  proud.close();
}

/**
  * Vypíše charakteristiky 1D pole do souboru
  * @param název souboru
  */
void charakteristiky_1D::vypis_time_charakteristiky(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis charakteristik hydrogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int ch = 0; ch < pocet_time_char; ch++)
  	proud << time_charakteristics(ch) << "\t";
  proud << "\n";
  proud.close();
}

/**
  * Vypíše objemove charakteristiky 1D pole do souboru
  * @param název souboru
  */
void charakteristiky_1D::vypis_vol_charakteristiky(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis charakteristik hydrogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int ch = 0; ch < pocet_vol_char; ch++)
  	proud << vol_charakteristics(ch) << "\t";
  proud << "\n";
  proud.close();
}


/**
  * Vypíše kombinovanych charakteristiky 1D pole do souboru
  * @param název souboru
  */
void charakteristiky_1D::vypis_comb_charakteristiky(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis charakteristik hydrogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int ch = 0; ch < pocet_comchar; ch++)
  	proud << com_charakteristics(ch) << "\t";
  proud << "\n";
  proud.close();
}

/**
  * Stanovení objemu dat sumou 1D pole, přetížení členské funkce
  * @param data 1D
  */
double charakteristiky_1D::Objem_1Ddat(colvec data)
{
     if ( suma_je_objem_vyska){
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet objemu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(0) = as_scalar( sum(data));
    return(as_scalar( charakteristiky(0)));
     }else {
        cout << "Do funkce Objem_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu dat sumou 1D pole, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Objem_1Ddat(double *data, unsigned int Velikost)
{
    if ( suma_je_objem_vyska){
    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet objemu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else pom_data.set_size(Velikost);
    
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }
    charakteristiky(0) = as_scalar( sum(pom_data));
    return(as_scalar( charakteristiky(0)));
    }else {
        cout << "Do funkce Objem_1Ddat(double *data, unsigned int Velikost) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu dat sumou 1D pole, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Objem_1Ddat()
{
    if ( suma_je_objem_vyska){
    charakteristiky(0) = as_scalar( sum(data_1D));
        return(as_scalar( charakteristiky(0)));
    } else {
        cout << "Do funkce Objem_1Ddat() je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení maxima 1D dat, přetížení členské funkce
  */
double charakteristiky_1D::Max_1Ddat()
{
    charakteristiky(1) = as_scalar( max(data_1D) );
    return(as_scalar(charakteristiky(1)));
}

/**
  * Stanovení maxima 1D dat, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Max_1Ddat(double *data, unsigned int Velikost)
{
    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet max, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
       
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }
    charakteristiky(1) = as_scalar( max(pom_data) );
    return(as_scalar(charakteristiky(1)));
}

/**
  * Stanovení maxima 1D dat, přetížení členské funkce
  * @param vektor dat
  */
double charakteristiky_1D::Max_1Ddat(colvec data)
{
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet max, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } 
    
    charakteristiky(1) = as_scalar( max(data));
    return(as_scalar(charakteristiky(1)));
}

/**
  * Stanovení minima 1D dat, přetížení členské funkce
  */
double charakteristiky_1D::Min_1Ddat()
{
    charakteristiky(2) = as_scalar( min(data_1D) );
    return(as_scalar(charakteristiky(2)));
}

/**
  * Stanovení minima 1D dat, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Min_1Ddat(double *data, unsigned int Velikost)
{
    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet min, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }
    charakteristiky(2) = as_scalar( min(pom_data) );
    return(as_scalar(charakteristiky(2)));
}

/**
  * Stanovení minima 1D dat, přetížení členské funkce
  * @param vektor dat
  */
double charakteristiky_1D::Min_1Ddat(colvec data)
{
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet min, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    charakteristiky(2) = as_scalar( min(data));
    return(as_scalar(charakteristiky(2)));
}

/**
  * Stanovení doby výskytu maxima 1D dat, přetížení členské funkce
  */
double charakteristiky_1D::Cas_max_1Ddat()
{
    double MAx=0.0, Cas_m=0.0;
    MAx = Max_1Ddat();

    for (unsigned int dat=0; dat < velikost; dat++){
    	 if (MAx == as_scalar(data_1D(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }

    charakteristiky(3) = Cas_m;
    return(Cas_m);
}

/**
  * Stanovení doby výskytu maxima 1D dat, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Cas_max_1Ddat(double *data, unsigned int Velikost)
{
    double MAx=0.0, Cas_m=0.0;

    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby max, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else    pom_data.set_size(Velikost);
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }
      
    MAx = Max_1Ddat(pom_data);

    for (unsigned int dat=0; dat < Velikost; dat++){
    	 if (MAx == as_scalar(pom_data(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }

    charakteristiky(3) = Cas_m;
    return(Cas_m);
}

/**
  * Stanovení doby výskytu maxima 1D dat, přetížení členské funkce
  * @param vektor dat
  */
double charakteristiky_1D::Cas_max_1Ddat(colvec data)
{
    double MAx=0.0, Cas_m=0.0;
    unsigned int Velikost = 99999;
    
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby max, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;
    MAx = Max_1Ddat(data);

    for (unsigned int dat=0; dat < Velikost; dat++){
    	 if (MAx == as_scalar(data(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }

    charakteristiky(3) = Cas_m;
    return(Cas_m);
}

/**
  * Stanovení doby výskytu minima 1D dat, přetížení členské funkce
  */
double charakteristiky_1D::Cas_min_1Ddat()
{

    double MIn = 999999.9, Cas_m = -999999.9;
    MIn = Min_1Ddat();

    for (unsigned int dat=0; dat < velikost; dat++){
    	 if (MIn == as_scalar(data_1D(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }
    charakteristiky(4)= Cas_m;
    return(Cas_m);
}

/**
  * Stanovení doby výskytu minima 1D dat, přetížení členské funkce
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Cas_min_1Ddat(double *data, unsigned int Velikost)
{
    double MIn = 999999.9, Cas_m = -999999.9;

    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby min, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
       
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }
      
    MIn = Min_1Ddat(pom_data);

    for (unsigned int dat=0; dat < velikost; dat++){
    	 if (MIn == as_scalar(pom_data(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }
    charakteristiky(4)= Cas_m;
    return(Cas_m);
}

/**
  * Stanovení doby výskytu minima 1D dat, přetížení členské funkce
  * @param vektor dat
  */
double charakteristiky_1D::Cas_min_1Ddat(colvec data)
{
    double MIn = 999999.9, Cas_m = -999999.9;
    unsigned int Velikost = 99999;
    
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby min, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;
    MIn= Min_1Ddat(data);

    for (unsigned int dat=0; dat < Velikost; dat++){
    	 if (MIn == as_scalar(data(dat))) {
    	     Cas_m = dat +1;
    	     break;
    	     }
         }

    charakteristiky(4) = Cas_m;
    return(Cas_m);
}

/**
  *  Stanovení Y souřadnice těžiště 1d pole
  */
double charakteristiky_1D::Y_teziste_1Ddat()
{
    
    double centroid_Y = 0.0;

     for (unsigned int dat = 0; dat<velikost; dat++){
     	    centroid_Y = centroid_Y + (data_1D(dat)/2)*(data_1D(dat))/(as_scalar( sum(data_1D) ));
           }

    charakteristiky(6) = centroid_Y;
    return(centroid_Y);
}

/**
  *  Stanovení Y souřadnice těžiště 1d pole
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::Y_teziste_1Ddat(double *data, unsigned int Velikost)
{
    
    double centroid_Y = 0.0;
    
    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Y-teziste, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
    
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }

     for (unsigned int dat = 0; dat<velikost; dat++){
     	    centroid_Y = centroid_Y + (pom_data(dat)/2)*(pom_data(dat))/(as_scalar( sum(pom_data) ));
           }

    charakteristiky(6) = centroid_Y;
    return(centroid_Y);
}


/**
  *  Stanovení Y souřadnice těžiště 1d pole
  * @param vektor pole
  */
double charakteristiky_1D::Y_teziste_1Ddat(colvec data)
{
    
    double centroid_Y = 0.0;
    unsigned int Velikost = 0.0;    
       
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Y-teziste, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;

     for (unsigned int dat = 0; dat<Velikost; dat++){
     	    centroid_Y = centroid_Y + (data(dat)/2)*(data(dat))/(as_scalar( sum(data) ));
           }

    charakteristiky(6) = centroid_Y;
    return(centroid_Y);
}

/**
  * Stanovení X souřadnice těžiště 1d pole
  */
double charakteristiky_1D::X_teziste_1Ddat()
  {
     double centroid_X =0.0;

     for (unsigned int dat = 0; dat<velikost; dat++){
     	    centroid_X = centroid_X + (0.5 +dat)*(data_1D(dat))/(as_scalar( sum(data_1D) ));
           }
    charakteristiky(5) = centroid_X;
    return(centroid_X);
  }
  
  
/**
  * Stanovení X souřadnice těžiště 1d pole
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::X_teziste_1Ddat(double *data, unsigned int Velikost)
  {
    double centroid_X =0.0;
    
    colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet X-teziste, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
       
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }

     for (unsigned int dat = 0; dat<velikost; dat++){
     	    centroid_X = centroid_X + (0.5 +dat)*(pom_data(dat))/(as_scalar( sum(pom_data) ));
           }
    charakteristiky(5) = centroid_X;
    return(centroid_X);
  }
  
/**
  * Stanovení X souřadnice těžiště 1d pole
  * @param data 1D
  */
double charakteristiky_1D::X_teziste_1Ddat(colvec data)
{
    double centroid_X = 0.0;
    unsigned int Velikost = 0;
       
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet X-teziste, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;
       
     for (unsigned int dat = 0; dat<Velikost; dat++){
     	    centroid_X = centroid_X + (0.5 +dat)*(data(dat))/(as_scalar( sum(data) ));
           }
    charakteristiky(5) = centroid_X;
    return(centroid_X);
}

/**
  * Stanoví délku mezi koncem dat a těžištěm norizontální osa (čas)
  */
double charakteristiky_1D::konec_X_teziste_1Ddat()
{
   charakteristiky(7) = Trvani_1Ddat() - X_teziste_1Ddat();
   return(as_scalar(charakteristiky(7)));
}


/**
  * Stanoví délku mezi koncem dat a těžištěm norizontální osa (čas)
  * @param data 1D
  * @param velikost pole
  */
double charakteristiky_1D::konec_X_teziste_1Ddat(double *data, unsigned int Velikost)
{
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet X-teziste - konec, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
   charakteristiky(7) = Trvani_1Ddat(data, Velikost) - X_teziste_1Ddat(data, Velikost);
   return(as_scalar(charakteristiky(7)));
}

/**
  * Stanoví délku mezi koncem dat a těžištěm norizontální osa (čas)
  * @param data 1D
  */
double charakteristiky_1D::konec_X_teziste_1Ddat(colvec data)
{
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet X-teziste - konec, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
   
   charakteristiky(7) = Trvani_1Ddat(data) - X_teziste_1Ddat(data);
   return(as_scalar(charakteristiky(7)));
}

/**
  * Stanoví dobu trvání daného pole
  */
double charakteristiky_1D::Trvani_1Ddat()
{
    charakteristiky(8) = velikost;
    return(as_scalar(charakteristiky(8)));
}

/**
  * Stanoví dobu trvání daného pole
  * @param data 1D
  * @param velikost 
  */
double charakteristiky_1D::Trvani_1Ddat(double *data, unsigned int Velikost)
{
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby trvani, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
       
    charakteristiky(8) = velikost;
    return(as_scalar(charakteristiky(8)));
}

/**
  * Stanoví dobu trvání daného pole
  * @param data 1D
  */
double charakteristiky_1D::Trvani_1Ddat(colvec data)
{
    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby trvani, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
       
    charakteristiky(8) = data.n_elem;
    return(as_scalar(charakteristiky(8)));
}

/**
  * Stanoví dobu od vzestupu, počátek dat až po maximum
  */
double charakteristiky_1D::Cas_vzestup_1Ddat()
{
    
    double MAx = -999999.9, CAs_vz = 0.0, j =0.0;
    unsigned int i = 0;

    CAs_vz = Cas_max_1Ddat();
    MAx = Max_1Ddat();


   for (i = CAs_vz; i<velikost; i++ ){
   	  if(MAx == data_1D(i)) j++;
   	     else break;
   }
//   cout << j << " j\n";
   CAs_vz = CAs_vz + (j+1)/2 - 1;

   charakteristiky(9) = CAs_vz;
   return(CAs_vz);
}

/**
  * Stanoví dobu od vzestupu, počátek dat až po maximum
  * @param data 1D
  * @param velikost   
  */
double charakteristiky_1D::Cas_vzestup_1Ddat(double *data, unsigned int Velikost)
{
    double MAx = -999999.9, CAs_vz = 0.0, j =0.0;
    unsigned int i = 0;

     colvec pom_data;
    
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro dobu vzestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
       
    for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }

    CAs_vz = Cas_max_1Ddat(data, Velikost);
    MAx = Max_1Ddat(data, Velikost);

   for (i = CAs_vz; i<Velikost; i++ ){
   	  if(MAx == pom_data(i)) j++;
   	     else break;
   }
//   cout << j << " j\n";
   CAs_vz = CAs_vz + (j+1)/2 - 1;

   charakteristiky(9) = CAs_vz;
   return(CAs_vz);
}

/**
  * Stanoví dobu od vzestupu, počátek dat až po maximum
  * @param data 1D
  */
double charakteristiky_1D::Cas_vzestup_1Ddat(colvec data)
{
    double MAx = -999999.9, CAs_vz = 0.0, j =0.0;
    unsigned int i = 0, Velikost = 0;

    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro dobu vzestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;

    CAs_vz = Cas_max_1Ddat(data);
    MAx = Max_1Ddat(data);

   for (i = CAs_vz; i<Velikost; i++ ){
   	  if(MAx == data(i)) j++;
   	     else break;
   }
//   cout << j << " j\n";
   CAs_vz = CAs_vz + (j+1)/2 - 1;

   charakteristiky(9) = CAs_vz;
   return(CAs_vz);
}

/**
  * Stanovení objemu vzestupné části 1D pole
  */
double charakteristiky_1D::Objem_vzestup_1Ddat()
{
 if ( suma_je_objem_vyska){
  double CAs_vz = 0.0,Objem_vz = 0.0, citac = 0.0;
  unsigned int dat = 0;

  CAs_vz = Cas_vzestup_1Ddat();
// TODO (pavel#1#): Tyto dva for cykly je mozne spojit do jednoho je potreba tohle overit
 for (dat = 0; dat < velikost; dat++){
 	if( dat < CAs_vz) citac++;
 	else break;
  }
citac--;

//cout << citac << " citac";
 dat = 0;
 for (dat = 0; dat < citac; dat++){
	Objem_vz = Objem_vz + data_1D(dat);
  }

//cout << data_1D;

Objem_vz = Objem_vz + (CAs_vz - (citac)) * as_scalar(data_1D(dat));

 charakteristiky(10) = Objem_vz;
 return(Objem_vz);
    }else {
        cout << "Do funkce Objem_Objem_vzestup_1Ddat() je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu vzestupné části 1D pole
  * @param data 1D
  * @param velikost     
  */
double charakteristiky_1D::Objem_vzestup_1Ddat(double *data, unsigned int Velikost)
{
 if ( suma_je_objem_vyska){
  double CAs_vz = 0.0,Objem_vz = 0.0, citac = 0.0;
  unsigned int dat = 0;

  colvec pom_data;
    
  if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro objemu vzestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else  pom_data.set_size(Velikost);
       
for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }

  CAs_vz = Cas_vzestup_1Ddat(data, Velikost);
// TODO (pavel#1#): Tyto dva for cykly je mozne spojit do jednoho je potreba tohle overit
 for (dat = 0; dat < Velikost; dat++){
 	if( dat < CAs_vz) citac++;
 	else break;
  }
citac--;
//cout << citac << " citac";
 dat = 0;
 for (dat = 0; dat < citac; dat++){
	Objem_vz = Objem_vz + pom_data(dat);
  }

 Objem_vz = Objem_vz + (CAs_vz - (citac)) * as_scalar(pom_data(dat));

 charakteristiky(10) = Objem_vz;
 return(Objem_vz);
    }else {
        cout << "Do funkce Objem_Objem_vzestup_1Ddat(double *data, unsigned int Velikost) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu vzestupné části 1D pole
  * @param data 1D
  */
double charakteristiky_1D::Objem_vzestup_1Ddat(colvec data)
{
if ( suma_je_objem_vyska){
  double CAs_vz = 0.0,Objem_vz = 0.0, citac = 0.0;
  unsigned int dat = 0, Velikost = 0;

    if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro objemu vzestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } else Velikost = data.n_elem;

  CAs_vz = Cas_vzestup_1Ddat(data);
// TODO (pavel#1#): Tyto dva for cykly je mozne spojit do jednoho je potreba tohle overit
 for (dat = 0; dat < Velikost; dat++){
 	if( dat < CAs_vz) citac++;
 	else break;
  }
citac--;
//cout << citac << " citac";
 dat = 0;
 for (dat = 0; dat < citac; dat++){
	Objem_vz = Objem_vz + data(dat);
  }

 Objem_vz = Objem_vz + (CAs_vz - (citac)) * as_scalar(data(dat));

 charakteristiky(10) = Objem_vz;
 return(Objem_vz);
         }else {
        cout << "Do funkce Objem_Objem_vzestup_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení času sestupu 1D pole
  */
double charakteristiky_1D::Cas_sestup_1Ddat()
{
  charakteristiky(11) = Trvani_1Ddat() - Cas_vzestup_1Ddat();
 return(Trvani_1Ddat() - Cas_vzestup_1Ddat());
}

/**
  * Stanovení času sestupu 1D pole
  * @param pole 1D
  * @param velikost
  */
double charakteristiky_1D::Cas_sestup_1Ddat(double *data, unsigned int Velikost)
{
   if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby sestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } 
     
 charakteristiky(11) = Trvani_1Ddat(data, Velikost) - Cas_vzestup_1Ddat(data, Velikost);
 return(Trvani_1Ddat(data, Velikost) - Cas_vzestup_1Ddat(data, Velikost));
}

/**
  * Stanovení času sestupu 1D pole
  * @param pole 1D
  */
double charakteristiky_1D::Cas_sestup_1Ddat(colvec data)
{
    if ( suma_je_objem_vyska){
   if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet doby sestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       } 
     
 charakteristiky(11) = Trvani_1Ddat(data) - Cas_vzestup_1Ddat(data);
 return(Trvani_1Ddat(data) - Cas_vzestup_1Ddat(data));
         }else {
        cout << "Do funkce Objem_Objem_sestup_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 
}

/**
  * Stanovení objemu sestupné části 1D pole
  */
double charakteristiky_1D::Objem_sestup_1Ddat()
{
    if ( suma_je_objem_vyska){
    charakteristiky(12) = Objem_1Ddat() - Objem_vzestup_1Ddat();
    return(Objem_1Ddat() - Objem_vzestup_1Ddat()) ;
        }else {
        cout << "Do funkce Objem_Objem_sestup_1Ddat() je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu sestupné části 1D pole
  * @param pole 1D
  * @param velikost pole
  */
double charakteristiky_1D::Objem_sestup_1Ddat(double *data, unsigned int Velikost)
{
    if ( suma_je_objem_vyska){
       if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet objemu sestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
      charakteristiky(12) = Objem_1Ddat(data, Velikost) - Objem_vzestup_1Ddat(data, Velikost);
    return(Objem_1Ddat(data, Velikost) - Objem_vzestup_1Ddat(data, Velikost)) ;
    
            }else {
        cout << "Do funkce Objem_Objem_sestup_1Ddat(double *data, unsigned int Velikost) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}

/**
  * Stanovení objemu sestupné části 1D pole
  * @param pole 1D
  */
double charakteristiky_1D::Objem_sestup_1Ddat(colvec data)
{
       if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet objemu sestupu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(12) = Objem_1Ddat(data) - Objem_vzestup_1Ddat(data);
    return(Objem_1Ddat(data) - Objem_vzestup_1Ddat(data)) ;
}

/**
  * Stanovení rozptylu 1D dat
  */
 double charakteristiky_1D::Rozptyl_1Ddat()
 {
    charakteristiky(13) = var(data_1D);
    return(var(data_1D));     
 } 

/**
  * Stanovení rozptylu 1D dat
  * @param pole 1D
  * @param Velikost
  */
 double charakteristiky_1D::Rozptyl_1Ddat(double *data, unsigned int Velikost)
 {
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet rozptylu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
            
    charakteristiky(13) = var(pom_data);
    return(var(pom_data));     
 } 

/**
  * Stanovení rozptylu 1D dat
  * @param pole 1D
  * @param Velikost
  */
 double charakteristiky_1D::Rozptyl_1Ddat(colvec data)
 {
     if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet rozptylu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(13) = var(data);
    return(var(data));     
 } 

/**
  * Stanovení směrodatné odchylky dat
  */
double charakteristiky_1D::Stddev_1Ddat()
{
     charakteristiky(14) = stddev(data_1D);
    return(stddev(data_1D));        
}

/**
  * Stanovení směrodatné odchylky dat
  * @param pole 1D
  * @param Velikost
  */
 double charakteristiky_1D::Stddev_1Ddat(double *data, unsigned int Velikost)
 {
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet SMOD, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
            
    charakteristiky(14) = stddev(pom_data);
    return(stddev(pom_data));     
 } 

/**
  * Stanovení směrodatné odchylky dat
  * @param pole 1D
  */
 double charakteristiky_1D::Stddev_1Ddat(colvec data)
 {
     if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet SMOD, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(14) = stddev(data);
    return(stddev(data));     
 } 

/**
  * Stanovení směrodatné odchylky dat
  */
double charakteristiky_1D::Mean_1Ddat()
{
     charakteristiky(15) = mean(data_1D);
    return( mean(data_1D));        
}

/**
  * Stanovení směrodatné odchylky dat
  * @param pole 1D
  * @param Velikost
  */
 double charakteristiky_1D::Mean_1Ddat(double *data, unsigned int Velikost)
 {
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Mean, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
            
    charakteristiky(15) =  mean(pom_data);
    return( mean(pom_data));     
 } 

/**
  * Stanovení směrodatné odchylky dat
  * @param pole 1D
  */
 double charakteristiky_1D::Mean_1Ddat(colvec data)
 {
     if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Mean, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(15) =  mean(data);
    return( mean(data));     
 } 

/**
  * Stanovení mediánu dat
  */
double charakteristiky_1D::Median_1Ddat()
{
     charakteristiky(16) = median(data_1D);
    return( median(data_1D));        
}

/**
  * Stanovení mediánu dat
  * @param pole 1D
  * @param Velikost
  */
 double charakteristiky_1D::Median_1Ddat(double *data, unsigned int Velikost)
 {
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Medianu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
            
    charakteristiky(16) =  median(pom_data);
    return( median(pom_data));     
 } 

/**
  * Stanovení mediánu dat
  * @param pole 1D
  */
 double charakteristiky_1D::Median_1Ddat(colvec data)
 {
     if ( data.n_elem <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Medianu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    charakteristiky(16) =  median(data);
    return( median(data));     
 } 
 
  /**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   */
 double charakteristiky_1D::Objem_po_MAX_1Ddat()
 {
     if ( suma_je_objem_vyska){
    double rozdil = 0.0, objem_pomax = 0.0, cas_max_pom = 0.0, Max_1d = 0.0;
    unsigned int cas_mm = 0;
    
    cas_max_pom = Cas_max_1Ddat();
    Max_1d = Max_1Ddat();

   if ((cas_max_pom -1 )== cas_mm){
     objem_pomax = 0.0;    
   } else {
     for ( cas_mm = 0;(static_cast<double>(cas_mm))<cas_max_pom; cas_mm++)
      objem_pomax = objem_pomax + as_scalar(data_1D(cas_mm));
    
     rozdil = cas_max_pom - (static_cast<double>(cas_mm));
     objem_pomax = objem_pomax + rozdil * Max_1d;
    }
   
  charakteristiky(17) = objem_pomax;
    
    return(objem_pomax);
     }else {
        cout << "Do funkce Objem_po_MAX_1Ddat() je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }
 
 
   /**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   */
 double charakteristiky_1D::Objem_po_MAX_1Ddat(double *data, unsigned int Velikost)
 {
     if ( suma_je_objem_vyska){
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Medianu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
     
    double rozdil = 0.0, objem_pomax = 0.0, cas_max_pom = 0.0, Max_1d = 0.0;
    unsigned int cas_mm = 0;
    
    cas_max_pom = Cas_max_1Ddat(pom_data);
    Max_1d = Max_1Ddat(pom_data);

   if ((cas_max_pom -1 )== cas_mm){
     objem_pomax = 0.0;    
   } else {
     for ( cas_mm = 0;(static_cast<double>(cas_mm))<cas_max_pom; cas_mm++)
      objem_pomax = objem_pomax + as_scalar(pom_data(cas_mm));
    
     rozdil = cas_max_pom - (static_cast<double>(cas_mm));
     objem_pomax = objem_pomax + rozdil * Max_1d;
    }
   
  charakteristiky(17) = objem_pomax;
    
    return(objem_pomax);
    }else {
        cout << "Do funkce Objem_po_MAX_1Ddat(double *data, unsigned int Velikost) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }
 
   /**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   * @param pole 1D   
   */
 double charakteristiky_1D::Objem_po_MAX_1Ddat(colvec data)
 {
     if ( suma_je_objem_vyska){
    double rozdil = 0.0, objem_pomax = 0.0, cas_max_pom = 0.0, Max_1d = 0.0;
    unsigned int cas_mm = 0;
    
    cas_max_pom = Cas_max_1Ddat(data);
    Max_1d = Max_1Ddat(data);

   if ((cas_max_pom -1 )== cas_mm){
     objem_pomax = 0.0;    
   } else {
     for ( cas_mm = 0;(static_cast<double>(cas_mm))<cas_max_pom; cas_mm++)
      objem_pomax = objem_pomax + as_scalar(data(cas_mm));
    
     rozdil = cas_max_pom - (static_cast<double>(cas_mm));
     objem_pomax = objem_pomax + rozdil * Max_1d;
    }
   
  charakteristiky(17) = objem_pomax;
    
    return(objem_pomax);
        }else {
        cout << "Do funkce Objem_po_MAX_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }
 
 
   /**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   */
 double charakteristiky_1D::Objem_po_Yteziste_1Ddat()
 {
  if ( suma_je_objem_vyska){
    double rozdil = 0.0, objem_po_tez = 0.0, cas_tez_pom = 0.0;
    unsigned int cas_tt =0;
    
    cas_tez_pom = X_teziste_1Ddat();

   if ((cas_tez_pom -1 )== cas_tt){
     objem_po_tez = 0.0;    
   } else {
     for ( cas_tt =0;static_cast<double>(cas_tt)<cas_tez_pom; cas_tt++)
      objem_po_tez = objem_po_tez + as_scalar(data_1D(cas_tt));
    
     rozdil = cas_tez_pom - static_cast<double>(cas_tt);
     objem_po_tez = objem_po_tez + rozdil * as_scalar(data_1D(cas_tt));
    }
   
  charakteristiky(18) = objem_po_tez;
    
    return(objem_po_tez);
            }else {
        cout << "Do funkce Objem_po_Yteziste_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }
 
 
   /**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   */
 double charakteristiky_1D::Objem_po_Yteziste_1Ddat(double *data, unsigned int Velikost)
 { 
     if ( suma_je_objem_vyska){
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Medianu, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
     
    double rozdil = 0.0, objem_po_tez = 0.0, cas_tez_pom = 0.0;
    unsigned int cas_tt =0;
    
    cas_tez_pom = X_teziste_1Ddat(pom_data);

   if ((cas_tez_pom -1 )== cas_tt){
     objem_po_tez = 0.0;    
   } else {
     for ( cas_tt =0;static_cast<double>(cas_tt)<cas_tez_pom; cas_tt++)
      objem_po_tez = objem_po_tez + as_scalar(pom_data(cas_tt));
    
     rozdil = cas_tez_pom - static_cast<double>(cas_tt);
     objem_po_tez = objem_po_tez + rozdil * as_scalar(pom_data(cas_tt));
    }
   
  charakteristiky(18) = objem_po_tez;
    
    return(objem_po_tez);
    
                    }else {
        cout << "Do funkce Objem_po_Yteziste_1Ddat(double *data, unsigned int Velikost) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }
 
/**
   * Stanovi objem 1Ddat od nuly po vyskyt maxima vcetne
   * @param pole 1D
   */
 double charakteristiky_1D::Objem_po_Yteziste_1Ddat(colvec data)
 {
     if ( suma_je_objem_vyska){
    double rozdil = 0.0, objem_po_tez = 0.0, cas_tez_pom = 0.0;
    unsigned int cas_tt =0;
    
    cas_tez_pom = X_teziste_1Ddat(data);

   if ((cas_tez_pom -1 )== cas_tt){
     objem_po_tez = 0.0;    
   } else {
     for ( cas_tt =0;static_cast<double>(cas_tt)<cas_tez_pom; cas_tt++)
      objem_po_tez = objem_po_tez + as_scalar(data(cas_tt));
    
     rozdil = cas_tez_pom - static_cast<double>(cas_tt);
     objem_po_tez = objem_po_tez + rozdil * as_scalar(data(cas_tt));
    }
   
  charakteristiky(18) = objem_po_tez;
    
    return(objem_po_tez);
                }else {
        cout << "Do funkce Objem_po_Yteziste_1Ddat(colvec data) je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
 }

 /**
   * Stanoví čas kdy odteklo pul objem
   */
double charakteristiky_1D::Cas_pul_OBJM()
{
  if ( suma_je_objem_vyska){
        
    double pul_obj = 0.0, rozdil_y = 0.0, casD = 0.0, rozdil_x = 0.0, pom_cas = 0.0, pom_obj = 0.0;
    unsigned int cas =0;
    
    pul_obj = 0.5*Objem_1Ddat();
    
    for (pom_cas = 0.0; pom_obj < pul_obj ; pom_cas++){
      cas++;
      pom_obj = pom_obj + as_scalar(data_1D(pom_cas));
      }
    pom_obj = pom_obj - data_1D(pom_cas) ;
    rozdil_y = pul_obj - pom_obj;
    rozdil_x = rozdil_y / as_scalar(data_1D(pom_cas));
    
    casD = static_cast<double>(cas) + rozdil_x - 1;
    
    charakteristiky(19) = casD;
    
        return(casD);
    
        return(casD);
                }else {
        cout << "Do funkce Cas_pul_OBJM() je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}
 
  /**
   * Stanoví čas kdy odteklo pul objem
   * @param pole 1D
   * @param Velikost
   */
double charakteristiky_1D::Cas_pul_OBJM(double *data, unsigned int Velikost)
{
  if ( suma_je_objem_vyska){
    
     if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet Cas_pul_OBJ, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
     
     colvec pom_data;
     
     pom_data.set_size(Velikost);
     
     for (unsigned int dat =0; dat < Velikost;dat ++ ){
      pom_data(dat) = data[dat];
      }    
    double pul_obj = 0.0, rozdil_y = 0.0, casD = 0.0, rozdil_x = 0.0, pom_cas = 0.0, pom_obj = 0.0;
    unsigned int cas =0;
    
    pul_obj = 0.5*Objem_1Ddat(pom_data);
    
    for (pom_cas = 0.0; pom_obj < pul_obj ; pom_cas++){
      cas++;
      pom_obj = pom_obj + as_scalar(pom_data(pom_cas));
      }
    pom_obj = pom_obj - pom_data(pom_cas) ;
    rozdil_y = pul_obj - pom_obj;
    rozdil_x = rozdil_y / as_scalar(pom_data(pom_cas));
    
    casD = static_cast<double>(cas) + rozdil_x - 1;
    
    charakteristiky(19) = casD;
    
        return(casD);
    
        return(casD);
                }else {
        cout << "Do funkce Cas_pul_OBJM je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}
 
  /**
   * Stanoví čas kdy odteklo pul objem
   * @param pole 1D 
   */
double charakteristiky_1D::Cas_pul_OBJM(colvec data)
{
  if ( suma_je_objem_vyska){
        
    double pul_obj = 0.0, rozdil_y = 0.0, casD = 0.0, rozdil_x = 0.0, pom_cas = 0.0, pom_obj = 0.0;
    unsigned int cas =0;
    
    pul_obj = 0.5*Objem_1Ddat(data);
    
    for (pom_cas = 0.0; pom_obj < pul_obj ; pom_cas++){
      cas++;
      pom_obj = pom_obj + as_scalar(data(pom_cas));
      }
    pom_obj = pom_obj - data(pom_cas) ;
    rozdil_y = pul_obj - pom_obj;
    rozdil_x = rozdil_y / as_scalar(data(pom_cas));
    
    casD = static_cast<double>(cas) + rozdil_x - 1;
    
    charakteristiky(19) = casD;
    
        return(casD);
                }else {
        cout << "Do funkce Cas_pul_OBJM je predavan spatne normovany objem!\n";
        exit(EXIT_FAILURE);
       }
}
 
 /**
   * Provede výpočet všech charakteristik najednou
   */
void charakteristiky_1D::vypocti_charakteristiky()
{
    if ( velikost <=0 )   {
        cout << "Chyba ve velikosti vektoru datv poli chrakteristiky1D!";
        exit(EXIT_FAILURE);
    }
    
    Objem_1Ddat(); Max_1Ddat(); Min_1Ddat(); Cas_max_1Ddat(), Cas_min_1Ddat();
    X_teziste_1Ddat(); Y_teziste_1Ddat(); konec_X_teziste_1Ddat();
    Trvani_1Ddat(); Cas_vzestup_1Ddat(); Objem_vzestup_1Ddat(); Cas_sestup_1Ddat();
    Objem_sestup_1Ddat(); Rozptyl_1Ddat(), Stddev_1Ddat(); Mean_1Ddat(), Median_1Ddat();
    Objem_po_MAX_1Ddat();Objem_po_Yteziste_1Ddat(), Cas_pul_OBJM();
}

 /**
   * Provede výpočet všech charakteristik najednou
   * @param pole 1d
   * @param velikost
   */
void charakteristiky_1D::vypocti_charakteristiky(double *data, unsigned int Velikost)
{
    if ( Velikost <=0 )   {
        cout << "Chyba ve velikosti pole predavaneho pro vypocet vsech charakteristik, musi byt vetsi nez 0!";
        exit(EXIT_FAILURE);
       }
    
    Objem_1Ddat(data, Velikost); Max_1Ddat(data, Velikost); Min_1Ddat(data, Velikost); Cas_max_1Ddat(data, Velikost), Cas_min_1Ddat(data, Velikost);
    X_teziste_1Ddat(data, Velikost); Y_teziste_1Ddat(data, Velikost); konec_X_teziste_1Ddat(data, Velikost);
    Trvani_1Ddat(data, Velikost); Cas_vzestup_1Ddat(data, Velikost); Objem_vzestup_1Ddat(data, Velikost); Cas_sestup_1Ddat(data, Velikost);
    Objem_sestup_1Ddat(data, Velikost); Rozptyl_1Ddat(data, Velikost), Stddev_1Ddat(data, Velikost); Mean_1Ddat(data, Velikost), Median_1Ddat(data, Velikost);
    Objem_po_MAX_1Ddat(data,Velikost);Objem_po_Yteziste_1Ddat(data,Velikost), Cas_pul_OBJM(data, Velikost);
}

 /**
   * Provede výpočet všech charakteristik najednou
   * @param data 1D
   */
void charakteristiky_1D::vypocti_charakteristiky(colvec data)
{
    Objem_1Ddat(data); Max_1Ddat(data); Min_1Ddat(data); Cas_max_1Ddat(data), Cas_min_1Ddat(data);
    X_teziste_1Ddat(data); Y_teziste_1Ddat(data); konec_X_teziste_1Ddat(data);
    Trvani_1Ddat(data); Cas_vzestup_1Ddat(data); Objem_vzestup_1Ddat(data); Cas_sestup_1Ddat(data);
    Objem_sestup_1Ddat(data); Rozptyl_1Ddat(data), Stddev_1Ddat(data); Mean_1Ddat(data), Median_1Ddat(data);
    Objem_po_MAX_1Ddat(data);Objem_po_Yteziste_1Ddat(data), Cas_pul_OBJM(data);
}

/**
   * Provede výpočet všech casovych charakteristik najednou
   */
void charakteristiky_1D::vypocti_timecharakteristiky()
{
    vypocti_charakteristiky();
 /*   
//        enum {Cas_Max0, Cas_Min1, Cas_Teziste2, Cas_Teziste_konec3, \
//                     Cele_Trvani4, Cas_Vzestup5, Cas_Sestup6, Cas_pulObj7, \
//                     Casmax_Trvani8, Casmin_Trvani9, Casteziste_Trvani10, Castezistekonec_Trvani11, \
//                     Casvzes_Trvani12, Cassestup_Trvani13, Caspul_trvani14, \
//                     rCasmax_Trvani15, rCasmin_Trvani16, rCasteziste_Trvani17, rCastezistekonec_Trvani18, \
//                     rCasvzes_Trvani19, rCassestup_Trvani20, rCaspul_trvani21 \
//                  } time_characteristics;//!< Specifikace časových charakteristik 1D pole( 22 clenů)    */
    time_charakteristics(0) = charakteristiky(3); time_charakteristics(1) = charakteristiky(4); 
    time_charakteristics(2) = charakteristiky(5); time_charakteristics(3) = charakteristiky(7); 
    time_charakteristics(4) = charakteristiky(8); time_charakteristics(5) = charakteristiky(9); 
    time_charakteristics(6) = charakteristiky(11); time_charakteristics(7) = charakteristiky(19);
    
    time_charakteristics(8) = time_charakteristics(4) - time_charakteristics(0);
    time_charakteristics(9) = time_charakteristics(4) - time_charakteristics(1);
    time_charakteristics(10) = time_charakteristics(4) - time_charakteristics(2);
    time_charakteristics(11) = time_charakteristics(4) - time_charakteristics(3);
    time_charakteristics(12) = time_charakteristics(4) - time_charakteristics(5);
    time_charakteristics(13) = time_charakteristics(4) - time_charakteristics(6);
    time_charakteristics(14) = time_charakteristics(4) - time_charakteristics(7);
    time_charakteristics(15) = time_charakteristics(0) / time_charakteristics(4);
    time_charakteristics(16) = time_charakteristics(1) / time_charakteristics(4);
    time_charakteristics(17) = time_charakteristics(2) / time_charakteristics(4);
    time_charakteristics(18) = time_charakteristics(3) / time_charakteristics(4);
    time_charakteristics(19) = time_charakteristics(5) / time_charakteristics(4);
    time_charakteristics(20) = time_charakteristics(6) / time_charakteristics(4);
    time_charakteristics(21) = time_charakteristics(7) / time_charakteristics(4);
}

/**
   * Provede výpočet všech casovych charakteristik najednou
   * @param pole 1d
   * @param velikost
   */
void charakteristiky_1D::vypocti_timecharakteristiky(double *data, unsigned int Velikost)
{
    vypocti_charakteristiky(data,Velikost);
 /*   
//        enum {Cas_Max0, Cas_Min1, Cas_Teziste2, Cas_Teziste_konec3, \
//                     Cele_Trvani4, Cas_Vzestup5, Cas_Sestup6, Cas_pulObj7, \
//                     Casmax_Trvani8, Casmin_Trvani9, Casteziste_Trvani10, Castezistekonec_Trvani11, \
//                     Casvzes_Trvani12, Cassestup_Trvani13, Caspul_trvani14, \
//                     rCasmax_Trvani15, rCasmin_Trvani16, rCasteziste_Trvani17, rCastezistekonec_Trvani18, \
//                     rCasvzes_Trvani19, rCassestup_Trvani20, rCaspul_trvani21 \
//                  } time_characteristics;//!< Specifikace časových charakteristik 1D pole( 22 clenů)    */
    time_charakteristics(0) = charakteristiky(3); time_charakteristics(1) = charakteristiky(4); 
    time_charakteristics(2) = charakteristiky(5); time_charakteristics(3) = charakteristiky(7); 
    time_charakteristics(4) = charakteristiky(8); time_charakteristics(5) = charakteristiky(9);
    time_charakteristics(6) = charakteristiky(11); time_charakteristics(7) = charakteristiky(19);
    
    time_charakteristics(8) = time_charakteristics(4) - time_charakteristics(0);
    time_charakteristics(9) = time_charakteristics(4) - time_charakteristics(1);
    time_charakteristics(10) = time_charakteristics(4) - time_charakteristics(2);
    time_charakteristics(11) = time_charakteristics(4) - time_charakteristics(3);
    time_charakteristics(12) = time_charakteristics(4) - time_charakteristics(5);
    time_charakteristics(13) = time_charakteristics(4) - time_charakteristics(6);
    time_charakteristics(14) = time_charakteristics(4) - time_charakteristics(7);
    time_charakteristics(15) = time_charakteristics(0) / time_charakteristics(4);
    time_charakteristics(16) = time_charakteristics(1) / time_charakteristics(4);
    time_charakteristics(17) = time_charakteristics(2) / time_charakteristics(4);
    time_charakteristics(18) = time_charakteristics(3) / time_charakteristics(4);
    time_charakteristics(19) = time_charakteristics(5) / time_charakteristics(4);
    time_charakteristics(20) = time_charakteristics(6) / time_charakteristics(4);
    time_charakteristics(21) = time_charakteristics(7) / time_charakteristics(4);
}

/**
   * Provede výpočet všech casovych charakteristik najednou
   * @param colvec s daty pro vypocet
   */
void charakteristiky_1D::vypocti_timecharakteristiky(colvec data)
{
    vypocti_charakteristiky(data);
 /*//        enum {Cas_Max0, Cas_Min1, Cas_Teziste2, Cas_Teziste_konec3, \
//                     Cele_Trvani4, Cas_Vzestup5, Cas_Sestup6, Cas_pulObj7, \
//                     Casmax_Trvani8, Casmin_Trvani9, Casteziste_Trvani10, Castezistekonec_Trvani11, \
//                     Casvzes_Trvani12, Cassestup_Trvani13, Caspul_trvani14, \
//                     rCasmax_Trvani15, rCasmin_Trvani16, rCasteziste_Trvani17, rCastezistekonec_Trvani18, \
//                     rCasvzes_Trvani19, rCassestup_Trvani20, rCaspul_trvani21 \
//                  } time_characteristics;//!< Specifikace časových charakteristik 1D pole( 22 clenů)    */
    time_charakteristics(0) = charakteristiky(3); time_charakteristics(1) = charakteristiky(4); 
    time_charakteristics(2) = charakteristiky(5); time_charakteristics(3) = charakteristiky(7); 
    time_charakteristics(4) = charakteristiky(8); time_charakteristics(5) = charakteristiky(9); 
    time_charakteristics(6) = charakteristiky(11); time_charakteristics(7) = charakteristiky(19); 
    
    time_charakteristics(8) = time_charakteristics(4) - time_charakteristics(0);
    time_charakteristics(9) = time_charakteristics(4) - time_charakteristics(1);
    time_charakteristics(10) = time_charakteristics(4) - time_charakteristics(2);
    time_charakteristics(11) = time_charakteristics(4) - time_charakteristics(3);
    time_charakteristics(12) = time_charakteristics(4) - time_charakteristics(5);
    time_charakteristics(13) = time_charakteristics(4) - time_charakteristics(6);
    time_charakteristics(14) = time_charakteristics(4) - time_charakteristics(7);
    time_charakteristics(15) = time_charakteristics(0) / time_charakteristics(4);
    time_charakteristics(16) = time_charakteristics(1) / time_charakteristics(4);
    time_charakteristics(17) = time_charakteristics(2) / time_charakteristics(4);
    time_charakteristics(18) = time_charakteristics(3) / time_charakteristics(4);
    time_charakteristics(19) = time_charakteristics(5) / time_charakteristics(4);
    time_charakteristics(20) = time_charakteristics(6) / time_charakteristics(4);
    time_charakteristics(21) = time_charakteristics(7) / time_charakteristics(4);
}

/**
   * Provede výpočet všech objemovych charakteristik najednou
   */
void charakteristiky_1D::vypocti_volcharakteristiky()
{
   /*               vyskaobj 0, Peak 1, mIN 2, Teziste 3, \
                     objem_vzestup 4, objem_sest 5, sttdev 6, \
                     arprum 7, mediaN 8, objempomax 9,objempoteziste 10, \
                     peak_vol 11, min_vol 12, teziste_vol 13, \
                     peak_objvzest 14,min_obj_vzest 15, teziste_objvzest 16, \
                     peak_objsest 17, min_objsest 18, teziste_objsest 19, \
                     peak_objpoteziste 20, min_objpoteziste 21,teziste_objpoteziste 22, \
                     peak_objpomax 23, min_objpomax 24, teziste_objmpomax 25, \
                     objmpoteziste_objm 26, objsest_objm27, obvest_objm 28   , rozptyl*/
                     
     vol_charakteristics(0) = charakteristiky(0);vol_charakteristics(1) = charakteristiky(1);vol_charakteristics(2) = charakteristiky(2);
     vol_charakteristics(3) = charakteristiky(6);vol_charakteristics(4) = charakteristiky(10);vol_charakteristics(5) = charakteristiky(11);    
     vol_charakteristics(6) = charakteristiky(14);vol_charakteristics(7) = charakteristiky(15);vol_charakteristics(8) = charakteristiky(16);     
     vol_charakteristics(9) = charakteristiky(17);vol_charakteristics(10) = charakteristiky(18);
     
     vol_charakteristics(11) = vol_charakteristics(1) / vol_charakteristics(0);//peak div obj
     vol_charakteristics(12) = vol_charakteristics(2) / vol_charakteristics(0);//min div obj
     vol_charakteristics(13) = vol_charakteristics(3) / vol_charakteristics(0);//tez div obj
     
     vol_charakteristics(14) = vol_charakteristics(1) / vol_charakteristics(4);//peak div obj_vzest
     vol_charakteristics(15) = vol_charakteristics(2) / vol_charakteristics(4);//min div obj_vzest
     vol_charakteristics(16) = vol_charakteristics(3) / vol_charakteristics(4);//min div obj_vzest     


     vol_charakteristics(17) = vol_charakteristics(1) / vol_charakteristics(5);//peak div obj_sest
     vol_charakteristics(18) = vol_charakteristics(2) / vol_charakteristics(5);//min div obj_sest
     vol_charakteristics(19) = vol_charakteristics(3) / vol_charakteristics(5);//min div obj_sest     

     vol_charakteristics(20) = vol_charakteristics(1) / vol_charakteristics(10);//peak div obj_po_tez
     vol_charakteristics(21) = vol_charakteristics(2) / vol_charakteristics(10);//min div objj_po_tez
     vol_charakteristics(22) = vol_charakteristics(3) / vol_charakteristics(10);//min div objj_po_tez

     vol_charakteristics(23) = vol_charakteristics(1) / vol_charakteristics(9);//peak div obj_po_max
     vol_charakteristics(24) = vol_charakteristics(2) / vol_charakteristics(9);//min div objj_po_max
     vol_charakteristics(25) = vol_charakteristics(3) / vol_charakteristics(9);//min div objj_po_max
     

     vol_charakteristics(26) = vol_charakteristics(10) / vol_charakteristics(0); //objm_poteziste div objm
     vol_charakteristics(27) = vol_charakteristics(5) / vol_charakteristics(0); // objmsest _div obj
     vol_charakteristics(28) = 1 - vol_charakteristics(26); //objvzest div obj
     
     vol_charakteristics(29) = charakteristiky(13) ; // ropztyl
     

   /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
}


/**
   * Provede výpočet všech objemovych charakteristik najednou
   * @param pole 1d
   * @param velikost
   */
void charakteristiky_1D::vypocti_volcharakteristiky(double *data, unsigned int Velikost)
{
    vypocti_charakteristiky(data,Velikost);
    
   /*               vyskaobj 0, Peak 1, mIN 2, Teziste 3, \
                     objem_vzestup 4, objem_sest 5, sttdev 6, \
                     arprum 7, mediaN 8, objempomax 9,objempoteziste 10, \
                     peak_vol 11, min_vol 12, teziste_vol 13, \
                     peak_objvzest 14,min_obj_vzest 15, teziste_objvzest 16, \
                     peak_objsest 17, min_objsest 18, teziste_objsest 19, \
                     peak_objpoteziste 20, min_objpoteziste 21,teziste_objpoteziste 22, \
                     peak_objpomax 23, min_objpomax 24, teziste_objmpomax 25, \
                     objmpoteziste_objm 26, objsest_objm27, obvest_objm 28   , rozptyl*/
                     
     vol_charakteristics(0) = charakteristiky(0);vol_charakteristics(1) = charakteristiky(1);vol_charakteristics(2) = charakteristiky(2);
     vol_charakteristics(3) = charakteristiky(6);vol_charakteristics(4) = charakteristiky(10);vol_charakteristics(5) = charakteristiky(11);    
     vol_charakteristics(6) = charakteristiky(14);vol_charakteristics(7) = charakteristiky(15);vol_charakteristics(8) = charakteristiky(16);     
     vol_charakteristics(9) = charakteristiky(17);vol_charakteristics(10) = charakteristiky(18);
     
     vol_charakteristics(11) = vol_charakteristics(1) / vol_charakteristics(0);//peak div obj
     vol_charakteristics(12) = vol_charakteristics(2) / vol_charakteristics(0);//min div obj
     vol_charakteristics(13) = vol_charakteristics(3) / vol_charakteristics(0);//tez div obj
     
     vol_charakteristics(14) = vol_charakteristics(1) / vol_charakteristics(4);//peak div obj_vzest
     vol_charakteristics(15) = vol_charakteristics(2) / vol_charakteristics(4);//min div obj_vzest
     vol_charakteristics(16) = vol_charakteristics(3) / vol_charakteristics(4);//min div obj_vzest     


     vol_charakteristics(17) = vol_charakteristics(1) / vol_charakteristics(5);//peak div obj_sest
     vol_charakteristics(18) = vol_charakteristics(2) / vol_charakteristics(5);//min div obj_sest
     vol_charakteristics(19) = vol_charakteristics(3) / vol_charakteristics(5);//min div obj_sest     

     vol_charakteristics(20) = vol_charakteristics(1) / vol_charakteristics(10);//peak div obj_po_tez
     vol_charakteristics(21) = vol_charakteristics(2) / vol_charakteristics(10);//min div objj_po_tez
     vol_charakteristics(22) = vol_charakteristics(3) / vol_charakteristics(10);//min div objj_po_tez

     vol_charakteristics(23) = vol_charakteristics(1) / vol_charakteristics(9);//peak div obj_po_max
     vol_charakteristics(24) = vol_charakteristics(2) / vol_charakteristics(9);//min div objj_po_max
     vol_charakteristics(25) = vol_charakteristics(3) / vol_charakteristics(9);//min div objj_po_max
     

     vol_charakteristics(26) = vol_charakteristics(10) / vol_charakteristics(0); //objm_poteziste div objm
     vol_charakteristics(27) = vol_charakteristics(5) / vol_charakteristics(0); // objmsest _div obj
     vol_charakteristics(28) = 1 - vol_charakteristics(26); //objvzest div obj
     
     vol_charakteristics(29) = charakteristiky(13) ; // ropztyl
     

   /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
}


/**
   * Provede výpočet všech objemovych charakteristik najednou
   * @param colvec dat
   */
void charakteristiky_1D::vypocti_volcharakteristiky(colvec data)
{
        vypocti_charakteristiky(data);
   /*               vyskaobj 0, Peak 1, mIN 2, Teziste 3, \
                     objem_vzestup 4, objem_sest 5, sttdev 6, \
                     arprum 7, mediaN 8, objempomax 9,objempoteziste 10, \
                     peak_vol 11, min_vol 12, teziste_vol 13, \
                     peak_objvzest 14,min_obj_vzest 15, teziste_objvzest 16, \
                     peak_objsest 17, min_objsest 18, teziste_objsest 19, \
                     peak_objpoteziste 20, min_objpoteziste 21,teziste_objpoteziste 22, \
                     peak_objpomax 23, min_objpomax 24, teziste_objmpomax 25, \
                     objmpoteziste_objm 26, objsest_objm27, obvzest_objm 28   , rozptyl*/
                     
     vol_charakteristics(0) = charakteristiky(0);vol_charakteristics(1) = charakteristiky(1);vol_charakteristics(2) = charakteristiky(2);
     vol_charakteristics(3) = charakteristiky(6);vol_charakteristics(4) = charakteristiky(10);vol_charakteristics(5) = charakteristiky(11);    
     vol_charakteristics(6) = charakteristiky(14);vol_charakteristics(7) = charakteristiky(15);vol_charakteristics(8) = charakteristiky(16);     
     vol_charakteristics(9) = charakteristiky(17);vol_charakteristics(10) = charakteristiky(18);
     
     vol_charakteristics(11) = vol_charakteristics(1) / vol_charakteristics(0);//peak div obj
     vol_charakteristics(12) = vol_charakteristics(2) / vol_charakteristics(0);//min div obj
     vol_charakteristics(13) = vol_charakteristics(3) / vol_charakteristics(0);//tez div obj
     
     vol_charakteristics(14) = vol_charakteristics(1) / vol_charakteristics(4);//peak div obj_vzest
     vol_charakteristics(15) = vol_charakteristics(2) / vol_charakteristics(4);//min div obj_vzest
     vol_charakteristics(16) = vol_charakteristics(3) / vol_charakteristics(4);//min div obj_vzest     


     vol_charakteristics(17) = vol_charakteristics(1) / vol_charakteristics(5);//peak div obj_sest
     vol_charakteristics(18) = vol_charakteristics(2) / vol_charakteristics(5);//min div obj_sest
     vol_charakteristics(19) = vol_charakteristics(3) / vol_charakteristics(5);//min div obj_sest     

     vol_charakteristics(20) = vol_charakteristics(1) / vol_charakteristics(10);//peak div obj_po_tez
     vol_charakteristics(21) = vol_charakteristics(2) / vol_charakteristics(10);//min div objj_po_tez
     vol_charakteristics(22) = vol_charakteristics(3) / vol_charakteristics(10);//min div objj_po_tez

     vol_charakteristics(23) = vol_charakteristics(1) / vol_charakteristics(9);//peak div obj_po_max
     vol_charakteristics(24) = vol_charakteristics(2) / vol_charakteristics(9);//min div objj_po_max
     vol_charakteristics(25) = vol_charakteristics(3) / vol_charakteristics(9);//min div objj_po_max
     

     vol_charakteristics(26) = vol_charakteristics(10) / vol_charakteristics(0); //objm_poteziste div objm
     vol_charakteristics(27) = vol_charakteristics(5) / vol_charakteristics(0); // objmsest _div obj
     vol_charakteristics(28) = 1 - vol_charakteristics(26); //objvzest div obj
     
     vol_charakteristics(29) = charakteristiky(13) ; // ropztyl
     

   /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
}


/**
   * Provede výpočet všech objemovych charakteristik najednou
   */
void charakteristiky_1D::vypocti_comcharakteristiky()
{
 /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
                     
    com_charakteristics(0) = charakteristiky(1) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(1) = charakteristiky(15) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(2) = charakteristiky(16) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(3) = charakteristiky(2) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(4) = charakteristiky(15) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(5) = charakteristiky(16) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(6) = charakteristiky(1) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(7) = charakteristiky(15) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(8) = charakteristiky(16) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(9) = charakteristiky(6) * charakteristiky(10);
    com_charakteristics(10) = charakteristiky(1) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(11) = charakteristiky(15) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(12) = charakteristiky(16) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(13) = charakteristiky(6) * charakteristiky(11);
    com_charakteristics(14) = charakteristiky(3) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(15) = charakteristiky(3) / charakteristiky(8) * charakteristiky(6) / charakteristiky(0);
    com_charakteristics(16) = charakteristiky(3) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(17) = charakteristiky(3) / charakteristiky(8) * charakteristiky(12);
    com_charakteristics(18) = charakteristiky(3) / charakteristiky(8) * charakteristiky(10);
    com_charakteristics(19) = charakteristiky(3) / charakteristiky(8) * charakteristiky(16) / charakteristiky(0);
    com_charakteristics(20) = charakteristiky(5) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(21) = charakteristiky(5) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(22) = charakteristiky(5) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(23) = charakteristiky(5) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(24) = charakteristiky(11) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(25) = charakteristiky(11) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(26) = charakteristiky(11) / charakteristiky(8) * charakteristiky(18) / charakteristiky(0);
    com_charakteristics(27) = charakteristiky(11) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);

   /*              peak_mul_centr_div_obj_div_obj 0, mean_mul_centr_div_obj_div_obj 1, median_centr_div_obj_div_obj 2,\
                   min_mul_peak_div_obj_div_obj 3, mean_mul_peak_div_obj_div_obj 4, median_mul_peak_div_obj_div_obj 5,\
                   peak_mul_centru_div_objvzestp_div_objvzestp 6, mean_mul_cent_div_objvzestp_div_objvzestp 7 , median_centr_div_objvzestp_div_objvzestp 8, centr_mul_objvzestp 9,\
                   peak_mul_centru_div_objsestp_div_objsestp 10, mean_mul_centr_div_objsestp_div_objsestp 11, median_centrdiv_objsestp_div_objsestp 12, centr_mul_objsestp 13,\
                   rtimepeak_rpeakvol 14 , rtimepeak_rcentrvol 15, rtimepeak_rmeanvol 16, rtimepeak_sestvol 17, rtimepeak_vzestvol 18 ,\
                   rtimepeak_rmedianvol 19 , rtimecn_rpeakvol 20, rtimecen_rmeanvol 21, rtimecen_rsestvol 22, rtimecen_rvzestvol 23,\
                   rtimesest_rvzestvol 24 , rtimesest_rsestvol 25 , rtimesest_rcentrvol 26, rtimesest_rpeakvol  27\  */
}


/**
   * Provede výpočet všech objemovych charakteristik najednou
   * @param data
   * @param pocet dat
   */
void charakteristiky_1D::vypocti_comcharakteristiky(double *data, unsigned int Velikost)
{
    vypocti_charakteristiky(data,Velikost);
 /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
                     
    com_charakteristics(0) = charakteristiky(1) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(1) = charakteristiky(15) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(2) = charakteristiky(16) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(3) = charakteristiky(2) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(4) = charakteristiky(15) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(5) = charakteristiky(16) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(6) = charakteristiky(1) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(7) = charakteristiky(15) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(8) = charakteristiky(16) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(9) = charakteristiky(6) * charakteristiky(10);
    com_charakteristics(10) = charakteristiky(1) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(11) = charakteristiky(15) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(12) = charakteristiky(16) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(13) = charakteristiky(6) * charakteristiky(11);
    com_charakteristics(14) = charakteristiky(3) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(15) = charakteristiky(3) / charakteristiky(8) * charakteristiky(6) / charakteristiky(0);
    com_charakteristics(16) = charakteristiky(3) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(17) = charakteristiky(3) / charakteristiky(8) * charakteristiky(12);
    com_charakteristics(18) = charakteristiky(3) / charakteristiky(8) * charakteristiky(10);
    com_charakteristics(19) = charakteristiky(3) / charakteristiky(8) * charakteristiky(16) / charakteristiky(0);
    com_charakteristics(20) = charakteristiky(5) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(21) = charakteristiky(5) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(22) = charakteristiky(5) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(23) = charakteristiky(5) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(24) = charakteristiky(11) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(25) = charakteristiky(11) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(26) = charakteristiky(11) / charakteristiky(8) * charakteristiky(18) / charakteristiky(0);
    com_charakteristics(27) = charakteristiky(11) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);

   /*              peak_mul_centr_div_obj_div_obj 0, mean_mul_centr_div_obj_div_obj 1, median_centr_div_obj_div_obj 2,\
                   min_mul_peak_div_obj_div_obj 3, mean_mul_peak_div_obj_div_obj 4, median_mul_peak_div_obj_div_obj 5,\
                   peak_mul_centru_div_objvzestp_div_objvzestp 6, mean_mul_cent_div_objvzestp_div_objvzestp 7 , median_centr_div_objvzestp_div_objvzestp 8, centr_mul_objvzestp 9,\
                   peak_mul_centru_div_objsestp_div_objsestp 10, mean_mul_centr_div_objsestp_div_objsestp 11, median_centrdiv_objsestp_div_objsestp 12, centr_mul_objsestp 13,\
                   rtimepeak_rpeakvol 14 , rtimepeak_rcentrvol 15, rtimepeak_rmeanvol 16, rtimepeak_sestvol 17, rtimepeak_vzestvol 18 ,\
                   rtimepeak_rmedianvol 19 , rtimecn_rpeakvol 20, rtimecen_rmeanvol 21, rtimecen_rsestvol 22, rtimecen_rvzestvol 23,\
                   rtimesest_rvzestvol 24 , rtimesest_rsestvol 25 , rtimesest_rcentrvol 26, rtimesest_rpeakvol  27\  */
}



/**
   * Provede výpočet všech objemovych charakteristik najednou
   * @param colvec dat
   */
void charakteristiky_1D::vypocti_comcharakteristiky(colvec data)
{
        vypocti_charakteristiky(data);
 /*        Objem 0, Max 1, Min 2, Cas_max 3, Cas_min 4,  \
                    X_teziste 5, Y_teziste 6, Cas_teziste_konec 7,  \
                    Trvani 8, Cas_vzestup 9, Objem_vzestup 10, Cas_sestup 11, \
                    Objem_sestup 12, Rozptyl 13, Stdev 14, Mean 15, Median 16, \
                    Objem_po_max 17, Objem_po_teziste 18, Cas_PUL_OBJ 19   */
                     
    com_charakteristics(0) = charakteristiky(1) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(1) = charakteristiky(15) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(2) = charakteristiky(16) * charakteristiky(6) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(3) = charakteristiky(2) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(4) = charakteristiky(15) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(5) = charakteristiky(16) * charakteristiky(1) / charakteristiky(0) / charakteristiky(0);
    com_charakteristics(6) = charakteristiky(1) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(7) = charakteristiky(15) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(8) = charakteristiky(16) * charakteristiky(6) / charakteristiky(10) / charakteristiky(10);
    com_charakteristics(9) = charakteristiky(6) * charakteristiky(10);
    com_charakteristics(10) = charakteristiky(1) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(11) = charakteristiky(15) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(12) = charakteristiky(16) * charakteristiky(6) / charakteristiky(11) / charakteristiky(11);
    com_charakteristics(13) = charakteristiky(6) * charakteristiky(11);
    com_charakteristics(14) = charakteristiky(3) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(15) = charakteristiky(3) / charakteristiky(8) * charakteristiky(6) / charakteristiky(0);
    com_charakteristics(16) = charakteristiky(3) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(17) = charakteristiky(3) / charakteristiky(8) * charakteristiky(12);
    com_charakteristics(18) = charakteristiky(3) / charakteristiky(8) * charakteristiky(10);
    com_charakteristics(19) = charakteristiky(3) / charakteristiky(8) * charakteristiky(16) / charakteristiky(0);
    com_charakteristics(20) = charakteristiky(5) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);
    com_charakteristics(21) = charakteristiky(5) / charakteristiky(8) * charakteristiky(15) / charakteristiky(0);
    com_charakteristics(22) = charakteristiky(5) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(23) = charakteristiky(5) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(24) = charakteristiky(11) / charakteristiky(8) * charakteristiky(10) / charakteristiky(0);
    com_charakteristics(25) = charakteristiky(11) / charakteristiky(8) * charakteristiky(12) / charakteristiky(0);
    com_charakteristics(26) = charakteristiky(11) / charakteristiky(8) * charakteristiky(18) / charakteristiky(0);
    com_charakteristics(27) = charakteristiky(11) / charakteristiky(8) * charakteristiky(1) / charakteristiky(0);

   /*              peak_mul_centr_div_obj_div_obj 0, mean_mul_centr_div_obj_div_obj 1, median_centr_div_obj_div_obj 2,\
                   min_mul_peak_div_obj_div_obj 3, mean_mul_peak_div_obj_div_obj 4, median_mul_peak_div_obj_div_obj 5,\
                   peak_mul_centru_div_objvzestp_div_objvzestp 6, mean_mul_cent_div_objvzestp_div_objvzestp 7 , median_centr_div_objvzestp_div_objvzestp 8, centr_mul_objvzestp 9,\
                   peak_mul_centru_div_objsestp_div_objsestp 10, mean_mul_centr_div_objsestp_div_objsestp 11, median_centrdiv_objsestp_div_objsestp 12, centr_mul_objsestp 13,\
                   rtimepeak_rpeakvol 14 , rtimepeak_rcentrvol 15, rtimepeak_rmeanvol 16, rtimepeak_sestvol 17, rtimepeak_vzestvol 18 ,\
                   rtimepeak_rmedianvol 19 , rtimecn_rpeakvol 20, rtimecen_rmeanvol 21, rtimecen_rsestvol 22, rtimecen_rvzestvol 23,\
                   rtimesest_rvzestvol 24 , rtimesest_rsestvol 25 , rtimesest_rcentrvol 26, rtimesest_rpeakvol  27\  */
}

 /**
   * Provede výpočet všech charakteristik najednou
   * @param data 1D
   */
void charakteristiky_1D::prevede_jednotky(double pom_prevod, bool suma_je_vyska_obj)
{
    data_1D = pom_prevod*data_1D;
    suma_je_objem_vyska = suma_je_vyska_obj;
}
