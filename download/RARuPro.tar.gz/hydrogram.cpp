#include "hydrogram.h"

hydrogram::hydrogram()
{
    pocet_charakteristik = 20;
    charakteristiky.set_size(pocet_charakteristik);
    charakteristiky.fill(999999.9);
    pocet_time_char = 22;
    time_charakteristics.set_size(pocet_time_char);
    time_charakteristics.fill(999999.9);
    pocet_vol_char = 30;
    vol_charakteristics.set_size(pocet_vol_char);
    vol_charakteristics.fill(999999.9);
    pocet_comchar = 28;
    com_charakteristics.set_size(pocet_comchar);
    com_charakteristics.fill(999999.99);
    velikost = 0;
    prevod_jednotek = 1;
    pocatek_konec = false;
    pocatek = 0;
    konec = 0;
    data_1D.set_size(velikost);
    for (int hd = 0; hd <7; hd++ ){
       typ_hydrogramu[hd] = false;
       }
}

hydrogram::hydrogram(const hydrogram& puvodni)
{
  pocatek = puvodni.pocatek;
  konec = puvodni.konec;
  pocatek_konec = puvodni.pocatek_konec;

  prevod_jednotek = puvodni.prevod_jednotek;

  pocet_charakteristik = puvodni.pocet_charakteristik;
  charakteristiky = puvodni.charakteristiky;

  pocet_time_char = puvodni.pocet_time_char;
  time_charakteristics = puvodni.time_charakteristics;
  
  pocet_vol_char = puvodni.pocet_vol_char;
  vol_charakteristics = puvodni.vol_charakteristics;
  
  pocet_comchar = puvodni.pocet_comchar;
  com_charakteristics = puvodni.com_charakteristics;

  velikost = puvodni.velikost;
  data_1D = puvodni.data_1D;
  for (int hd =0; hd <7; hd ++ ){
                typ_hydrogramu[hd] = puvodni.typ_hydrogramu[hd];
   }
   suma_je_objem_vyska = puvodni.suma_je_objem_vyska;
}

hydrogram& hydrogram::operator=(hydrogram& puvodni)
{
    if(this != &puvodni){
             pocatek = puvodni.pocatek;
             konec = puvodni.konec;
             pocatek_konec = puvodni.pocatek_konec;

             prevod_jednotek = puvodni.prevod_jednotek;

             pocet_charakteristik = puvodni.pocet_charakteristik;
             charakteristiky.set_size(pocet_charakteristik);
             charakteristiky = puvodni.charakteristiky;
                     
             pocet_time_char = puvodni.pocet_time_char;
             time_charakteristics.set_size(pocet_time_char);
             time_charakteristics = puvodni.time_charakteristics;
             
             pocet_vol_char = puvodni.pocet_vol_char;
             vol_charakteristics.set_size(pocet_vol_char);
             vol_charakteristics = puvodni.vol_charakteristics;
             
             pocet_comchar = puvodni.pocet_comchar;
             com_charakteristics.set_size(pocet_comchar);
             com_charakteristics = puvodni.com_charakteristics;
                          
             velikost = puvodni.velikost;
             data_1D.set_size(velikost);
             data_1D = puvodni.data_1D;
             
             for (int hd =0; hd <7; hd ++ ){
                typ_hydrogramu[hd] = puvodni.typ_hydrogramu[hd];
               }
            suma_je_objem_vyska = puvodni.suma_je_objem_vyska;
     }
    return *this;
}

hydrogram::~hydrogram()
{
    charakteristiky.reset();
    time_charakteristics.reset();
    vol_charakteristics.reset();
    com_charakteristics.reset();
    data_1D.reset();
}

/**
 * Vypíše charakteristiky do souboru
 * @param jméno souboru
 */
void hydrogram::vypis_hydrogram(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis hydrogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int h = 0; h < velikost; h++)
  	proud << data_1D(h) << "\n";
  proud.close();
}

/**
 * Načte data pro hydrogram ze souboru ktery obsahuje data hydrogramu v označeném sloupci
 * @param název souboru s daty
 * @param označení sloupce obsahujího odtoková data
 * @param pocet sloupců v souboru v jednom řádku
 * @param kontrola jednotek
 */
void hydrogram::nacti_data_hydrogramu(string nazev_souboru, bool suma_je_vyska_obj, unsigned int Q_sloupec,unsigned int pocet_sloupcu)
{
     string odpad;

     unsigned int pocet_radku = 0, velikost_filetu = 0;

     ifstream myfile (nazev_souboru.c_str());

  if (myfile.is_open()) {
    while (! myfile.eof() ) {
      getline (myfile,odpad);
      pocet_radku++;
    }
      velikost = pocet_radku-1;
      data_1D.set_size(velikost);
      velikost_filetu = myfile.tellg();
   //   cout << velikost_filetu << "\n";
      myfile.clear();
      myfile.seekg(0, ios::beg);
      for (unsigned int rad = 0; rad < velikost; rad++ ) {
             for (unsigned int sl = 0; sl < pocet_sloupcu; sl++ ) {
          	     if (sl == Q_sloupec-1)  myfile >> data_1D(rad);
          	        else myfile >> odpad;
              }
      }
    myfile.close();
    }  else { cout << "Chyba v otevreni souboru hydrogramu " << nazev_souboru.c_str() << "\n";
    exit(EXIT_FAILURE);
    }

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska = suma_je_vyska_obj;

}

/**
 * Přiřadí data z libovolného pole o dané velikosti do data_1D
 * @param průtoková data k přiřazení
 * @param velikost pole
 * @param informace o prevadenych jednotkach 
 */
void hydrogram::prirad_hydrogram_data(double *Q_data, unsigned int Q_size, bool pom_suma_je_objem_vyska)
{
    if (Q_size < 1) {
        cout << "\n Velikost dat v prirazovanem hydrogramu musi byt vetsi nez 0.\n";
        exit(EXIT_FAILURE);
       } else {
           
    velikost  = Q_size;

    data_1D.set_size(velikost);

    for (unsigned int prut = 0; prut < velikost; prut++){
    	data_1D(prut) = Q_data[prut];
         }

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska = pom_suma_je_objem_vyska;
    }
}

/**
 * Přiřadí data z libovolného pole o dané velikosti do data_1D
 * @param průtoková data k přiřazení
 * @param velikost pole
 * @param informace o prevadenych jednotkach 
 */
void hydrogram::prirad_hydrogram_data(colvec Q_data, bool pom_suma_je_objem_vyska)
{
    if (Q_data.n_elem < 1) {
        cout << "\n Velikost dat v prirazovanem hydrogramu musi byt vetsi nez 0.\n";
        exit(EXIT_FAILURE);
       } else {
           
    velikost  = Q_data.n_elem;
   	data_1D = Q_data;
    pocatek = 1;
    konec = velikost;
    pocatek_konec = true;
    suma_je_objem_vyska = pom_suma_je_objem_vyska;
    }
}


