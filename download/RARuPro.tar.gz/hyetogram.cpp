#include "hyetogram.h"

hyetogram::hyetogram()
{
    pocet_charakteristik = 20;
    charakteristiky.set_size(pocet_charakteristik);
    charakteristiky.fill(999999.9);
    pocet_time_char = 22;
    time_charakteristics.set_size(pocet_time_char);
    time_charakteristics.fill(999999.9);
    pocet_vol_char = 30;
    vol_charakteristics.set_size(pocet_vol_char);
    vol_charakteristics.fill(999999.9);
    pocet_comchar = 28;
    com_charakteristics.set_size(pocet_comchar);
    com_charakteristics.fill(999999.99);
    velikost = 0;
    prevod_jednotek = 1;
    pocatek_konec = false;
    pocatek = 0;
    konec = 0;
    data_1D.set_size(velikost);
    for (int hd = 0; hd <7; hd++ ){
       typ_hyetogramu[hd] = false;
       }
}


hyetogram::hyetogram(const hyetogram& puvodni)
{
  pocatek = puvodni.pocatek;
  konec = puvodni.konec;
  pocatek_konec = puvodni.pocatek_konec;

  prevod_jednotek = puvodni.prevod_jednotek;

  pocet_charakteristik = puvodni.pocet_charakteristik;
  charakteristiky = puvodni.charakteristiky;
  
  velikost = puvodni.velikost;
  
  pocet_time_char = puvodni.pocet_time_char;
  time_charakteristics = puvodni.time_charakteristics;
  
  pocet_vol_char = puvodni.pocet_vol_char;
  vol_charakteristics = puvodni.vol_charakteristics;
  
  pocet_comchar = puvodni.pocet_comchar;
  com_charakteristics = puvodni.com_charakteristics;
  
  data_1D = puvodni.data_1D;
  for (int hd =0; hd <7; hd ++ ){
                typ_hyetogramu[hd] = puvodni.typ_hyetogramu[hd];
   }
   suma_je_objem_vyska = puvodni.suma_je_objem_vyska;
}

hyetogram& hyetogram::operator=(hyetogram& puvodni)
{
    if(this != &puvodni){
             pocatek = puvodni.pocatek;
             konec = puvodni.konec;
             pocatek_konec = puvodni.pocatek_konec;

             prevod_jednotek = puvodni.prevod_jednotek;

             pocet_charakteristik = puvodni.pocet_charakteristik;
             charakteristiky.set_size(pocet_charakteristik);
             charakteristiky = puvodni.charakteristiky;
             
             pocet_time_char = puvodni.pocet_time_char;
             time_charakteristics.set_size(pocet_time_char);
             time_charakteristics = puvodni.time_charakteristics;
             
             pocet_vol_char = puvodni.pocet_vol_char;
             vol_charakteristics.set_size(pocet_vol_char);
             vol_charakteristics = puvodni.vol_charakteristics;
             
             pocet_comchar = puvodni.pocet_comchar;
             com_charakteristics.set_size(pocet_comchar);
             com_charakteristics = puvodni.com_charakteristics;
                          
             velikost = puvodni.velikost;
             data_1D.set_size(velikost);
             data_1D = puvodni.data_1D;
             
             for (int hd =0; hd <7; hd ++ ){
                typ_hyetogramu[hd] = puvodni.typ_hyetogramu[hd];
               }
            suma_je_objem_vyska = puvodni.suma_je_objem_vyska;
     }
    return *this;
}

hyetogram::~hyetogram()
{
    charakteristiky.reset();
    time_charakteristics.reset();
    vol_charakteristics.reset();
    com_charakteristics.reset();
    data_1D.reset();
}

/**
 * Vypíše charakteristiky do souboru
 * @param jméno souboru
 */
void hyetogram::vypis_hyetogram(string nazev_souboru)
{
  ofstream proud(nazev_souboru.c_str(), ios::app);
  if (!proud) {
    cout << "\nNeexistuje soubor pro vypis hyetogramu - " << nazev_souboru;
    exit(0);
  }
  for (unsigned int h = 0; h < velikost; h++)
  	proud << data_1D(h) << "\n";
  proud.close();
}

/**
 * Načte data pro hydrogram ze souboru ktery obsahuje data hydrogramu v označeném sloupci
 * @param název souboru s daty
 * @param označení sloupce obsahujího odtoková data
 * @param pocet sloupců v souboru v jednom řádku
 * @param kontrola jednotek
 */
void hyetogram::nacti_data_hyetogramu(string nazev_souboru, bool suma_je_vyska_obj, unsigned int P_sloupec,unsigned int pocet_sloupcu)
{
     string odpad;

     unsigned int pocet_radku = 0, velikost_filetu = 0;

     ifstream myfile (nazev_souboru.c_str());

  if (myfile.is_open()) {
    while (! myfile.eof() ) {
      getline (myfile,odpad);
      pocet_radku++;
    }
      velikost = pocet_radku-1;
      data_1D.set_size(velikost);
      velikost_filetu = myfile.tellg();
   //   cout << velikost_filetu << "\n";
      myfile.clear();
      myfile.seekg(0, ios::beg);
      for (unsigned int rad = 0; rad < velikost; rad++ ) {
             for (unsigned int sl = 0; sl < pocet_sloupcu; sl++ ) {
          	     if (sl == P_sloupec-1)  myfile >> data_1D(rad);
          	        else myfile >> odpad;
              }
      }
    myfile.close();
    }  else { cout << "Chyba v otevreni souboru s daty hyetogramu " << nazev_souboru.c_str() << "\n";
    exit(EXIT_FAILURE);
    }

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska = suma_je_vyska_obj;

}

/**
 * Přiřadí data z libovolného pole o dané velikosti do data_1D
 * @param srážková data k přiřazení
 * @param velikost pole
 */
void hyetogram::prirad_hyetogram_data(double *P_data, unsigned int P_size, bool pom_suma_je_objem_vyska)
{
    if (P_size < 1) {
        cout << "\n Velikost dat v prirazovanem hyetogramu musi byt vetsi nez 0.\n";
        exit(EXIT_FAILURE);
       } else {
           
    velikost  = P_size;

    data_1D.set_size(velikost);

    for (unsigned int sraz = 0; sraz < velikost; sraz++){
    	data_1D(sraz) = P_data[sraz];
         }

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska = pom_suma_je_objem_vyska;
     
    }
}

/**
 * Přiřadí data z libovolného pole o dané velikosti do data_1D
 * @param průtoková data k přiřazení
 * @param velikost pole
 */
void hyetogram::prirad_hyetogram_data(colvec P_data, bool pom_suma_je_objem_vyska)
{
    if (P_data.n_elem < 1) {
        cout << "\n Velikost dat v prirazovanem hyetogramu musi byt vetsi nez 0.\n";
        exit(EXIT_FAILURE);
       } else {
           
    velikost  = P_data.n_elem;

    data_1D.set_size(velikost);
    data_1D= P_data;
     

     pocatek = 1;
     konec = velikost;
     pocatek_konec = true;
     suma_je_objem_vyska = pom_suma_je_objem_vyska;
     
    }
}

