#ifndef HYETOGRAM_H
#define HYETOGRAM_H

#include "charakteristiky_1d.h"

using namespace std;
using namespace arma;

class hyetogram: public charakteristiky_1D
{
    public:

        enum {navrhovy, kalibracni, validacni, \
                     udalost, casova_rada, ensemble,efektivni} index_typu_hyetogramu;//!< Specifikace hyetogramů
        
        bool typ_hyetogramu[7];
        /**
         * Časové charakteristiky, indexaci je nutné zadávat necéčkovsky
         */
        void prirad_hyetogram_data(double *Q_data, unsigned int Q_size, bool pom_suma_je_objem_vyska);//!< Přiřadí data do pro proměnné data_1D
        void prirad_hyetogram_data(colvec P_data, bool pom_suma_je_objem_vyska);//!< Přiřadí data do pro proměnné data_1D
        void vypis_hyetogram(string nazev_souboru);//!< Vypíše hyetogram do souboru
        void nacti_data_hyetogramu(string nazev_souboru, bool suma_je_vyska_obj,  unsigned int Q_sloupec=1, unsigned int pocet_sloupcu =1);//!< Načte data do data_1D
  
        hyetogram();
        ~hyetogram();
        hyetogram(int tp_hyetogramu,  double *P_data, unsigned int P_size, bool poc_kon, unsigned int poc, unsigned int kon, double pre_jed, bool sum_je_vyska_obj) : charakteristiky_1D(P_data, P_size, poc_kon, poc, kon, pre_jed, sum_je_vyska_obj)
        {
            pocet_charakteristik = 20;
            charakteristiky.set_size(pocet_charakteristik);
            charakteristiky.fill(999999.9);
            pocet_time_char = 22;
            time_charakteristics.set_size(pocet_time_char);
            time_charakteristics.fill(999999.9);
            pocet_vol_char = 30;
            vol_charakteristics.set_size(pocet_vol_char);
            vol_charakteristics.fill(999999.9);
            pocet_comchar = 28;
            com_charakteristics.set_size(pocet_comchar);
            com_charakteristics.fill(999999.99);
            prevod_jednotek = pre_jed;
            pocatek_konec = poc_kon;
            for (int hd = 0; hd <7; hd++ ){
                    typ_hyetogramu[hd] = false;
                    if (hd == tp_hyetogramu) typ_hyetogramu[hd] = true;
                }

           if (pocatek_konec) {
                if (poc < 1) {
                    cout << "Spatne zadany pocatek hydrogramu: musi byt vetsi nez 0." << "\n";
                    exit(EXIT_FAILURE);
                          }
              pocatek = poc;
              if (kon < poc) {
                    cout << "Spatne zadany konec hydrogramu: musi byt vetsi nez pocatek." << "\n";
                    exit(EXIT_FAILURE);
                          }
              konec = kon;
              velikost = konec - pocatek + 1;
              if (P_size < velikost) {
                    cout << "Spatne zadana data pro pripravu hydrogramu: velikost originalnich dat musi byt vetsi nez rozsah zadaneho pocatku a konce." << "\n";
                    exit(EXIT_FAILURE);
                          }
              } else {
                konec = P_size;
                pocatek = 1;
                velikost = P_size;
                            }
            data_1D.set_size(velikost);
            unsigned long i = 0;
            for (unsigned long sraz = pocatek-1; sraz< konec; sraz++ ) {
                        data_1D(i) = prevod_jednotek * P_data[sraz];
      	                i++;
                     }
            suma_je_objem_vyska = sum_je_vyska_obj;
          };        

        hyetogram(const hyetogram& puvodni);
        hyetogram& operator=(hyetogram& puvodni);
};


#endif // HYETOGRAM_H
