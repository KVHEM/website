#ifndef HYDROGRAM_H
#define HYDROGRAM_H

#include <iostream>
#include <armadillo>

#include "charakteristiky_1d.h"

using namespace std;
using namespace arma;

/**
 * Třída hydrogramu
 */
class hydrogram: public charakteristiky_1D
{
    public:

        enum {navrhovy, kalibracni, validacni, \
                     udalost, casova_rada, ensemble,primy} index_typu_hydrogramu;//!< Specifikace hydrogramů
        
        bool typ_hydrogramu[7];
        /**
         * Časové charakteristiky, indexaci je nutné zadávat necéčkovsky
         */
        void prirad_hydrogram_data(double *Q_data, unsigned int Q_size, bool pom_suma_je_objem_vyska);//!< Přiřadí data do pro proměnné data_1D
        void prirad_hydrogram_data(colvec Q_data, bool pom_suma_je_objem_vyska);//!< Přiřadí data do pro proměnné data_1D
        void vypis_hydrogram(string nazev_souboru);//!< Vypíše data_1D do souboru
        void nacti_data_hydrogramu(string nazev_souboru, bool suma_je_vyska_obj,  unsigned int Q_sloupec=1, unsigned int pocet_sloupcu =1);//!< Načte data do data_1D

        hydrogram();
        hydrogram(int tp_hydrogramu,  double *Q_data, unsigned int Q_size, bool poc_kon, unsigned int poc, unsigned int kon, double pre_jed, bool sum_je_vyska_obj) : charakteristiky_1D(Q_data, Q_size, poc_kon, poc, kon, pre_jed, sum_je_vyska_obj)
        {
            pocet_charakteristik = 20;
            charakteristiky.set_size(pocet_charakteristik);
            pocet_time_char = 22;
            time_charakteristics.set_size(pocet_time_char);
            time_charakteristics.fill(999999.9);
            pocet_vol_char = 30;
            vol_charakteristics.set_size(pocet_vol_char);
            vol_charakteristics.fill(999999.9);
            pocet_comchar = 28;
            com_charakteristics.set_size(pocet_comchar);
            com_charakteristics.fill(999999.99);            
            prevod_jednotek = pre_jed;
            pocatek_konec = poc_kon;
            for (int hd = 0; hd <7; hd++ ){
                    typ_hydrogramu[hd] = false;
                    if (hd == tp_hydrogramu) typ_hydrogramu[hd] = true;
                }

  if (pocatek_konec) {
      if (poc < 1) {
             cout << "Spatne zadany pocatek hydrogramu: musi byt vetsi nez 0." << "\n";
             exit(EXIT_FAILURE);
           }
           pocatek = poc;
      if (kon < poc) {
             cout << "Spatne zadany konec hydrogramu: musi byt vetsi nez pocatek." << "\n";
             exit(EXIT_FAILURE);
           }
           konec = kon;
           velikost = konec - pocatek + 1;
      if (Q_size < velikost) {
             cout << "Spatne zadana data pro pripravu hydrogramu: velikost originalnich dat musi byt vetsi nez rozsah zadaneho pocatku a konce." << "\n";
             exit(EXIT_FAILURE);
           }
        } else {
           konec = Q_size;
           pocatek = 1;
           velikost = Q_size;
        }

        data_1D.set_size(velikost);

          unsigned long i = 0;
          for (unsigned long prut = pocatek-1; prut < konec; prut++ ) {
    	                  data_1D(i) = prevod_jednotek * Q_data[prut];
    	                  i++;
                         }
            suma_je_objem_vyska = sum_je_vyska_obj;
        }
                
        hydrogram(const hydrogram& puvodni);
        hydrogram& operator=(hydrogram& puvodni);
        ~hydrogram();

    protected:
    private:
};

#endif // HYDROGRAM_H
