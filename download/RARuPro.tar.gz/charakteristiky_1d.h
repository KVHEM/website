#ifndef CHARAKTERISTIKY_1D_H
#define CHARAKTERISTIKY_1D_H

#include <iostream>
#include <armadillo>

using namespace std;
using namespace arma;

/**
  * Třída základních charakteristik 1D pole
  */
class charakteristiky_1D
{
    public:
        charakteristiky_1D();
        charakteristiky_1D(double *data_1D_d, unsigned int data_size, bool poc_kon, unsigned int poc, unsigned int kon, double pre_jed, bool sum_je_vyska_obj);
        ~charakteristiky_1D();
        charakteristiky_1D(const charakteristiky_1D& other);
        charakteristiky_1D& operator=(const charakteristiky_1D& other);
  
          /**
           * Popis charakteristik 1D pole
           */       
        enum {Objem, Max, Min, Cas_max, Cas_min,  \
                    X_teziste, Y_teziste, Cas_teziste_konec,  \
                    Trvani, Cas_vzestup, Objem_vzestup, Cas_sestup, \
                    Objem_sestup, Rozptyl, Stdev, Mean, Median, \
                    Objem_po_max, Objem_po_teziste, Cas_PUL_OBJ} nazev_charakteristiky;//!< Specifikace charakteristik 1D pole (20 clenu)
        
        unsigned int pocet_charakteristik;//!< Počet charakteristik
        colvec charakteristiky;//!< Hodnoty charakteristik 1D pole
        
        enum {Cas_Max, Cas_Min, Cas_Teziste, Cas_Teziste_konec, \
                     Cele_Trvani, Cas_Vzestup, Cas_Sestup, Cas_pulObj, \
                     Casmax_Trvani, Casmin_Trvani, Casteziste_Trvani, Castezistekonec_Trvani, \
                     Casvzes_Trvani, Cassestup_Trvani, Caspul_trvani, \
                     rCasmax_Trvani, rCasmin_Trvani, rCasteziste_Trvani, rCastezistekonec_Trvani, \
                     rCasvzes_Trvani, rCassestup_Trvani, rCaspul_trvani \
                  } time_characteristics;//!< Specifikace časových charakteristik 1D pole( 22 clenů)
        
        unsigned int pocet_time_char;//!< Počet casovych charakteristik
        colvec time_charakteristics;//!< Hodnoty časových charakteristik 1D pole
        
        enum {
                     vyskaobj, Peak, mIN, Teziste, \
                     objem_vzestup, objem_sest, sttdev, \
                     arprum, mediaN, objempomax,objempoteziste, \
                     peak_vol, min_vol, teziste_vol, \
                     peak_objvzest,min_obj_vzest, teziste_objvzest, \
                     peak_objsest, min_objsest, teziste_objsest, \
                     peak_objpoteziste, min_objpoteziste,teziste_objpoteziste, \
                     peak_objpomax, min_objpomax, teziste_objmpomax, \
                     objmpoteziste_objm, objsest_objm, obvzest_objm, rozptyl     }vol_characteristics;//!< Specifikace objemových charakteristik 1D pole(30 clenů)
        
        unsigned int pocet_vol_char;//!< Počet objemovych charakteristik
        colvec vol_charakteristics;//!< Hodnoty  objemových charakteristik 1D pole
        
        enum{
                   peak_mul_centr_div_obj_div_obj, mean_mul_centr_div_obj_div_obj, median_centr_div_obj_div_obj,\
                   min_mul_peak_div_obj_div_obj, mean_mul_peak_div_obj_div_obj, median_mul_peak_div_obj_div_obj,\
                   peak_mul_centru_div_objvzestp_div_objvzestp, mean_mul_cent_div_objvzestp_div_objvzestp, median_centr_div_objvzestp_div_objvzestp, centr_mul_objvzestp,\
                   peak_mul_centru_div_objsestp_div_objsestp, mean_mul_centr_div_objsestp_div_objsestp, median_centrdiv_objsestp_div_objsestp, centr_mul_objsestp,\
                   rtimepeak_rpeakvol, rtimepeak_rcentrvol, rtimepeak_rmeanvol, rtimepeak_sestvol, rtimepeak_vzestvol,\
                   rtimepeak_rmedianvol, rtimecn_rpeakvol, rtimecen_rmeanvol, rtimecen_rsestvol, rtimecen_rvzestvol,\
                   rtimesest_rvzestvol, rtimesest_rsestvol, rtimesest_rcentrvol, rtimesest_rpeakvol
                   }comb_characteristics;//!< Specifikace objemových charakteristik 1D pole(28 clenů)
        

        unsigned int pocet_comchar;//!< Pocet kombinovanych charakteristik (28 clenu)
        colvec com_charakteristics;//!< Hodnoty kobimovaných charakteristik 1D pole

        unsigned int pocatek;//!< Index počátku úseku dat
        unsigned int konec;//!< Index konce úseku dat
        bool pocatek_konec;//!< Potvrzení zadání konce a počátku úseku vyhodnocovaných dat
        
        double prevod_jednotek;//!< Konstanta pro převod jednotek
        bool suma_je_objem_vyska;//!< Zda je prevod jednotek na mm
        
        unsigned int velikost;//!< Velikost 1D dat        
        colvec data_1D;//!< Vyhodnocovaná data
        
         /**
          * Členské funkce řešící odhad charakteristik 1D dat, přetíženy
          */
        double Objem_1Ddat();//!< Stanoví objem 1Ddat
        double Objem_1Ddat(double *data, unsigned int Velikost);//!< Stanoví objem 1Ddat
        double Objem_1Ddat(colvec data);//!< Stanoví objem 1Ddat

        double Max_1Ddat();//!< Stanoví kulminaci 1Ddat
        double Max_1Ddat(double *data, unsigned int Velikost);//!< Stanoví kulminaci 1Ddat
        double Max_1Ddat(colvec data);//!< Stanoví kulminaci 1Ddat
        
        double Min_1Ddat();//!< Stanoví minimum 1Ddat
        double Min_1Ddat(double *data, unsigned int Velikost);//!< Stanoví minimum 1Ddat
        double Min_1Ddat(colvec data);//!< Stanoví minimum 1Ddat
        
        double Cas_max_1Ddat();//!< Stanoví čas výskytu kulminace 1Ddat
        double Cas_max_1Ddat(double *data, unsigned int Velikost);//!< Stanoví čas výskytu kulminace 1Ddat
        double Cas_max_1Ddat(colvec data);//!< Stanoví čas výskytu kulminace 1Ddat
        
        double Cas_min_1Ddat();//!< Stanoví čas výskytu minima 1Ddat
        double Cas_min_1Ddat(double *data, unsigned int Velikost);//!< Stanoví čas výskytu minima 1Ddat
        double Cas_min_1Ddat(colvec data);//!< Stanoví čas výskytu minima 1Ddat
        
        double Y_teziste_1Ddat();//!< Stanoví těžiště 1Ddat na vertikální ose
        double Y_teziste_1Ddat(double *data, unsigned int Velikost);//!< Stanoví těžiště 1Ddat na vertikální ose
        double Y_teziste_1Ddat(colvec data);//!< Stanoví těžiště 1Ddat na vertikální ose
        
        double X_teziste_1Ddat();//!< Stanoví čas výskytu těžiště 1Ddat na časové ose
        double X_teziste_1Ddat(double *data, unsigned int Velikost);//!< Stanoví čas výskytu těžiště 1Ddat na časové ose
        double X_teziste_1Ddat(colvec data);//!< Stanoví čas výskytu těžiště 1Ddat na časové ose
        
        double konec_X_teziste_1Ddat();//!< Stanoví dobu mezi těžištěm 1Ddat a jeho koncem
        double konec_X_teziste_1Ddat(double *data, unsigned int Velikost);//!< Stanoví dobu mezi těžištěm 1Ddat a jeho koncem
        double konec_X_teziste_1Ddat(colvec data);//!< Stanoví dobu mezi těžištěm 1Ddat a jeho koncem
        
        double Trvani_1Ddat();//!< Stanoví dobu trvání
        double Trvani_1Ddat(double *data, unsigned int Velikost);//!< Stanoví dobu trvání
        double Trvani_1Ddat(colvec data);//!< Stanoví dobu trvání
        
        double Cas_vzestup_1Ddat();//!< Stanoví dobu vzestupu 1Ddat
        double Cas_vzestup_1Ddat(double *data, unsigned int Velikost);//!< Stanoví dobu vzestupu 1Ddat
        double Cas_vzestup_1Ddat(colvec data);//!< Stanoví dobu vzestupu 1Ddat
        
        double Objem_vzestup_1Ddat();//!< Stanoví objem vzestupné části 1Ddat zohlednuje 1/2 maxima
        double Objem_vzestup_1Ddat(double *data, unsigned int Velikost);//!< Stanoví objem vzestupné části 1Ddat zohlednuje 1/2 maxima
        double Objem_vzestup_1Ddat(colvec data);//!< Stanoví objem vzestupné části 1Ddat zohlednuje 1/2 maxima
        
        double Cas_sestup_1Ddat();//!< Stanoví dobu sestupu 1Ddat
        double Cas_sestup_1Ddat(double *data, unsigned int Velikost);//!< Stanoví dobu sestupu 1Ddat
        double Cas_sestup_1Ddat(colvec data);//!< Stanoví dobu sestupu 1Ddat
        
        double Objem_sestup_1Ddat();//!< Stanoví objem vzestupné části 1Ddat
        double Objem_sestup_1Ddat(double *data, unsigned int Velikost);//!< Stanoví objem vzestupné části 1Ddat
        double Objem_sestup_1Ddat(colvec data);//!< Stanoví objem vzestupné části 1Ddat
        
        double Rozptyl_1Ddat();//!< Stanoví rozptyl 1Ddat
        double Rozptyl_1Ddat(double *data, unsigned int Velikost);//!< Stanoví rozptyl 1Ddat
        double Rozptyl_1Ddat(colvec data);//!< Stanoví rozptyl 1Ddat
        
        double Stddev_1Ddat();//!< Stanoví směrodatnou odchylku 1Ddat
        double Stddev_1Ddat(double *data, unsigned int Velikost);//!< Stanoví směrodatnou odchylku 1Ddat
        double Stddev_1Ddat(colvec data);//!< Stanoví směrodatnou odchylku 1Ddat
        
        double Mean_1Ddat();//!< Stanoví aritmetický průměr 1Ddat
        double Mean_1Ddat(double *data, unsigned int Velikost);//!< Stanoví aritmetický průměr 1Ddat
        double Mean_1Ddat(colvec data);//!< Stanoví aritmetický průměr 1Ddat
        
        double Median_1Ddat();//!< Stanoví medián 1Ddat
        double Median_1Ddat(double *data, unsigned int Velikost);//!< Stanoví medián 1Ddat
        double Median_1Ddat(colvec data);//!< Stanoví medián 1Ddat
        
        double Objem_po_MAX_1Ddat();//!< Stanoví objem po maximum 1Ddat zohlednuje cele maximum
        double Objem_po_MAX_1Ddat(double *data, unsigned int Velikost);//!< Stanoví objem po maximum 1Ddat zohlednuje cele maximum
        double Objem_po_MAX_1Ddat(colvec data);//!< Stanoví objem po maximum 1Ddat zohlednuje cele maximum
 
        double Objem_po_Yteziste_1Ddat();//!< Stanoví objem po teziste 1Ddat
        double Objem_po_Yteziste_1Ddat(double *data, unsigned int Velikost);//!< Stanoví objem po teziste 1Ddat
        double Objem_po_Yteziste_1Ddat(colvec data);//!< Stanoví objem po teziste 1Ddat
        
        double Cas_pul_OBJM();//!< Stanoví čas kdy odteklo pul objem
        double Cas_pul_OBJM(double *data, unsigned int Velikost);//!< Stanoví čas kdy odteklo pul objem
        double Cas_pul_OBJM(colvec data);//!< Stanoví čas kdy odteklo pul objem        
        
        void prirad_1Ddata(double *data, unsigned int data_size, bool suma_je_vyska_obj);//!< Přiřadí data do pro proměnné data_1D
        void prirad_1Ddata(colvec data, unsigned int data_size, bool suma_je_vyska_obj);//!< Přiřadí data do pro proměnné data_1D
        
        void nacti_data_1D(string nazev_souboru,  unsigned int sloupec, unsigned int pocet_sloupcu);//!< Načte data do data_1D
        void vypis_data_1D(string nazev_souboru);//!< Vypíše data_1D do souboru
        
        void vypis_charakteristiky(string nazev_souboru);//!< Vypíše charakteristiky do souboru
        void vypis_time_charakteristiky(string nazev_souboru);//!< Vypíše casove charakteristiky do souboru
        void vypis_vol_charakteristiky(string nazev_souboru);//!< Vypíše objemove charakteristiky do souboru
        void vypis_comb_charakteristiky(string nazev_souboru);//!< Vypíše kombinovane charakteristiky do souboru
        
        void vypocti_charakteristiky();//!< Vypočte charakteristiky
        void vypocti_timecharakteristiky();//!< Vypocte casove charakteristiky
        void vypocti_volcharakteristiky();//!< Vypocte objemove charakteristiky
        void vypocti_comcharakteristiky();//!< Vypocte combinovane charakteristiky
        
        void vypocti_charakteristiky(double *data, unsigned int Velikost);//!< Vypočte charakteristiky
        void vypocti_timecharakteristiky(double *data, unsigned int Velikost);//!< Vypocte casove charakteristiky
        void vypocti_volcharakteristiky(double *data, unsigned int Velikost);//!< Vypocte objemove charakteristiky
        void vypocti_comcharakteristiky(double *data, unsigned int Velikost);//!< Vypocte combinovane charakteristiky
        
        void vypocti_charakteristiky(colvec data);//!< Vypočte charakteristiky
        void vypocti_timecharakteristiky(colvec data);//!< Vypocte casove charakteristiky
        void vypocti_volcharakteristiky(colvec data);//!< Vypocte objemove charakteristiky
        void vypocti_comcharakteristiky(colvec data);//!< Vypocte combinovane charakteristiky
        
        void prevede_jednotky(double pom_prevod, bool suma_je_vyska_obj);//!< převod jednotek
        
    protected:
    private:
};

#endif // CHARAKTERISTIKY_1D_H
